##=============================================================================
## Name:        HWWTruthCommonAnalysisFlags.py
##
## Author:      Karsten Koeneke
## Created:     August 2014
##
## Description: Here, all neccessary job flags that are commonly needed for
##              all Higgs->WW analyzes are defined.
##=============================================================================

__doc__ = """Here, all neccessary job flags for the common aspects of all the Higgs->WW analyzes are defined."""
__version__ = "0.0.1"
__author__  = "Karsten Koeneke <karsten.koeneke@cern.ch>"

from AthenaCommon.JobProperties import JobProperty, JobPropertyContainer
from AthenaCommon.JobProperties import jobproperties

# Import the module that allows to use named units, e.g. GeV
from AthenaCommon.SystemOfUnits import *

# Import the common helper functions
from PhysicsxAODConfig.HWWCommonHelpers import buildContainerNames

# Import ROOT
import PyUtils.RootUtils as ru
ROOT = ru.import_root()

# Import PyCintex to get enums from dictionaries for electron/muon isolation
import cppyy
cppyy.loadDictionary('xAODPrimitivesDict')
IsoEnums = ROOT.xAOD.Iso

# Get muon quality enums
cppyy.loadDictionary('xAODMuonDict')
MuonQualityEnums = ROOT.xAOD.Muon_v1

# Get the egamma enums
# cppyy.loadDictionary('xAODEgammaDict')
# EGammaEnums = ROOT.xAOD.



#=====================================================================
# First define container for the flags
#=====================================================================
class HWWTruthCommonAnalysisFlags(JobPropertyContainer):
    """ The Higgs->WW common truth analysis flag/job property container."""
jobproperties.add_Container(HWWTruthCommonAnalysisFlags)

#short-cut to get the HiggsWWCommonAnalysisFlags container with this one line:
#'from PhysicsxAODConfig.HWWCommonAnalysisFlags import hWWCommon'
#Note that name has to be different to avoid problems with pickle
hWWCommon = jobproperties.HWWTruthCommonAnalysisFlags

#=====================================================================
# Now define each flag and add it to the container
#=====================================================================

class Global(JobProperty):
    """Steer the common aspects of the H->WW analyzes"""
    statusOn             = True
    allowedTypes         = ['bool']
    StoredValue          = True
    logLevel             = 3 # 3=INFO, 2=DEBUG
    do1Lep               = True
    do2Lep               = True
    do3Lep               = True
    do4Lep               = True
    doFakeLep            = False
    inputIsSimulation    = True # This is a default. It will be determined from the input automatically
    inputSimulationType  = "" # This is a default. It will be determined from the input automatically: "FullSim" or "AFII"
    inputIsDAOD          = False # This is a default. It will be determined from the input automatically
    beamEnergy           = 6.5*TeV
    bunchSpacing         = 25 #[ns] The default. If input is 50ns, this will be changed automatically
    doGRLSelection       = True
    grlFileList          = [ "GoodRunsLists/data15_13TeV/20160720/data15_13TeV.periodAllYear_DetStatus-v79-repro20-02_DQDefects-00-02-02_PHYS_StandardGRL_All_Good_25ns.xml",
                             "GoodRunsLists/data16_13TeV/20170215/data16_13TeV.periodAllYear_DetStatus-v88-pro20-21_DQDefects-00-02-04_PHYS_StandardGRL_All_Good_25ns.xml" ]
    grlName              = "PHYS_StandardGRL_All_Good"
    LumiCalcFiles        = [ "GoodRunsLists/data15_13TeV/20160720/physics_25ns_20.7.lumicalc.OflLumi-13TeV-005.root",
                             "GoodRunsLists/data16_13TeV/20170215/physics_25ns_20.7.lumicalc.OflLumi-13TeV-008.root" ]
    doPileupReweighting                  = True
    doGeneratePileupReweightingConfig    = False
    PileupReweightingConfigFiles         = [ "PhysicsxAODConfig/mc15c_v2_defaults.NotRecommended.prw.root" ]
    PileupReweightingDefaultChannel      = 2 # Currently not used in the job options, as recommended
    PileupReweightingDataScaleFactor     = 1./1.09
    PileupReweightingDataScaleFactorUP   = 1.0
    PileupReweightingDataScaleFactorDOWN = 1./1.18
    doP4Systematics      = False
    doEffiSystematics    = False
    doTriggerSelection   = False
    doTriggerMatching    = False
    requireAlgList       = [] # This list will ist the algorithm instance names that everyone needs to add to their requireAlgs output stream
    breakUpAuxContainers = False
    # auxContsToBreakUp    = [ "EventInfoAux.", "AntiKt4PV0TrackJetsAux." ]
    auxContsToBreakUp    = [  ]
    writeLeptonTrackParticles  = False
    writeLeptonCaloClusters    = False
    writeJetCaloClusters       = False
    pass
hWWCommon.add_JobProperty(Global)



class Trigger(JobProperty):
    """Common trigger definitions for all the H->WW analyzes"""
    statusOn                = True
    allowedTypes            = ['bool']
    StoredValue             = True
    triggerMatchPrefix      = "trigMatch_"
    triggerPassPrefix       = "pass_"
    ## Extended list of trigger chains ##
    # muonTriggerList         = [ "HLT_mu20_iloose_L1MU15", "HLT_mu50", "HLT_mu24_iloose_L1MU15", "HLT_mu24_imedium", "HLT_mu26_imedium" ]
    muonTriggerList         = [ "HLT_mu20_iloose_L1MU15", "HLT_mu50", "HLT_mu24_iloose_L1MU15", "HLT_mu24_imedium" ]
    ## List of muon triggers, which will be considered as OR to the selected triggers for the muon trigger efficiency evaluation
    # muonTriggerSFORList     = [ "HLT_mu50" ]
    muonTriggerSFFullList   = [ "HLT_mu20_iloose_L1MU15_OR_HLT_mu50" ]
    diMuonTriggerList       = [ "HLT_mu18_mu8noL1", "HLT_mu22_mu8noL1", "HLT_mu24_mu8noL1" ]
    electronTriggerList     = [ "HLT_e24_lhmedium_iloose_L1EM18VH", "HLT_e24_lhmedium_L1EM20VH", "HLT_e24_lhmedium_L1EM18VH", "HLT_e60_lhmedium", "HLT_e120_lhloose", "HLT_e24_lhtight_iloose_L1EM20VH", "HLT_e26_lhtight_iloose", "HLT_e24_lhmedium_iloose_L1EM20VH" ]
    diElectronTriggerList   = [ "HLT_2e12_lhloose_L12EM10VH", "HLT_2e15_lhloose_L12EM13VH", "HLT_2e17_lhloose" ]
    ## Additional electron-muon trigger chains
    electronMuonTriggerList = [ "HLT_e17_lhloose_mu14", "HLT_e7_lhmedium_mu24" ]
    singleLeptonTriggerList = trigList = muonTriggerList + electronTriggerList
    diLeptonTriggerList     = diMuonTriggerList + diElectronTriggerList + electronMuonTriggerList
    allLeptonTriggerList    = singleLeptonTriggerList + diLeptonTriggerList
    pass
hWWCommon.add_JobProperty(Trigger)



class Electrons(JobProperty):
    """Definitions for the common electrons of all the H->WW analyzes"""
    statusOn            = True
    allowedTypes        = ['bool']
    StoredValue         = True
    inCont              = "TruthElectrons"
    calibCont           = "HWWTruthCalibElectrons"
    calibPreSelCont     = "HWWTruthCalibPreSelElectrons"
    calibPreSelORCont   = "HWWTruthCalibPreSelORElectrons"
    finalCont           = "HWWTruthElectrons"
    preORAllPtSortCont  = "PreORAllPtSort"+finalCont
    finalLeadPtSortCont = "FinalLeadPtSort"+finalCont
    finalAllPtSortCont  = "FinalAllPtSort"+finalCont
    def finalContList(self) :
        """ The names of the final electron containers. This is a list because every
        4-vector systematic variation is stored in its own container. Thus, we
        are building the list of all these containers using a helper function."""
        return buildContainerNames(baseName=self.finalCont, systList=hWWCommon.Electrons.p4Systs)

    p4Systs                 = ["EG_RESOLUTION_ALL__1down","EG_RESOLUTION_ALL__1up",
                               "EG_SCALE_ALL__1down","EG_SCALE_ALL__1up"]

    # Isolation working points to use for lepton flagging
    isoWorkingPointList  = ["LooseTrackOnly", "Loose", "Tight", "GradientLoose", "Gradient",
                            "FixedCutTight", "FixedCutTightTrackOnly", "FixedCutLoose" ]
    passIsoVarNameList   = [ "passIso"+wpName for wpName in isoWorkingPointList ]

    # Now come the pre-selection cuts
    class preSelection(object):
        #cutObjectQualityMask       = xAOD::BADCLUSELECTRON
        cutObjectQualityMask       = 1
        cutPtMin                   = 10.0*GeV
        cutAbsEtaMax               = 2.47
        #cutAbsEtaCrackMin          = 1.37
        #cutAbsEtaCrackMax          = 1.52
        cutIDList                  = [ ]
        cutIDPtMinList             = [ 0.0*GeV ]
        removeSelfOverlap          = True
        cutZ0SinThetaMax           = 0.5
        cutD0SignificanceMax       = 5.0
        pass

    # The following cuts are NOT used in the pre-selection
    cutObjectQualityMask       = 1
    cutPtMin                   = 15.0*GeV
    cutLeadPtMin               = 22.0*GeV
    cutAbsEtaMax               = 2.47
    cutAbsEtaCrackMin          = 1.37
    cutAbsEtaCrackMax          = 1.52
    # cutIDList                  = [ "isLHTight", "isLHMedium" ]
    # cutIDPtMinList             = [ 10.0*GeV, 25.0*GeV ]
    cutIDList                  = [  ]
    cutIDPtMinList             = [ 0.0*GeV]
    cutZ0SinThetaMax           = 0.5
    cutD0SignificanceMax       = 5.0
    removeSelfOverlap          = True
    pass
hWWCommon.add_JobProperty(Electrons)




class Muons(JobProperty):
    """Definitions for the common muons of all the H->WW analyzes"""
    statusOn            = True
    allowedTypes        = ['bool']
    StoredValue         = True
    inCont              = "TruthMuons"
    calibCont           = "HWWTruthCalibMuons"
    calibPreSelCont     = "HWWTruthCalibPreSelMuons"
    calibPreSelORCont   = "HWWTruthCalibPreSelORMuons"
    finalCont           = "HWWTruthMuons"
    preORAllPtSortCont  = "PreORAllPtSort"+finalCont
    finalLeadPtSortCont = "FinalLeadPtSort"+finalCont
    finalAllPtSortCont  = "FinalAllPtSort"+finalCont
    def finalContList(self) :
        """ The names of the final muon containers. This is a list because every
        4-vector systematic variation is stored in its own container. Thus, we
        are building the list of all these containers using a helper function."""
        return buildContainerNames(baseName=self.finalCont, systList=hWWCommon.Muons.p4Systs)

    p4Systs              = [ "MUONS_ID__1down", "MUONS_ID__1up",
                             "MUONS_MS__1down", "MUONS_MS__1up",
                             "MUONS_SCALE__1down", "MUONS_SCALE__1up" ]

    # Isolation working points to use for lepton flagging
    isoWorkingPointList  = ["LooseTrackOnly", "Loose", "Tight", "GradientLoose",
                            "Gradient", "FixedCutTightTrackOnly", "FixedCutLoose" ]
    passIsoVarNameList   = [ "passIso"+wpName for wpName in isoWorkingPointList ]
    effiTrigVarNameList  = []
    effiTrigSFToolList   = []
    effiTrigSysts        = []

    # Now come the pre-selection cuts
    class preSelection(object):
        cutPtMin             = 10.0*GeV
        cutAbsEtaMax         = 2.7
        cutIDList            = [ ]
        cutIDPtMinList       = [ 0.0*GeV ]
        cutInnerDetectorHits = False
        cutZ0SinThetaMax     = 0.5
        cutD0SignificanceMax = 3.0
        pass

    # The following cuts are NOT used in the pre-selection
    cutInnerDetectorHits = True
    cutPtMin             = 15.0*GeV
    cutLeadPtMin         = 22.0*GeV
    cutAbsEtaMax         = 2.5
    cutIDList            = [ ]
    cutIDPtMinList       = [ 0.0*GeV ]
    cutZ0SinThetaMax     = 0.5
    cutD0SignificanceMax = 3.0
    pass
hWWCommon.add_JobProperty(Muons)





class Jets(JobProperty):
    """Definitions for the common jets of all the H->WW analyzes"""
    statusOn            = True
    allowedTypes        = ['bool']
    StoredValue         = True
    truthCont           = "AntiKt4TruthJets"
    inTrackJetsCont     = "AntiKt4PV0TrackJets"
    writeTrackJets      = False
    # inCont              = "AntiKt4LCTopoJets"
    inCont              = "AntiKt4TruthJets"
    calibCont           = "HWWTruthCalibJets"
    calibPreSelCont     = "HWWTruthCalibPreSelJets"
    calibPreSelORCont   = "HWWTruthCalibPreSelORJets"
    finalCont           = "HWWTruthJets"
    preORAllPtSortCont  = "PreORAllPtSort"+finalCont
    finalAllPtSortCont  = "FinalAllPtSort"+finalCont
    def finalContList(self) :
        """ The names of the final jet containers. This is a list because every
        4-vector systematic variation is stored in its own container. Thus, we
        are building the list of all these containers using a helper function."""
        return buildContainerNames(baseName=self.finalCont, systList=hWWCommon.Jets.p4Systs)

    jesSysts            = [ 'JET_GroupedNP_1__1up', 'JET_GroupedNP_1__1down',
                            'JET_GroupedNP_2__1up', 'JET_GroupedNP_2__1down',
                            'JET_GroupedNP_3__1up', 'JET_GroupedNP_3__1down' ]
    jerSysts            = [ "JET_JER_SINGLE_NP__1up" ]
    p4Systs             = [ ] ## VD: this will be filled with the sum of jes and jer for application that are transparent to the difference

    updateJVTName       = "calibJvt"

    # Now come the pre-selection cuts
    class preSelection(object):
        cutPtMinList      = [ 20.0*GeV ]
        cutAbsEtaMaxList  = [ 4.5 ]
        cutCleanList      = [ ]
        cutCleanPtMinList = [ 0.0*GeV ]
        #requireTruthMatch = False
        cutJVT            = 0.64
        cutJVTMaxPt       = 50.0*GeV
        cutJVTMaxAbsEta   = 2.4
        pass

    # And now the final selection
    cutPtMinList      = [ 25.0*GeV, 30.0*GeV ]
    cutAbsEtaMaxList  = [ 2.4,      4.5 ]
    cutCleanList      = [  ]
    cutCleanPtMinList = [ 0.0*GeV ]
    cutJVT            = 0.64
    cutJVTMaxPt       = 50.0*GeV
    cutJVTMaxAbsEta   = 2.4

    pass
hWWCommon.add_JobProperty(Jets)





class MET(JobProperty):
    """Definitions for the missing ET of the H->WW-> analysis"""
    statusOn       = True
    allowedTypes   = ['bool']
    StoredValue    = True
    inMap          = "MET_Truth" # Only a default, gets changed according to the jet type
    inCore         = "MET_Truth" # Only a default, gets changed according to the jet type
    inCont         = "MET_Truth"
    inObject       = "NonInt"
    calibCont      = "HWWTruthMET"
    #finalCont      = "HWWTruthMET"
    finalCont      = "MET_Truth"
    #finalTrackCont = "HWWTrackMET"
    p4Systs        = [ #"MET_JetTrk_ScaleDown", "MET_JetTrk_ScaleUp",
                       #"MET_SoftCalo_Reso"   , "MET_SoftCalo_ScaleDown", "MET_SoftCalo_ScaleUp" , # Not recommendet: "MET_SoftTrk_ResoCorr" ,
                       #"MET_SoftTrk_ResoPara", "MET_SoftTrk_ResoPerp"  , "MET_SoftTrk_ScaleDown", "MET_SoftTrk_ScaleUp"
                      ]
    effiVarName    = "effiSF"
    effiSysts      = [ ]
    cutMETMin      = 0.0*GeV
    pass
hWWCommon.add_JobProperty(MET)
