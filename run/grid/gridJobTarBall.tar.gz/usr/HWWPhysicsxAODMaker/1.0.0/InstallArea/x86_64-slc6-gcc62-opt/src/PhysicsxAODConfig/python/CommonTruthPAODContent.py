##=============================================================================
## Name:        CommonPAODContent.py
##
## Author:      Karsten Koeneke
## Created:     August 2014
##
## Description: Here, we define the content that will be written for the
##              PhysicsAOD (PAOD) output file.
##=============================================================================

# Import the steering flags for this analysis
from PhysicsxAODConfig.HWWTruthCommonAnalysisFlags import hWWCommon


# ====================================================================
# Define the EventInfo variables to be written out
# ====================================================================
def eventInfoVars():
    """ Here, we define which individual variables for the event information get written out."""
    varList = [ "runNumber", "eventNumber", #"lumiBlock", "timeStamp", "timeStampNSOffset", "bcid",
                #"streamTagNames", "streamTagTypes",
                "eventTypeBitmask" # Contains 'IS_SIMULATION' and such
                #"primVtxIdx",
                #"nPrimVtx", "nPrimVtxTwoTrk", "nPrimVtxThreeTrk", "nPrimVtxFourTrk",
                #"actualInteractionsPerCrossing", "averageInteractionsPerCrossing"
                 ]
    if hWWCommon.Global.inputIsSimulation:
        varList.extend( [ "mcChannelNumber", "mcEventNumber", "mcEventWeights"
                          #"truth_WWtype",
                          #"truth_nTruthLep", "truth_isZZ", "truth_mvv",
                          #"truth_mW0W1", "truth_hasFSRPhoton" 
                          ] )
        pass
    #for trigName in hWWCommon.Trigger.allLeptonTriggerList :
    #    varList.append( hWWCommon.Trigger.triggerPassPrefix + trigName )
    #    pass
    varNames = ""
    for varName in varList:
        varNames += ("."+varName)
        pass
    return varNames.lstrip(".")


# ====================================================================
# Define the muon variables to be written out
# ====================================================================
def muonScaleFactorVars():
    """ This function is needed, because we need to dynamically figure out what
    the efficiency scale-factor variable names are (including systematics)."""
    # Also add all the scale factor variables
    varList = [ ]
    # Reconstruction and identification scale factors
    varList.extend( hWWCommon.Muons.effiVarNameList )
    for effiVarName in hWWCommon.Muons.effiVarNameList :
        varList.extend( [effiVarName+"___"+sysName for sysName in hWWCommon.Muons.effiSysts ] )
        pass
    # Track-to-vertex association scale factors
    varList.extend( hWWCommon.Muons.effiTTVAVarNameList )
    for effiVarName in hWWCommon.Muons.effiTTVAVarNameList :
        varList.extend( [effiVarName+"___"+sysName for sysName in hWWCommon.Muons.effiTTVASysts ] )
        pass
    # Isolation scale factors
    varList.extend( hWWCommon.Muons.effiIsoVarNameList )
    for effiIsoVarName in hWWCommon.Muons.effiIsoVarNameList :
        varList.extend( [effiIsoVarName+"___"+sysName for sysName in hWWCommon.Muons.effiIsoSysts ] )
        pass
    # Now, put everything in one long variable name, separated by "."
    varNames = ""
    for varName in varList:
        varNames += ("."+varName)
        pass
    return varNames.lstrip(".")

def muonVars():
    """ Here, we define which individual variables for the muons get written out."""
    varList = [ "px", "py", "pz", "e","pt", "eta", "phi", "m", "charge","pdgId","status","motherID","isFromTau"#, "muonType",
    #varList = [ "px", "py", "pz", "m", "pdgID","status","pt_dressed"#, "muonType",
                #"quality",
                #"Quality", "PassesIDCuts", "deltaPt", "momentumBalanceSignificance",
                #"InnerDetectorPt", "MuonSpectrometerPt",
                #"z0", "z0err", "sinTheta", "d0", "d0sig", # "z0sig", "d0err", "primVtxIsValid",
                #"ptvarcone30", "topoetcone20" # These two are used by the IsolationSelectionTool
                # "topoetcone20", "topoetcone30", "topoetcone40",
                # "ptvarcone20", "ptvarcone30", "ptvarcone40",
                # "ptcone20", "ptcone30", "ptcone40"
                ]
    #if hWWCommon.Global.inputIsSimulation:
    #    varList.extend( [ "truthType", "truthOrigin" ] )
    #    pass

    # Add the isolation true/false flag variables
    #varList.extend( hWWCommon.Muons.passIsoVarNameList )

    # Add trigger matching variables
    #if hWWCommon.Global.doTriggerMatching:
    #    for trigName in hWWCommon.Trigger.muonTriggerList :
    #        varList.append(hWWCommon.Trigger.triggerMatchPrefix+trigName)
    #        pass
    #    pass

    varNames = ""
    #varNames = muonScaleFactorVars()
    for varName in varList:
        varNames += ("."+varName)
        pass
    return varNames.lstrip(".")



# ====================================================================
# Define the electron variables to be written out
# ====================================================================
def electronScaleFactorVars():
    """ This function is needed, because we need to dynamically figure out what
    the efficiency scale-factor variable names are (including systematics)."""
    # Also add all the efficiency scale factor variables
    varList = [ ]
    # Reconstruction scale factors
    varList.extend( hWWCommon.Electrons.effiRecoVarNameList )
    for effiVarName in hWWCommon.Electrons.effiRecoVarNameList :
        varList.extend( [effiVarName+"___"+sysName for sysName in hWWCommon.Electrons.effiRecoSysts ] )
        pass
    # Identification scale factors
    varList.extend( hWWCommon.Electrons.effiVarNameList )
    for effiVarName in hWWCommon.Electrons.effiVarNameList :
        varList.extend( [effiVarName+"___"+sysName for sysName in hWWCommon.Electrons.effiSysts ] )
        pass
    # Trigger scale factors
    varList.extend( hWWCommon.Electrons.effiTrigVarNameList )
    for effiVarName in hWWCommon.Electrons.effiTrigVarNameList :
        varList.extend( [effiVarName+"___"+sysName for sysName in hWWCommon.Electrons.effiTrigSysts ] )
        pass
    # Isolation scale factors
    varList.extend( hWWCommon.Electrons.effiIsoVarNameList )
    for effiVarName in hWWCommon.Electrons.effiIsoVarNameList :
        varList.extend( [effiVarName+"___"+sysName for sysName in hWWCommon.Electrons.effiIsoSysts ] )
        pass
    # Now, put everything in one long variable name, separated by "."
    varNames = ""
    for varName in varList:
        varNames += ("."+varName)
        pass
    return varNames.lstrip(".")

def electronVars():
    """ Here, we define which individual variables for the electrons get written out."""
    varList = [ "px", "py", "pz", "e","pt", "eta", "phi", "m","charge","pdgId","status","motherID","isFromTau","motherID2"
                #"isLHLoose", "isLHMedium", "isLHTight",
                #"z0", "z0err", "sinTheta", "d0", "d0sig", # "z0sig", "d0err", "primVtxIsValid",
                #"ptvarcone20", "topoetcone20", # These two are used by the IsolationSelectionTool
                # "topoetcone20", "topoetcone30", "topoetcone40", #"topoetcone40_corrected",
                # "ptvarcone20", "ptvarcone30", "ptvarcone40",
                # "ptcone20", "ptcone30", "ptcone40",
                #"trackParticleLinks",
                #"caloClusterLinks",
                #"AmbiguityLoose","AmbiguityTight"
                ]

    #if hWWCommon.Global.inputIsSimulation:
    #    varList.extend( [ "truthType", "truthOrigin" ] )
    #    pass
    #varNames = electronScaleFactorVars()

    # Add the isolation true/false flag variables
    #varList.extend( hWWCommon.Electrons.passIsoVarNameList )

    # Add trigger matching variables
    #if hWWCommon.Global.doTriggerMatching:
    #    for trigName in hWWCommon.Trigger.electronTriggerList :
    #        varList.append(hWWCommon.Trigger.triggerMatchPrefix+trigName)
    #        pass
    #    pass
    varNames = ""

    for varName in varList:
        varNames += ("."+varName)
        pass
    return varNames.lstrip(".")



# ====================================================================
# Define the jet variables to be written out
# ====================================================================
def jetScaleFactorVars():
    """ This function is needed, because we need to dynamically figure out what
    the efficiency scale-factor variable names are (including systematics)."""
    # Also add all the efficiency scale factor variables
    effiVarName = hWWCommon.Jets.effiVarName
    varList = [ ]
    effiVarSuffixList = hWWCommon.Jets.effiSysts
    varList.extend( [effiVarName+"___"+sysName for sysName in effiVarSuffixList ] )
    varNames = effiVarName
    for varName in varList:
        varNames += ("."+varName)
        pass
    return varNames

def jetVars():
    """ Here, we define which individual variables for the jets get written out."""
    varList = [ "pt", "eta", "phi", "m", "charge","GhostBHadronsFinalCount","GhostBHadronsFinalPt","GhostBQuarksFinalCount","GhostBQuarksFinalPt","GhostCHadronsFinalCount","GhostCHadronsFinalPt","GhostCQuarksFinalCount","GhostCQuarksFinalPt","ConeTruthLabelID","HadronConeExclTruthLabelID","TruthLabelDeltaR_B","TruthLabelDeltaR_C","PartonTruthLabelID"#, "JVF", "calibJvt", "Jvt", "JvtJvfcorr", "JvtRpt",
                #"MV2c00","MV2c10", "MV2c20",
                #"btaggingLink",
                #"PassLooseBad", "PassTightBad" 
               ]
    #if hWWCommon.Global.inputIsSimulation:
    #    varList.extend( [ "hardScatterTruthMatchDeltaR", "hardScatterTruthJetPt" ] )
    #    varList.extend( [ "PartonTruthLabelID", "HadronConeExclTruthLabelID" ] )
    #    pass
    #varNames = jetScaleFactorVars()
    varNames = ""
    for varName in varList:
        varNames += ("."+varName)
        pass
    return varNames.lstrip(".")



# ====================================================================
# Define the MET variables to be written out
# ====================================================================
def metScaleFactorVars():
    """ This function is needed, because we need to dynamically figure out what
    the efficiency scale-factor variable names are (including systematics)."""
    # Also add all the efficiency scale factor variables
    effiVarName = hWWCommon.MET.effiVarName
    varList = [ ]
    effiVarSuffixList = hWWCommon.MET.effiSysts
    varList.extend( [effiVarName+"___"+sysName for sysName in effiVarSuffixList ] )
    varNames = effiVarName
    for varName in varList:
        varNames += ("."+varName)
        pass
    return varNames

def metVars():
    """ Here, we define which individual variables for the missingET get written out."""
    metVarName = hWWCommon.MET.effiVarName
    varList = [ "mpx", "mpy", "sumet" ]
    #varNames = metScaleFactorVars()
    varNames = ""
    for varName in varList:
        varNames += ("."+varName)
        pass
    return varNames.lstrip(".")



# ====================================================================
# Define the container item list of the output mini-xAOD
# ====================================================================
def pAODContent():
    """This function defines then which 'containers' are written to disk."""

    itemList = ["xAOD::EventInfo#EventInfo",
                "xAOD::EventAuxInfo#EventInfoAux."+eventInfoVars(),

                # Needed for being able to later use the ExpressionParser
                # (which uses also the trigger information). Only 3 bytes/event.
                #"xAOD::TrigConfKeys#TrigConfKeys",

                # "xAOD::ElectronContainer#"+hWWCommon.Electrons.finalCont+"*",
                # "xAOD::AuxContainerBase#"+hWWCommon.Electrons.finalCont+"*Aux."+electronVars(),
                # "xAOD::ShallowAuxContainer#"+hWWCommon.Electrons.finalCont+"*Aux.-originalObjectLink.-overlaps",

                "xAOD::TruthParticleContainer#"+hWWCommon.Muons.finalCont,
                "xAOD::TruthParticleContainer#"+hWWCommon.Muons.finalCont+"___MUONS_*",
                "xAOD::AuxContainerBase#"+hWWCommon.Muons.finalCont+"Aux."+muonVars(),
                "xAOD::ShallowAuxContainer#"+hWWCommon.Muons.finalCont+"___MUONS_*Aux.-originalObjectLink.-overlaps",

                "xAOD::MissingETContainer#"+hWWCommon.MET.finalCont,
                "xAOD::MissingETAuxContainer#"+hWWCommon.MET.finalCont+"Aux.*",
                "xAOD::AuxContainerBase#"+hWWCommon.MET.finalCont+"Aux."+metVars(),
                #"xAOD::AuxContainerBase#"+hWWCommon.MET.finalCont+"*Aux."+metVars(),
                "xAOD::ShallowAuxContainer#"+hWWCommon.MET.finalCont,


                ]

    for eleContName in hWWCommon.Electrons.finalContList() :
        itemList.append("xAOD::TruthParticleContainer#"+eleContName)
        if not "_" in eleContName :
            itemList.append("xAOD::AuxContainerBase#"+eleContName+"Aux."+electronVars())
            pass
        else :
            itemList.append("xAOD::ShallowAuxContainer#"+eleContName+"Aux.-originalObjectLink.-overlaps")
            pass

        pass

    # for muContName in hWWCommon.Muons.finalContList() :
    #     itemList.append("xAOD::MuonContainer#"+muContName)
    #     if not "_" in muContName :
    #         itemList.append("xAOD::AuxContainerBase#"+muContName+"Aux."+muonVars())
    #         pass
    #     else :
    #         itemList.append("xAOD::ShallowAuxContainer#"+muContName+"Aux.-originalObjectLink.-overlaps")
    #         pass
    #
    #     pass

    for jetContName in hWWCommon.Jets.finalContList() :
        itemList.append("xAOD::JetContainer#"+jetContName)
        if not "_" in jetContName :
            itemList.append("xAOD::AuxContainerBase#"+jetContName+"Aux."+jetVars())
            pass
        else :
            itemList.append("xAOD::ShallowAuxContainer#"+jetContName+"Aux.-originalObjectLink.-overlaps")
            pass

        pass

    # Schedule the broken-up AuxContainers to the output (and try to remove the others)
    if hWWCommon.Global.breakUpAuxContainers :
        from PhysicsxAODConfig import HWWCommonHelpers
        itemList = HWWCommonHelpers.replaceAuxContainers( itemList, hWWCommon.Global.auxContsToBreakUp )
        pass

    return itemList


# ====================================================================
# Define the meta-data item list of the output mini-xAOD
# ====================================================================
def pAODMetaDataContent():
    itemList = ["xAOD::CutBookkeeperContainer#*",
                "xAOD::CutBookkeeperAuxContainer#*",
                "IOVMetaDataContainer#*",
                "xAOD::FileMetaData#FileMetaData",
                "xAOD::FileMetaDataAuxInfo#FileMetaDataAux."
                ]
    return itemList
