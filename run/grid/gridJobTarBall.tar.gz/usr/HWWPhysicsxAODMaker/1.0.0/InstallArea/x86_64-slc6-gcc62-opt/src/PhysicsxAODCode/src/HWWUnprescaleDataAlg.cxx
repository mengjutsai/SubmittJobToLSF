///////////////////////// -*- C++ -*- /////////////////////////////
// HWWUnprescaleDataAlg.cxx
// Implementation file for class HWW::UnprescaleDataAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWUnprescaleDataAlg.h"

// STL includes
#include <vector>

// Framework includes
#include "GaudiKernel/AlgTool.h"

// EDM includes
#include "xAODEventInfo/EventInfo.h"

// Tool includes
#include "AsgAnalysisInterfaces/IPileupReweightingTool.h"



// Constructors
////////////////
HWW::UnprescaleDataAlg::UnprescaleDataAlg( const std::string& name,
                                           ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_prwTool("CP::PileupReweightingTool/UnprescaleDataPRWTool", this),
  m_inEventInfoName("EventInfo"),
  m_inTriggerExpression(""),
  m_inLumiCalcFiles()
{
  //
  // Property declaration
  //
  declareProperty( "EventInfoName",         m_inEventInfoName,     "The input EventInfo name" );
  declareProperty( "PileupReweightingTool", m_prwTool,             "The pileup reweighting tool" );
  declareProperty( "TriggerExpression",     m_inTriggerExpression, "The trigger expression to use for the unweighting of the data" );
  declareProperty( "LumiCalcFiles",         m_inLumiCalcFiles,     "The list of lumicalc files to pass to the tool" );
}



// Destructor
///////////////
HWW::UnprescaleDataAlg::~UnprescaleDataAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::UnprescaleDataAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inEventInfoName );
  ATH_MSG_DEBUG( "Using: " << m_prwTool );
  ATH_MSG_DEBUG( "Using: " << m_inTriggerExpression );
  ATH_MSG_DEBUG( "Using: " << m_inLumiCalcFiles );

  // Get the needed tools
  ATH_CHECK( m_prwTool.retrieve() );
  // And forward the needed property to it
  AlgTool* myPRWTool = dynamic_cast<AlgTool*>( &*m_prwTool );
  ATH_CHECK( myPRWTool->setProperty(m_inLumiCalcFiles) );
  return StatusCode::SUCCESS;
}



StatusCode HWW::UnprescaleDataAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release the needed tools
  ATH_CHECK( m_prwTool.release() );

  return StatusCode::SUCCESS;
}



StatusCode HWW::UnprescaleDataAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Get the EventInfo object
  const xAOD::EventInfo* evtInfo;
  ATH_CHECK( evtStore()->retrieve( evtInfo, m_inEventInfoName.value() ));
  const bool isSim = evtInfo->eventType(xAOD::EventInfo::EventType::IS_SIMULATION);

  // Define the decorators outside of the loop as a static, such that it
  // will be fully cached
  static SG::AuxElement::Decorator<float>  decDataWeight("dataWeight");

  // Now, get the info from the pileup reweighting tool and store it with the EventInfo object
  float dataWeight = 1.0;
  if (!isSim){
    dataWeight = m_prwTool->getDataWeight( *evtInfo, m_inTriggerExpression.value() );
    ATH_MSG_VERBOSE("Got data weight of " << dataWeight);
  }
  decDataWeight(*evtInfo) = dataWeight;

  return StatusCode::SUCCESS;
}
