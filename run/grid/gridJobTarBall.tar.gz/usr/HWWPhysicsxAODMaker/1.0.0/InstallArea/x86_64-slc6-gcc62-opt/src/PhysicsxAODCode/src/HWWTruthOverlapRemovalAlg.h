#ifndef HWWCOMMONANALYSISUTILS_HWWTRUTHOVERLAPREMOVALALG_H
#define HWWCOMMONANALYSISUTILS_HWWTRUTHOVERLAPREMOVALALG_H 1

// STL includes
#include <string>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"

//#include "AssociationUtils/IOverlapTool.h"
#include "AssociationUtils/OverlapRemovalDefs.h"
#include "AssociationUtils/OverlapDecorationHelper.h"

// EDM includes

// Forward declarations
//class IOverlapTool;
//class ORUtils::OverlapDecorationHelper;


// Put everything into a HWW namespace
namespace HWW {

  class TruthOverlapRemovalAlg
    : public ::AthAlgorithm
  {
    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
    public:

      /// Constructor with parameters:
      TruthOverlapRemovalAlg( const std::string& name, ISvcLocator* pSvcLocator );

      /// Destructor:
      virtual ~TruthOverlapRemovalAlg();

      /// Athena algorithm's initalize hook
      virtual StatusCode  initialize();

      /// Athena algorithm's execute hook
      virtual StatusCode  execute();

      /// Athena algorithm's finalize hook
      virtual StatusCode  finalize();



      /// Use one tool to remove overlaps
      /*StatusCode removeOverlap(const ToolHandle<IOverlapTool>& tool,
                               const xAOD::IParticleContainer* cont1,
                               const xAOD::IParticleContainer* cont2) const;*/

    private:

      /// Check if the given particle overlaps in DeltaR with any of the list
      bool checkOverlap(const xAOD::IParticle* part, const xAOD::IParticleContainer* cont, double DRmax, double DRmin);

      /// @name The properties that can be defined via the python job options
      /// @{

      //
      // Configurable properties
      //

      /// Input object decoration which specifies which objects to look at
      std::string m_inputLabel;
      /// Output object decoration which specifies overlapping objects
      std::string m_outputLabel;

      /// Toggle the output flag logic. If true, then non-overlapping
      /// objects will be assigned "true".
      bool m_outputPassValue;

      /// Require non-null container pointers when expected; i.e., when
      /// corresponding overlap tools are configured. On by default.
      bool m_requireExpectedPointers;

      /// Helper used to reset decorations
      std::unique_ptr<ORUtils::OverlapDecorationHelper> m_decHelper;

      //
      // Overlap tool handles
      //

      /// Ele-mu overlap handle
      //ToolHandle<IOverlapTool> m_eleMuORT;

      /// Ele-jet overlap handle
      //ToolHandle<IOverlapTool> m_eleJetORT;

      /// Mu-jet overlap handle
      //ToolHandle<IOverlapTool> m_muJetORT;

      // The ToolHandle for the TruthOverlapRemovalTool
      //ToolHandle<IOverlapRemovalTool> m_OverlapRemovalTool;

      /// The input electron container name
      StringProperty m_inElCont;

      /// The input muon container name
      StringProperty m_inMuCont;

      /// The input jet container name
      StringProperty m_inJetCont;

      /// The output electron container name
      StringProperty m_outElCont;

      /// The output muon container name
      StringProperty m_outMuCont;

      /// The output jet container name
      StringProperty m_outJetCont;
    
      /// @}

  };

} // End HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWTRUTHOVERLAPREMOVALALG_H
