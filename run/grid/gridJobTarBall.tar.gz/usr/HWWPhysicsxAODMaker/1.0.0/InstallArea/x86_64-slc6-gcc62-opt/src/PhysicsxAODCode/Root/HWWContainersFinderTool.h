///////////////////////// -*- C++ -*- /////////////////////////////
// HWWContainersFinderTool.h
// Header file for class HWW::ContainersFinderTool
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONXAODCODE_HWWCONTAINERSFINDERTOOL_H
#define HWWCOMMONXAODCODE_HWWCONTAINERSFINDERTOOL_H 1

// STL includes
#include <string>

// FrameWork includes
#include "GaudiKernel/ServiceHandle.h"
#include "AsgTools/AsgTool.h"
#include "PhysicsxAODCode/IHWWContainersFinderTool.h"

// EDM includes
#include "xAODBase/IParticleContainer.h"
#include "xAODJet/JetContainer.h"
#include "xAODEgamma/ElectronContainer.h"
#include "xAODMuon/MuonContainer.h"
#include "xAODMissingET/MissingETContainer.h"



namespace HWW {

  class ContainersFinderTool
    : virtual public asg::AsgTool,
      virtual public HWW::IContainersFinderTool
  {
    ASG_TOOL_CLASS(ContainersFinderTool, HWW::IContainersFinderTool)

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
  public:

    /// Constructor with parameters:
    ContainersFinderTool( std::string name );

    /// Destructor:
    virtual ~ContainersFinderTool();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();


    ///////////////////////////////////////////////////////////////////
    // Const methods:
    ///////////////////////////////////////////////////////////////////

    /// Get all container names with their systematic types, given one container name (looking for xAOD::IParticleContainer)
    virtual StatusCode containerNamesAndSysTypes( ContNameAndSysTypeVec_t& result, const std::string& searchPattern ) const override
    {
      return this->containerTemplateNamesAndSysTypes<xAOD::IParticleContainer>(result, searchPattern);
    }

    /// Get all container names with their systematic types, given one container name (looking for xAOD::JetContainer)
    virtual StatusCode jetNamesAndSysTypes( ContNameAndSysTypeVec_t& result, const std::string& searchPattern ) const override
    {
      return this->containerTemplateNamesAndSysTypes<xAOD::JetContainer>(result, searchPattern);
    }

    /// Get all container names with their systematic types, given one container name (looking for xAOD::ElectronContainer)
    virtual StatusCode electronNamesAndSysTypes( ContNameAndSysTypeVec_t& result, const std::string& searchPattern ) const override
    {
      return this->containerTemplateNamesAndSysTypes<xAOD::ElectronContainer>(result, searchPattern);
    }

    /// Get all container names with their systematic types, given one container name (looking for xAOD::MuonContainer)
    virtual StatusCode muonNamesAndSysTypes( ContNameAndSysTypeVec_t& result, const std::string& searchPattern ) const override
    {
      return this->containerTemplateNamesAndSysTypes<xAOD::MuonContainer>(result, searchPattern);
    }

    /// Get all container names with their systematic types, given one container name (looking for xAOD::MissingETContainer)
    virtual StatusCode metNamesAndSysTypes( ContNameAndSysTypeVec_t& result, const std::string& searchPattern ) const override
    {
      return this->containerTemplateNamesAndSysTypes<xAOD::MissingETContainer>(result, searchPattern);
    }

    ///////////////////////////////////////////////////////////////////
    // Private methods:
    ///////////////////////////////////////////////////////////////////
   private:
    /// Get all container names with their systematic types, given one container name (looking for xAOD::IParticleContainer)
    template<class TCONT>
    StatusCode containerTemplateNamesAndSysTypes( ContNameAndSysTypeVec_t& result, const std::string& searchPattern ) const;



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
   private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The suffix for the nominal name (default='')
    StringProperty m_nominalSuffix;

    /// The string separator between the variable/container name and its sytematic variation (default="___")
    StringProperty m_separator;

    /// @}


    /// @name Internal members
    /// @{


    /// @}

  };

} // End: namespace HWW


///////////////////////////////////////////////////////////////////
// Inline methods:
///////////////////////////////////////////////////////////////////


#endif //> !HWWCOMMONXAODCODE_HWWCONTAINERSFINDERTOOL_H
