#ifndef HWWCOMMONANALYSISUTILS_HWWOVERLAPREMOVALALG_H
#define HWWCOMMONANALYSISUTILS_HWWOVERLAPREMOVALALG_H 1

// STL includes
#include <string>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"

// EDM includes
#include "xAODBase/IParticle.h"
#include "AthContainers/AuxElement.h"

// Forward declarations
// class IOverlapRemovalTool;
namespace ORUtils {
  class IOverlapRemovalTool;
}


// Put everything into a HWW namespace
namespace HWW {

  class OverlapRemovalAlg
    : public ::AthAlgorithm
  {
    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
    public:

      /// Constructor with parameters:
      OverlapRemovalAlg( const std::string& name, ISvcLocator* pSvcLocator );

      /// Destructor:
      virtual ~OverlapRemovalAlg();

      /// Athena algorithm's initalize hook
      virtual StatusCode  initialize();

      /// Athena algorithm's execute hook
      virtual StatusCode  execute();

      /// Athena algorithm's finalize hook
      virtual StatusCode  finalize();


    // Private functions
    private:
      /// @name The properties that can be defined via the python job options
      /// @{

      /// Private function to check if an object passes the overlap removal
      bool passOR( const xAOD::IParticle* part, const std::vector<bool>& decisionVector ) const;

      /// @}

    private:

      /// @name The properties that can be defined via the python job options
      /// @{

      // The ToolHandle for the OverlapRemovalTool
      // ToolHandle<IOverlapRemovalTool> m_OverlapRemovalTool;
      // ToolHandle<ORUtils::IOverlapRemovalTool> m_OverlapRemovalTool;
      ToolHandleArray<ORUtils::IOverlapRemovalTool> m_OverlapRemovalToolList;

      /// The list of label names that the overlap removal tools used to flag overlaps
      StringArrayProperty m_overlapLabels;

      /// The list of booleans that declare which overlap precedure should be
      /// used to write out electrons. If multiple are given, a logical OR will
      /// be used.
      std::vector<bool> m_writeElectronOverlaps;

      /// The list of booleans that declare which overlap precedure should be
      /// used to write out muons. If multiple are given, a logical OR will
      /// be used.
      std::vector<bool> m_writeMuonOverlaps;

      /// The list of booleans that declare which overlap precedure should be
      /// used to write out jets. If multiple are given, a logical OR will
      /// be used.
      std::vector<bool> m_writeJetOverlaps;

      /// The list of booleans that declare which overlap precedure should be
      /// used to write out fat jets. If multiple are given, a logical OR will
      /// be used.
      std::vector<bool> m_writeFatJetOverlaps;


      /// The input electron container name
      StringProperty m_inElCont;

      /// The input muon container name
      StringProperty m_inMuCont;

      /// The input jet container name
      StringProperty m_inJetCont;

      /// The input large-R jet container name
      StringProperty m_inFatJetCont;

      /// The output electron container name
      StringProperty m_outElCont;

      /// The output muon container name
      StringProperty m_outMuCont;

      /// The output jet container name
      StringProperty m_outJetCont;

      /// The output large-R jet container name
      StringProperty m_outFatJetCont;

      /// The name of the tagger that we want to use (default='MV2c20')
      StringProperty m_taggerName;

      /// The cut value on the b-tagging discriminant
      DoubleProperty m_taggerCut;

      /// The name of the boolean variable to say pass/fail b-tagging
      StringProperty m_passBTagName;

      /// @}

      /// @name Data members for internal private useage
      /// @{

      /// The created accessors, based on the given input variable names
      std::vector< SG::AuxElement::Accessor<char> > m_accOverlapsList;

      /// @}


  };

} // End HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWOVERLAPREMOVALALG_H
