//  includes
#include "HWWGoodRunsListSelectionAlg.h"

// EDM includes
#include "xAODEventInfo/EventInfo.h"

// Tool includes
#include "AsgAnalysisInterfaces/IGoodRunsListSelectionTool.h"

// Framework includes
#include "GaudiKernel/Property.h"
#include "GaudiKernel/IJobOptionsSvc.h"


HWW::GoodRunsListSelectionAlg::GoodRunsListSelectionAlg( const std::string& name, ISvcLocator* pSvcLocator ):
  AthFilterAlgorithm( name, pSvcLocator ),
  m_jos("JobOptionsSvc", name),
  m_GRLSelectionTool("GoodRunsListSelectionTool/GoodRunsListSelectionTool", this),
  m_nEventsProcessed(0),
  m_setGRL(false)
{

  declareProperty("GoodRunsListVec", m_goodrunslistVec,
                  "The list of GoodRunsList names" );
  m_goodrunslistVec.declareUpdateHandler( &GoodRunsListSelectionAlg::setupGRL, this );

}


HWW::GoodRunsListSelectionAlg::~GoodRunsListSelectionAlg() {}


StatusCode HWW::GoodRunsListSelectionAlg::initialize()
{
  ATH_MSG_DEBUG("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using JobOptionsSvc: " << m_jos );
  ATH_MSG_DEBUG( "Using GRLSelectionTool: " <<  m_GRLSelectionTool);
  ATH_MSG_DEBUG( "Using GRLs with name: " <<  m_goodrunslistVec);

  // TODO need sanity checks?

  // Get the JobOptionService
  // We will use this to set the properties of our private GRL selection tool
  // from the properties of this algorithm.
  ATH_MSG_VERBOSE( "Getting the JobOptionService");
  ATH_CHECK( m_jos.retrieve() );

  // Get the full name of the private GRL selection tool
  ATH_MSG_VERBOSE( "Getting the full name of the tool");
  const std::string& fullToolName = this->name() + "." + m_GRLSelectionTool.name();
  ATH_MSG_DEBUG( "Got the full name of the tool: " << fullToolName );

  // Now, set all properties of the private GRL selection tool that were actually configured
  if(m_setGRL)
  {
    ATH_MSG_DEBUG( "Setting property" << m_goodrunslistVec << " of private tool with name: '" << fullToolName << "'" );
    ATH_CHECK( m_jos->addPropertyToCatalogue (fullToolName,m_goodrunslistVec) );
  }
  ATH_MSG_DEBUG( "Done setting properties of the tool");

  // Retrieve the GRL selection tool
  ATH_CHECK(m_GRLSelectionTool.retrieve());

  // Initialize the counters to zero
  m_nEventsProcessed = 0;

  return StatusCode::SUCCESS;
}

StatusCode HWW::GoodRunsListSelectionAlg::finalize()
{
  ATH_MSG_DEBUG("Finalizing " << name() << "...");

  // Release all tools and services
  ATH_CHECK( m_jos.release() );
  ATH_CHECK( m_GRLSelectionTool.release() );

  return StatusCode::SUCCESS;
}

StatusCode HWW::GoodRunsListSelectionAlg::execute()
{

  // Increase the event counter
  ++m_nEventsProcessed;

  // Simple status message at the beginning of each event execute
  ATH_MSG_DEBUG ("Executing " << name() << " on event " << m_nEventsProcessed << " ...");

  // Open EventInfo container
  const xAOD::EventInfo* evtInfo;
  ATH_CHECK( evtStore()->retrieve( evtInfo, "EventInfo" ));

  // Only do the event vetoing on data
  const bool isSim = evtInfo->eventType(xAOD::EventInfo::EventType::IS_SIMULATION);
  if ( isSim ) {
    ATH_MSG_DEBUG ("It is an MC event... not vetoing...");
    this->setFilterPassed(true);
    return StatusCode::SUCCESS;
  }

  // Check if event passes GRL selection
  bool eventPasses = m_GRLSelectionTool->passRunLB(*evtInfo);
  this->setFilterPassed( eventPasses );
  ATH_MSG_DEBUG("Event passes/fails: " << eventPasses );

  return StatusCode::SUCCESS;
}
