#ifndef HWWCOMMONANALYSISUTILS_HWWTRIGGERTOOL_H
#define HWWCOMMONANALYSISUTILS_HWWTRIGGERTOOL_H 1

// STL includes
#include <string>

// FrameWork includes
#include "AsgTools/AsgTool.h"
#include "PhysicsxAODCode/IHWWTriggerTool.h"
#include "GaudiKernel/ToolHandle.h"

// EDM includes
#include "xAODBase/IParticleContainer.h"
#include "xAODMuon/MuonContainer.h"
#include "xAODEgamma/ElectronContainer.h"

// Trigger matching
#include "TriggerMatchingTool/IMatchingTool.h"


// Put everything into a HWW namespace
namespace HWW {

  class TriggerTool
    : virtual public asg::AsgTool,
      virtual public HWW::ITriggerTool
  {
    ASG_TOOL_CLASS(TriggerTool, HWW::ITriggerTool)

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
    public:

      /// Constructor with parameters:
      TriggerTool( std::string name );

      /// Destructor:
      virtual ~TriggerTool();

      /// Athena algorithm's initalize hook
      virtual StatusCode  initialize();

      /// Athena algorithm's finalize hook
      virtual StatusCode  finalize();

      /// Single lepton trigger matching methods
      virtual bool match( const xAOD::IParticle *part ) const final override;
      virtual bool match( const xAOD::IParticle *part, const std::string& chain ) const final override;

      ///////////////////////////////
      /// Single muon trigger matching methods
      /// Muons are decorated with trigger matching result with name m_varPrefix+chain
      ///////////////////////////////

      /// Perform trigger matching on given muon using the provided list of muon trigger chains
      /// Returns true when any of the trigger chains could be matched, false otherwise
      virtual bool match( const xAOD::Muon *muon ) const final override;
      /// Perform trigger matching on given muon with given muon trigger chain
      /// Returns true when the trigger chain could be matched, false otherwise
      virtual bool match( const xAOD::Muon *muon, const std::string& chain ) const final override;
      /// Perform trigger matching on all muons in given muon collection using the provided list of muon trigger chains
      /// Returns true when any of the trigger chains could be matched with any of the muons, false otherwise
      virtual bool match( const xAOD::MuonContainer *muonCont ) const final override;
      /// Perform trigger matching on all muons in given muon collection with given muon trigger chain
      /// Returns true when the trigger chain could be matched with any of the muons, false otherwise
      virtual bool match( const xAOD::MuonContainer *muonCont, const std::string& chain ) const final override;

      ///////////////////////////////
      /// Single electron trigger matching methods
      /// Electrons are decorated with trigger matching result with name m_varPrefix+chain
      ///////////////////////////////

      /// Perform trigger matching on given electron using the provided list of electron trigger chains
      /// Returns true when any of the trigger chains could be matched, false otherwise
      virtual bool match( const xAOD::Electron *electron ) const final override;
      /// Perform trigger matching on given electron with given electron trigger chain
      /// Returns true when the trigger chain could be matched, false otherwise
      virtual bool match( const xAOD::Electron *electron, const std::string& chain ) const final override;
      /// Perform trigger matching on all electrons in given electron collection using the provided list of electron trigger chains
      /// Returns true when any of the trigger chains could be matched with any of the electrons, false otherwise
      virtual bool match( const xAOD::ElectronContainer *electronCont ) const final override;
      /// Perform trigger matching on all electrons in given electron collection with given electron trigger chain
      /// Returns true when the trigger chain could be matched with any of the electrons, false otherwise
      virtual bool match( const xAOD::ElectronContainer *electronCont, const std::string& chain ) const final override;

      ///////////////////////////////
      /// Di-lepton trigger matching methods
      /// Objects are decorated with a char with name m_varPrefix+chain, storing the trigger matching results
      ///////////////////////////////

      /// Electron-muon trigger matching, taking two IParticleContainer and chain name as input, returning the overall trigger matching decision
      virtual bool match( const xAOD::IParticleContainer *cont1, const xAOD::IParticleContainer *cont2, const std::string& chain ) const final override;
      virtual bool match( const xAOD::IParticleContainer *cont1, const xAOD::IParticleContainer *cont2 ) const final override;

    private:

      /// @name The properties that can be defined via the python job options
      /// @{

      /// The ToolHandle for the TrigMuonMatching tool
      ToolHandle<Trig::IMatchingTool> m_tmt;

      /// The prefix to be used for the trigger matching flags
      StringProperty m_varPrefix;

      /// The list of trigger chains to do muon matching on
      StringArrayProperty m_muonMatchList;

      /// The list of trigger chains to do electron matching on
      StringArrayProperty m_electronMatchList;

      /// The list of trigger chains to do di-muon matching on
      StringArrayProperty m_diMuMatchList;

      /// The list of trigger chains to do di-electron matching on
      StringArrayProperty m_diElMatchList;

      /// The list of trigger chains to do electron-muon matching on
      StringArrayProperty m_elMuMatchList;

      /// @}

      /// @name private member variables
      /// @{

      /// @}

  };

} // End HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWTRIGGERTOOL_H
