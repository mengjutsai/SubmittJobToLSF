#include "GaudiKernel/DeclareFactoryEntries.h"

#include "../../Root/HWWContainersFinderTool.h"
#include "../../Root/HWWElectronSelectionTool.h"
#include "../../Root/HWWTruthElectronSelectionTool.h"
#include "../../Root/HWWMuonSelectionTool.h"
#include "../../Root/HWWJetSelectionTool.h"
#include "../../Root/HWWTruthJetSelectionTool.h"
#include "../../Root/HWWTriggerTool.h"
#include "../HWWEventInfoDecorationAlg.h"
#include "../HWWElectronDecorationAlg.h"
#include "../HWWElectronCalibrationSmearingAlg.h"
#include "../HWWElectronScaleFactorAlg.h"
#include "../HWWMuonDecorationAlg.h"
#include "../HWWMuonCalibrationSmearingAlg.h"
#include "../HWWMuonScaleFactorAlg.h"
#include "../HWWMuonTriggerEfficiencyScaleFactorAlg.h"
#include "../HWWJetDecorationAlg.h"
#include "../HWWJetCalibrationSmearingAlg.h"
#include "../HWWJetJVTScaleFactorAlg.h"
#include "../HWWJetEventCleaningAlg.h"
#include "../HWWFatJetDecorationAlg.h"
#include "../HWWMETMakerAlg.h"
#include "../HWWMETCalibrationSmearingAlg.h"
#include "../HWWMETReducerAlg.h"
#include "../HWWFullEventBuilderAlg.h"
#include "../HWWBtagScaleFactorAlg.h"
#include "../HWWGoodRunsListSelectionAlg.h"
#include "../HWWOverlapRemovalAlg.h"
#include "../HWWTruthOverlapRemovalAlg.h"
#include "../HWWTruthLeptonAlg.h"
#include "../HWWTruthJetMETAlg.h"
#include "../HWWTriggerAlg.h"
#include "../HWWPrimaryVertexFilterAlg.h"
#include "../HWWEventSelectionAlg.h"
#include "../HWWTruthAlg.h"
#include "../HWWUnprescaleDataAlg.h"
#include "../HWWPileupReweightingAlg.h"

DECLARE_NAMESPACE_TOOL_FACTORY( HWW, ContainersFinderTool )
DECLARE_NAMESPACE_TOOL_FACTORY( HWW, ElectronSelectionTool )
DECLARE_NAMESPACE_TOOL_FACTORY( HWW, TruthElectronSelectionTool )
DECLARE_NAMESPACE_TOOL_FACTORY( HWW, MuonSelectionTool )
DECLARE_NAMESPACE_TOOL_FACTORY( HWW, JetSelectionTool )
DECLARE_NAMESPACE_TOOL_FACTORY( HWW, TruthJetSelectionTool )
DECLARE_NAMESPACE_TOOL_FACTORY( HWW, TriggerTool )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, EventInfoDecorationAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, ElectronDecorationAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, ElectronCalibrationSmearingAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, ElectronScaleFactorAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, MuonDecorationAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, MuonCalibrationSmearingAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, MuonScaleFactorAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, MuonTriggerEfficiencyScaleFactorAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, JetDecorationAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, JetCalibrationSmearingAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, JetJVTScaleFactorAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, JetEventCleaningAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, FatJetDecorationAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, METMakerAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, METCalibrationSmearingAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, METReducerAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, FullEventBuilderAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, BtagScaleFactorAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, GoodRunsListSelectionAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, OverlapRemovalAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, TruthOverlapRemovalAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, TruthLeptonAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, TruthJetMETAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, TriggerAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, PrimaryVertexFilterAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, EventSelectionAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, TruthAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, UnprescaleDataAlg )
DECLARE_NAMESPACE_ALGORITHM_FACTORY( HWW, PileupReweightingAlg )
