//  includes
#include "HWWTruthLeptonAlg.h"

// Tool includes

// EDM includes
#include "xAODTruth/TruthEventContainer.h"
#include "xAODTruth/TruthParticleContainer.h"
#include "xAODTruth/TruthParticleAuxContainer.h"

#include "AssociationUtils/MacroChecks.h"


HWW::TruthLeptonAlg::TruthLeptonAlg( const std::string& name, ISvcLocator* pSvcLocator ):
  AthAlgorithm( name, pSvcLocator ),
  m_inElCont(""),
  m_inMuCont(""),
  m_outElCont(""),
  m_outMuCont("")
{
  //declareProperty("OverlapRemovalTool", m_OverlapRemovalTool,
  //                "The OverlapRemovalTool" );
  //declareProperty("EleMuORT", m_eleMuORT, "Electron-muon overlap tool");
  //declareProperty("EleJetORT", m_eleJetORT, "Electron-jet overlap tool");
  //declareProperty("MuJetORT", m_muJetORT, "Muon-jet overlap tool");

  declareProperty("InputElectrons", m_inElCont,
                  "The name of the input electrons container" );

  declareProperty("InputMuons", m_inMuCont,
                  "The name of the input muons container" );

  declareProperty("OutputElectrons", m_outElCont,
                  "The name of the output electrons container" );

  declareProperty("OutputMuons", m_outMuCont,
                  "The name of the output muons container" );

}



HWW::TruthLeptonAlg::~TruthLeptonAlg() {}



StatusCode HWW::TruthLeptonAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inElCont );
  ATH_MSG_DEBUG( "Using: " << m_inMuCont );
  ATH_MSG_DEBUG( "Using: " << m_outElCont );
  ATH_MSG_DEBUG( "Using: " << m_outMuCont );


  return StatusCode::SUCCESS;
}



StatusCode HWW::TruthLeptonAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  return StatusCode::SUCCESS;
}


StatusCode HWW::TruthLeptonAlg::execute()
{
  // Get input containers (should be view containers of selected electrons, muons, and jets)
  const xAOD::TruthParticleContainer* electrons = nullptr;
  if (!(m_inElCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( electrons, m_inElCont.value() ) );}
  const xAOD::TruthParticleContainer* muons = nullptr;
  if (!(m_inMuCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( muons, m_inMuCont.value() ) );}


  // Define the decorators outside of the loop as a static, such that it
  // will be fully cached
  static xAOD::TruthParticle::Decorator<float> ptDeco("pt");
  static xAOD::TruthParticle::Decorator<float> etaDeco("eta");
  static xAOD::TruthParticle::Decorator<float> phiDeco("phi");
  static xAOD::TruthParticle::Decorator<float> chargeDeco("charge");
  static xAOD::TruthParticle::Decorator<int> fromTauDeco("isFromTau");
  static xAOD::TruthParticle::Decorator<int> midDeco("motherID2");


  // Create and record output containers (which are view containers)
  xAOD::TruthParticleContainer* outElCont = nullptr;
  if (electrons){
    outElCont = new xAOD::TruthParticleContainer( SG::VIEW_ELEMENTS );
    ATH_CHECK( evtStore()->record ( outElCont, m_outElCont.value() ) );
  }
  xAOD::TruthParticleContainer* outMuCont = nullptr;
  if (muons){
    outMuCont = new xAOD::TruthParticleContainer( SG::VIEW_ELEMENTS );
    ATH_CHECK( evtStore()->record ( outMuCont, m_outMuCont.value() ) );
  }

  // Run over input containers and fill output containers with objects which passed the OR. At the moment the variable is a boolean, in a later tag of the OR tool it's changed to char
  if (electrons){
    for(const xAOD::TruthParticle* electron : *electrons){
      ATH_MSG_DEBUG( "--> electron with: " << electron->pt()
         << " , " << electron->eta()
         << " , " << electron->phi()
         << " , Status: " << electron->status()
         << " , barcode: " << electron->barcode()
         << "  ID: " <<  electron->pdgId() );// << std::endl;
      ATH_MSG_DEBUG( "electron dressed pt: " << electron->auxdata<float>("pt_dressed") );
      ATH_MSG_DEBUG( "electron dressed eta: " << electron->auxdata<float>("eta_dressed") );
      ATH_MSG_DEBUG( "electron dressed phi: " << electron->auxdata<float>("phi_dressed") );
      ATH_MSG_DEBUG( "electron dressed motherid: " << electron->auxdata<int>("motherID") );
      const float pt = electron->auxdata<float>("pt_dressed") ;
      const float eta = electron->auxdata<float>("eta_dressed") ;
      const float phi = electron->auxdata<float>("phi_dressed") ;
      const float charge = electron->charge() ;
      int fromTau = 0;
      int mid = electron->auxdata<int>("motherID");
      /*ATH_MSG_DEBUG("number of parents: " << electron->nParents());
      if (abs(electron->auxdata<int>("motherID"))==11) {
        for (int i = 0; i < electron->nParents(); i++) {
           ATH_MSG_DEBUG("parent: " << i << " pdgid " << electron->parent(i)->pdgId());
           if(abs(electron->parent(i)->pdgId()) != 11) {
              mid = electron->parent(i)->pdgId();
              break;
           }
        }
      }*/
      if (abs(mid)==15) {
        fromTau = 1;
      }
      ptDeco(*electron)    = pt;
      etaDeco(*electron)    = eta;
      phiDeco(*electron)    = phi;
      chargeDeco(*electron)    = charge;
      fromTauDeco(*electron)    = fromTau;
      midDeco(*electron)    = mid;
      
      outElCont->push_back( const_cast<xAOD::TruthParticle*>(electron) );
   
    }
  }
  if (muons){
    for(const xAOD::TruthParticle* muon : *muons){
      ATH_MSG_DEBUG( "--> muon with: " << muon->pt()
         << " , " << muon->eta()
         << " , " << muon->phi()
         << " , Status: " << muon->status()
         << " , barcode: " << muon->barcode()
         << "  ID: " <<  muon->pdgId() );// << std::endl;
      ATH_MSG_DEBUG( "muon dressed pt: " << muon->auxdata<float>("pt_dressed") );
      ATH_MSG_DEBUG( "muon dressed eta: " << muon->auxdata<float>("eta_dressed") );
      ATH_MSG_DEBUG( "muon dressed phi: " << muon->auxdata<float>("phi_dressed") );
      ATH_MSG_DEBUG( "muon dressed motherid: " << muon->auxdata<int>("motherID") );
      
      const float pt = muon->auxdata<float>("pt_dressed") ;
      const float eta = muon->auxdata<float>("eta_dressed") ;
      const float phi = muon->auxdata<float>("phi_dressed") ;
      const float charge = muon->charge() ;
      int fromTau = 0;
      if (abs(muon->auxdata<int>("motherID"))==15) {
        fromTau = 1;
      }
      ptDeco(*muon)    = pt;
      etaDeco(*muon)    = eta;
      phiDeco(*muon)    = phi;
      chargeDeco(*muon)    = charge;
      fromTauDeco(*muon)    = fromTau;

      outMuCont->push_back( const_cast<xAOD::TruthParticle*>(muon) );
    }
  }

  return StatusCode::SUCCESS;
}
