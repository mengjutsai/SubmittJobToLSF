///////////////////////// -*- C++ -*- /////////////////////////////
// HWWFatJetDecorationAlg.h
// Header file for class HWW::FatJetDecorationAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWFATJETDECORATIONALG_H
#define HWWCOMMONANALYSISUTILS_HWWFATJETDECORATIONALG_H 1

// STL includes
#include <string>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"


// Forward declarations
//namespace BoostedJetTaggers {
class SmoothedWZTagger;
//}



// Put everything into a HWW namespace
namespace HWW {

  class FatJetDecorationAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
  public:

    // Copy constructor:

    /// Constructor with parameters:
    FatJetDecorationAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~FatJetDecorationAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
  private:

    /// @name The tools and utils that need to be used
    /// @{

    /// The W-boson tagger utility
    SmoothedWZTagger* m_wTagger;

    /// The Z-boson tagger utility
    SmoothedWZTagger* m_zTagger;

    /// @}

  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input jet container name
    StringProperty m_inContName;

    /// The working point of the boson taggers
    StringProperty m_vTaggerWP;

    /// The algorithm of the boson taggers
    StringProperty m_vTaggerAlg;

    /// The config file of the W-boson taggers
    StringProperty m_wTaggerConfig;

    /// The config file of the Z-boson taggers
    StringProperty m_zTaggerConfig;

    /// Decorate all copies of the input container
    bool m_decoAllCopies;

    /// @}

    /// The vector of jet container names
    std::vector<std::string> m_containerNameList;

  };

} // End: HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWFATJETDECORATIONALG_H
