//  includes
#include "HWWTruthJetMETAlg.h"

// Tool includes

// EDM includes
#include "xAODJet/Jet.h"
#include "xAODJet/JetContainer.h"
#include "xAODJet/JetAuxContainer.h"
#include "xAODMissingET/MissingETContainer.h"
#include "xAODMissingET/MissingETAuxContainer.h"

#include "AssociationUtils/MacroChecks.h"


HWW::TruthJetMETAlg::TruthJetMETAlg( const std::string& name, ISvcLocator* pSvcLocator ):
  AthAlgorithm( name, pSvcLocator ),
  m_inJetCont(""),
  m_inMetCont(""),
  m_outJetCont(""),
  m_outMetCont("")
{

  declareProperty("InputJets", m_inJetCont,
                  "The name of the input jets container" );

  declareProperty("InputMet", m_inMetCont,
                  "The name of the input met container" );

  declareProperty("OutputJets", m_outJetCont,
                  "The name of the output jets container" );

  declareProperty("OutputMet", m_outMetCont,
                  "The name of the output met container" );

}



HWW::TruthJetMETAlg::~TruthJetMETAlg() {}



StatusCode HWW::TruthJetMETAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inJetCont );
  ATH_MSG_DEBUG( "Using: " << m_inMetCont );
  ATH_MSG_DEBUG( "Using: " << m_outJetCont );
  ATH_MSG_DEBUG( "Using: " << m_outMetCont );


  return StatusCode::SUCCESS;
}



StatusCode HWW::TruthJetMETAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  return StatusCode::SUCCESS;
}


StatusCode HWW::TruthJetMETAlg::execute()
{
  // Get input containers (should be view containers of jets and met)
  const xAOD::JetContainer* jets = nullptr;
  if (!(m_inJetCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( jets, m_inJetCont.value() ) );}
  const xAOD::MissingETContainer* mets = nullptr;
  if (!(m_inMetCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( mets, m_inMetCont.value() ) );}


  // Define the decorators outside of the loop as a static, such that it
  // will be fully cached
  /*static xAOD::Jet::Decorator<float> ptDeco("pt");
  static xAOD::Jet::Decorator<float> etaDeco("eta");
  static xAOD::Jet::Decorator<float> phiDeco("phi");
  static xAOD::Jet::Decorator<float> chargeDeco("charge");
  static xAOD::Jet::Decorator<int> fromTauDeco("isFromTau");
  static xAOD::Jet::Decorator<int> midDeco("motherID2");*/


  // Create and record output containers (which are view containers)
  xAOD::JetContainer* outJetCont = nullptr;
  if (jets){
    outJetCont = new xAOD::JetContainer( SG::VIEW_ELEMENTS );
    ATH_CHECK( evtStore()->record ( outJetCont, m_outJetCont.value() ) );
  }
  xAOD::MissingETContainer* outMetCont = nullptr;
  //xAOD::MissingETAuxContainer* outMetContAux = nullptr;
  if (mets){
    outMetCont = new xAOD::MissingETContainer( SG::VIEW_ELEMENTS);
    ATH_CHECK( evtStore()->record ( outMetCont, m_outMetCont.value() ) );
    //outMetContAux = new xAOD::MissingETAuxContainer();
    //ATH_CHECK( evtStore()->record( outMetContAux, m_outMetCont.value() + "Aux." ) );
    //outMetCont->setStore( outMetContAux );
  }

  // Run over input containers and fill output containers with objects which passed the OR. At the moment the variable is a boolean, in a later tag of the OR tool it's changed to char
  if (jets){
    for(const xAOD::Jet* jet : *jets){
      ATH_MSG_DEBUG( "--> jet with: " << jet->pt()
         << " , " << jet->eta()
         << " , " << jet->phi()
         );// << std::endl;
      //ATH_MSG_DEBUG( "jet dressed pt: " << jet->auxdata<float>("pt_dressed") );
      outJetCont->push_back( const_cast<xAOD::Jet*>(jet) );
   
    }
  }
  if (mets){
    const xAOD::MissingET* met = (*mets)["NonInt"];
    ATH_MSG_DEBUG( "--> met with: " << met->met()
         << " , " << met->name());// << std::endl;

    outMetCont->push_back( const_cast<xAOD::MissingET*>(met) );
  }

  return StatusCode::SUCCESS;
}
