///////////////////////// -*- C++ -*- /////////////////////////////
// HWWElectronSelectionTool.cxx
// Implementation file for class HWWElectronSelectionTool
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWElectronSelectionTool.h"

// STL includes
#include <climits>
#include <cmath>
#include <string>

// FrameWork includes
#include "GaudiKernel/IToolSvc.h"

// EDM includes
#include "xAODBase/ObjectType.h"
#include "xAODBase/IParticle.h"
#include "xAODPrimitives/IsolationType.h"
#include "xAODEgamma/EgammaDefs.h"
#include "xAODEgamma/EgammaEnums.h"
#include "xAODEgamma/Electron.h"
#include "xAODEgamma/EgammaxAODHelpers.h"
#include "xAODCaloEvent/CaloCluster.h"
#include "xAODTracking/TrackingPrimitives.h"
#include "xAODTracking/Vertex.h"



// Constructors
////////////////
HWW::ElectronSelectionTool::ElectronSelectionTool( std::string name ) :
  asg::AsgTool(name),
  m_doOQCut(false),
  m_authorCut(false),
  m_doPtCut(false),
  m_doEtaCut(false),
  m_doZ0Cut(false),
  m_doD0Cut(false),
  m_d0MaxSquare(0.0),
  m_cutPosition_goodOQ(-9),
  m_cutPosition_author(-9),
  m_cutPosition_pt(-9),
  m_cutPosition_eta(-9),
  m_cutPosition_id(-9),
  m_cutPosition_z0(-9),
  m_cutPosition_d0(-9),
  m_cutPosition_caloIso(-9),
  m_cutPosition_trackIso(-9)
{
  //
  // Property declaration
  //
  declareProperty( "CutObjectQualityMask", m_oqCut=0, "The electron object quality cut mask" );
  m_oqCut.declareUpdateHandler( &HWW::ElectronSelectionTool::setupOQCut, this );

  declareProperty( "RequireIsElectronAuthor", m_authorCut=false, "The electron author cut" );

  declareProperty( "CutPtMin", m_ptMin=-99999.0, "The electron.pt() minimum cut value" );
  m_ptMin.declareUpdateHandler( &HWW::ElectronSelectionTool::setupPtCut, this );

  declareProperty( "CutAbsEtaMax",      m_absEtaMax=DBL_MAX,   "The |electron.cluster().eta()| maximum cut value" );
  m_absEtaMax.declareUpdateHandler( &HWW::ElectronSelectionTool::setupEtaCut, this );
  declareProperty( "CutAbsEtaCrackMin", m_absEtaCrackMin=-1000.0, "The |electron.cluster().eta()| minimum cut value for the calo crack" );
  m_absEtaCrackMin.declareUpdateHandler( &HWW::ElectronSelectionTool::setupEtaCut, this );
  declareProperty( "CutAbsEtaCrackMax", m_absEtaCrackMax=-1000.0, "The |electron.cluster().eta()| maximum cut value for the calo crack" );
  m_absEtaCrackMax.declareUpdateHandler( &HWW::ElectronSelectionTool::setupEtaCut, this );

  declareProperty( "CutIDList", m_idList, "The electron identification selection list" );
  declareProperty( "CutIDPtMinList", m_idPtMinList,
                   "The electron.pt minimum cuts for the identification selection; must be ordered from lowest to highest" );

  declareProperty( "CutZ0SinThetaMax", m_z0Max=FLT_MAX, "The electron z0 maximum cut value" );
  m_z0Max.declareUpdateHandler( &HWW::ElectronSelectionTool::setupZ0Cut, this );

  declareProperty( "CutD0SignificanceMax", m_d0Max=FLT_MAX, "The electron d0 maximum cut value" );
  m_d0Max.declareUpdateHandler( &HWW::ElectronSelectionTool::setupD0Cut, this );

  declareProperty( "CaloIsoList", m_caloIsoList, "The calorimetric isolation types list" );
  declareProperty( "CaloIsoRelativeMaxCutList", m_caloIsoRelMaxList, "The relativ calorimetric isolation maximum cut list" );
  declareProperty( "CaloIsoMaxCutList", m_caloIsoMaxList, "The absolute calorimetric isolation maximum cut list" );
  declareProperty( "CutCaloIsoPtMinList", m_caloIsoPtMinList,
                   "The minimum pt cuts for the calorimetric isolation list" );

  declareProperty( "TrackIsoList", m_trkIsoList, "The track isolation types list" );
  declareProperty( "TrackIsoRelativeMaxCutList", m_trkIsoRelMaxList, "The relativ track isolation maximum cut list" );
  declareProperty( "TrackIsoMaxCutList", m_trkIsoMaxList, "The absolute track isolation maximum cut list" );
  declareProperty( "CutTrackIsoPtMinList", m_trkIsoPtMinList,
                   "The minimum pt cuts for the track isolation list" );
}




// Destructor
///////////////
HWW::ElectronSelectionTool::~ElectronSelectionTool()
{}




// Athena algtool's Hooks
////////////////////////////
StatusCode HWW::ElectronSelectionTool::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_oqCut );
  ATH_MSG_DEBUG( "Using: " << m_authorCut );
  ATH_MSG_DEBUG( "Using: " << m_ptMin );
  ATH_MSG_DEBUG( "Using: " << m_absEtaMax );
  ATH_MSG_DEBUG( "Using: " << m_absEtaCrackMin );
  ATH_MSG_DEBUG( "Using: " << m_absEtaCrackMax );
  ATH_MSG_DEBUG( "Using: " << m_idList );
  ATH_MSG_DEBUG( "Using: " << m_idPtMinList );
  ATH_MSG_DEBUG( "Using: " << m_z0Max );
  ATH_MSG_DEBUG( "Using: " << m_d0Max );
  ATH_MSG_DEBUG( "Using: " << m_caloIsoList );
  ATH_MSG_DEBUG( "Using: CaloIsoRelativeMaxCutList=" << m_caloIsoRelMaxList );
  ATH_MSG_DEBUG( "Using: CaloIsoMaxCutList=" << m_caloIsoMaxList );
  ATH_MSG_DEBUG( "Using: CutCaloIsoPtMinList=" << m_caloIsoPtMinList );
  ATH_MSG_DEBUG( "Using: " << m_trkIsoList );
  ATH_MSG_DEBUG( "Using: TrackIsoRelativeMaxCutList=" << m_trkIsoRelMaxList );
  ATH_MSG_DEBUG( "Using: TrackIsoMaxCutList=" << m_trkIsoMaxList );
  ATH_MSG_DEBUG( "Using: CutTrackIsoPtMinList=" << m_trkIsoPtMinList );


  // Perform some sanity checks on the given lists
  if ( !(m_caloIsoList.value().empty()) ) {
    if ( !(m_caloIsoRelMaxList.empty())
         && m_caloIsoRelMaxList.size() != m_caloIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_caloIsoList.name() << " is " << m_caloIsoList.value().size()
                    << " and size of CaloIsoRelativeMaxCutList is " << m_caloIsoRelMaxList.size() );
    }
    if ( !(m_caloIsoMaxList.empty())
         && m_caloIsoMaxList.size() != m_caloIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_caloIsoList.name() << " is " << m_caloIsoList.value().size()
                    << " and size of CaloIsoMaxCutList is " << m_caloIsoMaxList.size() );
    }
    if ( !(m_caloIsoPtMinList.empty())
         && m_caloIsoPtMinList.size() != m_caloIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_caloIsoList.name() << " is " << m_caloIsoList.value().size()
                    << " and size of CutCaloIsoPtMinList is " << m_caloIsoPtMinList.size() );
    }
  }
  // If any other list is empty, fill it with negative infinities
  if ( m_caloIsoRelMaxList.empty() ) {
    for ( std::size_t i=0; i<m_caloIsoList.value().size(); ++i ) {
      m_caloIsoRelMaxList.push_back(FLT_MAX);
    }
  }
  if ( m_caloIsoMaxList.empty() ) {
    for ( std::size_t i=0; i<m_caloIsoList.value().size(); ++i ) {
      m_caloIsoMaxList.push_back(FLT_MAX);
    }
  }
  if ( m_caloIsoPtMinList.empty() ) {
    for ( std::size_t i=0; i<m_caloIsoList.value().size(); ++i ) {
      m_caloIsoPtMinList.push_back(-1.0*DBL_MAX);
    }
  }
  // Perform some sanity checks on the given lists
  if ( !(m_trkIsoList.value().empty()) ) {
    if ( !(m_trkIsoRelMaxList.empty())
         && m_trkIsoRelMaxList.size() != m_trkIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_trkIsoList.name() << " is " << m_trkIsoList.value().size()
                    << " and size of TrackIsoRelativeMaxCutList is " << m_trkIsoRelMaxList.size() );
    }
    if ( !(m_trkIsoMaxList.empty())
         && m_trkIsoMaxList.size() != m_trkIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_trkIsoList.name() << " is " << m_trkIsoList.value().size()
                    << " and size of TrackIsoMaxCutList is " << m_trkIsoMaxList.size() );
    }
    if ( !(m_trkIsoPtMinList.empty())
         && m_trkIsoPtMinList.size() != m_trkIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_trkIsoList.name() << " is " << m_trkIsoList.value().size()
                    << " and size of CutTrackIsoPtMinList is " << m_trkIsoPtMinList.size() );
    }
  }
  // If any other list is empty, fill it with negative infinities
  if ( m_trkIsoRelMaxList.empty() ) {
    for ( std::size_t i=0; i<m_trkIsoList.value().size(); ++i ) {
      m_trkIsoRelMaxList.push_back(FLT_MAX);
    }
  }
  if ( m_trkIsoMaxList.empty() ) {
    for ( std::size_t i=0; i<m_trkIsoList.value().size(); ++i ) {
      m_trkIsoMaxList.push_back(FLT_MAX);
    }
  }
  if ( m_trkIsoPtMinList.empty() ) {
    for ( std::size_t i=0; i<m_trkIsoList.value().size(); ++i ) {
      m_trkIsoPtMinList.push_back(-1.0*DBL_MAX);
    }
  }


  // Caluculate some internal variables
  if ( m_doD0Cut ) {
    m_d0MaxSquare = m_d0Max.value() * m_d0Max.value();
  }


  // --------------------------------------------------------------------------
  // Register the cuts and check that the registration worked:
  // NOTE: THE ORDER IS IMPORTANT!!! Cut0 corresponds to bit 0, Cut1 to bit 1,...
  // if ( m_cutPosition_nSCTMin < 0 ) sc = 0; // Exceeded the number of allowed cuts

  // Register the object quality cut
  if ( m_doOQCut ) {
    ATH_MSG_DEBUG("Registering object quality cut");
    m_cutPosition_goodOQ = m_accept.addCut( "OQCut", Form("isGoodOQ(%u)", m_oqCut.value()) );
    if ( m_cutPosition_goodOQ < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron quality cut");
      return StatusCode::FAILURE;
    }
  }

  // Register the author cut
  if ( m_authorCut.value() ) {
    ATH_MSG_DEBUG("Registering author cut");
    m_cutPosition_author = m_accept.addCut( "AuthorCut", "Require isElectron author" );
    if ( m_cutPosition_author < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron author cut");
      return StatusCode::FAILURE;
    }
  }

  // Register the pt cut
  if ( m_doPtCut ) {
    ATH_MSG_DEBUG("Registering pt cut");
    m_cutPosition_pt = m_accept.addCut( "PtCut", Form("pt > %g GeV", m_ptMin.value() * 0.001) );
    if ( m_cutPosition_pt < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron pt cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the eta cut
  if ( m_doEtaCut ) {
    ATH_MSG_DEBUG("Registering eta cut");
    m_cutPosition_eta = m_accept.addCut( "EtaCut", Form("( abs(eta) < %g ) || ( %g < abs(eta) %g )",
                                                         m_absEtaCrackMin.value(), m_absEtaCrackMax.value(), m_absEtaMax.value()) );
    if ( m_cutPosition_eta < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron eta cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the identification cut
  if ( !(m_idList.value().empty()) ) {
    ATH_MSG_DEBUG("Registering identification cut");
    // Build the cut decsription name
    std::string cutDescription("");
    if ( m_idPtMinList.value().empty() && m_idList.value().size() == 1 ) {
      cutDescription = m_idList.value().at(0);
    }
    else if ( m_idPtMinList.value().size() == m_idList.value().size() ) {
      // We have pt-dependent identification cuts
      const std::size_t maxIdx = m_idPtMinList.value().size();
      for ( std::size_t i=0; i<maxIdx; ++i ) {
        cutDescription += " (";
        cutDescription += Form( "%f", m_idPtMinList.value().at(i) * 0.001 );
        cutDescription += " GeV < ptEle && ID=" + m_idList.value().at(i) + ") ";
      }
    }
    // Actually register the cut
    m_cutPosition_id = m_accept.addCut( "IdentificationCut", cutDescription );
    if ( m_cutPosition_id < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron identificaion cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the z0 cut
  if ( m_doZ0Cut ) {
    ATH_MSG_DEBUG("Registering z0 cut");
    m_cutPosition_z0 = m_accept.addCut( "Z0Cut", Form("abs(z0*sin(theta)) < %g mm", m_z0Max.value()) );
    if ( m_cutPosition_z0 < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron z0 cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the d0 cut
  if ( m_doD0Cut ) {
    ATH_MSG_DEBUG("Registering d0 cut");
    m_cutPosition_d0 = m_accept.addCut( "D0Cut", Form("abs(d0/d0err) < %g", m_d0Max.value()) );
    if ( m_cutPosition_d0 < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron d0 cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the calo isolation cut
  if ( !(m_caloIsoList.value().empty()) ) {
    ATH_MSG_DEBUG("Registering calo isolation cut");
    // Build the cut decsription name
    std::string cutDescription("");
    for ( std::size_t i=0; i<m_caloIsoList.value().size(); ++i ) {
      cutDescription += " (";
      cutDescription += Form( "%f", m_caloIsoPtMinList.at(i) * 0.001 );
      cutDescription += " GeV < ptEle && iso=";
      cutDescription += Form( "%u", m_caloIsoList.value().at(i) );
      cutDescription += ") ";
    }
    m_cutPosition_caloIso = m_accept.addCut( "CaloIsoCut", cutDescription );
    if ( m_cutPosition_caloIso < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron calo isolation cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the track isolation cut
  if ( !(m_trkIsoList.value().empty()) ) {
    ATH_MSG_DEBUG("Registering track isolation cut");
    // Build the cut decsription name
    std::string cutDescription("");
    for ( std::size_t i=0; i<m_trkIsoList.value().size(); ++i ) {
      cutDescription += " (";
      cutDescription += Form( "%f", m_trkIsoPtMinList.at(i) * 0.001 );
      cutDescription += " GeV < ptEle && iso=";
      cutDescription += Form( "%u", m_trkIsoList.value().at(i) );
      cutDescription += ") ";
    }
    m_cutPosition_trackIso = m_accept.addCut( "TrackIsoCut", cutDescription );
    if ( m_cutPosition_trackIso < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron track isolation cut");
      return StatusCode::FAILURE;
    }
  }

  return StatusCode::SUCCESS;
}




StatusCode HWW::ElectronSelectionTool::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  return StatusCode::SUCCESS;
}




// Method to get the plain TAccept.
const Root::TAccept& HWW::ElectronSelectionTool::getTAccept( ) const
{
  return m_accept;
}




// The main accept method: the actual cuts are applied here
const Root::TAccept& HWW::ElectronSelectionTool::accept( const xAOD::IParticle* part,
                                                         const xAOD::Vertex* primVtx ) const
{
  // Reset the cut result bits to zero (= fail cut)
  m_accept.clear();

  // cast to an electron
  if ( part->type() != xAOD::Type::Electron ) {
    ATH_MSG_ERROR("Didn't get an IParticle of type electron... exiting");
    return m_accept;
  }
  const xAOD::Electron* ele = static_cast<const xAOD::Electron*>(part);
  if ( !ele ) {
    ATH_MSG_ERROR("Couldn't cast to an electron");
    return m_accept;
  }


  // ---------------------------------------------------------------------------
  // Do the actual selection:
  // If a cut is not passed, we return and the subsequent cuts are not tried out

  // Apply the object quality selection, if requested
  if ( m_doOQCut ) {
    ATH_MSG_VERBOSE("Going to do object quality selection");
    // const bool passCut = ele->isGoodOQ(m_oqCut.value());
    const bool passCut = ele->isGoodOQ(xAOD::EgammaParameters::BADCLUSELECTRON);// Hard-code the bitmask for now
    m_accept.setCutResult( m_cutPosition_goodOQ, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing object quality cut");
      return m_accept;
    }
  } // End do object quality selection


  // Apply the reconstruction author selection, if requested
  if ( m_authorCut.value() ) {
    ATH_MSG_VERBOSE("Going to do author selection");
    const bool passCut = xAOD::EgammaHelpers::isElectron(ele);
    m_accept.setCutResult( m_cutPosition_author, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing author cut");
      return m_accept;
    }
  } // End do object quality selection


  // Apply the pt selection, if requested
  const double elePt = ele->pt();
  if ( m_doPtCut ) {
    ATH_MSG_VERBOSE("Going to do pt selection");
    const bool passCut = elePt > m_ptMin.value();
    m_accept.setCutResult( m_cutPosition_pt, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing pt cut");
      return m_accept;
    }
  } // End: do pt cut


  // Apply the eta selection, if requested
  if ( m_doEtaCut ) {
    ATH_MSG_VERBOSE("Going to do eta selection");
    // Get the CaloCluster of this electron
    const xAOD::CaloCluster* clus = ele->caloCluster();
    if ( !clus ) {
      ATH_MSG_ERROR("Couldn't get the CaloCluster for this electron");
      return m_accept;
    }

    // Do the actual selection
    const double clusAbsEta = std::abs(clus->eta());
    const bool passCut = ( (clusAbsEta < m_absEtaCrackMin.value())
                           || ( m_absEtaCrackMax.value() < clusAbsEta
                                && clusAbsEta < m_absEtaMax.value() ) );
    m_accept.setCutResult( m_cutPosition_eta, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing eta cut");
      return m_accept;
    }
  } // End: if ( m_doEtaCut )

  // Do the electron identification selection, if requested, TODO: need to check if ORing the LH working points like in Run I is still necessary
  if ( !(m_idList.value().empty()) ) {
    ATH_MSG_VERBOSE("Going to do identification selection");
    bool passCut(false);
    const std::size_t maxIdx = m_idList.value().size();
    for ( std::size_t i=0; i<maxIdx; ++i ) {
      // If this object is already accepted, we don't need to look furhter
      if (passCut) break;
      // Get the current name of the identification to test
      const std::string& idName = m_idList.value().at(i);
      // Check in which pt-bin we are
      const double ptMin = m_idPtMinList.value().at(i);
      if ( i+1 < maxIdx ) {
        const double ptMax = m_idPtMinList.value().at(i+1);
        const double deltaPt = std::abs(ptMax - ptMin);
        if( deltaPt < 0.1 || ( ptMin <= elePt && elePt < ptMax ) ) {
          ATH_MSG_VERBOSE("Check if electron is " << idName << " for pT bin ( " << ptMin << " < " << elePt << " < " << ptMax << " )");
          // Get the electron LH decision from previously decorated tag
          passCut = ( ele->auxdata<char>(idName) != 0 );
        }
      }
      else if ( ptMin <= elePt ) {
        ATH_MSG_VERBOSE("Check if electron is " << idName << " for pT bin ( " << ptMin << " < " << elePt << " )");
        // Get the electron LH decision from previously decorated tag
        passCut = ( ele->auxdata<char>(idName) != 0 );
      }
    } // End: loop over all pt bins
    // Return if any of the electron passes the selection
    m_accept.setCutResult( m_cutPosition_id, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing identification cut");
      return m_accept;
    }
  } // End: do electron identification selection

  // Get the GSF TrackParticle, if needed
  const xAOD::TrackParticle* trackPart(0);
  if ( m_doZ0Cut || m_doD0Cut ) {
    trackPart = ele->trackParticle();
    if ( !trackPart ) {
      ATH_MSG_ERROR("Couldn't get the TrackParticle for this electron");
      return m_accept;
    }
  }


  // Do the track impact parameter z0 cut, if requested
  if ( m_doZ0Cut && primVtx ) {
    ATH_MSG_VERBOSE("Going to do z0 selection");
    // The TrackParticle is expressed w.r.t. the beam spot. Thus, we need to
    // do some gymnastics in order to get it w.r.t. the primary vertex.
    const float z0 = trackPart->z0() + trackPart->vz() - primVtx->z();
    const float z0sinTheta = std::abs( z0 * std::sin(trackPart->theta()) );
    const bool passCut = z0sinTheta < m_z0Max.value();
    m_accept.setCutResult( m_cutPosition_z0, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing z0 cut");
      return m_accept;
    }
  } // End: do z0 cut


  // Do the track impact parameter d0 cut, if requested
  if ( m_doD0Cut ) {
    ATH_MSG_VERBOSE("Going to do d0 selection");
    bool passCut(false);
    //const float d0 = ele->auxdata<float>("d0");
    //const float d0err = ele->auxdata<float>("d0err");
    float d0signif = ele->auxdata<float>("d0sig");
    //if ( d0err != 0.0 ){ d0signif = std::abs( d0/d0err ); }
    passCut = std::abs(d0signif) < m_d0Max.value();
    m_accept.setCutResult( m_cutPosition_d0, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing d0 cut with values: (d0/d0err)=" << d0signif << ", (cut value): " << m_d0Max.value() );
      return m_accept;
    }
  }


  // Do the calorimetric isolation cut, if requested
  if ( !(m_caloIsoList.value().empty()) ) {
    ATH_MSG_VERBOSE("Going to do calo isolation selection");
    bool passCut(false);
    if ( elePt <= 0.0 ) {
      ATH_MSG_WARNING("Failing calo isolation cut due to negative pt");
      return m_accept;
    }
    const double invElePt = 1.0/elePt;
    // Iterate over all given calo isolation types
    for ( std::size_t i=0; i<m_caloIsoList.value().size(); ++i ) {
      const xAOD::Iso::IsolationType isoType
          = static_cast<xAOD::Iso::IsolationType>(m_caloIsoList.value().at(i));
      // Get the isolation value
      float iso(0.0);
      if ( !(ele->isolationValue(iso, isoType)) ) {
        ATH_MSG_ERROR("Didn't find the isolation of type: " << isoType );
        return m_accept;
      }
      const double minPtCut = m_caloIsoPtMinList.at(i);
      double nextPtCut(DBL_MAX);
      if ( i+1 < m_caloIsoPtMinList.size() ) { nextPtCut = m_caloIsoPtMinList.at(i+1); }
      const float maxCaloIsoCut    = m_caloIsoMaxList.at(i);
      const float maxRelCaloIsoCut = m_caloIsoRelMaxList.at(i);
      if ( minPtCut < elePt && elePt < nextPtCut ) {
        ATH_MSG_VERBOSE("Check if electron has isolationtype " << static_cast<int>(isoType) << " / pt ( " << (iso*invElePt) << " < " << maxRelCaloIsoCut << " )" << " for pT bin ( " << minPtCut << " < " << elePt << " < " << nextPtCut << " )");
        if( iso < maxCaloIsoCut && (iso*invElePt) < maxRelCaloIsoCut ) {
          passCut = true; // We passed the isolation cut
        }
        break; // We are in the right pt-bin, nothing more to do here
      }
    } // End: loop over all calo iso types
    m_accept.setCutResult( m_cutPosition_caloIso, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing calo isolation cut");
      return m_accept;
    }
  } // End: calorimetric isolation selection


  // Do the track-based isolation cut, if requested
  if ( !(m_trkIsoList.value().empty()) ) {
    ATH_MSG_VERBOSE("Going to do track isolation selection");
    bool passCut(false);
    if ( elePt <= 0.0 ) {
      ATH_MSG_WARNING("Failing track isolation cut due to negative pt");
      return m_accept;
    }
    const double invElePt = 1.0/elePt;
    // Iterate over all given trk isolation types
    for ( std::size_t i=0; i<m_trkIsoList.value().size(); ++i ) {
      const xAOD::Iso::IsolationType isoType
          = static_cast<xAOD::Iso::IsolationType>(m_trkIsoList.value().at(i));
      // Get the isolation value
      float iso(0.0);
      if ( !(ele->isolationValue(iso, isoType)) ) {
        ATH_MSG_ERROR("Didn't find the isolation of type: " << isoType );
        return m_accept;
      }
      const double minPtCut = m_trkIsoPtMinList.at(i);
      double nextPtCut(DBL_MAX);
      if ( i+1 < m_trkIsoPtMinList.size() ) { nextPtCut = m_trkIsoPtMinList.at(i+1); }
      const float maxtrkIsoCut    = m_trkIsoMaxList.at(i);
      const float maxReltrkIsoCut = m_trkIsoRelMaxList.at(i);
      if ( minPtCut < elePt && elePt < nextPtCut ) {
        ATH_MSG_VERBOSE("Check if electron has isolationtype " << static_cast<int>(isoType) << " / pt ( " << (iso*invElePt) << " < " << maxReltrkIsoCut << " )" << " for pT bin ( " << minPtCut << " < " << elePt << " < " << nextPtCut << " )");
        if( iso < maxtrkIsoCut && (iso*invElePt) < maxReltrkIsoCut ) {
          passCut = true; // We passed the isolation cut
        }
        break; // We are in the right pt-bin, nothing more to do here
      }
    } // End: loop over all trk iso types
    m_accept.setCutResult( m_cutPosition_trackIso, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing track isolation cut");
      return m_accept;
    }
  } // End: track isolation selection


  return m_accept;
}
