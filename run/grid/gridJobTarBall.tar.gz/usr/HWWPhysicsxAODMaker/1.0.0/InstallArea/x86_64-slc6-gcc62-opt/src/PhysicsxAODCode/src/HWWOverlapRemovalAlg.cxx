//  includes
#include "HWWOverlapRemovalAlg.h"

// Tool includes
#include "AssociationUtils/IOverlapRemovalTool.h"

// EDM includes
#include "AthContainers/ConstDataVector.h"
#include "xAODEgamma/ElectronContainer.h"
#include "xAODMuon/MuonContainer.h"
#include "xAODJet/JetContainer.h"
#include "xAODBTagging/BTagging.h"

// Framework inlcudes
#include "GaudiKernel/SystemOfUnits.h"

using Gaudi::Units::GeV;



HWW::OverlapRemovalAlg::OverlapRemovalAlg( const std::string& name, ISvcLocator* pSvcLocator ):
  AthAlgorithm( name, pSvcLocator ),
  m_OverlapRemovalToolList(),
  m_overlapLabels(),
  m_writeElectronOverlaps(),
  m_writeMuonOverlaps(),
  m_writeJetOverlaps(),
  m_writeFatJetOverlaps(),
  m_inElCont(""),
  m_inMuCont(""),
  m_inJetCont(""),
  m_inFatJetCont(""),
  m_outElCont(""),
  m_outMuCont(""),
  m_outJetCont(""),
  m_outFatJetCont(""),
  m_taggerName("MV2c10"),
  m_taggerCut(0.1758),
  m_passBTagName(""),
  m_accOverlapsList()
{
  declareProperty("OverlapRemovalToolList", m_OverlapRemovalToolList, "The list of OverlapRemovalTools" );
  declareProperty("OverlapRemovalLabels",   m_overlapLabels,
                  "The list of label names that the overlap removal tools used to flag overlaps" );

  declareProperty("WriteElectronOverlaps", m_writeElectronOverlaps,
                  "The list of booleans that declare which overlap precedure should be used to write out electrons. If multiple are given, a logical OR will be used.");
  declareProperty("WriteMuonOverlaps",     m_writeMuonOverlaps,
                  "The list of booleans that declare which overlap precedure should be used to write out electrons. If multiple are given, a logical OR will be used.");
  declareProperty("WriteJetOverlaps",      m_writeJetOverlaps,
                  "The list of booleans that declare which overlap precedure should be used to write out electrons. If multiple are given, a logical OR will be used.");
  declareProperty("WriteFatJetOverlaps",   m_writeFatJetOverlaps,
                  "The list of booleans that declare which overlap precedure should be used to write out electrons. If multiple are given, a logical OR will be used.");

  declareProperty("InputElectrons", m_inElCont,     "The name of the input selected electrons container" );
  declareProperty("InputMuons",     m_inMuCont,     "The name of the input selected muons container" );
  declareProperty("InputJets",      m_inJetCont,    "The name of the input selected jets container" );
  declareProperty("InputFatJets",   m_inFatJetCont, "The name of the input selected jets container" );

  declareProperty("OutputElectrons",  m_outElCont,     "The name of the output overlap-removed electrons container" );
  declareProperty("OutputMuons",      m_outMuCont,     "The name of the output overlap-removed muons container" );
  declareProperty("OutputJets",       m_outJetCont,    "The name of the output overlap-removed jets container" );
  declareProperty("OutputFatJets",    m_outFatJetCont, "The name of the output overlap-removed jets container" );

  declareProperty("TaggerName",       m_taggerName, "The name of the tagger that we want to use (default='MV2c10')" );
  declareProperty("OperatingPoint",   m_taggerCut, "The cut value on the b-tagging discriminant" );
  declareProperty("PassBTaggingName", m_passBTagName, "The name of the boolean variable to say pass/fail b-tagging" );
}



HWW::OverlapRemovalAlg::~OverlapRemovalAlg() {}



StatusCode HWW::OverlapRemovalAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  // ATH_MSG_DEBUG( "Using: " << m_OverlapRemovalTool );
  ATH_MSG_DEBUG( "Using: " << m_OverlapRemovalToolList );
  ATH_MSG_DEBUG( "Using: " << m_overlapLabels );
  ATH_MSG_DEBUG( "Using: WriteElectronOverlaps " << m_writeElectronOverlaps );
  ATH_MSG_DEBUG( "Using: WriteMuonOverlaps     " << m_writeMuonOverlaps );
  ATH_MSG_DEBUG( "Using: WriteJetsOverlaps     " << m_writeJetOverlaps );
  ATH_MSG_DEBUG( "Using: WriteFatJetsOverlaps  " << m_writeFatJetOverlaps );
  ATH_MSG_DEBUG( "Using: " << m_inElCont );
  ATH_MSG_DEBUG( "Using: " << m_inMuCont );
  ATH_MSG_DEBUG( "Using: " << m_inJetCont );
  ATH_MSG_DEBUG( "Using: " << m_inFatJetCont );
  ATH_MSG_DEBUG( "Using: " << m_outElCont );
  ATH_MSG_DEBUG( "Using: " << m_outMuCont );
  ATH_MSG_DEBUG( "Using: " << m_outJetCont );
  ATH_MSG_DEBUG( "Using: " << m_outFatJetCont );
  ATH_MSG_DEBUG( "Using: " << m_taggerName );
  ATH_MSG_DEBUG( "Using: " << m_taggerCut );
  ATH_MSG_DEBUG( "Using: " << m_passBTagName );

  // Retrieve the OverlapRemovalTool
  ATH_CHECK(m_OverlapRemovalToolList.retrieve());

  // Create a list of accessors for getting the overlap information that the
  // overlap removal tool decorated to the objects
  for ( std::size_t i=0; i<m_overlapLabels.value().size(); ++i ){
    m_accOverlapsList.push_back( SG::AuxElement::Accessor<char>( m_overlapLabels.value().at(i) ) );
  }

  // Setup the lists of booleans for which overlap decision to use to write out the objects
  if ( m_writeElectronOverlaps.empty() ){
    for ( std::size_t i=0; i<m_OverlapRemovalToolList.size(); ++i ){
      m_writeElectronOverlaps.push_back(true);
    }
  }
  if ( m_writeMuonOverlaps.empty() ){
    for ( std::size_t i=0; i<m_OverlapRemovalToolList.size(); ++i ){
      m_writeMuonOverlaps.push_back(true);
    }
  }
  if ( m_writeJetOverlaps.empty() ){
    for ( std::size_t i=0; i<m_OverlapRemovalToolList.size(); ++i ){
      m_writeJetOverlaps.push_back(true);
    }
  }
  if ( m_writeFatJetOverlaps.empty() ){
    for ( std::size_t i=0; i<m_OverlapRemovalToolList.size(); ++i ){
      m_writeFatJetOverlaps.push_back(true);
    }
  }

  return StatusCode::SUCCESS;
}



StatusCode HWW::OverlapRemovalAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release all tools
  ATH_CHECK( m_OverlapRemovalToolList.release() );

  return StatusCode::SUCCESS;
}



StatusCode HWW::OverlapRemovalAlg::execute()
{
  // Get input containers (should be view containers of selected electrons, muons, and jets)
  const xAOD::ElectronContainer* electrons = nullptr;
  if (!(m_inElCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( electrons, m_inElCont.value() ) );}
  const xAOD::MuonContainer* muons = nullptr;
  if (!(m_inMuCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( muons, m_inMuCont.value() ) );}
  const xAOD::JetContainer* jets = nullptr;
  if (!(m_inJetCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( jets, m_inJetCont.value() ) );}
  // else {
  //   // we need to create an empty dummy jet container since it is required by the tool
  //   jets = new xAOD::JetContainer( SG::VIEW_ELEMENTS );
  // }
  const xAOD::JetContainer* fatJets = nullptr;
  if (!(m_inFatJetCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( fatJets, m_inFatJetCont.value() ) );}


  // HACK: as the current overlap removal tool requires each object to have a
  // <char>("selected") decoration, we add them here for all inputs
  static SG::AuxElement::Decorator<char> selDeco("selected");

  // Define the decorators outside of the loop, such that it will be fully cached
  SG::AuxElement::Decorator<char>* decPassBTag = nullptr;
  if ( !(m_passBTagName.value().empty()) ) decPassBTag = new SG::AuxElement::Decorator<char>(m_passBTagName.value());


  // Run over input containers and fill output containers with objects which passed the OR.
  // The resulting output view containers are recorded to StoreGate.
  if (electrons){
    for(const xAOD::Electron* electron : *electrons){
      selDeco(*electron) = static_cast<char>(true);
    }
  }
  if (muons){
    for(const xAOD::Muon* muon : *muons){
      selDeco(*muon) = static_cast<char>(true);
    }
  }
  if (jets){
    for(const xAOD::Jet* jet : *jets){
      selDeco(*jet) = static_cast<char>(true);
      // Also tag each jet, if it passes the b-tagging requirement
      // if ( !(m_passBTagName.value().empty()) ){
      if (decPassBTag){
        const xAOD::BTagging* btag = jet->btagging();
        if (!btag) {
          ATH_MSG_ERROR("Couldn't find the xAOD::BTagging object for the current jet");
          return StatusCode::FAILURE;
        }
        double bTagWeight = 0.0;
        if ( !(btag->MVx_discriminant(m_taggerName.value(),bTagWeight)) ) {
          ATH_MSG_ERROR("Couldn't find the tagger with name " << m_taggerName.value());
          return StatusCode::FAILURE;
        }
        bool passBTag = false;
        if ( bTagWeight > m_taggerCut.value() ){ passBTag = true; }
        bool isBTagged = passBTag && (jet->pt() > 20.0*GeV );
        (*decPassBTag)(*jet) = static_cast<char>(isBTagged);
      }
    }
  }
  if (fatJets){
    for(const xAOD::Jet* jet : *fatJets){
      selDeco(*jet) = static_cast<char>(true);
    }
  }

  // Clean up
  if (decPassBTag) delete decPassBTag;



  // Apply OverlapRemovalTool, which decorates the respective objects with an "overlaps" tag, which is false if they pass OR and true if they fail
  // ATH_CHECK( m_OverlapRemovalTool->removeOverlaps(electrons, muons, jets, nullptr, nullptr, fatJets) );
  // Loop over all given instances of the overlap removal tool
  for ( std::size_t toolIdx=0; toolIdx < m_OverlapRemovalToolList.size(); ++toolIdx ) {
    // Apply OverlapRemovalTool, which decorates the respective objects with an "overlaps" tag, which is false if they pass OR and true if they fail
    ATH_CHECK( m_OverlapRemovalToolList[toolIdx]->removeOverlaps(electrons, muons, jets, nullptr, nullptr, fatJets) );
  }


  // // Clean up temporary containers
  // if (m_inJetCont.value().empty()){
  //   delete jets;
  //   jets = nullptr;
  // }

  // Create a static accessor for getting the overlap information that the
  // overlap removal tool decorated to the objects
  // static SG::AuxElement::Accessor<char> accOverlaps("overlaps");
  // std::vector< SG::AuxElement::Accessor<char> > m_accOverlapsList;
  // for ( std::size_t i=0; i<m_overlapLabels.value().size(); ++i ){
  //   accOverlapsList.push_back( SG::AuxElement::Accessor<char> accOverlaps( m_overlapLabels.value().at(i) ) );
  // }



  // Run over input containers and fill output containers with objects which passed the OR.
  // The resulting output view containers are recorded to StoreGate.
  if (electrons){
    xAOD::ElectronContainer* outElCont = new xAOD::ElectronContainer( SG::VIEW_ELEMENTS );
    // ConstDataVector<xAOD::ElectronContainer>* outElCont = new ConstDataVector<xAOD::ElectronContainer>(SG::VIEW_ELEMENTS);
    ATH_CHECK( evtStore()->record ( outElCont, m_outElCont.value() ) );
    ATH_MSG_DEBUG("Recorded overlap-removed electron container with name " << m_outElCont.value() );
    for(const xAOD::Electron* electron : *electrons){
      bool passedOR = this->passOR(electron,m_writeElectronOverlaps);
      if(passedOR) outElCont->push_back( const_cast<xAOD::Electron*>(electron) );
      // if(passedOR) outElCont->push_back(electron);
    }
  }
  if (muons){
    xAOD::MuonContainer* outMuCont = new xAOD::MuonContainer( SG::VIEW_ELEMENTS );
    // ConstDataVector<xAOD::MuonContainer>* outMuCont = new ConstDataVector<xAOD::MuonContainer>(SG::VIEW_ELEMENTS);
    ATH_CHECK( evtStore()->record ( outMuCont, m_outMuCont.value() ) );
    ATH_MSG_DEBUG("Recorded overlap-removed muon container with name " << m_outMuCont.value() );
    for(const xAOD::Muon* muon : *muons){
      bool passedOR = this->passOR(muon,m_writeMuonOverlaps);
      if(passedOR) outMuCont->push_back( const_cast<xAOD::Muon*>(muon) );
      // if(passedOR) outMuCont->push_back(muon);
    }
  }
  if (jets){
    xAOD::JetContainer* outJetCont = new xAOD::JetContainer( SG::VIEW_ELEMENTS );
    // ConstDataVector<xAOD::JetContainer>* outJetCont = new ConstDataVector<xAOD::JetContainer>(SG::VIEW_ELEMENTS);
    ATH_CHECK( evtStore()->record ( outJetCont, m_outJetCont.value() ) );
    ATH_MSG_DEBUG("Recorded overlap-removed jet container with name " << m_outJetCont.value() );
    for(const xAOD::Jet* jet : *jets){
      bool passedOR = this->passOR(jet,m_writeJetOverlaps);
      if(passedOR) outJetCont->push_back( const_cast<xAOD::Jet*>(jet) );
      // if(passedOR) outJetCont->push_back(jet);
    }
  }
  if (fatJets){
    xAOD::JetContainer* outFatJetCont = new xAOD::JetContainer( SG::VIEW_ELEMENTS );
    // ConstDataVector<xAOD::JetContainer>* outFatJetCont = new ConstDataVector<xAOD::JetContainer>(SG::VIEW_ELEMENTS);
    ATH_CHECK( evtStore()->record ( outFatJetCont, m_outFatJetCont.value() ) );
    ATH_MSG_DEBUG("Recorded overlap-removed large-R jet container with name " << m_outFatJetCont.value() );
    for(const xAOD::Jet* jet : *fatJets){
      bool passedOR = this->passOR(jet,m_writeFatJetOverlaps);
      if(passedOR) outFatJetCont->push_back( const_cast<xAOD::Jet*>(jet) );
      // if(passedOR) outFatJetCont->push_back(jet);
    }
  }

  // Dump the content of StoreGate
  // ATH_MSG_VERBOSE("Current event store content: " << evtStore()->dump() );

  return StatusCode::SUCCESS;
}


// Private function to check if an object passes the overlap removal
bool HWW::OverlapRemovalAlg::passOR( const xAOD::IParticle* part, const std::vector<bool>& decisionVector ) const
{
  ATH_MSG_DEBUG("In passOR... having " << m_accOverlapsList.size() << " overlap accessors to check");
  for ( std::size_t i=0; i<m_accOverlapsList.size(); ++i ){
    const bool overlaps = static_cast<bool>(m_accOverlapsList[i](*part));
    ATH_MSG_VERBOSE("Found a particle of type " << part->type()
                    << " at container index " << part->index()
                    << " and at overlap index " << i
                    << " using this one to make write-decision " << decisionVector[i]
                    << " with overlaps = " << overlaps );
    if ( decisionVector[i] && overlaps == false ){
      return true;
    }
  }
  return false;
}
