#ifndef HWWCOMMONXAODCODE_HWWFULLEVENTBUILDERALG_H
#define HWWCOMMONXAODCODE_HWWFULLEVENTBUILDERALG_H 1

#include "AthenaBaseComps/AthAlgorithm.h"

// EDM includes
#include "xAODParticleEvent/CompositeParticleContainerFwd.h"
#include "xAODJet/JetContainer.h"

// forward declarations
namespace xAOD{
  class IParticle;
}



// Put everything into a HWW namespace
namespace HWW {

  class FullEventBuilderAlg: public ::AthAlgorithm
  {
  public:
    /// Default constructor
    FullEventBuilderAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Default destructor
    virtual ~FullEventBuilderAlg();

    /// Default athena initialize hook
    virtual StatusCode  initialize();

    /// Default athena execute hook
    virtual StatusCode  execute();

    /// Default athena finalize hook
    virtual StatusCode  finalize();


  private:
    /// Helper method to check if two particles are equal
    bool isEqual( const xAOD::IParticle* partA, const xAOD::IParticle* partB ) const;


  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// Name of the input lepton 1 container
    StringProperty m_lep1Cont;

    /// Name of the input lepton 2 container
    StringProperty m_lep2Cont;

    /// Name of the input jet container
    StringProperty m_jetCont;

    /// Name of the input missingET container
    StringProperty m_metCont;

    /// Name of the input missingET object
    StringProperty m_metObj;

    /// Name of the input container for other electrons, i.e., the ones for the third lepton veto
    StringProperty m_otherElCont;

    /// Name of the input container for other muons, i.e., the ones for the third lepton veto
    StringProperty m_otherMuCont;

    /// Name of the input container for other jets, i.e., the ones for the sub-threshold jets
    StringProperty m_otherJetCont;

    /// Name of the output event container
    StringProperty m_eventCont;

    /// Decide if we want to write a fully-split AuxContainer such that we can remove any variables
    BooleanProperty m_writeSplitAux;

    /// Name of the leading-lepton pt cut
    DoubleProperty m_cutLeadLepPt;

    /// @}

  };

}

#endif //> !HWWCOMMONXAODCODE_HWWFULLEVENTBUILDERALG_H
