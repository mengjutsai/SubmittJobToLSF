///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMuonSelectionTool.cxx
// Implementation file for class HWW::MuonSelectionTool
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWMuonSelectionTool.h"

// STL includes
#include <climits>
#include <cmath>
#include <string>

// FrameWork includes
#include "GaudiKernel/IToolSvc.h"

// EDM includes
#include "xAODBase/ObjectType.h"
#include "xAODBase/IParticle.h"
#include "xAODMuon/Muon.h"
#include "xAODTracking/TrackingPrimitives.h"
#include "xAODTracking/Vertex.h"


// Constructors
////////////////
HWW::MuonSelectionTool::MuonSelectionTool( std::string name ) :
  asg::AsgTool(name),
  m_doPtCut(false),
  m_doEtaCut(false),
  m_doZ0Cut(false),
  m_doD0Cut(false),
  m_d0MaxSquare(0.0),
  m_cutPosition_pt(-9),
  m_cutPosition_eta(-9),
  m_cutPosition_id(-9),
  m_cutPosition_innerDet(-9),
  m_cutPosition_z0(-9),
  m_cutPosition_d0(-9),
  m_cutPosition_caloIso(-9),
  m_cutPosition_trackIso(-9)
{
  //
  // Property declaration
  //
  declareProperty( "CutPtMin", m_ptMin=-99999.0, "The muon.pt() minimum cut value" );
  m_ptMin.declareUpdateHandler( &HWW::MuonSelectionTool::setupPtCut, this );

  declareProperty( "CutAbsEtaMax",      m_absEtaMax=DBL_MAX,   "The |muon.cluster().eta()| maximum cut value" );
  m_absEtaMax.declareUpdateHandler( &HWW::MuonSelectionTool::setupEtaCut, this );

  declareProperty( "CutIDList", m_idList, "The muon identification selection list" );
  declareProperty( "CutIDPtMinList", m_idPtMinList,
                   "The muon.pt minimum cuts for the identification selection; must be ordered from lowest to highest" );

  declareProperty( "CutInnerDetectorHits", m_doInDetCut=false, "The muon inner detector hit cuts" );

  declareProperty( "CutZ0SinThetaMax", m_z0Max=FLT_MAX, "The muon z0 maximum cut value" );
  m_z0Max.declareUpdateHandler( &HWW::MuonSelectionTool::setupZ0Cut, this );

  declareProperty( "CutD0SignificanceMax", m_d0Max=FLT_MAX, "The muon d0 maximum cut value" );
  m_d0Max.declareUpdateHandler( &HWW::MuonSelectionTool::setupD0Cut, this );

  declareProperty( "CaloIsoList", m_caloIsoList, "The calorimetric isolation types list" );
  declareProperty( "CaloIsoRelativeMaxCutList", m_caloIsoRelMaxList, "The relativ calorimetric isolation maximum cut list" );
  declareProperty( "CaloIsoMaxCutList", m_caloIsoMaxList, "The absolute calorimetric isolation maximum cut list" );
  declareProperty( "CutCaloIsoPtMinList", m_caloIsoPtMinList,
                   "The minimum pt cuts for the calorimetric isolation list" );

  declareProperty( "TrackIsoList", m_trkIsoList, "The track isolation types list" );
  declareProperty( "TrackIsoRelativeMaxCutList", m_trkIsoRelMaxList, "The relativ track isolation maximum cut list" );
  declareProperty( "TrackIsoMaxCutList", m_trkIsoMaxList, "The absolute track isolation maximum cut list" );
  declareProperty( "CutTrackIsoPtMinList", m_trkIsoPtMinList,
                   "The minimum pt cuts for the track isolation list" );
}




// Destructor
///////////////
HWW::MuonSelectionTool::~MuonSelectionTool()
{}




// Athena algtool's Hooks
////////////////////////////
StatusCode HWW::MuonSelectionTool::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_ptMin );
  ATH_MSG_DEBUG( "Using: " << m_absEtaMax );
  ATH_MSG_DEBUG( "Using: " << m_idList );
  ATH_MSG_DEBUG( "Using: CutIDPtMinList=" << m_idPtMinList );
  ATH_MSG_DEBUG( "Using: " << m_doInDetCut );
  ATH_MSG_DEBUG( "Using: " << m_z0Max );
  ATH_MSG_DEBUG( "Using: " << m_d0Max );
  ATH_MSG_DEBUG( "Using: " << m_caloIsoList );
  ATH_MSG_DEBUG( "Using: CaloIsoRelativeMaxCutList=" << m_caloIsoRelMaxList );
  ATH_MSG_DEBUG( "Using: CaloIsoMaxCutList=" << m_caloIsoMaxList );
  ATH_MSG_DEBUG( "Using: CutCaloIsoPtMinList=" << m_caloIsoPtMinList );
  ATH_MSG_DEBUG( "Using: " << m_trkIsoList );
  ATH_MSG_DEBUG( "Using: TrackIsoRelativeMaxCutList=" << m_trkIsoRelMaxList );
  ATH_MSG_DEBUG( "Using: TrackIsoMaxCutList=" << m_trkIsoMaxList );
  ATH_MSG_DEBUG( "Using: CutTrackIsoPtMinList=" << m_trkIsoPtMinList );

  // Massage the muon identifiaction cut lists
  if ( m_idPtMinList.empty() && !(m_idList.value().empty()) ) {
    for ( std::size_t i=0; i<m_idList.value().size(); ++i ) {
      m_idPtMinList.push_back(-1.0*DBL_MAX);
    }
  }

  // Perform some sanity checks on the given lists
  if ( !(m_caloIsoList.value().empty()) ) {
    if ( !(m_caloIsoRelMaxList.empty())
         && m_caloIsoRelMaxList.size() != m_caloIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_caloIsoList.name() << " is " << m_caloIsoList.value().size()
                    << " and size of CaloIsoRelativeMaxCutList is " << m_caloIsoRelMaxList.size() );
    }
    if ( !(m_caloIsoMaxList.empty())
         && m_caloIsoMaxList.size() != m_caloIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_caloIsoList.name() << " is " << m_caloIsoList.value().size()
                    << " and size of CaloIsoMaxCutList is " << m_caloIsoMaxList.size() );
    }
    if ( !(m_caloIsoPtMinList.empty())
         && m_caloIsoPtMinList.size() != m_caloIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_caloIsoList.name() << " is " << m_caloIsoList.value().size()
                    << " and size of CutCaloIsoPtMinList is " << m_caloIsoPtMinList.size() );
    }
  }
  // If any other list is empty, fill it with negative infinities
  if ( m_caloIsoRelMaxList.empty() ) {
    for ( std::size_t i=0; i<m_caloIsoList.value().size(); ++i ) {
      m_caloIsoRelMaxList.push_back(FLT_MAX);
    }
  }
  if ( m_caloIsoMaxList.empty() ) {
    for ( std::size_t i=0; i<m_caloIsoList.value().size(); ++i ) {
      m_caloIsoMaxList.push_back(FLT_MAX);
    }
  }
  if ( m_caloIsoPtMinList.empty() ) {
    for ( std::size_t i=0; i<m_caloIsoList.value().size(); ++i ) {
      m_caloIsoPtMinList.push_back(-1.0*DBL_MAX);
    }
  }
  // Perform some sanity checks on the given lists
  if ( !(m_trkIsoList.value().empty()) ) {
    if ( !(m_trkIsoRelMaxList.empty())
         && m_trkIsoRelMaxList.size() != m_trkIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_trkIsoList.name() << " is " << m_trkIsoList.value().size()
                    << " and size of TrackIsoRelativeMaxCutList is " << m_trkIsoRelMaxList.size() );
    }
    if ( !(m_trkIsoMaxList.empty())
         && m_trkIsoMaxList.size() != m_trkIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_trkIsoList.name() << " is " << m_trkIsoList.value().size()
                    << " and size of TrackIsoMaxCutList is " << m_trkIsoMaxList.size() );
    }
    if ( !(m_trkIsoPtMinList.empty())
         && m_trkIsoPtMinList.size() != m_trkIsoList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_trkIsoList.name() << " is " << m_trkIsoList.value().size()
                    << " and size of CutTrackIsoPtMinList is " << m_trkIsoPtMinList.size() );
    }
  }
  // If any other list is empty, fill it with negative infinities
  if ( m_trkIsoRelMaxList.empty() ) {
    for ( std::size_t i=0; i<m_trkIsoList.value().size(); ++i ) {
      m_trkIsoRelMaxList.push_back(FLT_MAX);
    }
  }
  if ( m_trkIsoMaxList.empty() ) {
    for ( std::size_t i=0; i<m_trkIsoList.value().size(); ++i ) {
      m_trkIsoMaxList.push_back(FLT_MAX);
    }
  }
  if ( m_trkIsoPtMinList.empty() ) {
    for ( std::size_t i=0; i<m_trkIsoList.value().size(); ++i ) {
      m_trkIsoPtMinList.push_back(-1.0*DBL_MAX);
    }
  }


  // Caluculate some internal variables
  if ( m_doD0Cut ) {
    m_d0MaxSquare = m_d0Max.value() * m_d0Max.value();
  }


  // --------------------------------------------------------------------------
  // Register the cuts and check that the registration worked:
  // NOTE: THE ORDER IS IMPORTANT!!! Cut0 corresponds to bit 0, Cut1 to bit 1,...
  // if ( m_cutPosition_nSCTMin < 0 ) sc = 0; // Exceeded the number of allowed cuts

  // Register the pt cut
  if ( m_doPtCut ) {
    ATH_MSG_DEBUG("Registering pt cut");
    m_cutPosition_pt = m_accept.addCut( "PtCut", Form("pt > %g GeV", m_ptMin.value() * 0.001) );
    if ( m_cutPosition_pt < 0 ) {
      ATH_MSG_ERROR("Couldn't book Muon pt cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the eta cut
  if ( m_doEtaCut ) {
    ATH_MSG_DEBUG("Registering eta cut");
    m_cutPosition_eta = m_accept.addCut( "EtaCut", Form("abs(eta) < %g", m_absEtaMax.value()) );
    if ( m_cutPosition_eta < 0 ) {
      ATH_MSG_ERROR("Couldn't book Muon eta cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the identification cut
  if ( !(m_idList.value().empty()) ) {
    ATH_MSG_DEBUG("Registering identification cut");
    // Build the cut decsription name
    std::string cutDescription("");
    if ( m_idPtMinList.empty() && m_idList.value().size() == 1 ) {
      cutDescription = m_idList.value().at(0);
    }
    else if ( m_idPtMinList.size() == m_idList.value().size() ) {
      // We have pt-dependent identification cuts
      const std::size_t maxIdx = m_idPtMinList.size();
      for ( std::size_t i=0; i<maxIdx; ++i ) {
        cutDescription += " (";
        cutDescription += Form( "%f", m_idPtMinList.at(i) * 0.001 );
        cutDescription += " GeV < ptMu && ID=";
        cutDescription += m_idList.value().at(i);
        cutDescription += ") ";
      }
    }
    // Actually register the cut
    m_cutPosition_id = m_accept.addCut( "IdentificationCut", cutDescription );
    if ( m_cutPosition_id < 0 ) {
      ATH_MSG_ERROR("Couldn't book Muon identificaion cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the inner detector cut
  if ( m_doInDetCut.value() ) {
    ATH_MSG_DEBUG("Registering inner detector cut");
    m_cutPosition_innerDet = m_accept.addCut( "InDetCut", Form("Require inner detector cuts: %d", m_doInDetCut.value()) );
    if ( m_cutPosition_innerDet < 0 ) {
      ATH_MSG_ERROR("Couldn't book muon inner detector cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the z0 cut
  if ( m_doZ0Cut ) {
    ATH_MSG_DEBUG("Registering z0 cut");
    m_cutPosition_z0 = m_accept.addCut( "Z0Cut", Form("abs(z0*sin(theta)) < %g mm", m_z0Max.value()) );
    if ( m_cutPosition_z0 < 0 ) {
      ATH_MSG_ERROR("Couldn't book Muon z0 cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the d0 cut
  if ( m_doD0Cut ) {
    ATH_MSG_DEBUG("Registering d0 cut");
    m_cutPosition_d0 = m_accept.addCut( "D0Cut", Form("abs(d0/d0err) < %g", m_d0Max.value()) );
    if ( m_cutPosition_d0 < 0 ) {
      ATH_MSG_ERROR("Couldn't book Muon d0 cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the calo isolation cut
  if ( !(m_caloIsoList.value().empty()) ) {
    ATH_MSG_DEBUG("Registering calo isolation cut");
    // Build the cut decsription name
    std::string cutDescription("");
    for ( std::size_t i=0; i<m_caloIsoList.value().size(); ++i ) {
      cutDescription += " (";
      cutDescription += Form( "%f", m_caloIsoPtMinList.at(i) * 0.001 );
      cutDescription += " GeV < ptEle && iso=";
      cutDescription += Form( "%u", m_caloIsoList.value().at(i) );
      cutDescription += ") ";
    }
    m_cutPosition_caloIso = m_accept.addCut( "CaloIsoCut", cutDescription );
    if ( m_cutPosition_caloIso < 0 ) {
      ATH_MSG_ERROR("Couldn't book Muon calo isolation cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the track isolation cut
  if ( !(m_trkIsoList.value().empty()) ) {
    ATH_MSG_DEBUG("Registering track isolation cut");
    // Build the cut decsription name
    std::string cutDescription("");
    for ( std::size_t i=0; i<m_trkIsoList.value().size(); ++i ) {
      cutDescription += " (";
      cutDescription += Form( "%f", m_trkIsoPtMinList.at(i) * 0.001 );
      cutDescription += " GeV < ptEle && iso=";
      cutDescription += Form( "%u", m_trkIsoList.value().at(i) );
      cutDescription += ") ";
    }
    m_cutPosition_trackIso = m_accept.addCut( "TrackIsoCut", cutDescription );
    if ( m_cutPosition_trackIso < 0 ) {
      ATH_MSG_ERROR("Couldn't book Muon track isolation cut");
      return StatusCode::FAILURE;
    }
  }

  return StatusCode::SUCCESS;
}




StatusCode HWW::MuonSelectionTool::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  return StatusCode::SUCCESS;
}




// Method to get the plain TAccept.
const Root::TAccept& HWW::MuonSelectionTool::getTAccept( ) const
{
  return m_accept;
}




// The main accept method: the actual cuts are applied here
const Root::TAccept& HWW::MuonSelectionTool::accept( const xAOD::IParticle* part,
                                                     const xAOD::Vertex* primVtx ) const
{
  // Reset the cut result bits to zero (= fail cut)
  m_accept.clear();

  // cast to an Muon
  if ( part->type() != xAOD::Type::Muon ) {
    ATH_MSG_ERROR("Didn't get an IParticle of type Muon... exiting");
    return m_accept;
  }
  const xAOD::Muon* muon = static_cast<const xAOD::Muon*>(part);
  if ( !muon ) {
    ATH_MSG_ERROR("Couldn't cast to an Muon");
    return m_accept;
  }


  // ---------------------------------------------------------------------------
  // Do the actual selection:
  // If a cut is not passed, we return and the subsequent cuts are not tried out

  // Apply the pt selection, if requested
  const double muPt = muon->pt();
  if ( m_doPtCut ) {
    ATH_MSG_VERBOSE("Going to do pt selection");
    const bool passCut = muPt > m_ptMin.value();
    m_accept.setCutResult( m_cutPosition_pt, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing pt cut");
      return m_accept;
    }
  } // End: do pt cut


  // Apply the eta selection, if requested
  if ( m_doEtaCut ) {
    ATH_MSG_VERBOSE("Going to do eta selection");
    const double muAbsEta = std::abs(muon->eta());
    const bool passCut = ( (muAbsEta < m_absEtaMax.value() ) );
    m_accept.setCutResult( m_cutPosition_eta, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing eta cut");
      return m_accept;
    }
  } // End: if ( m_doEtaCut )


  // Do the Muon identification selection, if requested
  if ( !(m_idList.value().empty()) ) {
    ATH_MSG_VERBOSE("Going to do identification selection");
    // Get muon quality from previously decorated tag
    static SG::AuxElement::Accessor<int>   accSetMuQuality("Quality");
    static SG::AuxElement::Accessor<char> accSetMuPassedIDCuts("PassesIDCuts");
    static SG::AuxElement::Accessor<char> accSetMuHighPtCuts("PassesHighPtCuts");
    // const xAOD::Muon::Quality muonQuality = static_cast<xAOD::Muon::Quality>(accSetMuQuality(*muon));
    const unsigned int muonQuality = static_cast<unsigned int>(accSetMuQuality(*muon));
    const bool passesIDCuts        = static_cast<bool>(accSetMuPassedIDCuts(*muon));
    const bool passesHighPtCuts    = static_cast<bool>(accSetMuHighPtCuts(*muon));
    // Loop over all cut values. If any of them passes, we accept this muon
    bool passCut(false);
    const std::size_t maxIdx = m_idList.value().size();
    for ( std::size_t i=0; i<maxIdx; ++i ) {
      // If this object is already accepted, we don't need to look furhter
      if (passCut) break;
      // Get the currently requested muon quality number (Tight=0, Medium=1, Loose=2, VeryLoose=3, HighPt=4)
      const unsigned int qualityType = m_idList.value().at(i);
      // Check in which pt-bin we are
      const double ptMin = m_idPtMinList.at(i);
      if ( i+1 < maxIdx ) {
        const double ptMax = m_idPtMinList.at(i+1);
        const double deltaPt = std::abs(ptMax - ptMin);
        if( deltaPt < 0.1 || ( ptMin <= muPt && muPt < ptMax ) ) {
          ATH_MSG_VERBOSE("Check if muon quality is " << qualityType << " for pT bin ( " << ptMin << " < " << muPt << " < " << ptMax << " )");
          if ( qualityType == 4 ){ passCut = (passesIDCuts && passesHighPtCuts); }
          else { passCut = ( qualityType >= muonQuality ); }
        }
      }
      else if ( ptMin <= muPt ) {
        ATH_MSG_VERBOSE("Check if muon quality is " << qualityType << " for pT bin ( " << ptMin << " < " << muPt << " )");
        if ( qualityType == 4 ){ passCut = (passesIDCuts && passesHighPtCuts); }
        else { passCut = ( qualityType >= muonQuality ); }
      }
    } // End: loop over all pt bins
    // Return if any of the muons passes the selection
    m_accept.setCutResult( m_cutPosition_id, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing identification cut");
      return m_accept;
    }
  } // End: do Muon identification selection


  // Apply the inner detector cuts, if requested
  if ( m_doInDetCut.value() ) {
    ATH_MSG_VERBOSE("Going to do passesIDCuts selection" );
    // Get the passedIDCuts decision from previously decorated tag
    const bool passCut = (muon->auxdata<char>("PassesIDCuts") != 0);
    m_accept.setCutResult( m_cutPosition_innerDet, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing inner detector hits cut");
      return m_accept;
    }
  } // End do inner detector selection


  // // Get the TrackParticle, if needed
  // const xAOD::TrackParticle* trackPart(0);
  // if ( m_doZ0Cut || m_doD0Cut ) {
  //   trackPart = muon->trackParticle(xAOD::Muon::TrackParticleType::InnerDetectorTrackParticle);
  //   if ( !trackPart ) {
  //     ATH_MSG_VERBOSE("Couldn't get inner detector track particle... trying to get primary one");
  //     trackPart = muon->trackParticle(xAOD::Muon::TrackParticleType::Primary);
  //   }
  //   if ( !trackPart ) {
  //     ATH_MSG_ERROR("Couldn't get the TrackParticle for this Muon");
  //     return m_accept;
  //   }
  // }


  // Do the track impact parameter z0 cut, if requested
  if ( m_doZ0Cut && primVtx ) {
    ATH_MSG_VERBOSE("Going to do z0 selection");
    // // The TrackParticle is expressed w.r.t. the beam spot. Thus, we need to
    // // do some gymnastics in order to get it w.r.t. the primary vertex.
    // const float z0 = trackPart->z0() + trackPart->vz() - primVtx->z();
    // const float z0sinTheta = std::abs( z0 * std::sin(trackPart->theta()) );

    // Get the value that we pre-computed earlier
    const float z0 = muon->auxdata<float>("z0");
    const float z0sinTheta = std::abs(z0 * muon->auxdata<float>("sinTheta") );
    const bool passCut = z0sinTheta < m_z0Max.value();
    m_accept.setCutResult( m_cutPosition_z0, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing z0 cut");
      return m_accept;
    }
  } // End: do z0 cut


  // Do the track impact parameter d0 cut, if requested
  if ( m_doD0Cut ) {
    ATH_MSG_VERBOSE("Going to do d0 selection");
    bool passCut(false);
    //const float d0 = muon->auxdata<float>("d0");
    //const float d0err = muon->auxdata<float>("d0err");
    const float d0signif = muon->auxdata<float>("d0sig");
    //if ( d0err != 0.0 ){ d0signif = std::abs( d0/d0err ); }
    passCut = std::abs(d0signif) < m_d0Max.value();
    m_accept.setCutResult( m_cutPosition_d0, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing d0 cut with values: (d0/d0err)=" << d0signif << ", (cut value): " << m_d0Max.value() );
      return m_accept;
    }
  }


  // Do the calorimetric isolation cut, if requested
  if ( !(m_caloIsoList.value().empty()) ) {
    ATH_MSG_VERBOSE("Going to do calo isolation selection");
    bool passCut(false);
    if ( muPt <= 0.0 ) {
      ATH_MSG_WARNING("Failing calo isolation cut due to negative pt");
      return m_accept;
    }
    const double invMuPt = 1.0/muPt;
    // Iterate over all given calo isolation types
    for ( std::size_t i=0; i<m_caloIsoList.value().size(); ++i ) {
      const xAOD::Iso::IsolationType isoType
          = static_cast<xAOD::Iso::IsolationType>(m_caloIsoList.value().at(i));
      // Get the isolation value
      float iso(0.0);
      if ( !(muon->isolation(iso, isoType)) ) {
        ATH_MSG_ERROR("Didn't find the isolation of type: " << isoType );
        return m_accept;
      }
      const double minPtCut        = m_caloIsoPtMinList.at(i);
      double nextPtCut(DBL_MAX);
      if ( i+1 < m_caloIsoPtMinList.size() ) { nextPtCut = m_caloIsoPtMinList.at(i+1); }
      const float maxCaloIsoCut    = m_caloIsoMaxList.at(i);
      const float maxRelCaloIsoCut = m_caloIsoRelMaxList.at(i);
      if ( minPtCut < muPt && muPt < nextPtCut) {
        ATH_MSG_VERBOSE("Check if muon has isolationtype " << static_cast<int>(isoType) << " / pt ( " << (iso*invMuPt) << " < " << maxRelCaloIsoCut << " )" << " for pT bin ( " << minPtCut << " < " << muPt << " < " << nextPtCut << " )");
      if( iso < maxCaloIsoCut && (iso*invMuPt) < maxRelCaloIsoCut ) {
          passCut = true; // We passed the isolation cut
        }
        break; // We are in the right pt-bin, nothing more to do here
      }
    } // End: loop over all calo iso types
    m_accept.setCutResult( m_cutPosition_caloIso, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing calo isolation cut");
      return m_accept;
    }
  } // End: calorimetric isolation selection


  // Do the track-based isolation cut, if requested
  if ( !(m_trkIsoList.value().empty()) ) {
    ATH_MSG_VERBOSE("Going to do track isolation selection");
    bool passCut(false);
    if ( muPt <= 0.0 ) {
      ATH_MSG_WARNING("Failing track isolation cut due to negative pt");
      return m_accept;
    }
    const double invMuPt = 1.0/muPt;
    // Iterate over all given trk isolation types
    for ( std::size_t i=0; i<m_trkIsoList.value().size(); ++i ) {
      const xAOD::Iso::IsolationType isoType
          = static_cast<xAOD::Iso::IsolationType>(m_trkIsoList.value().at(i));
      // Get the isolation value
      float iso(0.0);
      if ( !(muon->isolation(iso, isoType)) ) {
        ATH_MSG_ERROR("Didn't find the isolation of type: " << isoType );
        return m_accept;
      }
      const double minPtCut        = m_trkIsoPtMinList.at(i);
      double nextPtCut(DBL_MAX);
      if ( i+1 < m_trkIsoPtMinList.size() ) { nextPtCut = m_trkIsoPtMinList.at(i+1); }
      const float maxtrkIsoCut    = m_trkIsoMaxList.at(i);
      const float maxReltrkIsoCut = m_trkIsoRelMaxList.at(i);
      if ( minPtCut < muPt && muPt < nextPtCut ) {
        ATH_MSG_VERBOSE("Check if muon has isolationtype " << static_cast<int>(isoType) << " / pt ( " << (iso*invMuPt) << " < " << maxReltrkIsoCut << " )" << " for pT bin ( " << minPtCut << " < " << muPt << " < " << nextPtCut << " )");
        if( iso < maxtrkIsoCut && (iso*invMuPt) < maxReltrkIsoCut ) {
          passCut = true; // We passed the isolation cut
        }
        break; // We are in the right pt-bin, nothing more to do here
      }
    } // End: loop over all trk iso types
    m_accept.setCutResult( m_cutPosition_trackIso, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing track isolation cut");
      return m_accept;
    }
  } // End: track isolation selection


  return m_accept;
}
