

# Nominal 2-lepton output (Karsten)
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data15.txt                 --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data16.txt                 --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWHighMass.txt     --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignal.txt       --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignalNoSkim.txt --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__CommonOtherBkg.txt  --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__TopBkg.txt          --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SherpaDYBkg.txt     --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__AlpgenDYBkg.txt     --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__MadGraphDYBkg.txt   --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__PowhegDYBkg.txt     --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SystSamples.txt     --do2Lep --writePAOD_2L --writePAOD_2LDF --run

# Systematics 2-lepton output (Sasha)
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWHighMass.txt     --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignal.txt       --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignalNoSkim.txt --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__CommonOtherBkg.txt  --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__TopBkg.txt          --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SherpaDYBkg.txt     --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__AlpgenDYBkg.txt     --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__MadGraphDYBkg.txt   --do2Lep --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__PowhegDYBkg.txt     --do2Lep --writePAOD_2L --writePAOD_2LDF --run


# Nominal VH output (Aaron)
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data15.txt                --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data16.txt                --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWHighMass.txt    --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignal.txt      --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__CommonOtherBkg.txt --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__TopBkg.txt         --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SherpaDYBkg.txt    --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__AlpgenDYBkg.txt    --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__MadGraphDYBkg.txt  --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__PowhegDYBkg.txt    --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SystSamples.txt    --doVH --writePAOD_WH --writePAOD_ZH --run

# Systematics VH output (Yesenia)
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWHighMass.txt    --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignal.txt      --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__CommonOtherBkg.txt --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__TopBkg.txt         --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SherpaDYBkg.txt    --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__AlpgenDYBkg.txt    --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__MadGraphDYBkg.txt  --doVH --writePAOD_WH --writePAOD_ZH --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --doSystematics --forceStaged --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__PowhegDYBkg.txt    --doVH --writePAOD_WH --writePAOD_ZH --run


# Nominal W+jets fakes output (Weimin)
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data15.txt                --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data16.txt                --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWHighMass.txt    --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignal.txt      --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__CommonOtherBkg.txt --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__TopBkg.txt         --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SherpaDYBkg.txt    --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__AlpgenDYBkg.txt    --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__MadGraphDYBkg.txt  --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__PowhegDYBkg.txt    --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run


# Di-jet based fake-factor files (Weimin)
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_data15.txt --doFakeDiJet --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_data16__PeriodAtoF.txt --doFakeDiJet --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_data16__PeriodGtoL.txt --doFakeDiJet --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_mc15c.txt  --doFakeDiJet --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_mc15c__NoPrescale.txt  --doFakeDiJet --run


# Nominal Z+jets fakes output (Claudia)
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data15.txt                --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data16.txt                --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignal.txt      --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__CommonOtherBkg.txt --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__TopBkg.txt         --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SherpaDYBkg.txt    --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__AlpgenDYBkg.txt    --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__MadGraphDYBkg.txt  --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__PowhegDYBkg.txt    --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run






# From here on, we produce the files with the --doVeryLooseLH setting

# Di-jet based fake-factor files
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_data15.txt --doVeryLooseLH --doFakeDiJet --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_data16.txt --doVeryLooseLH --doFakeDiJet --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_mc15c.txt  --doVeryLooseLH --doFakeDiJet --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_mc15c__NoPrescale.txt  --doVeryLooseLH --doFakeDiJet --run


# Nominal Z+jets fakes output
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data15.txt                --doVeryLooseLH --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data16.txt                --doVeryLooseLH --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignal.txt      --doVeryLooseLH --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__CommonOtherBkg.txt --doVeryLooseLH --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__TopBkg.txt         --doVeryLooseLH --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SherpaDYBkg.txt    --doVeryLooseLH --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__AlpgenDYBkg.txt    --doVeryLooseLH --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__MadGraphDYBkg.txt  --doVeryLooseLH --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__PowhegDYBkg.txt    --doVeryLooseLH --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run


# Nominal W+jets fakes output
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data15.txt                --doVeryLooseLH --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data16.txt                --doVeryLooseLH --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWHighMass.txt    --doVeryLooseLH --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignal.txt      --doVeryLooseLH --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__CommonOtherBkg.txt --doVeryLooseLH --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__TopBkg.txt         --doVeryLooseLH --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SherpaDYBkg.txt    --doVeryLooseLH --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__AlpgenDYBkg.txt    --doVeryLooseLH --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__MadGraphDYBkg.txt  --doVeryLooseLH --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__PowhegDYBkg.txt    --doVeryLooseLH --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run





# From here on, we produce the files with the --doVeryLooseLH setting and the other overlap removal

# Di-jet based fake-factor files
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_data15.txt             --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --doFakeDiJet --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_data16.txt             --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --doFakeDiJet --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_mc15c.txt              --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --doFakeDiJet --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D3_mc15c__NoPrescale.txt  --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --doFakeDiJet --run


# Nominal Z+jets fakes output
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data15.txt                --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data16.txt                --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignal.txt      --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__CommonOtherBkg.txt --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__TopBkg.txt         --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SherpaDYBkg.txt    --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__AlpgenDYBkg.txt    --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__MadGraphDYBkg.txt  --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__PowhegDYBkg.txt    --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeZJets --writePAOD_2L --writePAOD_2LDF --writePAOD_2LFake --run


# Nominal W+jets fakes output
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data15.txt                --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_data16.txt                --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWHighMass.txt    --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__HWWSignal.txt      --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__CommonOtherBkg.txt --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__TopBkg.txt         --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__SherpaDYBkg.txt    --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__AlpgenDYBkg.txt    --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__MadGraphDYBkg.txt  --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
#submitGridJobs.py --nFilesPerJob=1 --official --prod --merge --useNewCode --oneOutDS --inDSTextFile samplelist_HIGG3D1_mc15c__PowhegDYBkg.txt    --doVeryLooseLH --doORNoMuNearJetRemoval --doORNoMuNearJetRemovalNoBJetPrecedence --do2Lep --doFakeWJets --writePAOD_2L --writePAOD_2LDF --run
