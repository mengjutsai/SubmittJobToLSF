///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMETReducerAlg.h

#ifndef HWWCOMMONXAODCODE_HWWMETREDUCERALG_H
#define HWWCOMMONXAODCODE_HWWMETREDUCERALG_H

#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"

// Forward declarations
class IMETMaker;



namespace HWW {
  class METReducerAlg : public AthAlgorithm {

  public:

    /// Constructor with parameters:
    METReducerAlg(const std::string& name, ISvcLocator* pSvcLocator);

    /// Destructor:
    ~METReducerAlg();

    /// @name  Athena algorithm's Hooks
    /// @{

    /// The framework's initialize method. Called once before the event loop
    virtual StatusCode  initialize();

    /// The framework's exectue method. Called once for every event
    virtual StatusCode  execute();

    /// The framework's initialize method. Called once after the event loop
    virtual StatusCode  finalize();

    /// @}

  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The name of the input MET container
    StringProperty m_metContName;

    /// @}

  };

}

#endif
