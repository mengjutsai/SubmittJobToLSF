///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMuonDecorationAlg.cxx
// Implementation file for class HWWMuonDecorationAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWMuonDecorationAlg.h"

// STL includes
#include <climits>
#include <cmath>
#include <algorithm>
#include <vector>

// EDM includes
#include "xAODMuon/MuonContainer.h"
#include "xAODTracking/TrackParticleContainer.h"
#include "xAODTracking/VertexContainer.h"
#include "xAODTracking/Vertex.h"
#include "xAODTruth/TruthParticle.h"
#include "xAODTruth/TruthParticleContainer.h"
#include "xAODTracking/TrackParticlexAODHelpers.h"
#include "xAODEventInfo/EventInfo.h"

// Tool includes
#include "PATCore/IAsgSelectionWithVertexTool.h"
#include "MuonAnalysisInterfaces/IMuonSelectionTool.h"
#include "IsolationSelection/IIsolationSelectionTool.h"



// Constructors
////////////////
HWW::MuonDecorationAlg::MuonDecorationAlg( const std::string& name,
                                           ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_inContName(""),
  m_muonSelectionTool(""),
  m_highPtMuonSelectionTool(""),
  m_isoToolList(),
  m_muonIsoWPList(),
  m_doDeltaPt(false),
  m_doImpactParameter(false),
  m_doStandardIsoWP(false),
  m_inPrimVtxCont("PrimaryVertices"),
  m_doTruth(false),
  m_decoAllCopies(false),
  m_containerNameList()
{
  //
  // Property declaration
  //
  declareProperty( "InputContainer",                  m_inContName, "Input container name" );
  declareProperty( "SelectionTool",                   m_muonSelectionTool, "The CP::MuonSelectionTool instance" );
  declareProperty( "HighPtSelectionTool",             m_highPtMuonSelectionTool, "The CP::MuonSelectionTool instance configured with the high-pt selection" );
  declareProperty( "SelectionWithVertexToolList",     m_selectionWithVertexToolList, "List of selection-with-vertex tool instances" );
  declareProperty( "SelectionWithVertexToolDecoList", m_selectionWithVertexDecoList, "List of decoration names for each selection-with-vertex tools" );
  declareProperty( "IsolationToolList" ,              m_isoToolList, "List of CP tool to calculate the lepton isolation" );
  declareProperty( "IsolationToolDecoList",           m_muonIsoWPList, "List of muon isolation working points" );
  declareProperty( "DoDeltaPt",                       m_doDeltaPt, "If true, will calculate and store the relative pt difference between MS and ID" );
  declareProperty( "DoImpactParameter",               m_doImpactParameter, "If true, will calculate and store the z0sinTheta, d0, and d0Err" );
  declareProperty( "PrimaryVertexContainer",          m_inPrimVtxCont, "The input primary vertex container name" );
  declareProperty( "DoTruthInformation",              m_doTruth, "If true, will attach the results of the MCTruthClassifer to the muon directly" );
  declareProperty( "DecorateAllCopies",               m_decoAllCopies, "If true, will decorate all copies of the input container" );
}



// Destructor
///////////////
HWW::MuonDecorationAlg::~MuonDecorationAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::MuonDecorationAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inContName );
  ATH_MSG_DEBUG( "Using: " << m_muonSelectionTool );
  ATH_MSG_DEBUG( "Using: " << m_highPtMuonSelectionTool );
  ATH_MSG_DEBUG( "Using: " << m_selectionWithVertexToolList );
  ATH_MSG_DEBUG( "Using: " << m_selectionWithVertexDecoList );
  ATH_MSG_DEBUG( "Using: " << m_isoToolList );
  ATH_MSG_DEBUG( "Using: " << m_muonIsoWPList );
  ATH_MSG_DEBUG( "Using: " << m_inPrimVtxCont );
  ATH_MSG_DEBUG( "Using DoDeltaPt: " << m_doDeltaPt );
  ATH_MSG_DEBUG( "Using DoImpactParameter: " << m_doImpactParameter );
  ATH_MSG_DEBUG( "Using DoTruthInformation: " << m_doTruth );
  ATH_MSG_DEBUG( "Using DecorateAllCopies: " << m_decoAllCopies );

  // Some sanity checks
  if ( m_selectionWithVertexToolList.size() != m_selectionWithVertexDecoList.value().size() ){
    ATH_MSG_ERROR( "Muon selection-with-vertex tool list is not same size as the SelectionWithVertexToolDecoList size" );
    return StatusCode::FAILURE;
  }

  // Get the needed tools
  if (!m_muonSelectionTool.empty()) ATH_CHECK( m_muonSelectionTool.retrieve() );
  if (!m_highPtMuonSelectionTool.empty()) ATH_CHECK( m_highPtMuonSelectionTool.retrieve() );
  ATH_CHECK( m_selectionWithVertexToolList.retrieve() );
  ATH_CHECK( m_isoToolList.retrieve() );

  return StatusCode::SUCCESS;
}



StatusCode HWW::MuonDecorationAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release the needed tools
  if (!m_muonSelectionTool.empty()) ATH_CHECK( m_muonSelectionTool.release() );
  if (!m_highPtMuonSelectionTool.empty()) ATH_CHECK( m_highPtMuonSelectionTool.release() );
  ATH_CHECK( m_selectionWithVertexToolList.release() );
  ATH_CHECK( m_isoToolList.release() );

  return StatusCode::SUCCESS;
}



StatusCode HWW::MuonDecorationAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Get the EventInfo object
  const xAOD::EventInfo* evtInfo;
  ATH_CHECK( evtStore()->retrieve( evtInfo, "EventInfo" ));
  const bool isSim = evtInfo->eventType(xAOD::EventInfo::EventType::IS_SIMULATION);
  ATH_MSG_VERBOSE("Got EventInfo");

  // Define the decorators outside of the loop as a static, such that it
  // will be fully cached
  static xAOD::Muon::Decorator<ElementLink<xAOD::TrackParticleContainer> > extrapTPLinkDeco("extrapolatedMuonSpectrometerTrackParticleLink");
  static xAOD::Muon::Decorator<float> deltaPtDeco("deltaPt");

  static xAOD::Muon::Decorator<float> chargeIDDeco("chargeID");
  static xAOD::Muon::Decorator<float> chargeMSDeco("chargeMS");
  static xAOD::Muon::Decorator<float> chargeEXDeco("chargeEX");
  static xAOD::Muon::Decorator<float> chargeCBDeco("chargeCB");

  static xAOD::Muon::Decorator<float> z0Deco("z0");
  // static xAOD::Muon::Decorator<float> z0SigDeco("z0sig");
  static xAOD::Muon::Decorator<float> z0ErrDeco("z0err");
  static xAOD::Muon::Decorator<float> sinThetaDeco("sinTheta");
  static xAOD::Muon::Decorator<float> d0Deco("d0");
  static xAOD::Muon::Decorator<float> d0SigDeco("d0sig");
  static SG::AuxElement::Decorator<int>  decTruthType ("truthType");
  static SG::AuxElement::Decorator<int>  decTruthOrigin ("truthOrigin");
  static SG::AuxElement::Decorator<int>  decHWWTruthType ("hwwTruthType");
  static SG::AuxElement::Decorator<int>  decHWWTruthOrigin ("hwwTruthOrigin");

  static SG::AuxElement::Decorator<float>decTruthPt        ("truthPt");
  static SG::AuxElement::Decorator<float>decTruthEta       ("truthEta");
  static SG::AuxElement::Decorator<float>decTruthPhi       ("truthPhi");
  static SG::AuxElement::Decorator<float>decTruthCharge    ("truthCharge");

  static SG::AuxElement::Decorator<int>  decFlavourTag ("flavourTag");

  std::vector< xAOD::Muon::Decorator<char> > isoDecList;
  isoDecList.reserve( m_muonIsoWPList.value().size() );
  for ( std::size_t idxIso=0; idxIso<m_muonIsoWPList.value().size(); ++idxIso ){
    isoDecList.push_back( xAOD::Muon::Decorator<char>( m_muonIsoWPList.value().at(idxIso) ) );
  }

  // Get the primary vertex, if needed
  const xAOD::Vertex* primVtx(0);
  if (m_doImpactParameter) {
    // Get the primary vertex container
    const xAOD::VertexContainer* primVtxCont;
    ATH_CHECK( evtStore()->retrieve( primVtxCont, m_inPrimVtxCont.value() ) );
    // Find "the" primary vertex inside this container
    for ( const auto* vtx : * primVtxCont ) {
      if ( vtx->vertexType() == xAOD::VxType::PriVtx ) {
        primVtx = vtx;
        break;
      }
    }
    if ( !primVtx ) {
      ATH_MSG_WARNING("Couldn't find a primary vertex in this event!");
    }
  }


  // Karsten: Test if the input TruthMuons container actually exists.
  const xAOD::TruthParticleContainer* tmuons = nullptr;
  if (m_doTruth && isSim){
    if ( evtStore()->contains<xAOD::TruthParticleContainer>("TruthMuons") ){
      ATH_CHECK( evtStore()->retrieve( tmuons, "TruthMuons" ) );
    }
    else {
      ATH_MSG_WARNING("Couldn't find the xAOD::TruthParticleContainer 'TruthMuons'. Won't decorate truth four-momentum or charge.");
    }
  }



  // Now, let's try to get all requested muon containers and iterate over them.
  // If not specifically requested to get all copies, only the exactly given
  // name will be retrieved. Otherwise, all containers with the same base-name,
  // i.e, the part before the "___", if present, will be used.
  // Do this expensice string manupulation and StoreGate search only the first time.
  if (m_containerNameList.empty()){
    if (m_decoAllCopies){
      const std::string& inContName = m_inContName.value();
      // First, remove the suffix that is separated by "___", if present
      std::string searchString = inContName;
      std::string::size_type pos = inContName.find("___");
      if(inContName.npos != pos){ searchString = inContName.substr(0, pos); }
      // Now, get all the StoreGate names of existing MuonContainers
      std::vector<std::string> sgKeys;
      evtStore()->keys<xAOD::MuonContainer>(sgKeys);
      ATH_MSG_DEBUG("Found " << sgKeys.size() << " xAOD::MuonContainers in the event store.");
      m_containerNameList.reserve(sgKeys.size());
      // Now, let's find all container names that start with our searchString
      for ( const std::string& item : sgKeys ){
        if ( item.compare(0, searchString.length(), searchString) == 0 ){
          // We found a match, i.e, the current StoreGate key begins with our searchString
          ATH_MSG_DEBUG("Found matching xAOD::MuonContainer name: " << item);
          m_containerNameList.push_back(item);
        }
      }
    }
    else{
      m_containerNameList.push_back(m_inContName.value());
    }
  }

  // Now, iterate over all input container names that were found and use these muon containers.
  for ( const std::string& inName : m_containerNameList ){
    // Open the input containers
    ATH_MSG_VERBOSE("Opening current input container with name: " << inName);
    const xAOD::MuonContainer *inCont(0);
    ATH_CHECK( evtStore()->retrieve( inCont, inName ) );

    // Decorate the muon, if requested
    for ( std::size_t toolIdx=0; toolIdx < m_selectionWithVertexToolList.size(); ++toolIdx ) {
      // Define the decorators outside of the loop, such that it will be fully cached
      SG::AuxElement::Decorator<char> decoSelWVtx (m_selectionWithVertexDecoList.value()[toolIdx]);
      for ( const xAOD::Muon* muon : *inCont){
        const bool passed = m_selectionWithVertexToolList[toolIdx]->accept(muon,primVtx);
        decoSelWVtx(*muon) = static_cast<char>(passed);
      }
    }



    for ( const xAOD::Muon* muon : *inCont ) {
      ATH_MSG_VERBOSE("Looking at muon number " << muon->index() << " with pt=" << 0.001*(muon->pt())
                      << " GeV, eta=" << muon->eta() << ", phi=" << muon->phi() );
      // Calculate the measured pt difference between MS and ID
      if (m_doDeltaPt) {
        float deltaPt = -9.0;
        const ElementLink< xAOD::TrackParticleContainer >& idTPLink = muon->inDetTrackParticleLink();
        const ElementLink< xAOD::TrackParticleContainer >& msTPLink = muon->muonSpectrometerTrackParticleLink();
        if ( idTPLink.isValid() && msTPLink.isValid() ) {
          const xAOD::TrackParticle_v1* idTP = *idTPLink;
          const xAOD::TrackParticle_v1* msTP = *msTPLink;
          double idPt = idTP->pt();
          double msPt = msTP->pt();
          if ( idPt ) {
            deltaPt = static_cast<float>( (idPt-msPt)/idPt );
          }
        }
        deltaPtDeco(*muon) = deltaPt;

        // philip: I'm writing out the invididual measurements of the muon charge
        if (idTPLink.isValid()) {
          const xAOD::TrackParticle_v1* idTP = *idTPLink;
          chargeIDDeco(*muon) = idTP->charge();
        }
        if (msTPLink.isValid()) {
          const xAOD::TrackParticle_v1* msTP = *msTPLink;
          chargeMSDeco(*muon) = msTP->charge();
        }
        const ElementLink< xAOD::TrackParticleContainer >& exTPLink = muon->extrapolatedMuonSpectrometerTrackParticleLink();
        const ElementLink< xAOD::TrackParticleContainer >& cbTPLink = muon->combinedTrackParticleLink();
        if (exTPLink.isValid()) {
          const xAOD::TrackParticle_v1* exTP = *exTPLink;
          chargeEXDeco(*muon) = exTP->charge();
        }
        if (cbTPLink.isValid()) {
          const xAOD::TrackParticle_v1* cbTP = *cbTPLink;
          chargeCBDeco(*muon) = cbTP->charge();
        }

      }


      // Store the muon quality
      if (!m_muonSelectionTool.empty()){
        static xAOD::Muon::Decorator<int>  decSetMuQuality ("Quality");
        static xAOD::Muon::Decorator<char> decSetMuPassedIDCuts ("PassesIDCuts");
        static xAOD::Muon::Decorator<char> decSetMuHighPtCuts("PassesHighPtCuts");
        const int muonQuality = m_muonSelectionTool->getQuality(*muon);
        decSetMuQuality(*muon) = muonQuality;

        static xAOD::Muon::Decorator<char> decSetMuIsBad("IsBadMuon");
        const bool isBad = m_muonSelectionTool->isBadMuon(*muon);
        decSetMuIsBad(*muon) = static_cast<char>(isBad);

        // Store the outcome of the muon selection tool
        bool passedIDCuts = false;
        bool passedHighPtCuts = false;
        // Explicitely not apply on standalone muons, to suppress warning spam
        if ( muon->muonType() != xAOD::Muon_v1::MuonStandAlone ) {
          passedIDCuts     = m_muonSelectionTool->passedIDCuts(*muon);
          passedHighPtCuts = m_muonSelectionTool->passedHighPtCuts(*muon);
        }
        decSetMuPassedIDCuts(*muon) = static_cast<char>(passedIDCuts);
        decSetMuHighPtCuts(*muon)   = static_cast<char>(passedHighPtCuts);
      }

      // Store the isBadMuon flag for the high-pt muon selection
      if (!m_highPtMuonSelectionTool.empty()){
        static xAOD::Muon::Decorator<char> decSetHighPtMuIsBad("IsBadHighPtMuon");
        const bool isBad = m_highPtMuonSelectionTool->isBadMuon(*muon);
        decSetHighPtMuIsBad(*muon) = static_cast<char>(isBad);
      }


      // Do the impact parameter calculations
      if ( m_doImpactParameter && primVtx ) {
        ATH_MSG_VERBOSE("Going to do impact parameter determination");
        // Get the TrackParticle
        const xAOD::TrackParticle* trackPart(0);
        trackPart = muon->primaryTrackParticle();
        if ( !trackPart ) {
          ATH_MSG_VERBOSE("Couldn't get primary track particle... trying to get inner detector one");
          trackPart = muon->trackParticle(xAOD::Muon::TrackParticleType::InnerDetectorTrackParticle);
        }
        if ( !trackPart ) {
          ATH_MSG_ERROR("Couldn't get the TrackParticle for this Muon with type: " << muon->muonType() );
          return StatusCode::FAILURE;
        }

        ATH_MSG_VERBOSE("Going to do z0 determination");
        // The TrackParticle is expressed w.r.t. the beam spot. Thus, we need to
        // do some gymnastics in order to get it w.r.t. the primary vertex.
        // const float z0sig = static_cast<float>(xAOD::TrackingHelpers::z0significance(trackPart, primVtx));
        // z0SigDeco(*muon)    = z0sig;
        const float z0 = trackPart->z0() + trackPart->vz() - primVtx->z();
        const float sinTheta = std::sin(trackPart->theta());
        z0Deco(*muon)       = z0;
        sinThetaDeco(*muon) = sinTheta;

        ATH_MSG_VERBOSE("Going to do d0 selection (and z0err)");
        const float d0 = trackPart->d0();
        ATH_MSG_VERBOSE("Got d0 = " << d0);
        float z0err    = 0.0;
        float d0sig    = 0.0;
        if ( !(xAOD::TrackingHelpers::hasValidCov(trackPart)) ){
          ATH_MSG_DEBUG("No definingParametersCovMatrix for current muon TrackParticle");
        }
        else {
          const std::size_t covMatrixSize = trackPart->definingParametersCovMatrixVec().size();
          ATH_MSG_VERBOSE("Size of covariance matrix: " << covMatrixSize);
          if ( covMatrixSize != 0 ){
            if ( xAOD::TrackingHelpers::hasValidCovD0(trackPart) ){
              ATH_MSG_VERBOSE("Getting d0significance");
              d0sig = static_cast<float>(xAOD::TrackingHelpers::d0significance( trackPart, evtInfo->beamPosSigmaX(), evtInfo->beamPosSigmaY(), evtInfo->beamPosSigmaXY() ));
              ATH_MSG_VERBOSE("Got d0significance = " << d0sig);
            }
            if ( xAOD::TrackingHelpers::hasValidCovZ0(trackPart) ){
              ATH_MSG_VERBOSE("Getting z0error");
              z0err = std::sqrt(trackPart->definingParametersCovMatrixVec().at(2));
              ATH_MSG_VERBOSE("Got z0 error = " << z0err);
            }
          }
          ATH_MSG_VERBOSE("Done calculating d0 significance and z0 error");
        }
        d0Deco(*muon)    = d0;
        d0SigDeco(*muon) = d0sig;
        z0ErrDeco(*muon) = z0err;


      } // End: Do the impact parameter calculations

      // Calculate the pass/fails for the isolation
      for ( std::size_t idxIso=0; idxIso<m_isoToolList.size(); ++idxIso ){
        ATH_MSG_VERBOSE("Doing muon isolation");
        const bool passed = (m_isoToolList[idxIso])->accept(*muon);
        (isoDecList.at(idxIso))(*muon) = static_cast<char>(passed);
      } // End: do the iso WP calculation

      // Get the MCTruthClassifer results and attach them to the muon directly
      if (m_doTruth && isSim){
        ATH_MSG_VERBOSE("Doing muon truth");

        // Default values
        int type   = -1;
        int origin = -1;
        int charge = 0;
        float pt   = 0;
        float eta  = 0;
        float phi  = 0;
        // First, try to get the values from the
        const ElementLink<xAOD::TrackParticleContainer>& idtpLink = muon->inDetTrackParticleLink();
        if ( idtpLink.isValid() ){
          ATH_MSG_VERBOSE("Got a valid muon inner-detector TrackParticleLink");
          const xAOD::TrackParticle* idtp = *idtpLink;
          if (decTruthType.isAvailable(*idtp)){   type   = idtp->auxdata<int>("truthType");   }
          if (decTruthOrigin.isAvailable(*idtp)){ origin = idtp->auxdata<int>("truthOrigin"); }
        }

        // philip: commenting, this is now done further below
        // // Then, if the previous doesn't work, e.g., for |eta|>2.5, try using the muon truth particle
        // if ( type < 0 ){
        //   ATH_MSG_VERBOSE("Still got muon truthType<0");
        //   const xAOD::TruthParticle* truth = nullptr;
        //   if ( muon->isAvailable<ElementLink<xAOD::TruthParticleContainer> >("truthParticleLink") ) {
        //     ATH_MSG_VERBOSE("Got a muon truthParticleLink");
        //     const ElementLink<xAOD::TruthParticleContainer>& link = muon->auxdata<ElementLink<xAOD::TruthParticleContainer> >("truthParticleLink");
        //     if ( link.isValid() ){
        //       ATH_MSG_VERBOSE("Did get a valid muon truthParticleLink");
        //       truth = *link;
        //       if (decTruthType.isAvailable(*truth)){   type   = truth->auxdata<int>("truthType");   }
        //       if (decTruthOrigin.isAvailable(*truth)){ origin = truth->auxdata<int>("truthOrigin"); }
        //     }
        //   }
        // }


        // philip: want also the truth pt
        if ( muon->isAvailable<ElementLink<xAOD::TruthParticleContainer> >("truthParticleLink") ) {
          ATH_MSG_VERBOSE("Got a muon truthParticleLink");
          const ElementLink<xAOD::TruthParticleContainer>& link = muon->auxdata<ElementLink<xAOD::TruthParticleContainer> >("truthParticleLink");
          if ( link.isValid() ){
            ATH_MSG_VERBOSE("Did get a valid muon truthParticleLink");
            const xAOD::TruthParticle* truth = *link;

            // // philip:
            // // old way of doing it, no dressing
            // if (truth && (truth->absPdgId()==13)){
            //   pt     = truth->pt() ;
            //   eta    = truth->eta();
            //   phi    = truth->phi();
            //   charge = truth->charge();
            // }

            // philip:
            // ok, here's the new way: I'm trying to get the dressed pt
            // if I just loop the truth particles, look for a particle with
            // matching barcode and retrieve the pt_dressed it should be fine, no?
            // Karsten: Test if the input container actually exists.
            if ( tmuons ){
              for(const xAOD::TruthParticle* tmuon : *tmuons){
                // const ElementLink<xAOD::TruthParticleContainer>& link2 = tmuon->auxdata<ElementLink<xAOD::TruthParticleContainer> >("originalTruthParticle");
                // if ( link == link2 && truth->absPdgId()==13 ) {
                if ( truth && truth->barcode() == tmuon->barcode() && (truth->absPdgId()==13) ) {
                  pt     = tmuon->auxdata<float>("pt_dressed")    ;
                  eta    = tmuon->auxdata<float>("eta_dressed")   ;
                  phi    = tmuon->auxdata<float>("phi_dressed")   ;
                  charge = tmuon->charge();
                }
              }
            }

            // Then, if the previous doesn't work, e.g., for |eta|>2.5, try using the muon truth particle
            if ( type < 0 ){
              ATH_MSG_VERBOSE("Still got muon truthType<0");
              if (decTruthType  .isAvailable(*truth)){ type   = truth->auxdata<int>("truthType"  ); }
              if (decTruthOrigin.isAvailable(*truth)){ origin = truth->auxdata<int>("truthOrigin"); }
            }
          }

        }

        // Decorate the muon with the final result
        decHWWTruthType  (*muon) = type  ;
        decHWWTruthOrigin(*muon) = origin;
        if ( tmuons ){
          decTruthPt       (*muon) = pt    ;
          decTruthEta      (*muon) = eta   ;
          decTruthPhi      (*muon) = phi   ;
          decTruthCharge   (*muon) = charge;
        }
      } // End: doTruth

      //------------------------------------------------//
      //  Truth flavour decorator as in Run-I (Javier)  //
      //------------------------------------------------//

      if (isSim){

        int flavTag = -1;

        //Store b, c, s and light truth objects (quarks and hadrons)
        const xAOD::TruthParticleContainer* truthParticles = 0;
        ATH_CHECK(evtStore()->retrieve( truthParticles, "TruthParticles" ));
        xAOD::TruthParticleContainer::const_iterator truthItr = truthParticles->begin();
        xAOD::TruthParticleContainer::const_iterator truthItrE = truthParticles->end();

        std::vector<const xAOD::TruthParticle*> bTruth; bTruth.clear();
        std::vector<const xAOD::TruthParticle*> cTruth; cTruth.clear();
        std::vector<const xAOD::TruthParticle*> sTruth; sTruth.clear();
        std::vector<const xAOD::TruthParticle*> lTruth; lTruth.clear();
        std::vector<const xAOD::TruthParticle*> mTruth; mTruth.clear();

        for (truthItr = truthParticles->begin(); truthItr != truthItrE; ++truthItr){
          const xAOD::TruthParticle * part = (*truthItr); long int pdg = part->pdgId();
          if (part->pt() <= 5000) continue;

          //Classify the truth particle
          bool hasBottom = 0; bool hasCharm = 0; bool hasStrange = 0; bool hasLight = 0;
          int q1 = (abs(pdg)/1000)%10; int q2 = (abs(pdg)/100)%10; int q3 = (abs(pdg)/10)%10;

          if (q1 == 0 && q2 == 5 && q3 == 5) hasBottom = 1; //BBbar meson
          else if (q1 == 0 && q3 < 5 && q3 > 0 && q2 == 5 ) hasBottom = 1; //Bottom meson
          else if (q1 == 5) hasBottom = 1; //Bottom baryon
          else if (abs(pdg) == 5) hasBottom = 1; //Bottom quark

          else if (q1 == 0 && q3 == 4 && q2 == 4) hasCharm = 1; //CCbar meson
          else if (q1 == 0 && q3 < 4 && q3 > 0 && q2 == 4) hasCharm = 1; //Charmed meson
          else if (q1 == 4) hasCharm = 1; //Charmed baryon
          else if (abs(pdg) == 4) hasCharm = 1; //Charm quark

          else if (q1 == 3) hasStrange = 1; //Strange baryon
          else if ((q1 == 0 && q2 == 3 && q3 < 3 && q3 > 0)|| abs(pdg) == 130) hasStrange = 1; //Strange meson
          else if (abs(pdg) == 3) hasStrange = 1; //Strange quark

          else if (q1 == 2 || q1 == 1) hasLight = 1; //Light baryon
          else if ((q1==0 && (q3 == 1 || q3 == 2) && (q2 == 1|| q2 == 2)) || (q1 == 0&& q3 == 3 && q2 == 3)) hasLight = 1; //Light meson
          else if (abs(pdg) == 2 || abs(pdg) == 1) hasLight = 1; //u,d quarks

          if (hasBottom) bTruth.push_back(part);
          if (hasCharm) cTruth.push_back(part);
          if (hasStrange) sTruth.push_back(part);
          if (hasLight) lTruth.push_back(part);
          if (fabs(pdg) == 13) mTruth.push_back(part);
        }

        //Now classify the muon
        TLorentzVector muVect; muVect.SetPtEtaPhiE(muon->pt(), muon->eta(), muon->phi(), muon->e());

        bool muonBottom = 0; bool muonCharm = 0; bool muonStrange = 0;
        bool muonLight = 0;

        bool bottomLeptonic = 0; bool bottomHadronic = 0;
        bool charmLeptonic = 0; bool charmHadronic = 0;
        bool strangeLeptonic = 0; bool strangeHadronic = 0;
        bool lightLeptonic = 0; bool lightHadronic = 0;
        bool gluonLeptonic = 0; bool gluonHadronic = 0;

        //See if it is matched to a truth muon
        bool isLeptonic = 0;
        for (size_t m = 0; m < mTruth.size(); ++m){
          TLorentzVector truthVect; truthVect.SetPtEtaPhiE(mTruth[m]->pt(), mTruth[m]->eta(), mTruth[m]->phi(), mTruth[m]->e());
          double dR = muVect.DeltaR(truthVect);
          if (dR < 0.03) isLeptonic = 1;
        }

        //Try to find a bottom-match
        for (size_t b = 0; b < bTruth.size(); ++b){
          TLorentzVector bVect; bVect.SetPtEtaPhiE(bTruth[b]->pt(), bTruth[b]->eta(), bTruth[b]->phi(), bTruth[b]->e());
          double dR = muVect.DeltaR(bVect);
          if (dR < 0.4) muonBottom = 1;
        }

        if (muonBottom){
          if (isLeptonic) bottomLeptonic = 1;
          else bottomHadronic = 1;
        }

        if (!muonBottom){

          //Try to find a charm-match
          for (size_t c = 0; c < cTruth.size(); ++c){
            TLorentzVector cVect; cVect.SetPtEtaPhiE(cTruth[c]->pt(), cTruth[c]->eta(), cTruth[c]->phi(), cTruth[c]->e());
            double dR = muVect.DeltaR(cVect);
            if (dR < 0.4) muonCharm = 1;
          }

          if (muonCharm){
            if (isLeptonic) charmLeptonic = 1;
            else charmHadronic = 1;
          }

          if (!muonCharm){

            //Try to find a strange-match
            for (size_t s = 0; s < sTruth.size(); ++s){
              TLorentzVector sVect; sVect.SetPtEtaPhiE(sTruth[s]->pt(), sTruth[s]->eta(), sTruth[s]->phi(), sTruth[s]->e());
              double dR = muVect.DeltaR(sVect);
              if (dR < 0.4) muonStrange = 1;
            }

            if (muonStrange){
              if (isLeptonic) strangeLeptonic = 1;
              else strangeHadronic = 1;
            }

            if (!muonStrange){

              //Try to find a light-match
              for (size_t l = 0; l < lTruth.size(); ++l){
                TLorentzVector lVect; lVect.SetPtEtaPhiE(lTruth[l]->pt(), lTruth[l]->eta(), lTruth[l]->phi(), lTruth[l]->e());
                double dR = muVect.DeltaR(lVect);
                if (dR < 0.4) muonLight = 1;
              }

              if (muonLight){
                if (isLeptonic) lightLeptonic = 1;
                else lightHadronic = 1;
              }

              if (!muonLight){
                if (isLeptonic) gluonLeptonic = 1;
                else gluonHadronic = 1;

              }
            }
          }
        }

        if (bottomLeptonic) flavTag = 1;
        if (bottomHadronic) flavTag = 2;

        if (charmLeptonic) flavTag = 3;
        if (charmHadronic) flavTag = 4;

        if (strangeLeptonic) flavTag = 5;
        if (strangeHadronic) flavTag = 6;

        if (lightLeptonic) flavTag = 7;
        if (lightHadronic) flavTag = 8;

        if (gluonLeptonic) flavTag = 9;
        if (gluonHadronic) flavTag = 10;

        //Decorate the muon with the flavour tag
        decFlavourTag(*muon) = flavTag;

      } //End: isSim

      ATH_MSG_VERBOSE("Done with current muon number " << muon->index());
    } // End:: Loop over muons

    ATH_MSG_VERBOSE("Done with current input container with name: " << inName);
  } // End: Loop over all input MuonContainer names

  return StatusCode::SUCCESS;
}
