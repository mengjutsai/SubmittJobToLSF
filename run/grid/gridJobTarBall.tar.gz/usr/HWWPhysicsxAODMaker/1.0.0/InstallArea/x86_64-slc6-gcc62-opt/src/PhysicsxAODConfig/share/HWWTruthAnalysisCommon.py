
# ====================================================================
# This file schedules all the standardized event pre-selections
# (trigger, GoodRunsList), and also crates the finally calibrated
# objects.
# Here, we also create the needed sub-sequences and we figure out
# over what kind of data/MC we are running.
# This will be the first file that any HWW analysis configuration needs
# to include.
# ====================================================================


# ====================================================================
# block that this file is included twice
# ====================================================================
include.block("PhysicsxAODConfig/HWWTruthAnalysisCommon.py")


# Import the module that allows to use named units, e.g. GeV
from AthenaCommon.SystemOfUnits import *

# Import the steering flags for this analysis
from PhysicsxAODConfig.HWWTruthCommonAnalysisFlags import hWWCommon


# ====================================================================
# Check if we have Monte Carlo or real data, based on the input file meta-data
# ====================================================================
if af.fileinfos.has_key("evt_type"):
    eventTypeList = af.fileinfos["evt_type"]
    if eventTypeList.__contains__("IS_SIMULATION") :
        hWW_msg.info( "Detected that the input file is a simulated dataset" )
        hWWCommon.Global.inputIsSimulation = True
        pass
    pass
# Determine the flavour of simulation, i.e., Full or AFII, makes no sense for truth
hWWCommon.Global.inputSimulationType = "FullSim"
#if hWWCommon.Global.inputIsSimulation :
#    simType = af.fileinfos['metadata']['/Simulation/Parameters']['SimulationFlavour']
#    if simType  == 'default' : #full sim or atlfast
#        hWWCommon.Global.inputSimulationType = "FullSim"
#        pass
#    elif simType  == 'atlfast' : #full sim or atlfast
#        hWWCommon.Global.inputSimulationType = "AFII"
#        pass
#    else:
#        hWW_msg.warning( "Input is simulation, but couldn't figure out of what type: %s" % simType )
#        pass
#    hWW_msg.info( "Detected that the input file is of simulation type: %s" % hWWCommon.Global.inputSimulationType )
#    pass


# ====================================================================
# Check if we have 50ns intra-bunch spacing or 25ns (default), makes no sense for truth
# ====================================================================
#if hWWCommon.Global.inputIsSimulation :
#    bunchSpace = af.fileinfos['metadata']['/Digitization/Parameters']['intraTrainBunchSpacing']
#    if bunchSpace == 50: hWWCommon.Global.bunchSpacing = 50
#    pass
#else:
#    runNumberList = af.fileinfos["run_number"]
#    if runNumberList[0] < 276000: hWWCommon.Global.bunchSpacing = 50
#    pass
#hWW_msg.info( "Using bunch spacing of %i ns" % hWWCommon.Global.bunchSpacing )


# ====================================================================
# Check if we have a DxAOD or xAOD, based on the input file meta-data
# ====================================================================
if af.fileinfos["metadata"]["/TagInfo"]["AtlasRelease"].__contains__("AtlasDerivation"):
    hWWCommon.Global.inputIsDAOD = True
    hWW_msg.info( "Input file is a DxAOD")
    pass


# ====================================================================
# Set truth MET
# # ====================================================================
#if af.fileinfos["eventdata_items"].__contains__(('xAOD::MissingETContainer', 'MET_Truth')):
#    hWWCommon.MET.inCont = "MET_Truth"
#    hWW_msg.info( "Using MET_Truth for the analysis")
#    pass
#hWWCommon.MET.inCont = "MET_Truth"


# ====================================================================
# Check if the input file also has the requested track jets.
# If not, turn off the track jets
# ====================================================================
hWWCommon.Jets.writeTrackJets = False


# ====================================================================
# Get beam energy from AthFile (set default to bigger than 4 TeV)
# ====================================================================
if af.fileinfos.has_key("beam_energy"):
    hWWCommon.Global.beamEnergy = af.fileinfos["beam_energy"][0]
    hWW_msg.info( "Beam energy from input metadata: %f", hWWCommon.Global.beamEnergy )
    pass
else:
    hWW_msg.warning( "No beam energy found in input metadata, use default value of %s TeV (to avoid crashes, no pileup reweighting will be applied)" % hWWCommon.Global.beamEnergy/TeV )
    pass


# ====================================================================
# Turn off the four-momentum systematic variations, if requested,
# or if running on data
# ====================================================================
# Try to see if the user specified on the command line which systematics to use
#if vars().has_key('doP4Systematics'):
#    hWWCommon.Global.doP4Systematics = doP4Systematics
#    hWW_msg.info( "The user requested to use hWWCommon.Global.doP4Systematics = %s" % hWWCommon.Global.doP4Systematics )
#    pass
if not hWWCommon.Global.doP4Systematics:
    hWW_msg.info( "Switching OFF four-momentum systematics" )
    hWWCommon.Electrons.p4Systs = []
    hWWCommon.Muons.p4Systs     = []
    hWWCommon.Jets.jesSysts     = []
    hWWCommon.Jets.jerSysts     = []
    hWWCommon.MET.p4Systs       = []
    pass
hWWCommon.Jets.p4Systs = hWWCommon.Jets.jesSysts + hWWCommon.Jets.jerSysts
hWW_msg.info("Using %i electron four-momentum systematics" % len(hWWCommon.Electrons.p4Systs) )
hWW_msg.info("Using %i muon four-momentum systematics" % len(hWWCommon.Muons.p4Systs) )
hWW_msg.info("Using %i jet four-momentum systematics" % len(hWWCommon.Jets.p4Systs) )
hWW_msg.info("Using %i missingET four-momentum systematics" % len(hWWCommon.MET.p4Systs) )

# Build the systematics tracker
from PhysicsxAODConfig.HWWCommonHelpers import SystematicsTracker
HWWSysTracker = SystematicsTracker( "HWWSystematicsTracker",
                                    jet      = hWWCommon.Jets.p4Systs,
                                    electron = hWWCommon.Electrons.p4Systs,
                                    muon     = hWWCommon.Muons.p4Systs,
                                    met      = hWWCommon.MET.p4Systs )
#HWWSysTracker.dump()



# ====================================================================
# Turn off the scale-factor systematic variations, if requested,
# or if running on data
# ====================================================================
# Try to see if the user specified on the command line which systematics to use
#if vars().has_key('doEffiSystematics'):
#    hWWCommon.Global.doEffiSystematics = doEffiSystematics
#    hWW_msg.info( "The user requested to use hWWCommon.Global.doEffiSystematics = %s" % hWWCommon.Global.doEffiSystematics )
#    pass
#if not hWWCommon.Global.doEffiSystematics :
#    hWW_msg.info( "Switching OFF efficiency systematics" )
#    hWWCommon.Electrons.effiSysts     = []
#    hWWCommon.Electrons.effiRecoSysts = []
#    hWWCommon.Electrons.effiTrigSysts = []
#    hWWCommon.Electrons.effiIsoSysts  = []
#    hWWCommon.Muons.effiSysts         = []
#    hWWCommon.Muons.effiIsoSysts      = []
#    hWWCommon.Muons.effiTrigSysts      = []
#    hWWCommon.Jets.effiSysts          = []
#    pass
#hWW_msg.info("Using %i electron efficiency systematics" % len(hWWCommon.Electrons.effiSysts) )
#hWW_msg.info("Using %i electron reconstruction efficiency systematics" % len(hWWCommon.Electrons.effiRecoSysts) )
#hWW_msg.info("Using %i electron efficiency trigger systematics" % len(hWWCommon.Electrons.effiTrigSysts) )
#hWW_msg.info("Using %i electron efficiency isolation systematics" % len(hWWCommon.Electrons.effiIsoSysts) )
#hWW_msg.info("Using %i muon efficiency systematics" % len(hWWCommon.Muons.effiSysts) )
#hWW_msg.info("Using %i muon isolation efficiency systematics" % len(hWWCommon.Muons.effiIsoSysts) )
#hWW_msg.info("Using %i muon trigger efficiency systematics" % len(hWWCommon.Muons.effiTrigSysts) )
#hWW_msg.info("Using %i jet efficiency systematics" % len(hWWCommon.Jets.effiSysts) )



# ====================================================================
# Break up the AuxContainers into individual AuxDyn variables for selected containers
# ====================================================================
if hWWCommon.Global.breakUpAuxContainers :
    if hWWCommon.Jets.writeTrackJets: hWWCommon.Global.auxContsToBreakUp.append("AntiKt4PV0TrackJetsAux.")
    topSequence += CfgMgr.xAODMaker__AuxStoreWrapper( "HWWAuxStoreWrapperAlg", OutputLevel = INFO )
    topSequence.HWWAuxStoreWrapperAlg.SGKeys = hWWCommon.Global.auxContsToBreakUp
    pass


# ====================================================================
# Create a subsequence:
# Only when the first algorithm returns isEventAccepted,
# the rest of this sub-sequence is executed
# ====================================================================
from AthenaCommon.AlgSequence import AthSequencer
hWWCommonPreFilterSeq = AthSequencer("HWWCommonAnalysisPreFilterSeq", OutputLevel = WARNING)
topSequence += hWWCommonPreFilterSeq


# ====================================================================
# Only add the GoodRunsList selection if we run on data, but NOT for Monte Carlo:
# ====================================================================
if not hWWCommon.Global.inputIsSimulation and hWWCommon.Global.doGRLSelection :
    # /afs/cern.ch/user/a/atlasdqm/www/Atlas/GROUPS/DATAPREPARATION/InteractionsperCrossing
    # http://atlasdqm.web.cern.ch/atlasdqm/grlgen/All_Good/

    hWWCommonPreFilterSeq += CfgMgr.HWW__GoodRunsListSelectionAlg( "HWWGoodRunsListSelectionAlg",
                                                                   #OutputLevel       = VERBOSE,
                                                                   GoodRunsListVec = hWWCommon.Global.grlFileList
                                                                   )
    hWWCommon.Global.requireAlgList.append("HWWGoodRunsListSelectionAlg")
    pass


# ====================================================================
# Veto data event with a bad event quality
# ====================================================================
#hWWCommonPreFilterSeq += CfgMgr.EventQualityFilterAlg( "HWWEventQualityFilter" )
#hWWCommon.Global.requireAlgList.append("HWWEventQualityFilter")


# ====================================================================
# Veto events without a good primary vertex
# ====================================================================
#hWWCommonPreFilterSeq += CfgMgr.HWW__PrimaryVertexFilterAlg("HWWPrimaryVertexFilterAlg", OutputLevel = WARNING)
#hWWCommon.Global.requireAlgList.append("HWWPrimaryVertexFilterAlg")


# ====================================================================
# Trigger selection
# ====================================================================
#if hWWCommon.Global.doTriggerSelection :
#    # Set up the needed tools
#    ToolSvc += CfgMgr.TrigConf__xAODConfigTool("TrigConfig")
#    ToolSvc += CfgMgr.Trig__TrigDecisionTool("TrigDecisionTool",
#                                             ConfigTool=ToolSvc.TrigConfig,
#                                             TrigDecisionKey="xTrigDecision" )
    # And use them in the algorithm to select the event based on an OR of all given trigger names.
    # Also, decorate the EventInfo object with the pass/fail results for every trigger.
#    hWWCommonPreFilterSeq += CfgMgr.TriggerSelectionAlg("HWWTriggerAlg",
#                                                        TrigDecisionTool = ToolSvc.TrigDecisionTool,
#                                                        TriggerList      = hWWCommon.Trigger.allLeptonTriggerList,
#                                                        VarNamePrefix    = hWWCommon.Trigger.triggerPassPrefix
#                                                        )
#    hWWCommon.Global.requireAlgList.append("HWWTriggerAlg")
#    pass


# ====================================================================
# Pileup Reweighting, use only on MC, also not for 13 TeV for now
# Is stored in EventInfo as "PileupWeight", TODO need to apply to total event weight in Event Building
# ====================================================================
#if hWWCommon.Global.inputIsSimulation and not hWWCommon.Global.beamEnergy>4.0*TeV and hWWCommon.Global.doPileupReweighting :
#    # Create an instance of the pileup reweighting tool
#    ToolSvc += CfgMgr.CP__PileupReweightingTool( "PileupReweighting" )# OutputLevel = VERBOSE )

#    # Check if we want to produce the config file for the given sample, if so run reweighting tool without config files
#    if not hWWCommon.Global.doGeneratePileupReweightingConfig :
#        ToolSvc.PileupReweighting.ConfigFiles   = hWWCommon.Global.PileupReweightingConfigFiles
#        ToolSvc.PileupReweighting.LumiCalcFiles = hWWCommon.Global.LumiCalcFiles
#        pass

#    # Create the pileup reweighting alg and schedule it
#    hWWCommonPreFilterSeq += CfgMgr.CP__PileupReweightingProvider( Tool=ToolSvc.PileupReweighting )
#    pass



# ====================================================================
# Temporary fix: Get the old-style EventInfo object and write out
# only the essentials, i.e., remove the information regarding the
# pileup sub-events.
# ====================================================================
#if eventDataItems.__contains__("PileUpEventInfo#McEventInfo") :
#    hWW_msg.info("Attempting to reduce the old-style EventInfo object")
#    hWWCommonPreFilterSeq += CfgMgr.ReducePileUpEventInfoAlg("HWWEventInfoReducer",
#                                                             #OutputLevel          = VERBOSE,
#                                                             ReducedEventInfoName = "HWWEventInfo" )
#    pass



# ====================================================================
# Decorate the xAOD::EventInfo object, primary vertex only
# ====================================================================
#hWWCommonPreFilterSeq += CfgMgr.HWW__EventInfoDecorationAlg("HWWEventInfoDecorationAlg",
#                                                             PrimaryVertexContainer = "TruthVertices")




# ====================================================================
# Decorate the xAOD::EventInfo object with some MCTruth-based quantities
# ====================================================================
if hWWCommon.Global.inputIsSimulation:
    # Sherpa needs some special treatment
    isFromSherpa = True
    isNNLOPS = False
    try:
        generator = af.fileinfos['metadata']['/TagInfo']['generators']
        hWW_msg.info("Generator name: " << generator)
        if "Powheg" in generator or "MadGraph" in generator or "McAtNlo" in generator: isFromSherpa = False
    except:
        try:
            hWW_msg.info("Trying to infer generator type from MC channel number...")
            mcChannelNumber = af.mc_channel_numbers[0]
            if mcChannelNumber in [410009]: isFromSherpa = False
            if mcChannelNumber in range(361700,361899): isFromSherpa = False
            if mcChannelNumber in range(361100,361110): isFromSherpa = False
        except:
            hWW_msg.warning("THIS SAMPLE DOES NOT HAVE METADATA INFO .... asusming SHERPA!!!")
            pass
        pass
    try:
        mcChannelNumber = af.mc_channel_numbers[0]
        if mcChannelNumber in [345324]: isNNLOPS = True
    except:
        hWW_msg.warning("THIS SAMPLE DOES NOT HAVE METADATA INFO .... asusming no NNLOPS!!!")
        pass

    hWWCommonPreFilterSeq += CfgMgr.HWW__TruthAlg("HWWTruthFlaggingAlg",
                                                  TruthInputContainer      = "TruthEvents",
                                                  TruthJetInputContainer   = "AntiKt4TruthJets",
                                                  TruthWZJetInputContainer = "AntiKt4TruthWZJets",
                                                  TruthMetInputContainer   = "MET_Truth",
                                                  TruthElectronInputContainer   = "TruthElectrons",
                                                  TruthMuonInputContainer   = "TruthMuons",
                                                  IsSherpa                 = isFromSherpa,
                                                  IsNNLOPS                 = isNNLOPS
                                                  )


# ====================================================================
# Create a sub-sequence that will always run through all algorithms
# ====================================================================
from AthenaCommon.AlgSequence import AthSequencer
hWWCommonCalibSeq = AthSequencer( "HWWCommonCalibSeq", OutputLevel = WARNING, StopOverride = True )
hWWCommonPreFilterSeq += hWWCommonCalibSeq


# ====================================================================
# Do the common object adaptions
# ====================================================================
include("PhysicsxAODConfig/HWWTruthObjectMod.py")


# ====================================================================
# Do the common muon calibration (including systematics)
# ====================================================================
#include("PhysicsxAODConfig/HWWMuonCalibrationScaleFactor.py")


# ====================================================================
# Do the common jet calibration (including systematics)
# ====================================================================
#include("PhysicsxAODConfig/HWWJetCalibrationScaleFactor.py")


# ====================================================================
# Do trigger matching on electrons and muons and tag them with the results
# ====================================================================
#if hWWCommon.Global.doTriggerMatching :
#    include("PhysicsxAODConfig/HWWTriggerMatching.py")
#    pass


# ====================================================================
# Create a sub-sequence that will always run through all algorithms
# ====================================================================
from AthenaCommon.AlgSequence import AthSequencer
hWWCommonSeq = AthSequencer( "HWWCommonSeq", OutputLevel = WARNING, StopOverride = True )
hWWCommonPreFilterSeq += hWWCommonSeq


# ====================================================================
# Create a sub-sequence that will always run through all algorithms.
# This one will be populated with things that need to run BEFORE the
# overlap removal is done, e.g., like lepton pre-selections.
# ====================================================================
from AthenaCommon.AlgSequence import AthSequencer
hWWPreORSeq = AthSequencer( "HWWPreORSeq", OutputLevel = WARNING, StopOverride = True )
hWWCommonSeq += hWWPreORSeq


# ====================================================================
# Do the overlap removal of the containers
# ====================================================================
include("PhysicsxAODConfig/HWWTruthOverlapRemoval.py")


# ====================================================================
# Do the electron selection
# ====================================================================
include("PhysicsxAODConfig/HWWTruthElectronSelection.py")


# ====================================================================
# Do the muon selection
# ====================================================================
include("PhysicsxAODConfig/HWWTruthMuonSelection.py")


# ====================================================================
# Do the jet selection
# ====================================================================
include("PhysicsxAODConfig/HWWTruthJetSelection.py")


# ====================================================================
# Do the common missingET building (including systematics).
# Only attempt this if the input file actually has the required
# missingET items in it (for example, the fake-factor derivations may not).
# ====================================================================
#if af.fileinfos["eventdata_items"].__contains__(('xAOD::MissingETContainer', hWWCommon.MET.inCore)) \
#  and af.fileinfos["eventdata_items"].__contains__(('xAOD::MissingETAssociationMap', hWWCommon.MET.inMap)):
#    include("PhysicsxAODConfig/HWWMETBuilding.py")
#    pass
#else:
#    hWW_msg.info("Couldn't find xAOD::MissingETContainer#%s and/or xAOD::MissingETAssociationMap#%s..." \
#      % (hWWCommon.MET.inCore, hWWCommon.MET.inMap) )
#    hWW_msg.info("...won't run missingET rebuilding!")
#    pass



# ====================================================================
# Do the commont thinning (removal of individual objects/particles
# within a container).
# ====================================================================
