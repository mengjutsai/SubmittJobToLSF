///////////////////////// -*- C++ -*- /////////////////////////////
// HWWTruthElectronSelectionTool.cxx
// Implementation file for class HWWTruthElectronSelectionTool
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWTruthElectronSelectionTool.h"

// STL includes
#include <climits>
#include <cmath>
#include <string>

// FrameWork includes
#include "GaudiKernel/IToolSvc.h"

// EDM includes
#include "xAODBase/ObjectType.h"
#include "xAODBase/IParticle.h"
#include "xAODPrimitives/IsolationType.h"
#include "xAODEgamma/EgammaDefs.h"
#include "xAODEgamma/EgammaEnums.h"
#include "xAODEgamma/Electron.h"
#include "xAODEgamma/EgammaxAODHelpers.h"
#include "xAODCaloEvent/CaloCluster.h"
#include "xAODTracking/TrackingPrimitives.h"
#include "xAODTracking/Vertex.h"
#include "xAODTruth/TruthEventContainer.h"
#include "xAODTruth/TruthParticleContainer.h"
#include "xAODTruth/TruthParticleAuxContainer.h"



// Constructors
////////////////
HWW::TruthElectronSelectionTool::TruthElectronSelectionTool( std::string name ) :
  asg::AsgTool(name),
  m_doPtCut(false),
  m_doEtaCut(false),
  m_cutPosition_pt(-9),
  m_cutPosition_eta(-9)
{
  //
  // Property declaration
  //
  declareProperty( "CutPtMin", m_ptMin=-99999.0, "The electron.pt() minimum cut value" );
  m_ptMin.declareUpdateHandler( &HWW::TruthElectronSelectionTool::setupPtCut, this );

  declareProperty( "CutAbsEtaMax",      m_absEtaMax=DBL_MAX,   "The |electron.cluster().eta()| maximum cut value" );
  m_absEtaMax.declareUpdateHandler( &HWW::TruthElectronSelectionTool::setupEtaCut, this );
  declareProperty( "CutAbsEtaCrackMin", m_absEtaCrackMin=-1000.0, "The |electron.cluster().eta()| minimum cut value for the calo crack" );
  m_absEtaCrackMin.declareUpdateHandler( &HWW::TruthElectronSelectionTool::setupEtaCut, this );
  declareProperty( "CutAbsEtaCrackMax", m_absEtaCrackMax=-1000.0, "The |electron.cluster().eta()| maximum cut value for the calo crack" );
  m_absEtaCrackMax.declareUpdateHandler( &HWW::TruthElectronSelectionTool::setupEtaCut, this );

}




// Destructor
///////////////
HWW::TruthElectronSelectionTool::~TruthElectronSelectionTool()
{}




// Athena algtool's Hooks
////////////////////////////
StatusCode HWW::TruthElectronSelectionTool::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_ptMin );
  ATH_MSG_DEBUG( "Using: " << m_absEtaMax );
  ATH_MSG_DEBUG( "Using: " << m_absEtaCrackMin );
  ATH_MSG_DEBUG( "Using: " << m_absEtaCrackMax );





  // --------------------------------------------------------------------------
  // Register the cuts and check that the registration worked:
  // NOTE: THE ORDER IS IMPORTANT!!! Cut0 corresponds to bit 0, Cut1 to bit 1,...
  // if ( m_cutPosition_nSCTMin < 0 ) sc = 0; // Exceeded the number of allowed cuts

  // Register the pt cut
  if ( m_doPtCut ) {
    ATH_MSG_DEBUG("Registering pt cut");
    m_cutPosition_pt = m_accept.addCut( "PtCut", Form("pt > %g GeV", m_ptMin.value() * 0.001) );
    if ( m_cutPosition_pt < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron pt cut");
      return StatusCode::FAILURE;
    }
  }


  // Register the eta cut
  if ( m_doEtaCut ) {
    ATH_MSG_DEBUG("Registering eta cut");
    m_cutPosition_eta = m_accept.addCut( "EtaCut", Form("( abs(eta) < %g ) || ( %g < abs(eta) %g )",
                                                         m_absEtaCrackMin.value(), m_absEtaCrackMax.value(), m_absEtaMax.value()) );
    if ( m_cutPosition_eta < 0 ) {
      ATH_MSG_ERROR("Couldn't book electron eta cut");
      return StatusCode::FAILURE;
    }
  }


  return StatusCode::SUCCESS;
}




StatusCode HWW::TruthElectronSelectionTool::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  return StatusCode::SUCCESS;
}




// Method to get the plain TAccept.
const Root::TAccept& HWW::TruthElectronSelectionTool::getTAccept( ) const
{
  return m_accept;
}




// The main accept method: the actual cuts are applied here
const Root::TAccept& HWW::TruthElectronSelectionTool::accept( const xAOD::IParticle* part) const
{
  // Reset the cut result bits to zero (= fail cut)
  m_accept.clear();

  // cast to an electron
  /*if ( part->type() != xAOD::Type::Electron ) {
    ATH_MSG_ERROR("Didn't get an IParticle of type electron... exiting");
    return m_accept;
  }*/
  //const xAOD::Electron* ele = static_cast<const xAOD::Electron*>(part);
  const xAOD::TruthParticle* ele = static_cast<const xAOD::TruthParticle*>(part);
  if ( !ele ) {
    ATH_MSG_ERROR("Couldn't cast to an electron");
    return m_accept;
  }


  // ---------------------------------------------------------------------------
  // Do the actual selection:
  // If a cut is not passed, we return and the subsequent cuts are not tried out


  // Apply the pt selection, if requested
  const double elePt = ele->pt();
  if ( m_doPtCut ) {
    ATH_MSG_VERBOSE("Going to do pt selection");
    const bool passCut = elePt > m_ptMin.value();
    m_accept.setCutResult( m_cutPosition_pt, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing pt cut");
      return m_accept;
    }
  } // End: do pt cut


  // Apply the eta selection, if requested
  if ( m_doEtaCut ) {
    ATH_MSG_VERBOSE("Going to do eta selection");
    // Get the CaloCluster of this electron
    // Do the actual selection
    const double clusAbsEta = std::abs(ele->eta());
    const bool passCut = ( (clusAbsEta < m_absEtaCrackMin.value())
                           || ( m_absEtaCrackMax.value() < clusAbsEta
                                && clusAbsEta < m_absEtaMax.value() ) );
    m_accept.setCutResult( m_cutPosition_eta, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing eta cut");
      return m_accept;
    }
  } // End: if ( m_doEtaCut )


  return m_accept;
}
