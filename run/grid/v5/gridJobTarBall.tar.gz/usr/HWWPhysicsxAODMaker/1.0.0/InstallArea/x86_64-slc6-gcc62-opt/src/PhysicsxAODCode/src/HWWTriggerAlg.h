#ifndef HWWCOMMONANALYSISUTILS_HWWTRIGGERALG_H
#define HWWCOMMONANALYSISUTILS_HWWTRIGGERALG_H 1

// STL includes
#include <string>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"

// EDM includes

// Forward declarations
namespace HWW{
  class ITriggerTool;
}


// Put everything into a HWW namespace
namespace HWW {

  class TriggerAlg
    : public ::AthAlgorithm
  {
    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
    public:

      /// Constructor with parameters:
      TriggerAlg( const std::string& name, ISvcLocator* pSvcLocator );

      /// Destructor:
      virtual ~TriggerAlg();

      /// Athena algorithm's initalize hook
      virtual StatusCode  initialize();

      /// Athena algorithm's execute hook
      virtual StatusCode  execute();

      /// Athena algorithm's finalize hook
      virtual StatusCode  finalize();


    private:

      /// @name The properties that can be defined via the python job options
      /// @{

      ToolHandle<HWW::ITriggerTool> m_TrigTool;

      /// The name of the input muon collection
      StringProperty m_inMuons;

      /// The name of the input electron collection
      StringProperty m_inElectrons;

      /// Switch for performing muon trigger matching
      bool m_doMuonMatch;

      /// Switch for performing electron trigger matching
      bool m_doElectronMatch;

      /// Switch for performing di-muon trigger matching
      bool m_doDiMuMatch;

      /// Switch for performing di-electron trigger matching
      bool m_doDiElMatch;

      /// Switch for performing electron-muon trigger matching
      bool m_doElMuMatch;

      /// Prefix used for the decoration variables
      StringProperty m_varPrefix;

      /// @}

      /// @name Other private members
      /// @{
      /// @}
  };

} // End HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWTRIGGERALG_H
