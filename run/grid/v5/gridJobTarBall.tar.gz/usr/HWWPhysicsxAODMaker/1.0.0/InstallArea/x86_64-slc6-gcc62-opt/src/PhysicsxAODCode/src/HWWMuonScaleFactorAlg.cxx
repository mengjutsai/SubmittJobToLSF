///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMuonScaleFactorAlg.cxx
// Implementation file for class HWW::MuonScaleFactorAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWMuonScaleFactorAlg.h"

// STL includes
#include <set>
#include <climits>
#include <cmath>

// boost includes
#include <boost/algorithm/string/predicate.hpp>
#include <boost/algorithm/string/replace.hpp>

// FrameWork includes
#include "GaudiKernel/SystemOfUnits.h"

// EDM includes
#include "xAODEventInfo/EventInfo.h"
#include "xAODCore/ShallowCopy.h"
#include "xAODMuon/Muon.h"
#include "xAODMuon/MuonContainer.h"
#include "xAODMuon/MuonAuxContainer.h"
#include "xAODParticleEvent/IParticleLink.h"

// Tool includes
#include "MuonAnalysisInterfaces/IMuonEfficiencyScaleFactors.h"
#include "PATInterfaces/ISystematicsTool.h"
#include "PATInterfaces/SystematicCode.h"
#include "PATInterfaces/SystematicSet.h"
#include "PATInterfaces/SystematicVariation.h"




// Getting the GeV and such units
using namespace Gaudi::Units;


// Constructors
////////////////
HWW::MuonScaleFactorAlg::MuonScaleFactorAlg( const std::string& name,
                                             ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_inCont(""),
  m_contFindTool("HWW::ContainersFinderTool/ContainersFinderTool"),
  m_decoAllCopies(true),
  m_separator("___"),
  m_muEffiSFToolList(this),
  m_muEffSFVarNameList(),
  m_muEffSFSysNames(),
  m_inContNameAndSysTypeList(),
  m_effiSystVarNameVec()
{
  //
  // Property declaration
  //
  declareProperty("InputContainer",  m_inCont="", "Input container name" );
  declareProperty("ContainersFinderTool", m_contFindTool, "The tool that tries to find all input containers, including their systematic variations" );
  declareProperty("DecorateAllCopies",    m_decoAllCopies, "If true, will decorate all copies of the input container" );

  declareProperty("Separator", m_separator,
                  "The string seperator between the output container name and the sytematic variation (default='___')" );

  declareProperty("MuonEfficiencyScaleFactorTools",  m_muEffiSFToolList,
                  "The ToolHandle for the muon efficiency scale factor tool" );

  declareProperty("EfficiencyScaleFactorVarNames", m_muEffSFVarNameList,
                  "The name of the efficiency scale-factor variable that will be added to the muon" );

  declareProperty("EfficiencySystematicVariations", m_muEffSFSysNames,
                  "The names of all systematic variations to be applied" );
}



// Destructor
///////////////
HWW::MuonScaleFactorAlg::~MuonScaleFactorAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::MuonScaleFactorAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inCont );
  ATH_MSG_DEBUG( "Using: " << m_contFindTool );
  ATH_MSG_DEBUG( "Using DecorateAllCopies: " << m_decoAllCopies );
  ATH_MSG_DEBUG( "Using: " << m_separator );
  ATH_MSG_DEBUG( "Using: " << m_muEffiSFToolList );
  ATH_MSG_DEBUG( "Using: " << m_muEffSFVarNameList );
  ATH_MSG_DEBUG( "Using: " << m_muEffSFSysNames );

  // Perform some sanity checks on the given container names
  if ( m_inCont.value().empty() ) {
    ATH_MSG_FATAL("Wrong user setup! You need to give a valid name for both the InputContainer!");
    return StatusCode::FAILURE;
  }

  // Abort on an unchecked systematics code
  // CP::SystematicCode::enableFailure();

  // Retrieve the tools
  ATH_CHECK(m_contFindTool.retrieve());
  ATH_CHECK(m_muEffiSFToolList.retrieve());
  // Check that we have at least one tool in the list
  if ( m_muEffiSFToolList.empty() ){
    ATH_MSG_FATAL("No muon efficiency scale factor tool given... stopping!");
    return StatusCode::FAILURE;
  }

  // Figure out what systematics are available and recommended
  if ( msgLvl(MSG::DEBUG) || msgLvl(MSG::VERBOSE) ) {
    CP::SystematicSet affSys = m_muEffiSFToolList[0]->affectingSystematics();
    std::string affSysNames = affSys.name();
    boost::replace_all( affSysNames, "-", "\", \"");
    affSysNames = "[\""+affSysNames+"\"]";
    ATH_MSG_DEBUG("Have " << affSys.size() << " affecting systematics with name "
                  << affSysNames << " for tool " << m_muEffiSFToolList[0]->name() );
    CP::SystematicSet recSys = m_muEffiSFToolList[0]->recommendedSystematics();
    std::string recSysNames = recSys.name();
    boost::replace_all( recSysNames, "-", "\", \"");
    recSysNames = "[\""+recSysNames+"\"]";
    ATH_MSG_DEBUG("Have " << recSys.size() << " recommended systematics with name "
                  << recSysNames << " for tool " << m_muEffiSFToolList[0]->name() );
  }

  // Set up the internal vector of systematics and container name post-fixes,
  // starting with the nominal one. First, clear it. Then, add the nominal, then systematics
  m_effiSystVarNameVec.clear();
  m_effiSystVarNameVec.push_back( std::make_pair( CP::SystematicSet(), m_muEffSFVarNameList.value() ) );
  for ( const auto& sysName  :  m_muEffSFSysNames.value() ) {
    CP::SystematicVariation sysVar = CP::SystematicVariation(sysName);
    if ( m_muEffiSFToolList[0]->isAffectedBySystematic(sysVar) ) {
      CP::SystematicSet sysSet{sysVar};
      std::vector<std::string> varNameList;
      for ( const std::string& varName : m_muEffSFVarNameList.value() ){
        varNameList.push_back( varName + m_separator.value() + sysName );
      }
      m_effiSystVarNameVec.push_back( std::make_pair( sysSet, varNameList ) );
      ATH_MSG_DEBUG("Adding systematic variation with name " << sysName );
    }
    else {
      CP::SystematicSet affSys = m_muEffiSFToolList[0]->affectingSystematics();
      std::string affSysNames = affSys.name();
      boost::replace_all( affSysNames, "-", "\", \"");
      affSysNames = "[\""+affSysNames+"\"]";
      ATH_MSG_WARNING("Couldn't find systematic variation with name " << sysName
                      << " amongst the affected systematics: " << affSysNames );
      return StatusCode::FAILURE;
    }
  } // End: adding all systematic variations to be processed

  return StatusCode::SUCCESS;
}



StatusCode HWW::MuonScaleFactorAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release the tools
  ATH_CHECK(m_contFindTool.release());
  ATH_CHECK(m_muEffiSFToolList.release());

  return StatusCode::SUCCESS;
}



StatusCode HWW::MuonScaleFactorAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Open EventInfo container
  const xAOD::EventInfo* evtInfo;
  ATH_CHECK( evtStore()->retrieve(evtInfo) );

  // Only do the event vetoing on data
  const bool isSim = evtInfo->eventType(xAOD::EventInfo::EventType::IS_SIMULATION);
  if ( !isSim ) {
    ATH_MSG_DEBUG ("It is a data event... nothing to be done...");
    return StatusCode::SUCCESS;
  }

  // Get the number of tools that we will iterate over
  const std::size_t nTools = m_muEffiSFToolList.size();


  // Now, let's try to get all requested containers and iterate over them.
  // If not specifically requested to get all copies, only the exactly given
  // name will be retrieved. Otherwise, all containers with the same base-name,
  // i.e, the part before the "___", if present, will be used.
  // Do this expensive string manupulation and StoreGate search only the first time.
  if (m_inContNameAndSysTypeList.empty()){
    if (m_decoAllCopies){
      ATH_CHECK( m_contFindTool->muonNamesAndSysTypes( m_inContNameAndSysTypeList, m_inCont.value() ) );
      ATH_MSG_DEBUG("Found " << m_inContNameAndSysTypeList.size() << " input containers to run over");
    }
    else {
      m_inContNameAndSysTypeList.push_back( std::make_pair( m_inCont.value(), HWW::SystematicType::NOMINAL ) );
      ATH_MSG_DEBUG("Only using the one given input container name to run over");
    }
  }


  // Open the input container
  for ( std::size_t contIdx=0; contIdx<m_inContNameAndSysTypeList.size(); ++contIdx ) {
    const xAOD::MuonContainer* inCont;
    ATH_CHECK( evtStore()->retrieve( inCont, m_inContNameAndSysTypeList.at(contIdx).first ));
    if ( inCont->size() == 0 ) {
      ATH_MSG_DEBUG("Have an empty input container... going to the next");
      continue;
    }
    ATH_MSG_VERBOSE("Now reading input container with name: " << m_inContNameAndSysTypeList.at(contIdx).first
                    << " and size: " <<" "<<inCont->size());

    // Check the systematics type of the input container
    HWW::SystematicType inContSysType = m_inContNameAndSysTypeList.at(contIdx).second;

    // Loop over the different tools that are provided
    for ( std::size_t toolIdx=0; toolIdx<nTools; ++toolIdx){

      // Now, we will loop over the efficiency scale-factor systematics to be applied
      for ( const auto& systVariationAndVarName : m_effiSystVarNameVec ) {
        const CP::SystematicSet& systSet = systVariationAndVarName.first;
        const std::string& varName       = systVariationAndVarName.second[toolIdx];

        // Set the tool state to apply a systematic variation.
        // Event if it is an empty variation, i.e, the nominal case, set the
        // state of the tool to that to avoid that the tool is still in a
        // systematic state from the previous event.
        ATH_MSG_VERBOSE("Name of the next variation: " << systSet.name() );
        if( m_muEffiSFToolList[toolIdx]->applySystematicVariation( systSet ) != CP::SystematicCode::Ok ) {
          ATH_MSG_ERROR("Cannot configure MuonEfficiencyScaleFactors for systematic variation " << systSet.name() );
          return StatusCode::FAILURE;
        }
        if ( !((systSet.name()).empty()) ) {
          // If we are NOT on the nominally calibrated 4-vector container, but
          // rather on a container with systematically varied 4-vectors, we
          // actually don't also apply the systematically varied scale factors,
          // i.e., we don't have both systematics (4-vector AND efficiency) at the
          // same time.
          if ( inContSysType == HWW::SystematicType::FOURMOM ) {
            ATH_MSG_DEBUG("We encountered an efficiency systematic set. "
                          << "but we are currenlty looking at a container with "
                          << "a systematically varied 4-vector... thus skipping.");
            // We can actually break out of the loop over efficiency systematics
            // here, because the nominal efficiency is always the first one in our
            // set of efficiency "systematics"
            break;
          }
        }
        ATH_MSG_DEBUG("Going to run muon efficiency scale-factor systematic variation (empty=nominal): " << systSet.name() );

        // Create the accassor for the new variable that will hold the efficiency scale factor
        SG::AuxElement::Decorator<float> decoSetEffiSF(varName);


        // Loop over all Muons in the current input container
        for ( const xAOD::Muon* muon : *inCont ) {
          ATH_MSG_VERBOSE("Now iterating over the muon container... at index=" << muon->index() );
          float effiSFValue(1.0);
          if ( m_muEffiSFToolList[toolIdx]->getEfficiencyScaleFactor(*muon,effiSFValue) == CP::CorrectionCode::Error ) {
            ATH_MSG_ERROR("MuonEfficiencyScaleFactors reported a CP::CorrectionCode::Error");
            return StatusCode::FAILURE;
          }
          // Decorate the current muon with the resulting efficiency scale-factor
          ATH_MSG_VERBOSE("Decorating the muon with an efficiency scale-factor variable with name "
                          << varName << " and value " << effiSFValue );
          decoSetEffiSF(*muon) = effiSFValue;
        } // End: loop over Muons

      } // End: loop over systematic variations

    } // End: loop over the scale-factor tools

  } // End: loop over input containers


  // TODO: Do the bookkeeping stuff

  return StatusCode::SUCCESS;
}
