// HWWMETReducerAlg.cxx

// PhysicsxAODCode includes
#include "HWWMETReducerAlg.h"

// EDM includes
#include "xAODMissingET/MissingETContainer.h"
#include "xAODMissingET/MissingETAuxContainer.h"


namespace HWW {

  //**********************************************************************

  METReducerAlg::METReducerAlg(const std::string& name, ISvcLocator* pSvcLocator ) :
    ::AthAlgorithm( name, pSvcLocator ),
    m_metContName("")
  {
    declareProperty( "METContainer", m_metContName, "The name of the input and output MET container" );
  }


  //**********************************************************************


  METReducerAlg::~METReducerAlg() { }


  //**********************************************************************


  StatusCode METReducerAlg::initialize()
  {
    ATH_MSG_DEBUG("Initializing " << name() << "...");
    ATH_MSG_DEBUG( "Using: " << m_metContName );

    // Some sanity checks of the user configuration
    if ( m_metContName.value().empty() ){
      ATH_MSG_FATAL("You need to specify: " << m_metContName );
      return StatusCode::FAILURE;
    }

    return StatusCode::SUCCESS;
  }


  //**********************************************************************


  StatusCode METReducerAlg::finalize()
  {
    ATH_MSG_DEBUG ("Finalizing " << name() << "...");
    return StatusCode::SUCCESS;
  }


  //**********************************************************************


  StatusCode METReducerAlg::execute()
  {
    ATH_MSG_DEBUG("Executing " << name() << "...");

    // Retrieve containers ***********************************************

    /// MET
    const xAOD::MissingETContainer* inMETCont = nullptr;
    ATH_CHECK( evtStore()->retrieve(inMETCont, m_metContName.value()) );

    // Create a MissingETContainer with its aux store
    xAOD::MissingETContainer* newMet = new xAOD::MissingETContainer();
    xAOD::MissingETAuxContainer* metAuxCont = new xAOD::MissingETAuxContainer();
    newMet->setStore(metAuxCont);

    // Copy over only the final terms from the input to the output met container
    for ( const xAOD::MissingET* met : *inMETCont ){
      if ( met->source() != MissingETBase::Source::total() ) continue;
      xAOD::MissingET* copyMETTotal = new xAOD::MissingET();
      newMet->push_back(copyMETTotal);
      *copyMETTotal = *met;
    }

    // Now, overwrite the existing met container with the new, reduced one
    ATH_CHECK( evtStore()->overwrite(newMet, m_metContName.value()) );
    ATH_CHECK( evtStore()->overwrite(metAuxCont, m_metContName.value()+"Aux.") );

    return StatusCode::SUCCESS;
  }
}
