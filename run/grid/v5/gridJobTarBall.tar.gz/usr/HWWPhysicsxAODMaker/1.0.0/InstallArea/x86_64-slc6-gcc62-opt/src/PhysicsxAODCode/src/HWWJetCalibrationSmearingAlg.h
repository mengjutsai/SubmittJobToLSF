///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetCalibrationSmearingAlg.h
// Header file for class HWWJetCalibrationSmearingAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWJETCALIBRATIONSMEARINGALG_H
#define HWWCOMMONANALYSISUTILS_HWWJETCALIBRATIONSMEARINGALG_H 1

// STL includes
#include <vector>
#include <string>
#include <utility>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"
#include "PATInterfaces/SystematicSet.h"

// forward declarations
class IJetCalibrationTool;
class ICPJetUncertaintiesTool;
class IJERSmearingTool;



// Put everything into a HWW namespace
namespace HWW {

  class JetCalibrationSmearingAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
   public:

    // Copy constructor:

    /// Constructor with parameters:
    JetCalibrationSmearingAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~JetCalibrationSmearingAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
   private:

    /// Default constructor:
    // JetCalibrationSmearingAlg();

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input container name
    StringProperty m_inCont;

    /// The output container name
    StringProperty m_outCont;

    /// Enable using the truth b-jet labeling to get flavor-dependent JES uncertainties (default: true)
    BooleanProperty m_doBJES;

    /// The suffix for the JES systematic variation name as used in the output
    /// container name; to be added before the '__1up/down' part
    StringProperty m_jesNameSuffix;

    /// The names of all systematic variations to be applied for the JES
    StringArrayProperty m_jesSmearSysNames;

    /// The name of the MC, either 'MC15' (default) or 'AFII'
    StringProperty m_mcType;

    /// The names of all systematic variations to be applied for the JER
    StringArrayProperty m_jerSmearSysNames;


    /// The ToolHandle for the jet calibration tool
    ToolHandle<IJetCalibrationTool> m_jetCalibTool;


    /// The ToolHandle for the jet energy scale uncertainties tool
    ToolHandle<ICPJetUncertaintiesTool> m_jesUncertaintyTool;

    /// The ToolHandle for the jet energy scale uncertainties tool for systematics
    ToolHandle<ICPJetUncertaintiesTool> m_jesSysUncertaintyTool;


    /// The ToolHandle for the jet energy resolution smearing tool
    ToolHandle<IJERSmearingTool> m_jerSmearTool;


    /// The string separator between the output container name and the sytematic variation (default="___")
    StringProperty m_separator;


    /// Enable a hack for using the fat-jet
    BooleanProperty m_doFatJetHack;

    /// @}


  private:

    /// @name Truly private internal data members
    /// @{

    /// The vector of all JES momentum systematics and the corresponding container-name post-fixes
    std::vector< std::pair< CP::SystematicSet, std::string > > m_jesSystVarNameVec;

    /// The vector of all JER momentum systematics and the corresponding container-name post-fixes
    std::vector< std::pair< CP::SystematicSet, std::string > > m_jerSystVarNameVec;

    /// @}


  };

} // End HWW Namespace



///////////////////////////////////////////////////////////////////
// Inline methods:
///////////////////////////////////////////////////////////////////


#endif //> !HWWCOMMONANALYSISUTILS_HWWJETCALIBRATIONSMEARINGALG_H
