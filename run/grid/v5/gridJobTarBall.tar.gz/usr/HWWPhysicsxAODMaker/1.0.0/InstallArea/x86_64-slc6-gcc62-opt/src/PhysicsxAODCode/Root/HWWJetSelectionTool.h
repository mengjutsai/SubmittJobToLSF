///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetSelectionTool.h
// Header file for class HWW:JetSelectionTool
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWJETSELECTIONTOOL_H
#define HWWCOMMONANALYSISUTILS_HWWJETSELECTIONTOOL_H 1

// STL includes
#include <string>

// FrameWork includes
#include "GaudiKernel/ServiceHandle.h"
#include "AsgTools/AsgTool.h"

// PATCore includes
#include "PATCore/TAccept.h"
#include "PATCore/IAsgSelectionWithVertexTool.h"

// EDM includes
#include "xAODTracking/VertexFwd.h"
#include "xAODMuon/Muon.h"

// Forward declaration
namespace xAOD{
  class IParticle;
}



namespace HWW {

  class JetSelectionTool
    : virtual public asg::AsgTool,
      virtual public IAsgSelectionWithVertexTool
  {
    ASG_TOOL_CLASS(JetSelectionTool, IAsgSelectionWithVertexTool)

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
  public:

    /// Constructor with parameters:
    JetSelectionTool( std::string name );

    /// Destructor:
    virtual ~JetSelectionTool();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();


    ///////////////////////////////////////////////////////////////////
    // Const methods:
    ///////////////////////////////////////////////////////////////////

    /** Method to get the plain TAccept.
        This is needed so that one can already get the TAccept
        and query what cuts are defined before the first object
        is passed to the tool. */
    virtual const Root::TAccept& getTAccept( ) const final override;


    /// The main accept method: the actual cuts are applied here
    virtual const Root::TAccept& accept( const xAOD::IParticle* part,
                                         const xAOD::Vertex* primVtx=0 ) const final override;


  private:
    /// @name The update handlers. They can detect if a property was set from the
    ///       python job option side
    /// @{

    /// This internal method will realize if a user sets a JVT cut property
    void setupJVTCut( Property& /*prop*/ );

    /// This internal method will realize if a user sets a b-tagging cut property
    void setupBTagCut( Property& /*prop*/ );

    /// @}


    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
   private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The property for CutPtMin
    DoubleArrayProperty m_ptMinList;

    /// The property for CutAbsEtaMax
    DoubleArrayProperty m_absEtaMaxList;


    /// The property for CutCleanList
    StringArrayProperty m_cleanList;

    /// The property for CutCleanPtMinList
    DoubleArrayProperty m_cleanPtMinList;


    /// Variable name for the updated JVT
    StringProperty m_updatedJVTName;

    /// Name of the variable that stores if a forward jet passes the FJVT selection
    StringProperty m_passForwardJVTName;

    /// Name of the variable that stores if a jet passes the JVT selection
    StringProperty m_passJVTName;

    /// The property for CutJVTMaxPt
    DoubleProperty m_jvtMaxPt;

    /// The property for CutJVTMaxAbsEta
    DoubleProperty m_jvtMaxAbsEta;

    /// A flag that will be true if a JVT cut was configured
    bool m_doJVTCut;


    /// Require the jet to be truth-matched
    bool m_requireTruthMatch;


    /// The property for CutBTagName
    StringProperty m_bTagWeightName;

    /// The property for CutBTagMin
    DoubleProperty m_bTagWeightMin;

    /// The property for CutBTagMax
    DoubleProperty m_bTagWeightMax;

    /// A flag that will be true if a b-tagging cut was configured
    bool m_doBTagCut;

    /// @}


    /// @name Internal members
    /// @{

    /// The return object
    mutable Root::TAccept m_accept;


    /// The position of the pt-eta (2-d) cut in the TAccept return object
    int m_cutPosition_pteta;

    /// The position of the JetCleaning cut in the TAccept return object
    int m_cutPosition_clean;

    /// The position of the jet-vertex-tagger (JVT) cut in the TAccept return object
    int m_cutPosition_jvt;

    /// The position of the forward jet-vertex-tagger (FJVT) cut in the TAccept return object
    int m_cutPosition_forwardjvt;

    /// The position of the jet truth-match cut in the TAccept return object
    int m_cutPosition_tm;

    /// The position of the b-tagging cut in the TAccept return object
    int m_cutPosition_btag;

    /// @}

  };

} // End: namespace HWW


///////////////////////////////////////////////////////////////////
// Inline methods:
///////////////////////////////////////////////////////////////////

inline void HWW::JetSelectionTool::setupJVTCut( Property& /*prop*/ ) {
  m_doJVTCut = true;
  return;
}

inline void HWW::JetSelectionTool::setupBTagCut( Property& /*prop*/ ) {
  m_doBTagCut = true;
  return;
}


#endif //> !HWWCOMMONANALYSISUTILS_HWWJETSELECTIONTOOL_H
