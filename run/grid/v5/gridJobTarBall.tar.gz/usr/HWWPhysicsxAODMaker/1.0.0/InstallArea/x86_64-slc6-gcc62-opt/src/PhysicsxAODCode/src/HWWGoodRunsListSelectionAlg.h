#ifndef HWWCOMMONANALYSISUTILS_HWWGOODRUNSLISTSELECTIONALG_H
#define HWWCOMMONANALYSISUTILS_HWWGOODRUNSLISTSELECTIONALG_H 1

// STL includes
#include <string>

// FrameWork includes
#include "AthenaBaseComps/AthFilterAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"
#include "GaudiKernel/ServiceHandle.h"

// EDM includes

// Forward declarations
class IJobOptionsSvc;
class IGoodRunsListSelectionTool;


// Put everything into a HWW namespace
namespace HWW {

  class GoodRunsListSelectionAlg
    : public ::AthFilterAlgorithm
  {
    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
    public:
    
      /// Constructor with parameters:
      GoodRunsListSelectionAlg( const std::string& name, ISvcLocator* pSvcLocator );
    
      /// Destructor:
      virtual ~GoodRunsListSelectionAlg();
    
      /// Athena algorithm's initalize hook
      virtual StatusCode  initialize();
    
      /// Athena algorithm's execute hook
      virtual StatusCode  execute();
    
      /// Athena algorithm's finalize hook
      virtual StatusCode  finalize();

  
    private:
    
      /// @name The properties that can be defined via the python job options
      /// @{
    
      // TODO Add more properties from GoodRunsListSelectionTool
      // The list of GoodRunsList names
      StringArrayProperty m_goodrunslistVec;
    
      /// The job options service (will be used to forward this algs properties to the private tool)
      ServiceHandle<IJobOptionsSvc> m_jos;
    
      // The ToolHandle for the GoodRunsListSelectionTool
      ToolHandle<IGoodRunsListSelectionTool> m_GRLSelectionTool;
    
      /// @}
    
    private:
    
      // The update handlers
    
      /// This internal method will realize if the GoodRunsListVec property was set
      void setupGRL( Property& /*prop*/ );
  
      ///////////////////////////////////////////////////////////////////
      // Private data:
      ///////////////////////////////////////////////////////////////////
  
      /// Internal event counter
      unsigned long m_nEventsProcessed;
    
      // This boolean is true if the GoodRunsListVec property was set
      bool m_setGRL;

  };
  
} // End HWW namespace

///////////////////////////////////////////////////////////////////
// Inline methods:
///////////////////////////////////////////////////////////////////

/// This internal method will realize if the GoodRunsListVec property was set
inline void HWW::GoodRunsListSelectionAlg::setupGRL( Property& /*prop*/ )
{
  m_setGRL = true;
  return;
}

#endif //> !HWWCOMMONANALYSISUTILS_HWWGOODRUNSLISTSELECTIONALG_H
