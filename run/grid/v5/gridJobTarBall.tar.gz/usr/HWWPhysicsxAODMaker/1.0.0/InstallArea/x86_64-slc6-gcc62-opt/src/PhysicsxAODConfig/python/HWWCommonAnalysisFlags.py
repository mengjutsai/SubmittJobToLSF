##=============================================================================
## Name:        HWWCommonAnalysisFlags.py
##
## Author:      Karsten Koeneke
## Created:     August 2014
##
## Description: Here, all neccessary job flags that are commonly needed for
##              all Higgs->WW analyzes are defined.
##=============================================================================

__doc__ = """Here, all neccessary job flags for the common aspects of all the Higgs->WW analyzes are defined."""
__version__ = "0.0.1"
__author__  = "Karsten Koeneke <karsten.koeneke@cern.ch>"

from AthenaCommon.JobProperties import JobProperty, JobPropertyContainer
from AthenaCommon.JobProperties import jobproperties

# Import the module that allows to use named units, e.g. GeV
from AthenaCommon.SystemOfUnits import *

# Import the common helper functions
from PhysicsxAODConfig.HWWCommonHelpers import buildContainerNames

# Import ROOT
import PyUtils.RootUtils as ru
ROOT = ru.import_root()

# Import PyCintex to get enums from dictionaries for electron/muon isolation
import cppyy
cppyy.loadDictionary('xAODPrimitivesDict')
IsoEnums = ROOT.xAOD.Iso

# Get muon quality enums
cppyy.loadDictionary('xAODMuonDict')
MuonQualityEnums = ROOT.xAOD.Muon_v1

# Get the egamma enums
# cppyy.loadDictionary('xAODEgammaDict')
# EGammaEnums = ROOT.xAOD.



#=====================================================================
# First define container for the flags
#=====================================================================
class HWWCommonAnalysisFlags(JobPropertyContainer):
    """ The Higgs->WW common analysis flag/job property container."""
jobproperties.add_Container(HWWCommonAnalysisFlags)

#short-cut to get the HiggsWWCommonAnalysisFlags container with this one line:
#'from PhysicsxAODConfig.HWWCommonAnalysisFlags import hWWCommon'
#Note that name has to be different to avoid problems with pickle
hWWCommon = jobproperties.HWWCommonAnalysisFlags

#=====================================================================
# Now define each flag and add it to the container
#=====================================================================

class Global(JobProperty):
    """Steer the common aspects of the H->WW analyzes"""
    
    FatJets                = True 
    statusOn               = True
    allowedTypes           = ['bool']
    StoredValue            = True
    logLevel               = 3 # 3=INFO, 2=DEBUG
    do1Lep                 = False
    do2Lep                 = False
    do3Lep                 = False
    do4Lep                 = False
    doFakeLep              = False
    doFakeWJets            = False
    doFakeZJets            = False
    doMediumOtherLeptons   = False
    doVeryLooseLH          = False
    doORNoMuNearJetRemoval = False
    doORNoMuNearJetRemovalNoBJetPrecedence = False
    doEventPreSelection    = True
    doTruthFlagging        = True
    doCalibrations         = True
    doSelections           = True
    doOverlapRemoval       = True
    doCandidateBuilding    = True
    doEffiScaleFactors     = False #mgeisen
    doOnlyEffiScaleFactors = False
    doFilterEffiSFSeq      = True
    doThinning             = True
    inputIsSimulation      = False # This is a default. It will be determined from the input automatically
    inputSimulationType    = "" # This is a default. It will be determined from the input automatically: "FullSim" or "AFII"
    inputIsDAOD            = False # This is a default. It will be determined from the input automatically
    inputStreamName        = ""
    inputRelease           = "21.2" # This will be checked, and overwritten, if needed
    beamEnergy             = 6.5*TeV
    bunchSpacing           = 25 #[ns] The default. If input is 50ns, this will be changed automatically
    doGRLSelection         = True
    #grlFileList            = [ "GoodRunsLists/data15_13TeV/20160720/data15_13TeV.periodAllYear_DetStatus-v79-repro20-02_DQDefects-00-02-02_PHYS_StandardGRL_All_Good_25ns.xml",
    #                           "GoodRunsLists/data16_13TeV/20170215/data16_13TeV.periodAllYear_DetStatus-v88-pro20-21_DQDefects-00-02-04_PHYS_StandardGRL_All_Good_25ns.xml"
    #                           ]
    grlFileList            = [ "GoodRunsLists/data15_13TeV/20170619/data15_13TeV.periodAllYear_DetStatus-v89-pro21-02_Unknown_PHYS_StandardGRL_All_Good_25ns.xml",
                               "GoodRunsLists/data16_13TeV/20170605/data16_13TeV.periodAllYear_DetStatus-v89-pro21-01_DQDefects-00-02-04_PHYS_StandardGRL_All_Good_25ns.xml",
                               #"GoodRunsLists/data17_13TeV/20171130/data17_13TeV.periodAllYear_DetStatus-v97-pro21-13_Unknown_PHYS_StandardGRL_All_Good_25ns_Triggerno17e33prim.xml"
                             ]
    grlName                = "PHYS_StandardGRL_All_Good"
    #LumiCalcFiles          = [ "GoodRunsLists/data15_13TeV/20160720/physics_25ns_20.7.lumicalc.OflLumi-13TeV-005.root",
    #                           "GoodRunsLists/data16_13TeV/20170215/physics_25ns_20.7.lumicalc.OflLumi-13TeV-008.root",
    #                           ]
    LumiCalcFiles          = [ "GoodRunsLists/data15_13TeV/20170619/PHYS_StandardGRL_All_Good_25ns_276262-284484_OflLumi-13TeV-008.root",
                               "GoodRunsLists/data16_13TeV/20170605/PHYS_StandardGRL_All_Good_25ns_297730-311481_OflLumi-13TeV-008.root",
                               #"GoodRunsLists/data17_13TeV/20171130/physics_25ns_Triggerno17e33prim.lumicalc.OflLumi-13TeV-001.root"
                             ]
    doPileupReweighting               = False #mgeisen
    doGeneratePileupReweightingConfig = False
    
    #PileupReweightingConfigFiles      = [ "PhysicsxAODConfig/mc15c_v2_defaults.NotRecommended.prw.root" ]
    PileupReweightingConfigFiles      = [ "PhysicsxAODConfig/user.mgeisen.ggf.myPRW.root",
                                          "PhysicsxAODConfig/user.mgeisen.vbf.myPRW.root",
                                          "PhysicsxAODConfig/user.mgeisen.ttbar.myPRW.root" ]
    PileupReweightingDefaultChannel   = 2 # Currently not used in the job options, as recommended
    PileupReweightingDataScaleFactor     = 1./1.03
    PileupReweightingDataScaleFactorUP   = 1.0 # TODO: update to rel21 MC16 recommendation when available (https://twiki.cern.ch/twiki/bin/view/AtlasProtected/ExtendedPileupReweighting)
    PileupReweightingDataScaleFactorDOWN = 1./1.18 # TODO: update to rel21 MC16 recommendations when available (https://twiki.cern.ch/twiki/bin/view/AtlasProtected/ExtendedPileupReweighting)
    doP4Systematics            = True
    doEffiSystematics          = True
    doTriggerSelection         = True
    doTriggerMatching          = True
    requireAlgList             = [] # This list will ist the algorithm instance names that everyone needs to add to their requireAlgs output stream
    breakUpAuxContainers       = False
    # auxContsToBreakUp          = [ "EventInfoAux.", "AntiKt4PV0TrackJetsAux." ]
    auxContsToBreakUp          = [  ]
    writeLeptonTrackParticles  = False
    writeLeptonCaloClusters    = False
    writeJetCaloClusters       = False
    writeTruthParticles        = False
    pass
hWWCommon.add_JobProperty(Global)



class Trigger(JobProperty):
    """Common trigger definitions for all the H->WW analyzes"""
    statusOn                     = True
    allowedTypes                 = ['bool']
    StoredValue                  = True
    triggerMatchPrefix           = "trigMatch_"
    triggerPassPrefix            = "pass_"
    ## Extended list of trigger chains ##
    
    electronTriggerList          = [ "HLT_e24_lhmedium_L1EM20VH",             # 2015
                                     "HLT_e24_lhmedium_L1EM18VH",
                                     "HLT_e60_lhmedium",
                                     "HLT_e120_lhloose",
                                     "HLT_e24_lhtight_nod0_ivarloose",        # 2016
                                     "HLT_e26_lhtight_nod0_ivarloose",
                                     "HLT_e17_lhloose",                        # Legs from the electron-muon triggers 2015
                                     "HLT_e7_lhmedium",
                                     "HLT_e17_lhloose_nod0",                   # Legs from the electron-muon triggers 2016
                                     "HLT_e7_lhmedium_nod0",
                                     "HLT_e60_lhmedium_nod0",                  # 2016 + 2017
                                     "HLT_e140_lhloose_nod0",
                                     "HLT_e28_lhtight_nod0_ivarloose",         # 2017
                                     "HLT_e300_etcut"
                                   ]
    diElectronTriggerList        = [ "HLT_2e12_lhloose_L12EM10VH",             # 2015
                                     "HLT_2e17_lhvloose_nod0",                 # 2016 + 2017
                                     "HLT_2e17_lhvloose_nod0_L12EM15VHI*",     # 2017
                                     
                                   ]
    multiElectronTriggerList     = [ "HLT_e17_lhloose_2e9_lhloose",            # 2015
                                     "HLT_e17_lhloose_nod0_2e9_lhloose_nod0",  # 2016
                                     "HLT_e24_lhvloose_nod0_2e12_lhvloose_nod0_L1EM20VH_3EM10VH" # 2017
                                   ]
    
    muonTriggerList              = [ "HLT_mu20_iloose_L1MU15",                 # 2015
                                     "HLT_mu50",
                                     "HLT_mu24_ivarmedium",                    # 2016
                                     "HLT_mu26_imedium",
                                     "HLT_mu24_imedium", 
                                     "HLT_mu14",                               # Legs from the electron-muon triggers
                                     "HLT_mu24",
                                     "HLT_mu26_ivarmedium",                    # 2016 + 2017
                                     "HLT_mu50",                               # 2017
                                     "HLT_mu60_0eta105_msonly"
                                   ] 
    muonTriggerSFFullList        = [ ["HLT_mu20_iloose_L1MU15_OR_HLT_mu50","HLT_mu24_ivarmedium_OR_HLT_mu50"],
                                     ["HLT_mu20_iloose_L1MU15_OR_HLT_mu50","HLT_mu26_ivarmedium_OR_HLT_mu50"],
                                     #["HLT_mu10","HLT_mu10"],
                                     ["HLT_mu18", "HLT_mu22"],
                                     ["HLT_mu8noL1", "HLT_mu8noL1"],
                                     ["HLT_mu14","HLT_mu14"],
                                     ["HLT_mu24","HLT_mu24"] ]  # The first one of the pair is always for data2015, the second one for data2016
    diMuonTriggerList            = [ "HLT_mu18_mu8noL1",                       # 2015
                                     "HLT_2mu10",
                                     "HLT_mu20_mu8noL1",                       # 2016
                                     "HLT_mu22_mu8noL1",                       # 2016 + 2017
                                     "HLT_2mu14",                              # 2017
                                     "HLT_mu22_mu8noL1_calotag_0eta010"
                                   ]
    multiMuonTriggerList         = [ "HLT_3mu6",
                                     "HLT_3mu6_msonly",
                                     "HLT_mu20_2mu4noL1",
                                     "HLT_3mu4",
                                   ]
    
    #muonTriggerSFReducedList     = [ "HLT_mu20_iloose_L1MU15_OR_HLT_mu50" ]
    
    ## Additional electron-muon trigger chains
    electronMuonTriggerList      = [ "HLT_e17_lhloose_mu14",                   # 2015
                                     "HLT_e7_lhmedium_mu24",
                                     "HLT_e17_lhloose_nod0_mu14",              # 2016 + 2017
                                     "HLT_e7_lhmedium_nod0_mu24",
                                     "HLT_e26_lhmedium_nod0_mu8noL1",          # 2017
                                   ] 
    multiElectronMuonTriggerList = [ "HLT_2e12_lhloose_mu10",                  # 2015
                                     "HLT_e12_lhloose_2mu10",
                                     "HLT_2e12_lhloose_nod0_mu10",             # 2016 + 2017
                                     "HLT_e12_lhloose_nod0_2mu10",
                                   ]
    
    singleLeptonTriggerList      = trigList = muonTriggerList + electronTriggerList
    diLeptonTriggerList          = diMuonTriggerList + diElectronTriggerList + electronMuonTriggerList
    multiLeptonTriggerList       = multiMuonTriggerList + multiElectronTriggerList + multiElectronMuonTriggerList
    allLeptonTriggerList         = singleLeptonTriggerList + diLeptonTriggerList + multiLeptonTriggerList
    metTriggerList               = [ "HLT_xe70" ]
    allTriggerList               = allLeptonTriggerList + metTriggerList
    pass
hWWCommon.add_JobProperty(Trigger)



class Electrons(JobProperty):
    """Definitions for the common electrons of all the H->WW analyzes"""
    statusOn            = True
    allowedTypes        = ['bool']
    StoredValue         = True
    inCont              = "Electrons"
    calibCont           = "HWWCalibElectrons"
    calibPreSelCont     = "HWWCalibPreSelElectrons"
    calibPreSelORCont   = "HWWCalibPreSelORElectrons"
    finalCont           = "HWWElectrons"
    finalAllPtSortCont  = "FinalAllPtSort"+finalCont
    def finalContList(self) :
        """ The names of the final electron containers. This is a list because every
        4-vector systematic variation is stored in its own container. Thus, we
        are building the list of all these containers using a helper function."""
        return buildContainerNames(baseName=self.finalCont, systList=hWWCommon.Electrons.p4Systs)

    ESModel                 = "es2016data_mc15c"
    decorrelationModel      = "1NPCOR_PLUS_UNCOR"
    p4Systs                 = ["EG_RESOLUTION_ALL__1down", "EG_RESOLUTION_ALL__1up",
                               "EG_SCALE_ALLCORR__1down", "EG_SCALE_ALLCORR__1up",
                               "EG_SCALE_E4SCINTILLATOR__1down", "EG_SCALE_E4SCINTILLATOR__1up",
                               "EG_SCALE_LARCALIB_EXTRA2015PRE__1down", "EG_SCALE_LARCALIB_EXTRA2015PRE__1up",
                               "EG_SCALE_LARTEMPERATURE_EXTRA2015PRE__1down", "EG_SCALE_LARTEMPERATURE_EXTRA2015PRE__1up",
                               "EG_SCALE_LARTEMPERATURE_EXTRA2016PRE__1down", "EG_SCALE_LARTEMPERATURE_EXTRA2016PRE__1up"]

    # The file path prefix for all scale-factor configuration files
    correctionFilePathPrefix   = "ElectronEfficiencyCorrection/2015_2016/rel20.7/Moriond_February2017_v1/"
    correctionFilePathPrefixV2 = "ElectronEfficiencyCorrection/2015_2016/rel20.7/Moriond_February2017_v2/"

    # Identification scale-factors
    effiVarName             = "effiSF"
    effiVarNameList         = [ effiVarName+"LooseAndBLayerLLH", effiVarName+"MediumLH", effiVarName+"TightLH" ]
    effiCorrectionFiles     = [correctionFilePathPrefix+"offline/efficiencySF.offline.LooseAndBLayerLLH_d0z0_v11.root",
                               correctionFilePathPrefix+"offline/efficiencySF.offline.MediumLLH_d0z0_v11.root",
                               correctionFilePathPrefix+"offline/efficiencySF.offline.TightLLH_d0z0_v11.root" ]
    effiIDCorrelationModel  = "SIMPLIFIED"
    effiSysts               = ["EL_EFF_ID_CorrUncertaintyNP0__1down", "EL_EFF_ID_CorrUncertaintyNP0__1up",
                               "EL_EFF_ID_CorrUncertaintyNP1__1down", "EL_EFF_ID_CorrUncertaintyNP1__1up",
                               "EL_EFF_ID_CorrUncertaintyNP2__1down", "EL_EFF_ID_CorrUncertaintyNP2__1up",
                               "EL_EFF_ID_CorrUncertaintyNP3__1down", "EL_EFF_ID_CorrUncertaintyNP3__1up",
                               "EL_EFF_ID_CorrUncertaintyNP4__1down", "EL_EFF_ID_CorrUncertaintyNP4__1up",
                               "EL_EFF_ID_CorrUncertaintyNP5__1down", "EL_EFF_ID_CorrUncertaintyNP5__1up",
                               "EL_EFF_ID_CorrUncertaintyNP6__1down", "EL_EFF_ID_CorrUncertaintyNP6__1up",
                               "EL_EFF_ID_CorrUncertaintyNP7__1down", "EL_EFF_ID_CorrUncertaintyNP7__1up",
                               "EL_EFF_ID_CorrUncertaintyNP8__1down", "EL_EFF_ID_CorrUncertaintyNP8__1up",
                               "EL_EFF_ID_CorrUncertaintyNP9__1down", "EL_EFF_ID_CorrUncertaintyNP9__1up",
                               "EL_EFF_ID_CorrUncertaintyNP10__1down", "EL_EFF_ID_CorrUncertaintyNP10__1up",
                               "EL_EFF_ID_CorrUncertaintyNP11__1down", "EL_EFF_ID_CorrUncertaintyNP11__1up",
                               "EL_EFF_ID_CorrUncertaintyNP12__1down", "EL_EFF_ID_CorrUncertaintyNP12__1up",
                               "EL_EFF_ID_CorrUncertaintyNP13__1down", "EL_EFF_ID_CorrUncertaintyNP13__1up",
                               "EL_EFF_ID_CorrUncertaintyNP14__1down", "EL_EFF_ID_CorrUncertaintyNP14__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP0__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP0__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP1__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP1__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP2__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP2__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP3__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP3__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP4__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP4__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP5__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP5__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP6__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP6__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP7__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP7__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP8__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP8__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP9__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP9__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP10__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP10__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP11__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP11__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP12__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP12__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP13__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP13__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP14__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP14__1up",
                               "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP15__1down", "EL_EFF_ID_SIMPLIFIED_UncorrUncertaintyNP15__1up"]

    # Reconstruction scale-factors
    effiRecoVarNameList         = [effiVarName+"RecoTrk"]
    effiRecoCorrectionFiles     = [correctionFilePathPrefix+"offline/efficiencySF.offline.RecoTrk.root"]
    effiRecoCorrelationModel    = "TOTAL"
    effiRecoSysts               = ["EL_EFF_Reco_TOTAL_1NPCOR_PLUS_UNCOR__1down", "EL_EFF_Reco_TOTAL_1NPCOR_PLUS_UNCOR__1up"]

    # Trigger scale-factors
    effiSFTrigVarNameList       = [effiVarName+"Trig_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_wrtOffline_MediumLHIsoGradient",
                                   effiVarName+"Trig_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_wrtOffline_TightLHIsoGradient",
                                   effiVarName+"Trig_e17_lhloose_2016_e17_lhloose_nod0_wrtOffline_MediumLHIsoGradient",
                                   effiVarName+"Trig_e17_lhloose_2016_e17_lhloose_nod0_wrtOffline_TightLHIsoGradient",
                                   effiVarName+"Trig_e7_lhmedium_2016_e7_lhmedium_nod0_wrtOffline_MediumLHIsoGradient",
                                   effiVarName+"Trig_e7_lhmedium_2016_e7_lhmedium_nod0_wrtOffline_TightLHIsoGradient",
                                   effiVarName+"Trig_singleEl_preICHEP_wrtOffline_MediumLHIsoGradient",
                                   effiVarName+"Trig_singleEl_preICHEP_wrtOffline_TightLHIsoGradient",
                                   effiVarName+"Trig_singleEl_postICHEP_wrtOffline_MediumLHIsoGradient",
                                   effiVarName+"Trig_singleEl_postICHEP_wrtOffline_TightLHIsoGradient",
                                   effiVarName+"Trig_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_wrtOffline_MediumLHIsoFixedCutTightTrackOnly",
                                   effiVarName+"Trig_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_wrtOffline_TightLHIsoFixedCutTightTrackOnly",
                                   effiVarName+"Trig_e17_lhloose_2016_e17_lhloose_nod0_wrtOffline_MediumLHIsoFixedCutTightTrackOnly",
                                   effiVarName+"Trig_e17_lhloose_2016_e17_lhloose_nod0_wrtOffline_TightLHIsoFixedCutTightTrackOnly",
                                   effiVarName+"Trig_e7_lhmedium_2016_e7_lhmedium_nod0_wrtOffline_MediumLHIsoFixedCutTightTrackOnly",
                                   effiVarName+"Trig_e7_lhmedium_2016_e7_lhmedium_nod0_wrtOffline_TightLHIsoFixedCutTightTrackOnly",
                                   effiVarName+"Trig_singleEl_preICHEP_wrtOffline_MediumLHIsoFixedCutTightTrackOnly",
                                   effiVarName+"Trig_singleEl_preICHEP_wrtOffline_TightLHIsoFixedCutTightTrackOnly",
                                   effiVarName+"Trig_singleEl_postICHEP_wrtOffline_MediumLHIsoFixedCutTightTrackOnly",
                                   effiVarName+"Trig_singleEl_postICHEP_wrtOffline_TightLHIsoFixedCutTightTrackOnly",
                                   effiVarName+"Trig_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_wrtOffline_TightLHIsoLoose",
                                   effiVarName+"Trig_e17_lhloose_2016_e17_lhloose_nod0_wrtOffline_TightLHIsoLoose",
                                   effiVarName+"Trig_e7_lhmedium_2016_e7_lhmedium_nod0_wrtOffline_TightLHIsoLoose",
                                   effiVarName+"Trig_singleEl_preICHEP_wrtOffline_TightLHIsoLoose",
                                   effiVarName+"Trig_singleEl_postICHEP_wrtOffline_TightLHIsoLoose"]
    effiSFTrigCorrectionFiles   = [correctionFilePathPrefix+"trigger/efficiencySF.DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0.MediumLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0.TightLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.MULTI_L_2015_e17_lhloose_2016_e17_lhloose_nod0.MediumLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.MULTI_L_2015_e17_lhloose_2016_e17_lhloose_nod0.TightLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.MULTI_L_2015_e7_lhmedium_2016_e7_lhmedium_nod0.MediumLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.MULTI_L_2015_e7_lhmedium_2016_e7_lhmedium_nod0.TightLLH_d0z0_v11_isolGradient.root",
                                   "ElectronEfficiencyCorrection/2015_2016/rel20.7/ICHEP_June2016_v3/trigger/efficiencySF.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.MediumLLH_d0z0_v11_isolGradient.root",
                                   "ElectronEfficiencyCorrection/2015_2016/rel20.7/ICHEP_June2016_v3/trigger/efficiencySF.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.TightLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.MediumLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.TightLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.MULTI_L_2015_e17_lhloose_2016_e17_lhloose_nod0.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.MULTI_L_2015_e17_lhloose_2016_e17_lhloose_nod0.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.MULTI_L_2015_e7_lhmedium_2016_e7_lhmedium_nod0.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.MULTI_L_2015_e7_lhmedium_2016_e7_lhmedium_nod0.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   "ElectronEfficiencyCorrection/2015_2016/rel20.7/ICHEP_June2016_v3/trigger/efficiencySF.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   "ElectronEfficiencyCorrection/2015_2016/rel20.7/ICHEP_June2016_v3/trigger/efficiencySF.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0.TightLLH_d0z0_v11_isolLoose.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.MULTI_L_2015_e17_lhloose_2016_e17_lhloose_nod0.TightLLH_d0z0_v11_isolLoose.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.MULTI_L_2015_e7_lhmedium_2016_e7_lhmedium_nod0.TightLLH_d0z0_v11_isolLoose.root",
                                   "ElectronEfficiencyCorrection/2015_2016/rel20.7/ICHEP_June2016_v3/trigger/efficiencySF.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.TightLLH_d0z0_v11_isolLoose.root",
                                   correctionFilePathPrefix+"trigger/efficiencySF.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.TightLLH_d0z0_v11_isolLoose.root"]
    effiSFTrigCorrelationModel  = "TOTAL"
    effiSFTrigSysts             = ["EL_EFF_Trigger_TOTAL_1NPCOR_PLUS_UNCOR__1down", "EL_EFF_Trigger_TOTAL_1NPCOR_PLUS_UNCOR__1up"]

    # Trigger efficiencies
    effiTrigVarNameList         = ["effiTrig_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_wrtOffline_MediumLHIsoGradient",
                                   "effiTrig_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_wrtOffline_TightLHIsoGradient",
                                   "effiTrig_e17_lhloose_2016_e17_lhloose_nod0_wrtOffline_MediumLHIsoGradient",
                                   "effiTrig_e17_lhloose_2016_e17_lhloose_nod0_wrtOffline_TightLHIsoGradient",
                                   "effiTrig_e7_lhmedium_2016_e7_lhmedium_nod0_wrtOffline_MediumLHIsoGradient",
                                   "effiTrig_e7_lhmedium_2016_e7_lhmedium_nod0_wrtOffline_TightLHIsoGradient",
                                   "effiTrig_singleEl_preICHEP_wrtOffline_MediumLHIsoGradient",
                                   "effiTrig_singleEl_preICHEP_wrtOffline_TightLHIsoGradient",
                                   "effiTrig_singleEl_postICHEP_wrtOffline_MediumLHIsoGradient",
                                   "effiTrig_singleEl_postICHEP_wrtOffline_TightLHIsoGradient",
                                   "effiTrig_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_wrtOffline_MediumLHIsoFixedCutTightTrackOnly",
                                   "effiTrig_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_wrtOffline_TightLHIsoFixedCutTightTrackOnly",
                                   "effiTrig_e17_lhloose_2016_e17_lhloose_nod0_wrtOffline_MediumLHIsoFixedCutTightTrackOnly",
                                   "effiTrig_e17_lhloose_2016_e17_lhloose_nod0_wrtOffline_TightLHIsoFixedCutTightTrackOnly",
                                   "effiTrig_e7_lhmedium_2016_e7_lhmedium_nod0_wrtOffline_MediumLHIsoFixedCutTightTrackOnly",
                                   "effiTrig_e7_lhmedium_2016_e7_lhmedium_nod0_wrtOffline_TightLHIsoFixedCutTightTrackOnly",
                                   "effiTrig_singleEl_preICHEP_wrtOffline_MediumLHIsoFixedCutTightTrackOnly",
                                   "effiTrig_singleEl_preICHEP_wrtOffline_TightLHIsoFixedCutTightTrackOnly",
                                   "effiTrig_singleEl_postICHEP_wrtOffline_MediumLHIsoFixedCutTightTrackOnly",
                                   "effiTrig_singleEl_postICHEP_wrtOffline_TightLHIsoFixedCutTightTrackOnly"]
    effiTrigCorrectionFiles     = [correctionFilePathPrefix+"trigger/efficiency.DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0.MediumLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiency.DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0.TightLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiency.MULTI_L_2015_e17_lhloose_2016_e17_lhloose_nod0.MediumLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiency.MULTI_L_2015_e17_lhloose_2016_e17_lhloose_nod0.TightLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiency.MULTI_L_2015_e7_lhmedium_2016_e7_lhmedium_nod0.MediumLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiency.MULTI_L_2015_e7_lhmedium_2016_e7_lhmedium_nod0.TightLLH_d0z0_v11_isolGradient.root",
                                   "ElectronEfficiencyCorrection/2015_2016/rel20.7/ICHEP_June2016_v3/trigger/efficiency.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.MediumLLH_d0z0_v11_isolGradient.root",
                                   "ElectronEfficiencyCorrection/2015_2016/rel20.7/ICHEP_June2016_v3/trigger/efficiency.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.TightLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiency.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.MediumLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiency.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.TightLLH_d0z0_v11_isolGradient.root",
                                   correctionFilePathPrefix+"trigger/efficiency.DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiency.DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiency.MULTI_L_2015_e17_lhloose_2016_e17_lhloose_nod0.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiency.MULTI_L_2015_e17_lhloose_2016_e17_lhloose_nod0.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiency.MULTI_L_2015_e7_lhmedium_2016_e7_lhmedium_nod0.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiency.MULTI_L_2015_e7_lhmedium_2016_e7_lhmedium_nod0.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   "ElectronEfficiencyCorrection/2015_2016/rel20.7/ICHEP_June2016_v3/trigger/efficiency.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   "ElectronEfficiencyCorrection/2015_2016/rel20.7/ICHEP_June2016_v3/trigger/efficiency.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiency.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                                   correctionFilePathPrefix+"trigger/efficiency.SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root"]

    effiTrigCorrelationModel    = "TOTAL"
    effiTrigSysts               = ["EL_EFF_TriggerEff_TOTAL_1NPCOR_PLUS_UNCOR__1down", "EL_EFF_TriggerEff_TOTAL_1NPCOR_PLUS_UNCOR__1up"]

    # Isolation scale-factors
    effiIsoVarNameList     = [effiVarName+"IsoGradient_wrtMediumLH",
                              effiVarName+"IsoGradient_wrtTightLH",
                              effiVarName+"IsoGradientLoose_wrtMediumLH",
                              effiVarName+"IsoGradientLoose_wrtTightLH",
                              effiVarName+"IsoLoose_wrtMediumLH",
                              effiVarName+"IsoLoose_wrtTightLH",
                              effiVarName+"IsoFixedCutTightTrackOnly_wrtMediumLH",
                              effiVarName+"IsoFixedCutTightTrackOnly_wrtTightLH",
                              effiVarName+"IsoFixedCutTrackCone40_wrtMediumLH",
                              effiVarName+"IsoFixedCutTrackCone40_wrtTightLH",
                              effiVarName+"IsoLoosePrompt_wrtTightLH",
                              effiVarName+"IsoLoosePromptCFTMedium_wrtTightLH"]
    effiIsoCorrectionFiles = [correctionFilePathPrefixV2+"isolation/efficiencySF.Isolation.MediumLLH_d0z0_v11_isolGradient.root",
                              correctionFilePathPrefixV2+"isolation/efficiencySF.Isolation.TightLLH_d0z0_v11_isolGradient.root",
                              correctionFilePathPrefixV2+"isolation/efficiencySF.Isolation.MediumLLH_d0z0_v11_isolGradientLoose.root",
                              correctionFilePathPrefixV2+"isolation/efficiencySF.Isolation.TightLLH_d0z0_v11_isolGradientLoose.root",
                              correctionFilePathPrefixV2+"isolation/efficiencySF.Isolation.MediumLLH_d0z0_v11_isolLoose.root",
                              correctionFilePathPrefixV2+"isolation/efficiencySF.Isolation.TightLLH_d0z0_v11_isolLoose.root",
                              correctionFilePathPrefixV2+"isolation/efficiencySF.Isolation.MediumLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                              correctionFilePathPrefixV2+"isolation/efficiencySF.Isolation.TightLLH_d0z0_v11_isolFixedCutTightTrackOnly.root",
                              correctionFilePathPrefixV2+"isolation/efficiencySF.Isolation.MediumLLH_d0z0_v11_isolFixedCutTrackCone40.root",
                              correctionFilePathPrefixV2+"isolation/efficiencySF.Isolation.TightLLH_d0z0_v11_isolFixedCutTrackCone40.root",
                              "PhysicsxAODConfig/efficiencySF.Isolation.TightLLH_d0z0_v11_isolLoose_PromptLeptonIso.root",
                              "PhysicsxAODConfig/efficiencySF.Isolation.TightLLH_d0z0_v11_isolLoose_PromptLeptonIsoAndCFTMedium.root"]
    effiIsoCorrelationModel= "TOTAL"
    effiIsoSysts           = ["EL_EFF_Iso_TOTAL_1NPCOR_PLUS_UNCOR__1down", "EL_EFF_Iso_TOTAL_1NPCOR_PLUS_UNCOR__1up"]


    # Isolation working points to use for lepton flagging
    isoWorkingPointList  = ["LooseTrackOnly", "Loose", "GradientLoose", "Gradient",
                            "FixedCutTight", "FixedCutTightTrackOnly", "FixedCutLoose",
                            "FixedCutTrackCone40" ]
    passIsoVarNameList   = [ "passIso"+wpName for wpName in isoWorkingPointList ]

    # Now come the pre-selection cuts (used for overlap removal, MET-making, and going into "otherElectrons")
    class preSelection(object):
        #cutObjectQualityMask           = xAOD::BADCLUSELECTRON
        cutObjectQualityMask           = 1
        cutPtMin                       = 10.0*GeV
        cutAbsEtaMax                   = 2.47
        #cutAbsEtaCrackMin              = 1.37
        #cutAbsEtaCrackMax              = 1.52
        cutIDList                      = [ "isLHLoose" ]
        cutIDPtMinList                 = [ 0.0*GeV ]
        cutIDListMedium                = [ "isLHMedium" ]    # For testing. Only used if command-line option doMediumOther=True is set
        cutIDListVeryLoose             = [ "isLHVeryLoose" ] # Only used if command-line option doVeryLooseLH=True is set
        removeSelfOverlap              = True
        cutZ0SinThetaMax               = 0.5
        cutD0SignificanceMax           = 5.0
        fakeWJets_cutZ0SinThetaMax     = 0.5 # KEEP THEM AT NOMINAL, NO IMPROVEMENT EXPECTED. For W+jets or Z+jets fakes, used if hWWCommon.Global.doFakeWJets=True OR doFakeZJets=True
        fakeWJets_cutD0SignificanceMax = 5.0 # KEEP THEM AT NOMINAL, NO IMPROVEMENT EXPECTED. For W+jets or Z+jets fakes, used if hWWCommon.Global.doFakeWJets=True OR doFakeZJets=True
        #fakeWJets_cutZ0SinThetaMax     = 1.5  # For W+jets or Z+jets fakes, used if hWWCommon.Global.doFakeWJets=True OR doFakeZJets=True
        #fakeWJets_cutD0SignificanceMax = 15.0 # For W+jets or Z+jets fakes, used if hWWCommon.Global.doFakeWJets=True OR doFakeZJets=True
        pass

    # The following cuts are NOT used in the pre-selection
    cutObjectQualityMask           = 1
    cutPtMin                       = 10.0*GeV
    cutLeadPtMin                   = 22.0*GeV
    cutAbsEtaMax                   = 2.47
    cutAbsEtaCrackMin              = 1.37
    cutAbsEtaCrackMax              = 1.52
    cutIDList                      = [ "isLHMediumNoBLayer" ]
    fakeWJets_cutIDList            = [ "isLHLoose" ]     # For W+jets fakes, used if hWWCommon.Global.doFakeWJets=True
    fakeWJets_cutIDListVeryLoose   = [ "isLHVeryLoose" ] # For W+jets fakes, used if hWWCommon.Global.doFakeWJets=True AND doVeryLooseLH=True are set
    cutIDPtMinList                 = [ 0.0*GeV ]
    cutZ0SinThetaMax               = 0.5
    cutD0SignificanceMax           = 5.0
    fakeWJets_cutZ0SinThetaMax     = 0.5 # KEEP THEM AT NOMINAL, NO IMPROVEMENT EXPECTED. For W+jets or Z+jets fakes, used if hWWCommon.Global.doFakeWJets=True OR doFakeZJets=True
    fakeWJets_cutD0SignificanceMax = 5.0 # KEEP THEM AT NOMINAL, NO IMPROVEMENT EXPECTED. For W+jets or Z+jets fakes, used if hWWCommon.Global.doFakeWJets=True OR doFakeZJets=True
    #fakeWJets_cutZ0SinThetaMax     = 1.5  # For W+jets fakes, used if hWWCommon.Global.doFakeWJets=True
    #fakeWJets_cutD0SignificanceMax = 15.0 # For W+jets fakes, used if hWWCommon.Global.doFakeWJets=True
    removeSelfOverlap              = True
    pass
hWWCommon.add_JobProperty(Electrons)




class Muons(JobProperty):
    """Definitions for the common muons of all the H->WW analyzes"""
    statusOn            = True
    allowedTypes        = ['bool']
    StoredValue         = True
    inCont              = "Muons"
    calibCont           = "HWWCalibMuons"
    calibPreSelCont     = "HWWCalibPreSelMuons"
    calibPreSelORCont   = "HWWCalibPreSelORMuons"
    finalCont           = "HWWMuons"
    finalAllPtSortCont  = "FinalAllPtSort"+finalCont
    def finalContList(self) :
        """ The names of the final muon containers. This is a list because every
        4-vector systematic variation is stored in its own container. Thus, we
        are building the list of all these containers using a helper function."""
        return buildContainerNames(baseName=self.finalCont, systList=hWWCommon.Muons.p4Systs)

    p4Systs              = [ "MUON_ID__1down",    "MUON_ID__1up",
                             "MUON_MS__1down",    "MUON_MS__1up",
                             "MUON_SCALE__1down", "MUON_SCALE__1up" ]
    effiVarName          = "effiSF"
    effiVarNameList      = [] # Will be filled automatically
    effiSysts            = ["MUON_EFF_STAT__1down", "MUON_EFF_STAT__1up",
                            "MUON_EFF_SYS__1down", "MUON_EFF_SYS__1up",
                            "MUON_EFF_STAT_LOWPT__1down", "MUON_EFF_STAT_LOWPT__1up",
                            "MUON_EFF_SYS_LOWPT__1down", "MUON_EFF_SYS_LOWPT__1up"]

    effiTTVAVarNameList   = ["effiSFTTVA"] # Will be filled automatically
    effiTTVASysts         = ["MUON_TTVA_STAT__1down", "MUON_TTVA_STAT__1up", "MUON_TTVA_SYS__1down", "MUON_TTVA_SYS__1up"]

    effiIsoVarNameList   = [] # Will be filled automatically
    effiIsoSysts         = ["MUON_ISO_STAT__1down", "MUON_ISO_STAT__1up", "MUON_ISO_SYS__1down", "MUON_ISO_SYS__1up"]

    effiTrigVarNameList   = [] # Will be filled in job option
    effiTrigSFVarNameList = [] # Will be filled in job option
    #effiTrigSFToolList    = [] # Will be filled in job option
    effiTrigSysts         = ["MUON_EFF_TrigStatUncertainty__1down", "MUON_EFF_TrigStatUncertainty__1up",
                             "MUON_EFF_TrigSystUncertainty__1down", "MUON_EFF_TrigSystUncertainty__1up"]

    # Isolation working points to use for lepton flagging
    isoWorkingPointList  = ["LooseTrackOnly", "Loose", "GradientLoose",
                            "Gradient", "FixedCutTight", "FixedCutTightTrackOnly", "FixedCutLoose" ]
    passIsoVarNameList   = [ "passIso"+wpName for wpName in isoWorkingPointList ]

    # Now come the pre-selection cuts (used for overlap removal, MET-making, and going into "otherMuons")
    class preSelection(object):
        cutPtMin                       = 10.0*GeV
        cutAbsEtaMax                   = 2.7
        cutIDList                      = [ MuonQualityEnums.Loose ]
        cutIDListMedium                = [ MuonQualityEnums.Medium ] # For testing. Only used if command-line option doMediumOther=True is set
        cutIDPtMinList                 = [ 0.0*GeV ]
        cutInnerDetectorHits           = True
        cutZ0SinThetaMax               = 0.5
        cutD0SignificanceMax           = 3.0
        fakeWJets_cutZ0SinThetaMax     = 1.5  # For W+jets or Z+jets fakes, used if hWWCommon.Global.doFakeWJets=True OR doFakeZJets=True
        fakeWJets_cutD0SignificanceMax = 15.0 # For W+jets or Z+jets fakes, used if hWWCommon.Global.doFakeWJets=True OR doFakeZJets=True
        pass

    # The following cuts are the final cuts, used on top of the pre-selection
    cutInnerDetectorHits           = True
    cutPtMin                       = 10.0*GeV
    cutLeadPtMin                   = 22.0*GeV
    cutAbsEtaMax                   = 2.5
    cutIDList                      = [ MuonQualityEnums.Medium, 4 ]
    cutIDPtMinList                 = [ 0.0*GeV, 0.0*GeV ]
    cutZ0SinThetaMax               = 0.5
    cutD0SignificanceMax           = 3.0
    fakeWJets_cutZ0SinThetaMax     = 1.5  # For W+jets fakes, used if hWWCommon.Global.doFakeWJets=True
    fakeWJets_cutD0SignificanceMax = 15.0 # For W+jets fakes, used if hWWCommon.Global.doFakeWJets=True
    pass
hWWCommon.add_JobProperty(Muons)





class Jets(JobProperty):
    """Definitions for the common jets of all the H->WW analyzes"""
    statusOn              = True
    allowedTypes          = ['bool']
    StoredValue           = True
    truthCont             = "AntiKt4TruthJets"
    inTrackJetsCont       = "AntiKt4PV0TrackJets"
    writeTrackJets        = False #mgeisen: test for rel21
    writeAntiKt2TrackJets = False
    writeJetConstituents  = True
    inCont                = "AntiKt4EMTopoJets"
    # inCont                = "AntiKt4EMPFlowJets"
    calibCont             = "HWWCalibJets"
    calibPreSelCont       = "HWWCalibPreSelJets"
    calibPreSelORCont     = "HWWCalibPreSelORJets"
    finalCont             = "HWWJets"
    finalAllPtSortCont    = "FinalAllPtSort"+finalCont
    def finalContList(self) :
        """ The names of the final jet containers. This is a list because every
        4-vector systematic variation is stored in its own container. Thus, we
        are building the list of all these containers using a helper function."""
        return buildContainerNames(baseName=self.finalCont, systList=hWWCommon.Jets.p4Systs)

    # For standard AntiKt4EMTopoJets
    #calibConfigFile     = "JES_data2016_data2015_Recommendation_Dec2016.config"
    #calibConfigFile     = "JES_MC16Recommendation_Aug2017.config"
    #calibAFIIConfigFile = "JES_MC15Prerecommendation_AFII_June2015.config"
    #calibSequence       = "JetArea_Residual_Origin_EtaJES_GSC"
    #mgeisen: new jet calibration recommendations for 2015,2016,2017
    calibConfigFile     = "JES_data2017_2016_2015_Recommendation_Feb2018_rel21.config"
    calibAFIIConfigFile = "JES_data2017_2016_2015_Recommendation_Feb2018_rel21.config" #mgeisen: no known AFII file
    calibSequence       = "JetArea_Residual_EtaJES_GSC"
    dataCalibSeqSuffix  = "_Insitu"

    # # For AntiKt4EMPFlow:
    # calibConfigFile     = "JES_MC15cRecommendation_PFlow_Aug2016.config"
    # calibAFIIConfigFile = "JES_MC15Prerecommendation_AFII_June2015.config"
    # calibSequence       = "JetArea_Residual_EtaJES"
    # dataCalibSeqSuffix  = "_Insitu"


    # JES uncertainties
    #jesConfigFile       = "JES_2016/Moriond2017/JES2016_21NP.config"
    #mgeisen: new JES pre recommendations (don't know which one to use?!)
    jesConfigFile       = "rel21/Moriond2018/R4_StrongReduction_Scenario1.config"
    jesCalibArea        = "CalibArea-01"
    #jesConfigFile       = "rel21/Moriond2018/R4_AllNuisanceParameters.config"
    #jesConfigFile       = "rel21/Moriond2018/R4_GlobalReduction.config"
    #jesConfigFile       = "rel21/Moriond2018/R4_CategoryReduction.config"
    jesSysts            = ["JET_BJES_Response__1up",                  "JET_BJES_Response__1down",
                           "JET_EffectiveNP_1__1up",                  "JET_EffectiveNP_1__1down",
                           "JET_EffectiveNP_2__1up",                  "JET_EffectiveNP_2__1down",
                           "JET_EffectiveNP_3__1up",                  "JET_EffectiveNP_3__1down",
                           "JET_EffectiveNP_4__1up",                  "JET_EffectiveNP_4__1down",
                           "JET_EffectiveNP_5__1up",                  "JET_EffectiveNP_5__1down",
                           "JET_EffectiveNP_6__1up",                  "JET_EffectiveNP_6__1down",
                           "JET_EffectiveNP_7__1up",                  "JET_EffectiveNP_7__1down",
                           "JET_EffectiveNP_8restTerm__1up",          "JET_EffectiveNP_8restTerm__1down",
                           "JET_EtaIntercalibration_Modelling__1up",  "JET_EtaIntercalibration_Modelling__1down",
                           "JET_EtaIntercalibration_NonClosure__1up", "JET_EtaIntercalibration_NonClosure__1down",
                           "JET_EtaIntercalibration_TotalStat__1up",  "JET_EtaIntercalibration_TotalStat__1down",
                           "JET_Flavor_Composition__1up",             "JET_Flavor_Composition__1down",
                           "JET_Flavor_Response__1up",                "JET_Flavor_Response__1down",
                           "JET_Pileup_OffsetMu__1up",                "JET_Pileup_OffsetMu__1down",
                           "JET_Pileup_OffsetNPV__1up",               "JET_Pileup_OffsetNPV__1down",
                           "JET_Pileup_PtTerm__1up",                  "JET_Pileup_PtTerm__1down",
                           "JET_Pileup_RhoTopology__1up",             "JET_Pileup_RhoTopology__1down",
                           "JET_PunchThrough_MC15__1up",              "JET_PunchThrough_MC15__1down",
                           "JET_RelativeNonClosure_MC15__1up",        "JET_RelativeNonClosure_MC15__1down",
                           "JET_PunchThrough_AFII__1up",              "JET_PunchThrough_AFII__1down",
                           "JET_RelativeNonClosure_AFII__1up",        "JET_RelativeNonClosure_AFII__1down",
                           "JET_SingleParticle_HighPt__1up",          "JET_SingleParticle_HighPt__1down" ]

    # Configuration for the jet energy resolution
    jerConfigFile       = "JetResolution/Prerec2015_xCalib_2012JER_ReducedTo9NP_Plots_v2.root"
    jerSystematicMode   = "Simple"
    jerSysts            = [ "JET_JER_SINGLE_NP__1up" ]

    ## This will be filled automatically with the sum of all JES and JER systematics
    p4Systs             = [ ]

    # JVT stuff
    updateJVTName         = "calibJvt"
    passJVTVarName        = "passJVT"
    effiJVTVarName        = "effiSFJVT"
    effiForwardJVTVarName = "effiSFForwardJVT"
    jvtConfigFile         = "JetJvtEfficiency/Moriond2017/JvtSFFile_EM.root"
    forwardJvtConfigFile  = "JetJvtEfficiency/Moriond2016_v2/fJvtSFFile.root"
    effiJVTSysts          = ["JET_JvtEfficiency__1down", "JET_JvtEfficiency__1up"]

    # b-tagging stuff
    effiVarName          = "effiSF"
    effiSysts            = ["FT_EFF_Eigen_B_0__1down", "FT_EFF_Eigen_B_0__1up",
                            "FT_EFF_Eigen_B_1__1down", "FT_EFF_Eigen_B_1__1up",
                            "FT_EFF_Eigen_B_2__1down", "FT_EFF_Eigen_B_2__1up",
                            "FT_EFF_Eigen_C_0__1down", "FT_EFF_Eigen_C_0__1up",
                            "FT_EFF_Eigen_C_1__1down", "FT_EFF_Eigen_C_1__1up",
                            "FT_EFF_Eigen_C_2__1down", "FT_EFF_Eigen_C_2__1up",
                            "FT_EFF_Eigen_C_3__1down", "FT_EFF_Eigen_C_3__1up",
                            "FT_EFF_Eigen_Light_0__1down", "FT_EFF_Eigen_Light_0__1up",
                            "FT_EFF_Eigen_Light_1__1down", "FT_EFF_Eigen_Light_1__1up",
                            "FT_EFF_Eigen_Light_2__1down", "FT_EFF_Eigen_Light_2__1up",
                            "FT_EFF_Eigen_Light_3__1down", "FT_EFF_Eigen_Light_3__1up",
                            "FT_EFF_Eigen_Light_4__1down", "FT_EFF_Eigen_Light_4__1up",
                            "FT_EFF_extrapolation__1down", "FT_EFF_extrapolation__1up",
                            "FT_EFF_extrapolation_from_charm__1down", "FT_EFF_extrapolation_from_charm__1up"]
    systematicsStrategy   = "SFEigen"
    systematicsReduction  = "Medium"
    bTagName              = "MV2c10" #
    bTagWP                = "FixedCutBEff_85" # 85% WP
    bTagWPNumber          = 0.1758   # 85% WP for MV2c10
    bTagWPTrackJets       = "FixedCutBEff_77" # 77% WP for AntiKt4PV0TrackJets
    bTagWPTrackJetsNumber = 0.5140 # 77% WP for AntiKt4PV0TrackJets
    # bTagWPTrackJetsNumber = -0.0168 # 85% WP for AntiKt4PV0TrackJets
    CDIFile               = "xAODBTaggingEfficiency/13TeV/2016-20_7-13TeV-MC15-CDI-2017-04-24_v1.root"
    bJetLabel             = "isBJet85"


    # Now come the pre-selection cuts (used for overlap removal, MET-making, and going into "otherJets")
    class preSelection(object):
        cutPtMinList          = [ 20.0*GeV ]
        cutAbsEtaMaxList      = [ 4.5 ]
        # passForwardJVTVarName = "" # empty string would be no selection
        passForwardJVTVarName = "passFJVT" # empty string would be no selection
        pass

    # And now the final selection
    cutPtMinList         = [ 25.0*GeV, 25.0*GeV ]
    cutAbsEtaMaxList     = [ 2.4,      4.5 ]
    cutCleaningMinPt     = 20.0*GeV
    cutCleaningMaxPt     = 60.0*GeV
    cutCleaningMaxAbsEta = 2.4

    # And now the selection for the jet event cleaning
    passLooseJetCleaningVarName   = "PassLooseBad" #"PassTightBad"
    passLooseEventCleaningVarName = "PassLooseJetEventCleaning"
    passTightJetCleaningVarName   = "PassTightBad" #"PassTightBad"
    passTightEventCleaningVarName = "PassTightJetEventCleaning"
    pass
hWWCommon.add_JobProperty(Jets)






class FatJets(JobProperty):
    """Definitions for the large-R jets of all the H->WW analyzes"""
    statusOn            = True
    allowedTypes        = ['bool']
    StoredValue         = True
    inCont              = "AntiKt10LCTopoTrimmedPtFrac5SmallR20Jets"
    # inCont              = "AntiKt10LCTopoJets"
    calibCont           = "HWWCalibFatJets"
    calibPreSelCont     = "HWWCalibPreSelFatJets"
    calibPreSelORCont   = "HWWCalibPreSelORFatJets"
    finalCont           = "HWWFatJets"
    finalAllPtSortCont  = "FinalAllPtSort"+finalCont

    calibConfigFile     = "JES_MC15recommendation_FatJet_June2015.config"
    calibAFIIConfigFile = "JES_MC15recommendation_FatJet_June2015.config" # No AF2 file available yet!
    calibSequence       = "EtaJES_JMS"
    dataCalibSeqSuffix  = ""
    jesConfigFile       = "UJ_2015/Prerec/Prerec2015_WZTagging_SplitScales2.config"
    p4Systs             = ['JET_WZ_CrossCalib_D2__1up','JET_WZ_CrossCalib_D2__1down',
                           'JET_WZ_CrossCalib_mass__1up','JET_WZ_CrossCalib_mass__1down',
                           'JET_WZ_CrossCalib_pT__1up','JET_WZ_CrossCalib_pT__1down',
                           'JET_WZ_Run1_D2__1up','JET_WZ_Run1_D2__1down',
                           'JET_WZ_Run1_mass__1up','JET_WZ_Run1_mass__1down',
                           'JET_WZ_Run1_pT__1up','JET_WZ_Run1_pT__1down']

    bosonTaggerWorkingPoint = "medium"
    bosonTaggerAlgorithm    = "smooth"
    WTaggerConfigFile       = "JetSubStructureUtils/data/config_13TeV_Wtagging_MC15_Prerecommendations_20150809.dat"
    ZTaggerConfigFile       = "JetSubStructureUtils/data/config_13TeV_Ztagging_MC15_Prerecommendations_20150809.dat"

    # Now come the pre-selection cuts
    class preSelection(object):
        cutPtMinList      = [ 200.0*GeV ]
        cutAbsEtaMaxList  = [ 2.0 ]
        pass

    # And now the final selection
    cutPtMinList      = [ 200.0*GeV ]
    cutAbsEtaMaxList  = [ 2.0 ]
    pass
hWWCommon.add_JobProperty(FatJets) #mgeisen





class MET(JobProperty):
    """Definitions for the missing ET of the H->WW-> analysis"""
    statusOn       = True
    allowedTypes   = ['bool']
    StoredValue    = True
    # inMap and inCore must currently be set to EMTopo for MET to properly
    # be written out when making FakeDijet PAODs. The reason is that HIGG3D3
    # doesn't have LCTopo jets and the check for that happens before checking
    # what jets are to be used. TODO: fix this.
    inMap          = "METAssoc_AntiKt4EMTopo" # Only a default, gets changed according to the jet type
    inCore         = "MET_Core_AntiKt4EMTopo" # Only a default, gets changed according to the jet type
    inObject       = "FinalTrk"
    calibCont      = "HWWCalibMET"
    finalCont      = "HWWMET"
    finalTrackCont = "HWWTrackMET"

    configSoftTrkFile = "TrackSoftTerms.config"
    configJetTrkFile  = "JetTrackSyst.config"

    p4TSTSysts     = ["MET_SoftTrk_ResoPara", "MET_SoftTrk_ResoPerp", "MET_SoftTrk_ScaleDown", "MET_SoftTrk_ScaleUp"]
    p4CSTSysts     = []#"MET_SoftCalo_Reso", "MET_SoftCalo_ScaleDown", "MET_SoftCalo_ScaleUp", "MET_SoftTrk_ResoCorr"]
    p4JetTrkSysts  = [ "MET_JetTrk_ScaleDown", "MET_JetTrk_ScaleUp" ]
    p4Systs        = [ ]
    effiVarName    = "effiSF"
    effiSysts      = [ ]
    cutMETMin      = 0.0*GeV
    pass
hWWCommon.add_JobProperty(MET)
