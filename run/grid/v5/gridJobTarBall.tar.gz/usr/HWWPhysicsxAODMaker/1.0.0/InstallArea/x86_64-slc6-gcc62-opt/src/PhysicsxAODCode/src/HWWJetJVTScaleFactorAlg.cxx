///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetJVTScaleFactorAlg.cxx
// Implementation file for class HWW::JetJVTScaleFactorAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWJetJVTScaleFactorAlg.h"

// STL includes
#include <climits>
#include <cmath>
#include <algorithm>
#include <vector>

// boost includes
#include <boost/algorithm/string/replace.hpp>

// EDM includes
#include "xAODJet/JetContainer.h"
#include "xAODEventInfo/EventInfo.h"
#include "AthContainers/ConstDataVector.h"

// Tool includes
#include "JetJvtEfficiency/IJetJvtEfficiency.h"

// Framework includes
#include "GaudiKernel/SystemOfUnits.h"
using Gaudi::Units::GeV;



// Constructors
////////////////
HWW::JetJVTScaleFactorAlg::JetJVTScaleFactorAlg( const std::string& name,
                                                 ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_inContName(""),
  m_inContAllJetsName(""),
  m_contFindTool("HWW::ContainersFinderTool/ContainersFinderTool"),
  m_jvtEffiSFTool("CP::JetJvtEfficiency/JetJvtEfficiencyTool", this),
  m_jvtEffSFSysNames(),
  m_jvtEffSFVarName(""),
  m_separator("___"),
  m_passJVTVarName(""),
  m_abortOnUncheckedCorrCode(false),
  m_decoAllCopies(true),
  m_decoJets(true),
  m_decoEvent(true),
  m_effiSystVarNameVec()
{
  //
  // Property declaration
  //
  declareProperty("InputContainer",       m_inContName, "Input container name" );
  declareProperty("InputAllCalibORJets",  m_inContAllJetsName, "The input jet container name for the calibrated, overlap-removed jets" );
  declareProperty("ContainersFinderTool", m_contFindTool, "The tool that tries to find all input containers, including their systematic variations" );

  declareProperty("JetJvtEfficiencyTool",           m_jvtEffiSFTool, "The CP::IJetJvtEfficiency instance" );
  declareProperty("EfficiencySystematicVariations", m_jvtEffSFSysNames,
                  "The names of all systematic variations to be applied" );
  declareProperty("EfficiencyScaleFactorVarName",   m_jvtEffSFVarName,
                  "The name of the efficiency scale-factor variable that will be added to the jet" );
  declareProperty("Separator", m_separator,
                  "The string seperator between the variable/container name and its sytematic variation (default='___')" );

  declareProperty("PassJVTVarName", m_passJVTVarName, "The name of the variable for passing the JVT selection");

  declareProperty("AbortOnUncheckedCorrectionCode", m_abortOnUncheckedCorrCode,
                  "Abort on an unchecked CP::CorrectionCode" );

  declareProperty("DecorateAllCopies", m_decoAllCopies, "If true, will decorate all copies of the input container" );

  declareProperty("DecorateJets",      m_decoJets,  "If true, will decorate each individual jet" );
  declareProperty("DecorateEvent",     m_decoEvent, "If true, will decorate the event with the combined scale-factor and uncertainty" );
}



// Destructor
///////////////
HWW::JetJVTScaleFactorAlg::~JetJVTScaleFactorAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::JetJVTScaleFactorAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inContName );
  ATH_MSG_DEBUG( "Using: " << m_inContAllJetsName );
  ATH_MSG_DEBUG( "Using: " << m_contFindTool );
  ATH_MSG_DEBUG( "Using: " << m_jvtEffiSFTool );
  ATH_MSG_DEBUG( "Using: " << m_jvtEffSFSysNames );
  ATH_MSG_DEBUG( "Using: " << m_jvtEffSFVarName );
  ATH_MSG_DEBUG( "Using: " << m_separator );
  ATH_MSG_DEBUG( "Using: " << m_passJVTVarName );
  ATH_MSG_DEBUG( "Using AbortOnUncheckedCorrectionCode: " << m_abortOnUncheckedCorrCode );
  ATH_MSG_DEBUG( "Using DecorateAllCopies: " << m_decoAllCopies );
  ATH_MSG_DEBUG( "Using DecorateJets:      " << m_decoJets );
  ATH_MSG_DEBUG( "Using DecorateEvent:     " << m_decoEvent );

  // Enable failure on an unchecked CP::CorrectionCode
  if ( m_abortOnUncheckedCorrCode ) { CP::CorrectionCode::enableFailure(); }

  // Perform some sanity checks on the given container names
  if ( m_inContName.value().empty() ) {
    ATH_MSG_ERROR("Wrong user setup! You need to give a valid name for the InputContainer!");
    return StatusCode::FAILURE;
  }

  // Get the needed tools
  ATH_CHECK(m_contFindTool.retrieve());
  ATH_CHECK( m_jvtEffiSFTool.retrieve() );

  // Configure the systematic variations due to JVT
  //---------------------------------------------------------------------------

  // Figure out what systematics are available and recommended
  if ( msgLvl(MSG::DEBUG) || msgLvl(MSG::VERBOSE) ) {
    CP::SystematicSet affSys = m_jvtEffiSFTool->affectingSystematics();
    std::string affSysNames = affSys.name();
    boost::replace_all( affSysNames, "-", "\", \"");
    affSysNames = "[\""+affSysNames+"\"]";
    ATH_MSG_DEBUG("!!!!Have " << affSys.size() << " affecting systematics with name !!!!!"
                  << affSysNames << " for tool " << m_jvtEffiSFTool->name() );
    CP::SystematicSet recSys = m_jvtEffiSFTool->recommendedSystematics();
    std::string recSysNames = recSys.name();
    boost::replace_all( recSysNames, "-", "\", \"");
    recSysNames = "[\""+recSysNames+"\"]";
    ATH_MSG_DEBUG("!!!!Have " << recSys.size() << " recommended systematics with name !!!!!"
                  << recSysNames << " for tool " << m_jvtEffiSFTool->name() );
  }

  // Set up the internal vector of systematics and variable names, starting with
  // the nominal one. First, clear it. Then, add the nominal, then systematics
  m_effiSystVarNameVec.clear();
  if ( !(m_jvtEffSFVarName.value().empty()) ) m_effiSystVarNameVec.push_back( std::make_pair( CP::SystematicSet(), m_jvtEffSFVarName.value() ) );
  for ( const auto& sysName  :  m_jvtEffSFSysNames.value() ) {
    CP::SystematicVariation sysVar = CP::SystematicVariation(sysName);
    if ( m_jvtEffiSFTool->isAffectedBySystematic(sysVar) ) {
      CP::SystematicSet sysSet{sysVar};
      m_effiSystVarNameVec.push_back( std::make_pair( sysSet, m_jvtEffSFVarName.value() + m_separator.value() + sysName ) );
      ATH_MSG_VERBOSE("Adding systematic variation with name " << sysName );
    }
    else {
      CP::SystematicSet affSys = m_jvtEffiSFTool->affectingSystematics();
      std::string affSysNames = affSys.name();
      boost::replace_all( affSysNames, "-", "\", \"");
      affSysNames = "[\""+affSysNames+"\"]";
      ATH_MSG_WARNING("Couldn't find systematic variation with name " << sysName
                      << " amongst the affected systematics: " << affSysNames );
      return StatusCode::FAILURE;
    }
  } // End: adding all systematic variations to be processed

  return StatusCode::SUCCESS;
}



StatusCode HWW::JetJVTScaleFactorAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release the needed tools
  ATH_CHECK(m_contFindTool.release());
  ATH_CHECK( m_jvtEffiSFTool.release() );

  return StatusCode::SUCCESS;
}



StatusCode HWW::JetJVTScaleFactorAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Get the EventInfo object
  const xAOD::EventInfo* evtInfo;
  ATH_CHECK( evtStore()->retrieve( evtInfo, "EventInfo" ));
  const bool isSim = evtInfo->eventType(xAOD::EventInfo::EventType::IS_SIMULATION);

  // Define the decorators outside of the loop, such that it will be fully cached
  SG::AuxElement::Decorator<char>* decPassJVT = nullptr;
  if ( !(m_passJVTVarName.value().empty()) ) decPassJVT = new SG::AuxElement::Decorator<char>(m_passJVTVarName.value());


  // Now, let's try to get all requested containers and iterate over them.
  // If not specifically requested to get all copies, only the exactly given
  // name will be retrieved. Otherwise, all containers with the same base-name,
  // i.e, the part before the "___", if present, will be used.
  // Do this expensive string manupulation and StoreGate search only the first time.
  if (m_inContNameAndSysTypeList.empty()){
    if (m_decoAllCopies){
      ATH_CHECK( m_contFindTool->jetNamesAndSysTypes( m_inContNameAndSysTypeList, m_inContName.value() ) );
      ATH_MSG_DEBUG("Found " << m_inContNameAndSysTypeList.size() << " input containers to run over");
    }
    else {
      m_inContNameAndSysTypeList.push_back( std::make_pair( m_inContName.value(), HWW::SystematicType::NOMINAL ) );
      ATH_MSG_DEBUG("Only using the one given input container name to run over");
    }
  }


  // Now, iterate over all input container names that were found and use these jet containers.
  for ( std::size_t contIdx=0; contIdx<m_inContNameAndSysTypeList.size(); ++contIdx ) {
    const xAOD::JetContainer* inCont = nullptr;
    ATH_CHECK( evtStore()->retrieve( inCont, m_inContNameAndSysTypeList.at(contIdx).first ));
    if ( inCont->size() == 0 ) {
      ATH_MSG_DEBUG("Have an empty input container... going to the next");
      continue;
    }
    ATH_MSG_VERBOSE("Now reading input container with name: " << m_inContNameAndSysTypeList.at(contIdx).first
                    << " and size: " <<" "<<inCont->size());

    // Check the systematics type of the input container
    HWW::SystematicType inContSysType = m_inContNameAndSysTypeList.at(contIdx).second;

    // Loop over all Jets in the current input container to calculate JVT pass/fail
    for ( const xAOD::Jet* jet : *inCont ) {
      ATH_MSG_VERBOSE("Looking at jet number " << jet->index() << " with pt=" << 0.001*(jet->pt())
                      << " GeV, eta=" << jet->eta() << ", phi=" << jet->phi() );

      // Get the information if the current jet passes the JVT selection and store it, if requested
      if (decPassJVT){
        bool passJVT(false);
        passJVT = m_jvtEffiSFTool->passesJvtCut(*jet);
        (*decPassJVT)(*jet) = static_cast<char>(passJVT);
      }
    }

    // Now, decorate each jet with the scale factor and uncertainty, if requested
    if (m_decoJets){
      // Only do the JVT efficiency scale-factor calculation if running on MC
      if (!isSim) continue;

      // Now, we will loop over the efficiency scale-factor systematics to be applied
      ATH_MSG_VERBOSE("Size of effiSystVarNameVec : " << m_effiSystVarNameVec.size() );
      for ( const auto& systVariationAndVarName : m_effiSystVarNameVec ) {
        const CP::SystematicSet& systSet = systVariationAndVarName.first;
        const std::string& varName       = systVariationAndVarName.second;
        ATH_MSG_VERBOSE("Name of the next variation: " << systSet.name() );

        // Set the tool state to apply a systematic variation.
        // Event if it is an empty variation, i.e, the nominal case, set the
        // state of the tool to that to avoid that the tool is still in a
        // systematic state from the previous event.
        ATH_MSG_VERBOSE("Name of the next variation: " << systSet.name() );
        if ( m_jvtEffiSFTool->applySystematicVariation( systSet ) != CP::SystematicCode::Ok ) {
          ATH_MSG_ERROR("Cannot configure JetJvtEfficiency for systematic variation " << systSet.name() );
          return StatusCode::FAILURE;
        }
        if ( !((systSet.name()).empty()) ) {
          // If we are NOT on the nominally calibrated 4-vector container, but
          // rather on a container with systematically varied 4-vectors, we
          // actually don't also apply the systematically varied scale factors,
          // i.e., we don't have both systematics (4-vector AND efficiency) at the
          // same time.
          if ( inContSysType == HWW::SystematicType::FOURMOM ) {
            ATH_MSG_DEBUG("We encountered an efficiency systematic set. "
                          << "but we are currenlty looking at a container with "
                          << "a systematically varied 4-vector... thus skipping.");
            // We can actually break out of the loop over efficiency systematics
            // here, because the nominal efficiency is always the first one in our
            // set of efficiency "systematics"
            break;
          }
        }
        ATH_MSG_DEBUG("Going to run JetJvtEfficiency scale-factor systematic variation (empty=nominal): " << systSet.name() );

        // Create the accassor for the new variable that will hold the efficiency scale factor
        SG::AuxElement::Decorator<float> accSetEffiSF(varName);

        // Loop over all Jets in the current input container
        for ( const xAOD::Jet* jet : *inCont ) {
          ATH_MSG_VERBOSE("Looking at jet number " << jet->index() << " with pt=" << 0.001*(jet->pt())
                          << " GeV, eta=" << jet->eta() << ", phi=" << jet->phi() );

          // Set the default jvt efficiency scale-factor value
          float effiSFValue(1.0);
          if ( m_jvtEffiSFTool->getEfficiencyScaleFactor(*jet,effiSFValue) == CP::CorrectionCode::Error ) {
            ATH_MSG_ERROR("JetJvtEfficiency reported a CP::CorrectionCode::Error");
            return StatusCode::FAILURE;
          }
          // Decorate the current jet with the resulting efficiency scale-factor
          ATH_MSG_DEBUG("Decorating the jet with an efficiency scale-factor variable with name "
                        << varName << " and value " << effiSFValue );
          accSetEffiSF(*jet) = effiSFValue;
        }  // End: loop over Jets

      } // End: loop over systematic variations

    } // End: Decorate each jet with the scale-factor and systematic, if requested

  } // End: Loop over all input JetContainer names


  // Now, decorate the event with the combined scale factor and uncertainty, if requested
  if ( m_decoEvent && isSim ){
    ATH_MSG_DEBUG("Going to decorate the event with the combined JVT scale-factor");
    // First, build the jet view-containers with the selected jets from the input container
    const xAOD::JetContainer* inContAllJets = nullptr;
    ATH_CHECK( evtStore()->retrieve( inContAllJets, m_inContAllJetsName.value() ) );
    ATH_MSG_VERBOSE("Now reading input container with name: " << m_inContAllJetsName.value()
                    << " and size: " << " " << inContAllJets->size());
    // Now, build from the input container the individual jet view-containers
    // with the right kinematic cuts
    ConstDataVector<xAOD::JetContainer> jetsC25F25( SG::VIEW_ELEMENTS );
    ConstDataVector<xAOD::JetContainer> jetsC25F30( SG::VIEW_ELEMENTS );
    ConstDataVector<xAOD::JetContainer> jetsC30F30( SG::VIEW_ELEMENTS );
    // Loop over all Jets in the current input container to calculate JVT pass/fail
    for ( const xAOD::Jet* jet : *inContAllJets ) {
      ATH_MSG_VERBOSE("Looking at jet number " << jet->index() << " with pt=" << 0.001*(jet->pt())
                      << " GeV, eta=" << jet->eta() << ", phi=" << jet->phi() );
      const double pt = jet->pt();
      const double absEta = std::abs(jet->eta());
      // place the first cuts
      if ( pt < 25.0*GeV || absEta > 4.5 ) continue;
      jetsC25F25.push_back(jet);
      if ( absEta > 2.4 && pt < 30.0*GeV ) continue;
      jetsC25F30.push_back(jet);
      if ( pt < 30.0*GeV ) continue;
      jetsC30F30.push_back(jet);
    }
    ATH_MSG_DEBUG("Got " << jetsC25F25.size() << " jets with minPt=25 GeV");
    ATH_MSG_DEBUG("Got " << jetsC25F30.size() << " jets with minPt=25 GeV in the central part and 30 GeV in the forward part");
    ATH_MSG_DEBUG("Got " << jetsC30F30.size() << " jets with minPt=30 GeV");

    // Now, we will loop over the efficiency scale-factor systematics to be applied
    ATH_MSG_VERBOSE("Size of effiSystVarNameVec : " << m_effiSystVarNameVec.size() );
    for ( const auto& systVariationAndVarName : m_effiSystVarNameVec ) {
      const CP::SystematicSet& systSet = systVariationAndVarName.first;
      std::string varName              = systVariationAndVarName.second;
      ATH_MSG_VERBOSE("Name of the next variation: " << systSet.name() );

      // Set the tool state to apply a systematic variation.
      // Event if it is an empty variation, i.e, the nominal case, set the
      // state of the tool to that to avoid that the tool is still in a
      // systematic state from the previous event.
      ATH_MSG_VERBOSE("Name of the next variation: " << systSet.name() );
      if ( m_jvtEffiSFTool->applySystematicVariation( systSet ) != CP::SystematicCode::Ok ) {
        ATH_MSG_ERROR("Cannot configure JetJvtEfficiency for systematic variation " << systSet.name() );
        return StatusCode::FAILURE;
      }
      ATH_MSG_DEBUG("Going to run JetJvtEfficiency scale-factor systematic variation (empty=nominal): " << systSet.name() );

      // Set the default jvt efficiency scale-factor value
      float effiSFValue(1.0);
      if ( m_jvtEffiSFTool->applyAllEfficiencyScaleFactor(jetsC30F30.asDataVector(),effiSFValue) == CP::CorrectionCode::Error ) {
        ATH_MSG_ERROR("JetJvtEfficiency reported a CP::CorrectionCode::Error");
        return StatusCode::FAILURE;
      }
      // Decorate the current event with the resulting efficiency scale-factor
      ATH_MSG_DEBUG("Decorating the event with an efficiency scale-factor variable with name "
                    << varName << " and value " << effiSFValue );
      evtInfo->auxdecor<float>(varName) = effiSFValue;

      // Reset the scale-factor
      effiSFValue = 1.0;
      // Add an additional part to the scale-factor name
      const std::string newPartC25F30 = m_jvtEffSFVarName.value() + "C25F30";
      const std::string& oldNamePart = m_jvtEffSFVarName.value();
      boost::replace_all( varName, oldNamePart, newPartC25F30);
      // Set the default jvt efficiency scale-factor value
      if ( m_jvtEffiSFTool->applyAllEfficiencyScaleFactor(jetsC25F30.asDataVector(),effiSFValue) == CP::CorrectionCode::Error ) {
        ATH_MSG_ERROR("JetJvtEfficiency reported a CP::CorrectionCode::Error");
        return StatusCode::FAILURE;
      }
      // Decorate the current event with the resulting efficiency scale-factor
      ATH_MSG_DEBUG("Decorating the event with an efficiency scale-factor variable with name "
                    << varName << " and value " << effiSFValue );
      evtInfo->auxdecor<float>(varName) = effiSFValue;

      // Reset the scale-factor
      effiSFValue = 1.0;
      // Add an additional part to the scale-factor name
      const std::string newPartC25F25 = m_jvtEffSFVarName.value() + "C25F25";
      boost::replace_all( varName, newPartC25F30, newPartC25F25);
      // Set the default jvt efficiency scale-factor value
      if ( m_jvtEffiSFTool->applyAllEfficiencyScaleFactor(jetsC25F25.asDataVector(),effiSFValue) == CP::CorrectionCode::Error ) {
        ATH_MSG_ERROR("JetJvtEfficiency reported a CP::CorrectionCode::Error");
        return StatusCode::FAILURE;
      }
      // Decorate the current event with the resulting efficiency scale-factor
      ATH_MSG_DEBUG("Decorating the event with an efficiency scale-factor variable with name "
                    << varName << " and value " << effiSFValue );
      evtInfo->auxdecor<float>(varName) = effiSFValue;

    } // End: loop over systematic variations

  } // End: decorate the event with the combined scale-factor and uncertainty, if requested


  // Clean up
  if (decPassJVT) delete decPassJVT;

  return StatusCode::SUCCESS;
}
