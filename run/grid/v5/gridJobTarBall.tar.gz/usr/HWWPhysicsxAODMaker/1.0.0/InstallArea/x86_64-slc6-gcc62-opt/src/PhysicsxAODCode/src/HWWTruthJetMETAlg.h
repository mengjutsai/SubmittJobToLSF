#ifndef HWWCOMMONANALYSISUTILS_HWWTRUTHJETMETALG_H
#define HWWCOMMONANALYSISUTILS_HWWTRUTHJETMETALG_H 

// STL includes
#include <string>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
//#include "GaudiKernel/ToolHandle.h"

// EDM includes

// Forward declarations


// Put everything into a HWW namespace
namespace HWW {

  class TruthJetMETAlg
    : public ::AthAlgorithm
  {
    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
    public:

      /// Constructor with parameters:
      TruthJetMETAlg( const std::string& name, ISvcLocator* pSvcLocator );

      /// Destructor:
      virtual ~TruthJetMETAlg();

      /// Athena algorithm's initalize hook
      virtual StatusCode  initialize();

      /// Athena algorithm's execute hook
      virtual StatusCode  execute();

      /// Athena algorithm's finalize hook
      virtual StatusCode  finalize();




    private:

      /// @name The properties that can be defined via the python job options
      /// @{

      //
      // Configurable properties
      //

      /// The input jet container name
      StringProperty m_inJetCont;

      /// The input met container name
      StringProperty m_inMetCont;

      /// The output jet container name
      StringProperty m_outJetCont;

      /// The output met container name
      StringProperty m_outMetCont;

      /// @}

  };

} // End HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWTRUTHJETMETALG_H
