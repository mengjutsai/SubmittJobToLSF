# =============================================================================
#  Name:        HWWTruthAnalysis_topOptions.py
#
#  Author:      Karsten Koeneke
#  Created:     August 2014
#
#  Usage: Here, all neccessary job options for the HWW analysis on truth files can be set.
#         To run, type:
#              athena PhysicsxAODConfig/HWWTruthAnalysis_topOptions.py 2>&1 | tee log.txt
# =============================================================================

# Import the error handling
#svcMgr.CoreDumpSvc.FatalHandler = 438
#import traceback

# To change the print format, leave 40 characters before "INFO",...
MessageSvc.Format = "% F%60W%S%7W%R%T %0W%M"

# Import the steering flags for this analysis
from PhysicsxAODConfig.HWWTruthCommonAnalysisFlags import hWWCommon

# for messaging
from AthenaCommon.Logging import logging
hWW_msg = logging.getLogger( 'HWWAnalysis' )
hWWCommon.Global.logLevel = vars().get('PAODLogLevel', DEBUG) # 3=INFO, 2=DEBUG
hWW_msg.setLevel(hWWCommon.Global.logLevel)


# ==============================================================================
# Load your input file that you want to process.
# Note that the last method gets the highest priority.
# ==============================================================================
from AthenaCommon.AthenaCommonFlags import jobproperties as jp
import AthenaPoolCnvSvc.ReadAthenaPool
from glob import glob
myFileList = ["/home/becker/cluster/Athena/truthDxAODs/20.1.8.3/WorkArea/run/DAOD_TRUTH1.firsttestHWW_withweights.pool.root"]

envVar = "DataMC"
# envVar = "SharedDataMC"
if os.getenv(envVar) and os.path.exists(os.getenv(envVar)) :
    #basePath = os.getenv(envVar)+"/mc/DxAOD/mc15_13TeV.341079.PowhegPythia8EvtGen_CT10_AZNLOCTEQ6L1_ggH125_WWlvlv_EF_15_5.merge.DAOD_HIGG3D1.e3871_s2608_s2183_r6630_r6264_p2352/"
    basePath = os.getenv(envVar)+"/mc/DxAOD/mc15_13TeV.341079.PowhegPythia8EvtGen_CT10_AZNLOCTEQ6L1_ggH125_WWlvlv_EF_15_5.merge.DAOD_HIGG3D1.e3871_s2608_s2183_r6630_r6264_p2419/"
    #basePath = os.getenv(envVar)+"/data/DxAOD/data15_13TeV.00276262.physics_Main.merge.DAOD_HIGG3D1.f620_m1480_p2425/"
    #basePath = os.getenv(envVar)+"/mc/DxAOD/mc15_13TeV.361063.Sherpa_CT10_llll.merge.DAOD_HIGG3D1.e3836_s2608_s2183_r6869_r6282_p2419/"
    myFileList = glob( basePath+"*.root*")
    pass
# For local running
if vars().has_key('INDIR'):
    inDir = vars().get('INDIR')
    if os.path.exists(inDir): myFileList = glob(inDir+"/*.root*")
    else: hWW_msg.warning("Provided directory '%s' does not exist. Using input files: %s" % (inDir, myFileList))
    pass
if vars().has_key('INFILELIST'):
    inFileStringList = vars().get('INFILELIST')
    inFileList = inFileStringList.split(',')
    tmpFileList = []
    for inFile in inFileList:
        if os.path.exists(inFile): tmpFileList.append(inFile)
        else: paodMsg.warning("Provided input file '%s' does not exist.... skipping it!" % inFile)
        pass
    myFileList = tmpFileList
    pass
if vars().has_key('INFILE'):
    inFile = vars().get('INFILE')
    if os.path.exists(inFile): myFileList = [inFile]
    else: hWW_msg.warning("Provided input file '%s' does not exist. Using input files: %s" % (inFile, myFileList))
    pass
hWW_msg.info("Using %i input files: %s" % (len(myFileList), myFileList))
jp.AthenaCommonFlags.FilesInput = myFileList


# ==============================================================================
# Fetch the AthAlgSeq, i.e., one of the existing master sequences where one should attach all algorithms
# ==============================================================================
topSequence = CfgMgr.AthSequencer("AthAlgSeq", OutputLevel = WARNING) # set back to WARNING


# ==============================================================================
# Perform some commonly needed tasks
# ==============================================================================
svcMgr.EventSelector.InputCollections = jp.AthenaCommonFlags.FilesInput()
svcMgr.StatusCodeSvc.AbortOnError=True

# Import the reading of in-file metadata
from PyUtils import AthFile
af = AthFile.fopen( svcMgr.EventSelector.InputCollections[0] )
eventDataItems = []
for evtItem in af.fileinfos["eventdata_items"]:
    evtItem0 = evtItem[0]
    if evtItem[0] == None :
        hWW_msg.info("Got an unknown type from the input file for the item with name: %s" % evtItem[1])
        evtItem0 = "None"
    eventDataItems.append( evtItem0 + "#" + evtItem[1] )
    pass



# ==============================================================================
# Schedule the bookkeeping of the number of processed events and sum-of-weights
# ==============================================================================
from EventBookkeeperTools.CutFlowHelpers import CreateCutFlowSvc
CreateCutFlowSvc( svcName="CutFlowSvc", athFile=af, seq=topSequence, addMetaDataToAllOutputFiles=True )
# svcMgr.CutFlowSvc.OutputLevel = VERBOSE

### Update also the other counters for the non-nominal MC weights
topSequence.AllExecutedEvents.BookkeepOtherMCEventWeights = True

# For the correct handling of the trigger meta-data
ToolSvc += CfgMgr.xAODMaker__TriggerMenuMetaDataTool("TriggerMenuMetaDataTool")
svcMgr.MetaDataSvc.MetaDataTools += [ ToolSvc.TriggerMenuMetaDataTool ]

# For the correct handling of the luminosity blocks meta-data
# from LumiBlockComps.LumiBlockCompsConf import LumiBlockMetaDataTool
# svcMgr.MetaDataSvc.MetaDataTools += [ "LumiBlockMetaDataTool" ]
ToolSvc += CfgMgr.LumiBlockMetaDataTool("LumiBlockMetaDataTool")
svcMgr.MetaDataSvc.MetaDataTools += [ ToolSvc.LumiBlockMetaDataTool ]

# For the correct handling of the xAOD::EventFormat (required to read file in ROOT)
ToolSvc += CfgMgr.xAODMaker__EventFormatMetaDataTool( "EventFormatMetaDataTool" )
svcMgr.MetaDataSvc.MetaDataTools += [ ToolSvc.EventFormatMetaDataTool ]
# theApp.CreateSvc += [ "xAODMaker::EventFormatSvc" ]
# outStream.AddMetaDataItem(["xAOD::EventFormat#EventFormat"])

# Set up the metadata tool:
# ToolSvc += CfgMgr.xAODMaker__FileMetaDataCreatorTool( "FileMetaDataCreatorTool" )
# svcMgr.MetaDataSvc.MetaDataTools += [ ToolSvc.FileMetaDataCreatorTool ]


# ==============================================================================
# If you have your own analysis scripts
# (for examples, see in svn: PhysicsAnalysis/MyPackage/share/MySuperJobOption.py ),
# then just include your script (wherever it is) here:
#
#       include("MyPackage/MySuperJobOption.py")
#
# The HWW analysis scripts are appended below, so you can see how it works!
# ==============================================================================

# # For being able to read DC14 files while already running MC15 software
# include("AthAnalysisBaseComps/ContainerRemapping.py")

# This is for the H->WW->lnulnu analysis
hWWCommon.Global.do2Lep = vars().get('do2Lep', hWWCommon.Global.do2Lep)
if hWWCommon.Global.do2Lep:
    try: from HWWlnulnuxAODConfig.HWWlnulnuTruthAnalysisFlags import hWWlnulnu
    except ImportError:
        hWWCommon.Global.do2Lep = False
        hWW_msg.info("Couldn't load the H->WW->lnulnu configuration. The HWWlnulnuxAODConfig package is probably not available.")
        pass
    pass

# This is for the VH, H->WW analyses
hWWCommon.Global.do3Lep = vars().get('do3Lep', hWWCommon.Global.do3Lep)
hWWCommon.Global.do4Lep = vars().get('do4Lep', hWWCommon.Global.do4Lep)
if hWWCommon.Global.do3Lep or hWWCommon.Global.do4Lep:
    try: import HWWVHxAOD.VHTruthFlags as vh_flags
    except ImportError:
        hWWCommon.Global.do3Lep = False
        hWWCommon.Global.do4Lep = False
        hWW_msg.info("Couldn't load the VH configuration. The HWWVHxAOD package is probably not available.")
        pass
    pass

# This is for the lepton fake factor analysis
#hWWCommon.Global.doFakeLep = vars().get('DoFakeLep', hWWCommon.Global.doFakeLep)
#if hWWCommon.Global.doFakeLep:
#    try: from HWWFakeFactorxAOD.HWWFakeFactorFlags import hWWFakes
#    except ImportError:
#        hWWCommon.Global.doFakeLep = False
#        hWW_msg.info("Couldn't load the lepton-fake configuration. The HWWFakeFactorxAOD package is probably not available.")
#        pass
#    pass

# This is for the H->WW->lnuqq analysis
#hWWCommon.Global.do1Lep = vars().get('Do1Lep', hWWCommon.Global.do1Lep)
#if hWWCommon.Global.do1Lep:
#    if hWWCommon.Global.do2Lep or hWWCommon.Global.do3Lep or hWWCommon.Global.do4Lep or hWWCommon.Global.doFakeLep:
#        hWW_msg.warning("You asked to produce PAOD_1L AND some other PAOD. This is not allowed (due to interfernce). Will NOT produce PAOD_1L!")
#        hWWCommon.Global.do1Lep = False
#        pass
#    else:
#        try: from HWWlvqqxAODConfig.HWWlnuqqAnalysisFlags import hWWlnuqq
#        except ImportError:
#            hWWCommon.Global.do1Lep = False
#            hWW_msg.info("Couldn't load the H->WW->lnuqq configuration. The HWWlvqqxAODConfig package is probably not available.")
#            pass
#        pass
#    pass
#

# Now, actually load the wanted configurations
if hWWCommon.Global.do2Lep: include("HWWlnulnuxAODConfig/HWWlnulnuTruthAnalysisCommon.py")
if hWWCommon.Global.do3Lep or hWWCommon.Global.do4Lep: include("HWWVHxAOD/VHTruthAnalysisCommon.py")
#if hWWCommon.Global.doFakeLep: include("HWWFakeFactorxAOD/HWWFakeFactorAnalysisCommon.py")
#if hWWCommon.Global.do1Lep: include("HWWlvqqxAODConfig/HWWlnuqqAnalysisCommon.py")


# ==============================================================================
#           ---- NO NEED TO CHANGE ANYTHING BELOW THIS LINE !!! ----
# ==============================================================================



# ====================================================================
# THINNING: We must create an instance of the ThinningSvc for all output streams.
# Thinning service name must match the one passed to the thinning tools
# ====================================================================
from AthenaServices.Configurables import ThinningSvc
outputSteamNameList = []
for stream in MSMgr.StreamList:
    outputSteamNameList.append(stream.GetEventStream().name())
    pass
hWW_msg.info("Using these streams for thinning: %s" % outputSteamNameList)
svcMgr += ThinningSvc("HWWCommonThinning", Streams=outputSteamNameList)



# ----------------------------------------------------------------------------------------------------
# If you want to drastically reduce the information that is printed out, you can increase the general
# output level of the MessageService. The default is INFO.
# The possible options are: FATAL, ERROR, WARNING, INFO, DEBUG, VERBOSE
# ----------------------------------------------------------------------------------------------------
# rec.OutputLevel.set_Value_and_Lock( WARNING )

# Change the way Athena MultiProcessing (AthenaMP) is distribution files/events to the workers
#from AthenaMP.AthenaMPFlags import jobproperties as jps
#jps.AthenaMPFlags.Strategy = 'FileScheduling'
# 'SharedQueue' (default), 'FileScheduling', 'SharedReader' and 'TokenScatterer'


# ==============================================================================
# Set the number of events that you want to process (-1 means all events) or skip.
# Shown is a handy way how you can use command-line options.
# If EVTMAX is not given on the command line, the default -1 (process all events) is used.
# If SKIPEVT is not given on the command line, the default 0 (start from the beginning) is used.
# This works for any command line option that you may need; it is a python feature.
# ==============================================================================
svcMgr.EventSelector.SkipEvents = vars().get('SKIPEVT', 0)
theApp.EvtMax = vars().get('EVTMAX', -1)


# Suppress warnings from unknown objects (i.e., non-xAOD objects) in the input file
#svcMgr.PoolSvc.OutputLevel=ERROR

# Change the event printout interval, if you want to
evtPrintoutInterval = vars().get('EVTPRINT', 500)
svcMgr += CfgMgr.AthenaEventLoopMgr( EventPrintoutInterval=evtPrintoutInterval )


# ==============================================================================
# Remove the long printouts of ItemListSvc at the end of the job
# ==============================================================================
# svcMgr.ItemListSvc.OutputLevel = WARNING


# ==============================================================================
# Optional include to suppress as much athena output as possible
# ==============================================================================
include("AthAnalysisBaseComps/SuppressLogging.py")


# ==============================================================================
# Add basic code performance monitoring.
# The results will be presented at the end of your job.
# PerfMon profiles what memory was use and how long it took to run.
# Chrono tells you in an ordered table how much time was spend in each algorithm.
# ==============================================================================
from PerfMonComps.PerfMonFlags import jobproperties as pmjp
pmjp.PerfMonFlags.doFastMon = True    # to only enable a lightweight monitoring
if vars().get('doChrono',True):
    theAuditorSvc = svcMgr.AuditorSvc
    theAuditorSvc.Auditors  += [ "ChronoAuditor"]
    svcMgr.ChronoStatSvc.PrintUserTime     = False
    svcMgr.ChronoStatSvc.PrintSystemTime   = False
    svcMgr.ChronoStatSvc.PrintEllapsedTime = False
    svcMgr.ChronoStatSvc.NumberOfSkippedEventsForMemStat = 1
    theApp.AuditAlgorithms = True
pass



# ==============================================================================
# Change the basket size only for the DataHeaderForm in order to increase the
# efficiency of the compression
# ==============================================================================
# from HWWlnulnuxAODConfig.HWWlnulnuAnalysisFlags import hWWlnulnu
# svcMgr.AthenaPoolCnvSvc.PoolAttributes += [ "ContainerName = 'POOLContainerForm(DataHeaderForm)'; BRANCH_BASKET_SIZE = '10000000'" ] # 10 MB
# svcMgr.AthenaPoolCnvSvc.PoolAttributes += [ "DatabaseName = '" + hWWlnulnu.Global.FileName + "'; ContainerName = 'TTree=POOLContainerForm'; CONTAINER_SPLITLEVEL = '99'" ]
# svcMgr.AthenaPoolCnvSvc.PoolAttributes += [ "DatabaseName = '" + hWWlnulnu.Global.FileName + "'; COMPRESSION_LEVEL = '9'" ]
# svcMgr.AthenaPoolCnvSvc.PoolAttributes += [ "ContainerName = 'POOLContainerForm(DataHeaderForm)'; BRANCH_BASKET_SIZE = '2000000'" ] # 2 MB


# Some more stuff if you want to profile a given algorithm using valgrind
# For more info, see: https://twiki.cern.ch/twiki/bin/view/AtlasComputing/OptimisingCode
# svcMgr += CfgMgr.ValgrindSvc( OutputLevel        = VERBOSE,
#                               IgnoreFirstNEvents = 5,
#                               ProfiledAlgs       = [ "HWWMuonCalibrationSmearingAlg",
#                                                      "HWWMuonSelectionAlg",
#                                                      "HWWMuonEffiScaleFactorAlg" ] )
# Run it with:
# valgrind --tool=callgrind --trace-children=yes --num-callers=8 --collect-jumps=yes --instr-atstart=no `which athena.py` --stdcmalloc HWWAnalysis_topOptions.py
