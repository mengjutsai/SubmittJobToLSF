///////////////////////// -*- C++ -*- /////////////////////////////
// HWWEventSelectionAlg.h
// Header file for class HWW::EventSelectionAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWEVENTSELECTIONALG_H
#define HWWCOMMONANALYSISUTILS_HWWEVENTSELECTIONALG_H 1

// STL includes
#include <string>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthFilterAlgorithm.h"

// EDM includes
#include "xAODJet/Jet.h"
#include "xAODMuon/Muon.h"

// Forward declarations



// Put everything into a HWW namespace
namespace HWW {

  class EventSelectionAlg
    : public ::AthFilterAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
   public:

    // Copy constructor:

    /// Constructor with parameters:
    EventSelectionAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~EventSelectionAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();


    ///////////////////////////////////////////////////////////////////
    // Private methods:
    ///////////////////////////////////////////////////////////////////
   private:
    /// Check if a jet is b-tagged
    StatusCode isBTagged(const xAOD::Jet* jet, bool& passBTagging ) const;

    /// Check if the muon is fully identified
    bool muonIsID(const xAOD::Muon* muon) const;

    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
   private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input container name list
    StringArrayProperty m_inContList;

    /// The minimum number of other leptons required
    IntegerProperty m_nMinOtherLeptons;

    /// The minimum number of jets required
    IntegerProperty m_nMinJets;

    /// The minimum number of b-tagged jets required
    IntegerProperty m_nMinBJets;

    /// The name of the tagger that we want to use (default='MV2c20')
    StringProperty m_taggerName;

    /// The cut value on the b-tagging discriminant
    DoubleProperty m_taggerCut;

    /// Ask for an identified fake muon
    BooleanProperty m_hasIDFakeMuon;

    /// Ask for an identified other muon
    BooleanProperty m_hasIDOtherMuon;

    /// @}


    /// @name Internal members
    /// @{

    /// The vector of muon container names
    std::vector<std::string> m_containerNameList;

    /// @}

  };

} // End:: HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWEVENTSELECTIONALG_H
