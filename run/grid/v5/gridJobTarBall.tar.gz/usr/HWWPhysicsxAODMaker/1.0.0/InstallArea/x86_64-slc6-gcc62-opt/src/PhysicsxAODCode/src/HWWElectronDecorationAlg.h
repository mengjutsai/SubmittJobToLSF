///////////////////////// -*- C++ -*- /////////////////////////////
// HWWElectronDecorationAlg.h
// Header file for class HWW::ElectronDecorationAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWELECTRONDECORATIONALG_H
#define HWWCOMMONANALYSISUTILS_HWWELECTRONDECORATIONALG_H 1

// STL includes
#include <string>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"

// Forward declarations
class IAsgSelectionTool;
class IAsgSelectionWithVertexTool;
namespace CP{
  class IIsolationSelectionTool;
}
class IEGammaAmbiguityTool;
class IAsgElectronLikelihoodTool;


// Put everything into a HWW namespace
namespace HWW {

  class ElectronDecorationAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
  public:

    // Copy constructor:

    /// Constructor with parameters:
    ElectronDecorationAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~ElectronDecorationAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input electron container name
    StringProperty m_inContName;

    /// The CP selection tools
    ToolHandleArray<IAsgSelectionTool> m_electronSelectionToolList;

    /// The electron decoration names
    StringArrayProperty m_electronDecList;

    /// List of selection-with-vertex tool instances
    ToolHandleArray<IAsgSelectionWithVertexTool> m_selectionWithVertexToolList;

    /// List of decoration names for each selection-with-vertex tools
    StringArrayProperty m_selectionWithVertexDecoList;

    /// The CP iso tool
    ToolHandleArray<CP::IIsolationSelectionTool> m_isoToolList;

    /// The electron islation tool result decoration names
    StringArrayProperty m_electronIsoWPList;

    /// Transfer variables from the input (given here) to the output
    StringArrayProperty m_transferSources;

    /// Transfer variables from the input to the output (given here)
    StringArrayProperty m_transferTargets;

    /// If true, will calculate and store the z0sinTheta, d0, and d0Err
    bool m_doImpactParameter;

    /// The input primary vertex container name
    StringProperty m_inPrimVtxCont;

    /// If true, will calculate the results from the egamma ambiguity tool
    bool m_doAmbiguity;

    /// The EGamma Ambiguity Tool
    ToolHandle<IEGammaAmbiguityTool> m_egammaAmbiguityTool;
    
    /// The EGamma Ambiguity Tool
    ToolHandle<IEGammaAmbiguityTool> m_egammaAmbiguityTool_Tight; //mgeisen
    
    /// If true, will calculate the results from the electron charge ID selector
    bool m_doECIDS;

    /// The EGamma Charge ID Selector Tool
    ToolHandle<IAsgElectronLikelihoodTool> m_electronECIDSTool;

    /// If true, will decorate charge and pt to ele (Philip)
    bool m_doTruth;

    /// Decorate all copies of the input container
    bool m_decoAllCopies;

    /// The vector of muon container names
    std::vector<std::string> m_containerNameList;

    /// @}

  private:

  };

} // End: HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWELECTRONDECORATIONALG_H
