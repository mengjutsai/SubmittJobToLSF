///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetJVTScaleFactorAlg.h
// Header file for class HWW::JetJVTScaleFactorAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWJETJVTSCALEFACTORALG_H
#define HWWCOMMONANALYSISUTILS_HWWJETJVTSCALEFACTORALG_H 1

// STL includes
#include <string>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"
#include "PATInterfaces/SystematicSet.h"

#include "PhysicsxAODCode/IHWWContainersFinderTool.h"

// Forward declarations
namespace CP {
  class IJetJvtEfficiency;
}



// Put everything into a HWW namespace
namespace HWW {

  class JetJVTScaleFactorAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
  public:

    // Copy constructor:

    /// Constructor with parameters:
    JetJVTScaleFactorAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~JetJVTScaleFactorAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input jet container name
    StringProperty m_inContName;

    /// The input jet container name for the calibrated, overlap-removed jets
    StringProperty m_inContAllJetsName;

    /// The tool that tries to find all input containers, including their systematic variations
    ToolHandle<HWW::IContainersFinderTool> m_contFindTool;

    /// The Jet JVT efficiency scale-factor tool
    ToolHandle<CP::IJetJvtEfficiency> m_jvtEffiSFTool;

    /// The names of all systematic variations to be applied
    StringArrayProperty m_jvtEffSFSysNames;

    /// The name of the efficiency scale-factor variable that will be added to the jet
    StringProperty m_jvtEffSFVarName;

    /// The string separator between the variable/container name and its sytematic variation (default="___")
    StringProperty m_separator;

    /// The name of the variable for passing the JVT selection
    StringProperty m_passJVTVarName;

    /// Abort on an unchecked CP::CorrectionCode
    bool m_abortOnUncheckedCorrCode;

    /// Decorate all copies of the input container
    bool m_decoAllCopies;

    /// Decorate each individual jet
    bool m_decoJets;

    /// Decorate the EventInfo object
    bool m_decoEvent;

    /// @}

  private:

    /// @name Truly private internal data members
    /// @{

    /// Vector of all input container names to consider and what type of systematics they contain (filled automatically)
    HWW::ContNameAndSysTypeVec_t m_inContNameAndSysTypeList;

    /// The vector of all efficiency scale factor systematics and the corresponding variable names
    std::vector< std::pair< CP::SystematicSet, std::string > > m_effiSystVarNameVec;

    /// @}

  };

} // End: HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWJETJVTSCALEFACTORALG_H
