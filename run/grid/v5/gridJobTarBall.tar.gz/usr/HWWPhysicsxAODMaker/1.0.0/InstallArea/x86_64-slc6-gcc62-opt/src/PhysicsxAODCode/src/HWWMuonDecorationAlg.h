///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMuonDecorationAlg.h
// Header file for class HWW::MuonDecorationAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWMUONDECORATIONALG_H
#define HWWCOMMONANALYSISUTILS_HWWMUONDECORATIONALG_H 1

// STL includes
#include <string>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "PATCore/IAsgSelectionTool.h"
#include "GaudiKernel/ToolHandle.h"


// Forward declarations
namespace CP {
  class IMuonSelectionTool;
  class IIsolationSelectionTool;
}
class IAsgSelectionWithVertexTool;



// Put everything into a HWW namespace
namespace HWW {

  class MuonDecorationAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
  public:

    // Copy constructor:

    /// Constructor with parameters:
    MuonDecorationAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~MuonDecorationAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input muon container name
    StringProperty m_inContName;

    /// The muon selection tool
    ToolHandle<CP::IMuonSelectionTool> m_muonSelectionTool;

    /// The CP::MuonSelectionTool instance configured with the high-pt selection
    ToolHandle<CP::IMuonSelectionTool> m_highPtMuonSelectionTool;

    /// List of selection-with-vertex tool instances
    ToolHandleArray<IAsgSelectionWithVertexTool> m_selectionWithVertexToolList;

    /// List of decoration names for each selection-with-vertex tools
    StringArrayProperty m_selectionWithVertexDecoList;

    /// The CP iso tool
    ToolHandleArray<CP::IIsolationSelectionTool> m_isoToolList;

    /// The electron decoration names
    StringArrayProperty m_muonIsoWPList;

    /// If true, will calculate and store the relative pt difference between MS and ID
    bool m_doDeltaPt;

    /// If true, will calculate and store the z0sinTheta, d0, and d0Err
    bool m_doImpactParameter;

    /// If true, will store the result of ALL the recommended isoaltion WP
    bool m_doStandardIsoWP;

    /// The input primary vertex container name
    StringProperty m_inPrimVtxCont;

    /// If true, will attach the results of the MCTruthClassifer to the muon directly
    bool m_doTruth;

    /// Decorate all copies of the input container
    bool m_decoAllCopies;

    /// The vector of muon container names
    std::vector<std::string> m_containerNameList;

    /// @}

  private:


  };

} // End: HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWMUONDECORATIONALG_H
