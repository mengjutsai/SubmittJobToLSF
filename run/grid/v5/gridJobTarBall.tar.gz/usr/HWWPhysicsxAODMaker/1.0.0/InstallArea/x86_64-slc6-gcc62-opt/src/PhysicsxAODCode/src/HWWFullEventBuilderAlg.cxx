// PhysicsxAODCode includes
#include "HWWFullEventBuilderAlg.h"

// EDM includes
#include "xAODCore/AuxContainerBase.h"
#include "xAODBase/IParticle.h"
#include "xAODBase/IParticleContainer.h"
#include "xAODParticleEvent/IParticleLink.h"
#include "xAODParticleEvent/CompositeParticle.h"
#include "xAODParticleEvent/CompositeParticleContainer.h"
#include "xAODParticleEvent/CompositeParticleAuxContainer.h"
#include "xAODMissingET/MissingETContainer.h"
#include "xAODMissingET/MissingET.h"

// Some helpers
#include "CxxUtils/fpcompare.h"


HWW::FullEventBuilderAlg::FullEventBuilderAlg( const std::string& name,
                                               ISvcLocator* pSvcLocator ) :
  AthAlgorithm( name, pSvcLocator ),
  m_lep1Cont(""),
  m_lep2Cont(""),
  m_jetCont(""),
  m_metCont(""),
  m_metObj(""),
  m_otherElCont(""),
  m_otherMuCont(""),
  m_otherJetCont(""),
  m_eventCont(""),
  m_writeSplitAux(true),
  m_cutLeadLepPt(0.0)
{
  declareProperty( "Lepton1Container",          m_lep1Cont, "Name of the input lepton 1 container" );
  declareProperty( "Lepton2Container",          m_lep2Cont, "Name of the input lepton 2 container" );
  declareProperty( "JetContainer",              m_jetCont,  "Name of the input jet container" );
  declareProperty( "MissingETContainer",        m_metCont,  "Name of the input missingET container" );
  declareProperty( "MissingETObject",           m_metObj,   "Name of the input missingET object" );
  declareProperty( "OtherElectronContainer",    m_otherElCont,
                   "Name of the input container for other electrons, i.e., the ones for the third lepton veto" );
  declareProperty( "OtherMuonContainer",        m_otherMuCont,
                   "Name of the input container for other muons, i.e., the ones for the third lepton veto" );
  declareProperty( "OtherJetContainer",         m_otherJetCont,
                   "Name of the input container for other jets, i.e., the ones for the sub-threshold jets" );
  declareProperty( "EventContainer",            m_eventCont,"Name of the output event container" );
  declareProperty( "WriteSplitOutputContainer", m_writeSplitAux,
                   "Decide if we want to write a fully-split AuxContainer such that we can remove any variables" );
  declareProperty( "CutLeadingLeptonPtMin",     m_cutLeadLepPt, "Name of the leading-lepton pt cut" );
}



HWW::FullEventBuilderAlg::~FullEventBuilderAlg() {}



StatusCode HWW::FullEventBuilderAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");
  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_lep1Cont );
  ATH_MSG_DEBUG( "Using: " << m_lep2Cont );
  ATH_MSG_DEBUG( "Using: " << m_jetCont );
  ATH_MSG_DEBUG( "Using: " << m_metCont );
  ATH_MSG_DEBUG( "Using: " << m_metObj );
  ATH_MSG_DEBUG( "Using: " << m_otherElCont );
  ATH_MSG_DEBUG( "Using: " << m_otherMuCont );
  ATH_MSG_DEBUG( "Using: " << m_otherJetCont );
  ATH_MSG_DEBUG( "Using: " << m_eventCont );
  ATH_MSG_DEBUG( "Using: " << m_writeSplitAux );
  ATH_MSG_DEBUG( "Using: " << m_cutLeadLepPt );

  return StatusCode::SUCCESS;
}



StatusCode HWW::FullEventBuilderAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");
  return StatusCode::SUCCESS;
}



StatusCode HWW::FullEventBuilderAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Check what is in the current event store
  ATH_MSG_VERBOSE("Current event store content: " << evtStore()->dump() );

  // Open the input lepton 1 container
  const xAOD::IParticleContainer* lep1Cont = nullptr;
  ATH_CHECK( evtStore()->retrieve( lep1Cont, m_lep1Cont.value() ) );
  ATH_MSG_VERBOSE("Retrieved lepton container 1 with name: " << m_lep1Cont.value() );

  // Open the input lepton 1 container
  const xAOD::IParticleContainer* lep2Cont = nullptr;
  ATH_CHECK( evtStore()->retrieve( lep2Cont, m_lep2Cont.value() ) );
  ATH_MSG_VERBOSE("Retrieved lepton container 2 with name: " << m_lep2Cont.value() );

  // Create a new output container for the event and its associated auxiliary container
  xAOD::CompositeParticleContainer* eventCont = new xAOD::CompositeParticleContainer();
  ATH_CHECK( evtStore()->record ( eventCont, m_eventCont.value() ) );
  ATH_MSG_VERBOSE("Created a new output container with name: " << m_eventCont.value() );
  if ( m_writeSplitAux ) {
    xAOD::AuxContainerBase* outEventAuxContainer = new xAOD::AuxContainerBase();
    ATH_CHECK( evtStore()->record( outEventAuxContainer, m_eventCont.value() + "Aux." ) );
    eventCont->setStore( outEventAuxContainer );
  }
  else {
    xAOD::CompositeParticleAuxContainer* outEventAuxContainer = new xAOD::CompositeParticleAuxContainer();
    ATH_CHECK( evtStore()->record( outEventAuxContainer, m_eventCont.value() + "Aux." ) );
    eventCont->setStore( outEventAuxContainer );
  }


  // If we have zero leptons in either lep1Cont or lep2Cont, there is nothing to do
  if ( lep1Cont->size() == 0 || lep2Cont->size() == 0 ) {
    ATH_MSG_DEBUG("We have lep1Cont->size()=" << lep1Cont->size() <<
                  " and lep2Cont->size()=" << lep2Cont->size() << "... nothing the do");
    return StatusCode::SUCCESS;
  }


  // Now, let's open the other needed input containers

  // Open the input missingET container
  const xAOD::MissingET* metObj = nullptr;
  if ( !(m_metCont.value().empty()) && evtStore()->contains<xAOD::MissingETContainer>(m_metCont.value()) ) {
    const xAOD::MissingETContainer* metCont = nullptr;
    ATH_CHECK( evtStore()->retrieve( metCont, m_metCont.value() ) );
    metObj = (*metCont)[m_metObj.value()];
  }
  ATH_MSG_VERBOSE("Retrieved missingET container with name: " << m_metCont.value() );


  // Open the input jet container
  const xAOD::IParticleContainer* jetCont = nullptr;
  if ( !(m_jetCont.value().empty()) && evtStore()->contains<xAOD::IParticleContainer>(m_jetCont.value()) ) {
    ATH_CHECK( evtStore()->retrieve( jetCont, m_jetCont.value() ) );
  }
  ATH_MSG_VERBOSE("Retrieved jet container with name: " << m_jetCont.value() );

  // Open the input other electrons container
  const xAOD::IParticleContainer* otherElCont = nullptr;
  if ( !(m_otherElCont.value().empty()) && evtStore()->contains<xAOD::IParticleContainer>(m_otherElCont.value()) ) {
    ATH_CHECK( evtStore()->retrieve( otherElCont, m_otherElCont.value() ) );
  }
  ATH_MSG_VERBOSE("Retrieved other electron container with name: " << m_otherElCont.value() );

  // Open the input other muon container
  const xAOD::IParticleContainer* otherMuCont = nullptr;
  if ( !(m_otherMuCont.value().empty()) && evtStore()->contains<xAOD::IParticleContainer>(m_otherMuCont.value()) ) {
    ATH_CHECK( evtStore()->retrieve( otherMuCont, m_otherMuCont.value() ) );
  }
  ATH_MSG_VERBOSE("Retrieved other muon container with name: " << m_otherMuCont.value() );

  // Open the input other jet container
  const xAOD::IParticleContainer* otherJetCont = nullptr;
  if ( !(m_otherJetCont.value().empty()) && evtStore()->contains<xAOD::IParticleContainer>(m_otherJetCont.value()) ) {
    ATH_CHECK( evtStore()->retrieve( otherJetCont, m_otherJetCont.value() ) );
  }
  ATH_MSG_VERBOSE("Retrieved other jet container with name: " << m_otherJetCont.value() );


  // OK, now, we have all the needed container and we can get down to buisness


  // Assume that the ele container is pt-sorted.
  // Remember that we only want to put in the composite particle 4-mon only the two selected object
  for ( const xAOD::IParticle* lep1 : *lep1Cont ) {
    const double let1Pt = lep1->pt();
    if ( let1Pt <= m_cutLeadLepPt.value() ){
      ATH_MSG_VERBOSE("Failing the leading lepton pt cut: " << 0.001*let1Pt << " <= " << 0.001*(m_cutLeadLepPt.value()) );
      continue;
    }
    for ( const xAOD::IParticle* lep2 : *lep2Cont ) {
      if ( lep1==lep2 ){
        ATH_MSG_VERBOSE("Got identical leptons... continue");
        continue;
      }
      if ( lep2->pt() > lep1->pt() ){
        ATH_MSG_VERBOSE("Lep1Pt=" << 0.001*(lep1->pt())
                        << " GeV is smaller than Lep2Pt=" << 0.001*(lep2->pt()) << "... continue");
        continue;
      }

      // Create an empty event candidate for each pair
      xAOD::CompositeParticle* event = new xAOD::CompositeParticle();
      eventCont->push_back(event);

      // Add the two leptons as the first two object in the event
      // Don't bother with updating the four-momentum of the event.
      ATH_MSG_VERBOSE("Adding lepton1 with index " << lep1->index() << " and container address " << lep1->container() );
      ATH_MSG_VERBOSE("Adding lepton1 with pt=" << 0.001*(lep1->pt()) << " GeV, eta=" << lep1->eta() << ", and phi=" << lep1->phi());
      event->addPart( lep1, false );
      ATH_MSG_VERBOSE("Adding lepton2 with index " << lep2->index() << " and container address " << lep2->container() );
      ATH_MSG_VERBOSE("Adding lepton2 with pt=" << 0.001*(lep2->pt()) << " GeV, eta=" << lep2->eta() << ", and phi=" << lep2->phi());
      event->addPart( lep2, false );


      // Now, we have to do a HACK:
      // We first add lep2 as another particle and then remove it again.
      // This forces the underlying auxiliary branch to be created.
      event->addOtherPart( lep2 );
      event->removeOtherPart( lep2 );


      /// Add the missingET
      if (metObj) {
        ATH_MSG_VERBOSE("Adding missingET with met=" << 0.001*(metObj->met()) << " GeV and phi=" << metObj->phi() );
        event->setMissingET( metObj, false );
      }


      /// Add the jets
      if (jetCont) {
        ATH_MSG_DEBUG("Going to add " << jetCont->size() << " jets");
        for ( const xAOD::IParticle* jet : *jetCont ){
          ATH_MSG_VERBOSE("Adding jet with pt=" << 0.001*(jet->pt()) << " GeV, eta=" << jet->eta() << ", and phi=" << jet->phi());
          event->addPart( jet, false );
        }
      }


      /// Add the other electrons
      if (otherElCont) {
        ATH_MSG_DEBUG("Going to try to add up to " << otherElCont->size() << " other electrons");
        for ( const xAOD::IParticle* part : *otherElCont ){
          if ( this->isEqual(part,lep1) || this->isEqual(part,lep2) ){
            ATH_MSG_VERBOSE("Got already the other electron with pt=" << 0.001*(part->pt())
                            << " GeV, eta=" << part->eta() << ", and phi=" << part->phi() << " as a nominal electron in this event... continue");
            continue;
          }
          ATH_MSG_VERBOSE("Adding other electron with pt=" << 0.001*(part->pt()) << " GeV, eta=" << part->eta() << ", and phi=" << part->phi());
          event->addOtherPart( part );
        }
      }


      /// Add the other muons
      if (otherMuCont) {
        ATH_MSG_DEBUG("Going to try to add up to " << otherMuCont->size() << " other muons");
        for ( const xAOD::IParticle* part : *otherMuCont ){
          if ( this->isEqual(part,lep1) || this->isEqual(part,lep2) ){
            ATH_MSG_VERBOSE("Got already the other muon with pt=" << 0.001*(part->pt())
                            << " GeV, eta=" << part->eta() << ", and phi=" << part->phi() << " as a nominal muon in this event... continue");
            continue;
          }
          ATH_MSG_VERBOSE("Adding other muon with pt=" << 0.001*(part->pt()) << " GeV, eta=" << part->eta() << ", and phi=" << part->phi());
          event->addOtherPart( part );
        }
      }


      /// Add the other jets
      if (otherJetCont) {
        ATH_MSG_DEBUG("Going to try to add up to " << otherJetCont->size() << " other jets");
        const xAOD::IParticleLinkContainer& eventPartLinks = event->partLinks();
        for ( const xAOD::IParticle* jet : *otherJetCont ){
          // We have to test by hand if the jet already exists since
          // xAOD::CompositeParticle::contains does only a pointer comparisson.
          bool haveJet = false;
          for ( const xAOD::IParticleLink& evtPartLink : eventPartLinks ){
            if ( !(evtPartLink.isValid()) ) {
              ATH_MSG_FATAL("Got an invalid element link");
              return StatusCode::FAILURE;
            }
            const xAOD::IParticle* evtPart = *evtPartLink;
            if ( this->isEqual(jet,evtPart) ){
              ATH_MSG_VERBOSE("Got already the other jet with pt=" << 0.001*(jet->pt())
                              << " GeV, eta=" << jet->eta() << ", and phi=" << jet->phi() << " as a nominal jet in this event... continue");
              haveJet = true;
              break;
            }
          }
          if (!haveJet) {
            ATH_MSG_VERBOSE("Adding other jet with pt=" << 0.001*(jet->pt()) << " GeV, eta=" << jet->eta() << ", and phi=" << jet->phi());
            event->addOtherPart( jet );
          }
        }
      }


    } //end second electron
  } //end first electron

  return StatusCode::SUCCESS;
}



bool HWW::FullEventBuilderAlg::isEqual( const xAOD::IParticle* partA, const xAOD::IParticle* partB ) const
{
  // Let's first try simple pointer comparisson
  if ( partA == partB ) return true;
  // Let's now go on to check the properties
  if ( partA->type() != partB->type() ) return false;
  if ( !(CxxUtils::fpcompare::equal(partA->pt(),partB->pt())) ) return false;
  if ( !(CxxUtils::fpcompare::equal(partA->eta(),partB->eta())) ) return false;
  if ( !(CxxUtils::fpcompare::equal(partA->phi(),partB->phi())) ) return false;
  return true;
}
