///////////////////////// -*- C++ -*- /////////////////////////////
// HWWFatJetDecorationAlg.cxx
// Implementation file for class HWWFatJetDecorationAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWFatJetDecorationAlg.h"

// STL includes
#include <climits>
#include <cmath>

// FrameWork includes
#include "GaudiKernel/SystemOfUnits.h"

// EDM includes
#include "xAODJet/JetContainer.h"

// Tool includes
#include "BoostedJetTaggers/SmoothedWZTagger.h"



// Getting the GeV and such units
using namespace Gaudi::Units;


// Constructors
////////////////
HWW::FatJetDecorationAlg::FatJetDecorationAlg( const std::string& name,
                                               ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_wTagger(nullptr),
  m_zTagger(nullptr),
  m_inContName(""),
  m_vTaggerWP("medium"),
  m_vTaggerAlg("smooth"),
  m_wTaggerConfig(""),
  m_zTaggerConfig(""),
  m_decoAllCopies(false),
  m_containerNameList()
{
  //
  // Property declaration
  //
  declareProperty( "InputContainer",          m_inContName,    "Input container name" );
  declareProperty( "BosonTaggerWorkingPoint", m_vTaggerWP,     "The working point of the boson taggers" );
  declareProperty( "BosonTaggerAlgorithm",    m_vTaggerAlg,    "The algorithm of the boson taggers" );
  declareProperty( "WBosonTaggerConfig",      m_wTaggerConfig, "The config file of the W-boson taggers" );
  declareProperty( "ZBosonTaggerConfig",      m_zTaggerConfig, "The config file of the Z-boson taggers" );
  declareProperty( "DecorateAllCopies",       m_decoAllCopies, "If true, will decorate all copies of the input container" );
}



// Destructor
///////////////
HWW::FatJetDecorationAlg::~FatJetDecorationAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::FatJetDecorationAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inContName );
  ATH_MSG_DEBUG( "Using: " << m_vTaggerWP );
  ATH_MSG_DEBUG( "Using: " << m_vTaggerAlg );
  ATH_MSG_DEBUG( "Using: " << m_wTaggerConfig );
  ATH_MSG_DEBUG( "Using: " << m_zTaggerConfig );
  ATH_MSG_DEBUG( "Using DecorateAllCopies: " << m_decoAllCopies );

  // Configure the W/Z taggers
  m_wTagger = new SmoothedWZTagger( name() );
		  //"medium", "smooth", m_wTaggerConfig.value(), false, false);
  m_zTagger = new SmoothedWZTagger( name() );
		  //m_vTaggerWP.value(), m_vTaggerAlg.value(), m_zTaggerConfig.value(), false, false );

  return StatusCode::SUCCESS;
}



StatusCode HWW::FatJetDecorationAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Clean up
  if (m_wTagger) delete m_wTagger;
  if (m_zTagger) delete m_zTagger;

  return StatusCode::SUCCESS;
}



StatusCode HWW::FatJetDecorationAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Create the needed decorators
  static SG::AuxElement::Decorator<char> isWJetDeco("isWJet");
  static SG::AuxElement::Decorator<char> passWMassCutDeco("passWMassCut");
  static SG::AuxElement::Decorator<char> passWSubstructureDeco("passWSubstructure");
  static SG::AuxElement::Decorator<char> isZJetDeco("isZJet");
  static SG::AuxElement::Decorator<char> passZMassCutDeco("passZMassCut");
  static SG::AuxElement::Decorator<char> passZSubstructureDeco("passZSubstructure");
  static SG::AuxElement::Decorator<float> d2Deco("D2");


  // Now, let's try to get all requested muon containers and iterate over them.
  // If not specifically requested to get all copies, only the exactly given
  // name will be retrieved. Otherwise, all containers with the same base-name,
  // i.e, the part before the "___", if present, will be used.
  // Do this expensice string manupulation and StoreGate search only the first time.
  if (m_containerNameList.empty()){
    if (m_decoAllCopies){
      const std::string& inContName = m_inContName.value();
      // First, remove the suffix that is separated by "___", if present
      std::string searchString = inContName;
      std::string::size_type pos = inContName.find("___");
      if(inContName.npos != pos){ searchString = inContName.substr(0, pos); }
      // Now, get all the StoreGate names of existing MuonContainers
      std::vector<std::string> sgKeys;
      evtStore()->keys<xAOD::JetContainer>(sgKeys);
      ATH_MSG_DEBUG("Found " << sgKeys.size() << " xAOD::JetContainers in the event store.");
      m_containerNameList.reserve(sgKeys.size());
      // Now, let's find all container names that start with our searchString
      for ( const std::string& item : sgKeys ){
        if ( item.compare(0, searchString.length(), searchString) == 0 ){
          // We found a match, i.e, the current StoreGate key begins with our searchString
          ATH_MSG_DEBUG("Found matching xAOD::JetContainer name: " << item);
          m_containerNameList.push_back(item);
        }
      }
    }
    else{
      m_containerNameList.push_back(m_inContName.value());
    }
  }

  // Now, iterate over all input container names that were found and use these muon containers.
  for ( const std::string& inName : m_containerNameList ){

    // Open the input containers
    const xAOD::JetContainer *inCont(0);
    ATH_CHECK( evtStore()->retrieve(inCont, inName) );

    // Loop over all jets and calculate the needed variables
    for ( const xAOD::Jet* jet : *inCont ){
      ATH_MSG_VERBOSE("Now on jet number=" << jet->index() << ", pt=" << (jet->pt())*0.001
                      << " GeV, eta=" << jet->eta() << ", mass=" << (jet->m())*0.001 << " GeV" );

      // Do the W-boson tagging
      const int wResult = m_wTagger->tag(*jet);

      const bool isWJet = (wResult == 3);
      ATH_MSG_VERBOSE("Decorating jet with isWJet=" << isWJet);
      isWJetDeco(*jet) = static_cast<char>(isWJet);

      const bool passWMassCut = ( (wResult >> 1) == 1 );
      ATH_MSG_VERBOSE("Decorating jet with passWMassCut=" << passWMassCut);
      passWMassCutDeco(*jet) = static_cast<char>(passWMassCut);

      const bool passWSubstructure = (wResult & 0x1);
      ATH_MSG_VERBOSE("Decorating jet with passWSubstructure=" << passWSubstructure);
      passWSubstructureDeco(*jet) = static_cast<char>(passWSubstructure);


      // Do the Z-boson tagging
      const int zResult = m_zTagger->tag(*jet);

      const bool isZJet = (zResult == 3);
      ATH_MSG_VERBOSE("Decorating jet with isZJet=" << isZJet);
      isZJetDeco(*jet) = static_cast<char>(isZJet);

      const bool passZMassCut = ( (zResult >> 1) == 1 );
      ATH_MSG_VERBOSE("Decorating jet with passZMassCut=" << passZMassCut);
      passZMassCutDeco(*jet) = static_cast<char>(passZMassCut);

      const bool passZSubstructure = (zResult & 0x1);
      ATH_MSG_VERBOSE("Decorating jet with passWSubstructure=" << passZSubstructure);
      passZSubstructureDeco(*jet) = static_cast<char>(passZSubstructure);


      // Calculate the D2 variable
      const float ecf1 = jet->getAttribute<float>("ECF1");
      const float ecf2 = jet->getAttribute<float>("ECF2");
      const float ecf3 = jet->getAttribute<float>("ECF3");
      float d2 = 0.0;
      if ( std::abs(ecf2) > 0.0 ){
        d2 = ecf3 * std::pow(ecf1, 3) / std::pow(ecf2, 3);
      }
      d2Deco(*jet) = d2;

    } // End: loop over jets

  } // End: loop over all possible input container names

  return StatusCode::SUCCESS;
}
