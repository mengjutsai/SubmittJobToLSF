

#submitBatchJobs.py  --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/fileListsToProcess/group.phys-higgs.data15_13TeV.HWW_VeryLooseLH.merge.PAOD_2L.V17b_FakeZJets_PAOD_2LFake              ${1} ${2} ${3} ${4} ${5} ${6}
#submitBatchJobs.py  --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/fileListsToProcess/group.phys-higgs.data16_13TeV.HWW_VeryLooseLH.merge.PAOD_2L.V17b_FakeZJets_PAOD_2LFake              ${1} ${2} ${3} ${4} ${5} ${6}
#submitBatchJobs.py  --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/fileListsToProcess/group.phys-higgs.mc15_13TeV.HWW_VeryLooseLH_AlpgenDYBkg.merge.PAOD_2L.V17b_FakeZJets_PAOD_2LFake    ${1} ${2} ${3} ${4} ${5} ${6}
#submitBatchJobs.py  --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/fileListsToProcess/group.phys-higgs.mc15_13TeV.HWW_VeryLooseLH_CommonOtherBkg.merge.PAOD_2L.V17b_FakeZJets_PAOD_2LFake ${1} ${2} ${3} ${4} ${5} ${6}
#submitBatchJobs.py  --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/fileListsToProcess/group.phys-higgs.mc15_13TeV.HWW_VeryLooseLH_HWWSignal.merge.PAOD_2L.V17b_FakeZJets_PAOD_2LFake      ${1} ${2} ${3} ${4} ${5} ${6}
#submitBatchJobs.py  --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/fileListsToProcess/group.phys-higgs.mc15_13TeV.HWW_VeryLooseLH_MadGraphDYBkg.merge.PAOD_2L.V17b_FakeZJets_PAOD_2LFake  ${1} ${2} ${3} ${4} ${5} ${6}
#submitBatchJobs.py  --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/fileListsToProcess/group.phys-higgs.mc15_13TeV.HWW_VeryLooseLH_PowhegDYBkg.merge.PAOD_2L.V17b_FakeZJets_PAOD_2LFake    ${1} ${2} ${3} ${4} ${5} ${6}
#submitBatchJobs.py  --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/fileListsToProcess/group.phys-higgs.mc15_13TeV.HWW_VeryLooseLH_SherpaDYBkg.merge.PAOD_2L.V17b_FakeZJets_PAOD_2LFake    ${1} ${2} ${3} ${4} ${5} ${6}
#submitBatchJobs.py  --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/fileListsToProcess/group.phys-higgs.mc15_13TeV.HWW_VeryLooseLH_TopBkg.merge.PAOD_2L.V17b_FakeZJets_PAOD_2LFake         ${1} ${2} ${3} ${4} ${5} ${6}

#submitBatchJobs.py --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/FakeDiJets_VeryLooseLH/fileListsToProcess/group.phys-higgs.data15_13TeV.HWW_VeryLooseLH.merge.PAOD.V17b_FakeDiJets_PAOD_FakeL  ${1} ${2} ${3} ${4} ${5} ${6}
#submitBatchJobs.py --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/FakeDiJets_VeryLooseLH/fileListsToProcess/group.phys-higgs.data16_13TeV.HWW_VeryLooseLH_PeriodAtoF.merge.PAOD.V17b_FakeDiJets_PAOD_FakeL  ${1} ${2} ${3} ${4} ${5} ${6}
#submitBatchJobs.py --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/FakeDiJets_VeryLooseLH/fileListsToProcess/group.phys-higgs.data16_13TeV.HWW_VeryLooseLH_PeriodGtoL.merge.PAOD.V17b_FakeDiJets_PAOD_FakeL  ${1} ${2} ${3} ${4} ${5} ${6}
submitBatchJobs.py --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V17b/FakeDiJets_VeryLooseLH/fileListsToProcess/group.phys-higgs.mc15_13TeV.HWW_VeryLooseLH.merge.PAOD.V17b_FakeDiJets_PAOD_FakeL  ${1} ${2} ${3} ${4} ${5} ${6}

#submitBatchJobs.py --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V16/fileListsToProcess/group.phys-higgs.data16_13TeV.HWW.merge.PAOD.V16_FakeDiJets_PAOD_FakeL
#submitBatchJobs.py --inDir /nfs/dust/atlas/user/kkoeneke/DataMC/PxAOD/V16/fileListsToProcess/group.phys-higgs.mc15_13TeV.HWW.merge.PAOD.V16_FakeDiJets_PAOD_FakeL
