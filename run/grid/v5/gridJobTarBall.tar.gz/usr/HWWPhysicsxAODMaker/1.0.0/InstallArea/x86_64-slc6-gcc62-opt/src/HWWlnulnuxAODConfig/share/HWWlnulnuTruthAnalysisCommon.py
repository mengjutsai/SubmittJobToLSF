# ====================================================================
# block that this file is included twice
# ====================================================================
include.block("HWWlnulnuxAODConfig/HWWlnulnuTruthAnalysisCommon.py")

# Import the module that allows to use named units, e.g. GeV
from AthenaCommon.SystemOfUnits import *

# Import the steering flags for the common analysis
from PhysicsxAODConfig.HWWTruthCommonAnalysisFlags import hWWCommon

# Import the steering flags for this analysis
from HWWlnulnuxAODConfig.HWWlnulnuTruthAnalysisFlags import hWWlnulnu

# for messaging
from AthenaCommon.Logging import logging
hWWlnulnu_msg = logging.getLogger( 'HWWlnulnuAnalysis' )
hWWlnulnu_msg.setLevel(hWWlnulnu.Global.logLevel)


# ====================================================================
# Include the common configuration
# Note that this will only be included if it was NOT included before
# due to the include.block(...) statement in that file.
# ====================================================================
include("PhysicsxAODConfig/HWWTruthAnalysisCommon.py")



# ====================================================================
# Do the final event candidate building
# ====================================================================
include("HWWlnulnuxAODConfig/HWWlnulnuTruthEventCandidateBuilding.py")




# ====================================================================
# Here, we create our output mini-xAOD file and configure what should go into it
# ====================================================================
if hWWlnulnu.Global.writeMinixAOD:
    # Create a new mini-xAOD output stream object
    from OutputStreamAthenaPool.MultipleStreamManager import MSMgr
    HWWlnulnuOutStream = MSMgr.NewPoolRootStream( hWWlnulnu.Global.StreamName, hWWlnulnu.Global.FileName )

    # Filter the events
    # All events that are accepted by any algorithm in the AcceptAlgs list will be written out
    if hWWlnulnu.Global.doSkimming :
        hWWlnulnu_msg.info( "Applying an event selection based on these accept algorithms: %s" % hWWlnulnu.Global.acceptAlgList )
        HWWlnulnuOutStream.AcceptAlgs( hWWlnulnu.Global.acceptAlgList )
        pass
    # We always filter based on the listed require algs. These are, e.g.,
    # the GRL filter, trigger fitler, vertex filter,...
    hWWlnulnu_msg.info( "Applying an event selection based on these requite algorithms: %s" % hWWCommon.Global.requireAlgList )
    HWWlnulnuOutStream.RequireAlgs( hWWCommon.Global.requireAlgList )

    # Use our common container item list to define the per-event content of the mini-xAOD
    from HWWlnulnuxAODConfig.HWWlnulnuTruthPAODContent import pAODContent, pAODMetaDataContent
    HWWlnulnuOutStream.AddItem( pAODContent() )
    HWWlnulnuOutStream.AddMetaDataItem( pAODMetaDataContent() )


    # Print the final item list to the log file
    if hWWlnulnu_msg.isEnabledFor(hWWlnulnu_msg.mapLevelGaudiToLogging(DEBUG)):
        hWWlnulnu_msg.debug( "OutputStream info:")
        HWWlnulnuOutStream.Print()
        pass
    pass



# ====================================================================
# Here, we create our output mini-xAOD file and configure what should go into it.
# This one will only contain events with at least one valid different-flavor candidate.
# ====================================================================
if hWWlnulnu.Global.writeDifferentFlavorPxAOD:
    # Create a new mini-xAOD output stream object
    from OutputStreamAthenaPool.MultipleStreamManager import MSMgr
    HWWlnulnuDFOutStream = MSMgr.NewPoolRootStream( hWWlnulnu.Global.DFStreamName, hWWlnulnu.Global.DFFileName )

    # Filter the events
    # All events that are accepted by any algorithm in the AcceptAlgs list will be written out
    if hWWlnulnu.Global.doSkimming :
        dfAcceptAlgList = []
        for algName in hWWlnulnu.Global.acceptAlgList:
            if algName.__contains__("HWWElElFullEventExistsAlg") or algName.__contains__("HWWMuMuFullEventExistsAlg"): continue
            dfAcceptAlgList.append(algName)
            pass
        hWWlnulnu_msg.info( "Applying an event selection based on these accept algorithms: %s" % dfAcceptAlgList )
        HWWlnulnuDFOutStream.AcceptAlgs( dfAcceptAlgList )
        pass
    # We always filter based on the listed require algs. These are, e.g.,
    # the GRL filter, trigger fitler, vertex filter,...
    hWWlnulnu_msg.info( "Applying an event selection based on these requite algorithms: %s" % hWWCommon.Global.requireAlgList )
    HWWlnulnuDFOutStream.RequireAlgs( hWWCommon.Global.requireAlgList )

    # Use our common container item list to define the per-event content of the mini-xAOD
    from HWWlnulnuxAODConfig.HWWlnulnuTruthPAODContent import pAODContent, pAODMetaDataContent
    HWWlnulnuDFOutStream.AddItem( pAODContent() )
    HWWlnulnuDFOutStream.AddMetaDataItem( pAODMetaDataContent() )


    # Print the final item list to the log file
    if hWWlnulnu_msg.isEnabledFor(hWWlnulnu_msg.mapLevelGaudiToLogging(DEBUG)):
        hWWlnulnu_msg.debug( "OutputStream info:")
        HWWlnulnuDFOutStream.Print()
        pass
    pass
