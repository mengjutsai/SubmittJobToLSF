///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMuonTriggerEfficiencyScaleFactorAlg.h
// Header file for class HWW::MuonTriggerEfficiencyScaleFactorAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWMUONTRIGGEREFFICIENCYSCALEFACTORALG_H
#define HWWCOMMONANALYSISUTILS_HWWMUONTRIGGEREFFICIENCYSCALEFACTORALG_H 1

// STL includes
#include <vector>
#include <string>
#include <utility>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"
#include "PATInterfaces/SystematicSet.h"

#include "PhysicsxAODCode/IHWWContainersFinderTool.h"

// forward declarations
namespace CP{
  class IMuonTriggerScaleFactors;
}


// Put everything into a HWW namespace
namespace HWW {

  class MuonTriggerEfficiencyScaleFactorAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
   public:

    // Copy constructor:

    /// Constructor with parameters:
    MuonTriggerEfficiencyScaleFactorAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~MuonTriggerEfficiencyScaleFactorAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
   private:

    /// Default constructor:
    // MuonScaleFactorAlg();

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input container name
    StringProperty m_inCont;

    /// The tool that tries to find all input containers, including their systematic variations
    ToolHandle<HWW::IContainersFinderTool> m_contFindTool;

    /// Decorate all copies of the input container
    bool m_decoAllCopies;

    /// The string separator between the output container name and the sytematic variation (default="___")
    StringProperty m_separator;

    /// The ToolHandleArray for the muon efficiency scale factor tools for 2015
    ToolHandleArray<CP::IMuonTriggerScaleFactors> m_muEffiSFTool2015List;

    /// The ToolHandleArray for the muon efficiency scale factor tools for 2016
    ToolHandleArray<CP::IMuonTriggerScaleFactors> m_muEffiSFTool2016List;

    /// The list of names of the efficiency scale-factor variable that will be added to the muon" );
    StringArrayProperty m_muEffSFVarNameList;

    /// The names of all systematic variations to be applied
    StringArrayProperty m_muEffSFSysNames;

    /// The list of names of the efficiency variables that will be added to the muon" );
    StringArrayProperty m_muEffVarNameList;

    /// The names of the 2015 triggers to be used
    StringArrayProperty m_muTrigName2015List;

    /// The names of the 2016 triggers to be used
    StringArrayProperty m_muTrigName2016List;

    /// Set to true, if we want the data efficiency (default: false)
    bool m_useDataEffi;

    /// @}

  private:

    /// @name Truly private internal data members
    /// @{

    /// Vector of all input container names to consider and what type of systematics they contain (filled automatically)
    HWW::ContNameAndSysTypeVec_t m_inContNameAndSysTypeList;

    /// The vector of all efficiency scale factor systematics and the corresponding variable names
    // std::vector< std::pair< CP::SystematicSet, std::vector< std::vector< std::pair<std::string, std::string> > > > > m_effiSystVarNameVec;

    /// The vector of all efficiency scale factor systematics and the corresponding variable names (scale-factor,efficiency)
    std::vector< std::vector< std::pair< CP::SystematicSet, std::pair<std::string, std::string> > > > m_effiSystVarNameVec;

    /// @}

  };

} // End: HWW namespace


///////////////////////////////////////////////////////////////////
// Inline methods:
///////////////////////////////////////////////////////////////////


#endif //> !HWWCOMMONANALYSISUTILS_HWWMUONTRIGGEREFFICIENCYSCALEFACTORALG_H
