///////////////////////// -*- C++ -*- /////////////////////////////
// HWWBtagScaleFactorAlg.h
// Header file for class HWW::BtagScaleFactorAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWBTAGSCALEFACTORALG_H
#define HWWCOMMONANALYSISUTILS_HWWBTAGSCALEFACTORALG_H 1

// STL includes
#include <vector>
#include <string>
#include <utility>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"
#include "PATInterfaces/SystematicSet.h"

#include "PhysicsxAODCode/IHWWContainersFinderTool.h"

// forward declarations
//namespace CP{
//  class IBTaggingEfficiencyTool;
//}

class IBTaggingEfficiencyTool;

// Put everything into a HWW namespace
namespace HWW {

  class BtagScaleFactorAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
   public:

    // Copy constructor:

    /// Constructor with parameters:
    BtagScaleFactorAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~BtagScaleFactorAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();


    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
   private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input container name
    StringProperty m_inCont;

    /// The tool that tries to find all input containers, including their systematic variations
    ToolHandle<HWW::IContainersFinderTool> m_contFindTool;

    /// Decorate all copies of the input container
    bool m_decoAllCopies;

    // /// The suffixes (without the '___') of the shallow copy containers where the pt was modified
    // std::vector<std::string> m_inContSuffixes;

    /// The string separator between the output container name and the sytematic variation (default="___")
    StringProperty m_separator;

    /// The name of the tagger that we want to use (default='MV2c20')
    StringProperty m_taggerName;

    /// The cut value on the b-tagging discriminant
    DoubleProperty m_taggerCut;

    /// The ToolHandle for the muon efficiency scale factor tool
    ToolHandle<IBTaggingEfficiencyTool> m_btagEffiSFTool;

    /// The names of all systematic variations to be applied
    StringArrayProperty m_btagEffSFSysNames;

    /// The name of the efficiency scale-factor variable that will be added to the jet
    StringProperty m_btagEffSFVarName;

    /// The cut value on the minimum jet pt
    DoubleProperty m_minJetPt;

    /// Abort on an unchecked CP::CorrectionCode
    bool m_abortOnUncheckedCorrCode;

    /// @}

  private:

    /// @name Truly private internal data members
    /// @{

    // /// Vector of all input container names
    // std::vector<std::string> m_inContNameList;

    /// Vector of all input container names to consider and what type of systematics they contain (filled automatically)
    HWW::ContNameAndSysTypeVec_t m_inContNameAndSysTypeList;

    /// The vector of all efficiency scale factor systematics and the corresponding variable names
    std::vector< std::pair< CP::SystematicSet, std::string > > m_effiSystVarNameVec;

    /// @}

  };

} // End: HWW namespace


///////////////////////////////////////////////////////////////////
// Inline methods:
///////////////////////////////////////////////////////////////////


#endif //> !HWWCOMMONANALYSISUTILS_HWWBTAGSCALEFACTORALG_H
