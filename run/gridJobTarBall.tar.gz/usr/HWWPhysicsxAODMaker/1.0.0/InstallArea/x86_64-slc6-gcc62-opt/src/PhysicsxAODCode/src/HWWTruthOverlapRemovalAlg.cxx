//  includes
#include "HWWTruthOverlapRemovalAlg.h"

// Tool includes
//#include "AssociationUtils/IOverlapRemovalTool.h"
#include "CxxUtils/make_unique.h"
#include "AssociationUtils/IOverlapTool.h"
//#include "AssociationUtils/OverlapDecorationHelper.h"

// EDM includes
#include "xAODEgamma/ElectronContainer.h"
#include "xAODMuon/MuonContainer.h"
#include "xAODJet/Jet.h"
#include "xAODJet/JetContainer.h"
#include "xAODJet/JetAuxContainer.h"
#include "xAODTruth/TruthEventContainer.h"
#include "xAODTruth/TruthParticleContainer.h"
#include "xAODTruth/TruthParticleAuxContainer.h"

#include "AssociationUtils/MacroChecks.h"

#include "FourMomUtils/xAODP4Helpers.h"

HWW::TruthOverlapRemovalAlg::TruthOverlapRemovalAlg( const std::string& name, ISvcLocator* pSvcLocator ):
  AthAlgorithm( name, pSvcLocator ),
  //m_OverlapRemovalTool("IOverlapRemovalTool", this),
  //m_eleMuORT("IOverlapTool", this), m_eleJetORT("IOverlapTool", this), m_muJetORT("IOverlapTool", this),
  m_inElCont(""),
  m_inMuCont(""),
  m_inJetCont(""),
  m_outElCont(""),
  m_outMuCont(""),
  m_outJetCont("")
{
  //declareProperty("OverlapRemovalTool", m_OverlapRemovalTool,
  //                "The OverlapRemovalTool" );
  //declareProperty("EleMuORT", m_eleMuORT, "Electron-muon overlap tool");
  //declareProperty("EleJetORT", m_eleJetORT, "Electron-jet overlap tool");
  //declareProperty("MuJetORT", m_muJetORT, "Muon-jet overlap tool");

  declareProperty("SelectedElectrons", m_inElCont,
                  "The name of the input selected electrons container" );

  declareProperty("SelectedMuons", m_inMuCont,
                  "The name of the input selected muons container" );

  declareProperty("SelectedJets", m_inJetCont,
                  "The name of the input selected jets container" );

  declareProperty("ORElectrons", m_outElCont,
                  "The name of the output OR electrons container" );

  declareProperty("ORMuons", m_outMuCont,
                  "The name of the output OR muons container" );

  declareProperty("ORJets", m_outJetCont,
                  "The name of the output OR jets container" );

  // Input/output labels for reset functionality.
  declareProperty("InputLabel", m_inputLabel = "selected"
                  "Decoration which specifies input objects");
  declareProperty("OutputLabel", m_outputLabel = "overlaps",
                  "Decoration given to objects that fail OR");
  declareProperty("OutputPassValue", m_outputPassValue = false,
                  "Set the result assigned to objects that pass");
  declareProperty("RequireExpectedPointers", m_requireExpectedPointers = true,
                  "Require non-null container pointers when expected by config");
}



HWW::TruthOverlapRemovalAlg::~TruthOverlapRemovalAlg() {}



StatusCode HWW::TruthOverlapRemovalAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  //ATH_MSG_DEBUG( "Using: " << m_TruthOverlapRemovalTool );
  ATH_MSG_DEBUG( "Using: " << m_inElCont );
  ATH_MSG_DEBUG( "Using: " << m_inMuCont );
  ATH_MSG_DEBUG( "Using: " << m_inJetCont );
  ATH_MSG_DEBUG( "Using: " << m_outElCont );
  ATH_MSG_DEBUG( "Using: " << m_outMuCont );
  ATH_MSG_DEBUG( "Using: " << m_outJetCont );

  // Initialize the decoration helper
    m_decHelper = CxxUtils::make_unique<ORUtils::OverlapDecorationHelper>(m_inputLabel, m_outputLabel, m_outputPassValue); 

  // Retrieve the configured tools
  //if(!m_eleMuORT.empty())  ATH_CHECK( m_eleMuORT.retrieve() );
  //if(!m_eleJetORT.empty()) ATH_CHECK( m_eleJetORT.retrieve() );
  //if(!m_muJetORT.empty())  ATH_CHECK( m_muJetORT.retrieve() );
  // Retrieve the TrigDecisionTool
  //ATH_CHECK(m_TruthOverlapRemovalTool.retrieve());

  return StatusCode::SUCCESS;
}



StatusCode HWW::TruthOverlapRemovalAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release all tools
  //ATH_CHECK( m_OverlapRemovalTool.release() );
  //ATH_CHECK( m_eleMuORT.release() );
  //ATH_CHECK( m_eleJetORT.release() );
  //ATH_CHECK( m_muJetORT.release() );

  return StatusCode::SUCCESS;
}


  //---------------------------------------------------------------------------
  // Perform overlap removal with one tool
  //---------------------------------------------------------------------------
bool HWW::TruthOverlapRemovalAlg::checkOverlap(const xAOD::IParticle* part, const xAOD::IParticleContainer* cont, double DRmax, double DRmin = 0.0) {
  if (!part) return false;
  ATH_MSG_DEBUG( "--> Particle to check: " << part->pt()
         << " , " << part->eta()
         << " , " << part->phi());
  for(const xAOD::IParticle* otherpart : *cont){
    const double pt = otherpart->pt();
    ATH_MSG_DEBUG( "--> Particle to compare: " << otherpart->pt()
         << " , " << otherpart->eta()
         << " , " << otherpart->phi());
    if (pt > 15000.0) {
      if (DRmin==0.0) {
        if ( xAOD::P4Helpers::isInDeltaR(*part, *otherpart, DRmax)){  
          ATH_MSG_DEBUG( "--> Particles overlap: " << DRmax);
          return true;
        }
      } else {
        if ( xAOD::P4Helpers::isInDeltaR(*part, *otherpart, DRmax) && !(xAOD::P4Helpers::isInDeltaR(*part, *otherpart, DRmin))) {
          ATH_MSG_DEBUG( "--> Particles overlap: " << DRmax << " but outside " << DRmin);
          return true;
        }
      }
    }
  }
  return false;
}

/*StatusCode HWW::TruthOverlapRemovalAlg::
removeOverlap(const ToolHandle<IOverlapTool>& tool,
              const xAOD::IParticleContainer* cont1,
              const xAOD::IParticleContainer* cont2) const
{
  if(!tool.empty()) {
    if(cont1 && cont2) {
      ATH_CHECK( tool->findOverlaps(*cont1, *cont2) );
    }
    else if(!cont1 && m_requireExpectedPointers) {
      ATH_MSG_ERROR("First container pointer for " << tool.name() << " is NULL!");
      return StatusCode::FAILURE;
    }
    else if(!cont2 && m_requireExpectedPointers) {
      ATH_MSG_ERROR("Second container pointer for " << tool.name() << " is NULL!");
      return StatusCode::FAILURE;
    }
  }
  return StatusCode::SUCCESS;
}*/



StatusCode HWW::TruthOverlapRemovalAlg::execute()
{
  // Get input containers (should be view containers of selected electrons, muons, and jets)
  const xAOD::TruthParticleContainer* electrons = nullptr;
  if (!(m_inElCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( electrons, m_inElCont.value() ) );}
  const xAOD::TruthParticleContainer* muons = nullptr;
  if (!(m_inMuCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( muons, m_inMuCont.value() ) );}
  const xAOD::JetContainer* jets = nullptr;
  if (!(m_inJetCont.value().empty())){ ATH_CHECK( evtStore()->retrieve( jets, m_inJetCont.value() ) );}
  else {
    // we need to create an empty dummy jet container since it is required by the tool
    jets = new xAOD::JetContainer( SG::VIEW_ELEMENTS );
  }

  // Reset all decorations to passing
  //if(electrons) m_decHelper->resetDecorations(*electrons);
  //if(muons)     m_decHelper->resetDecorations(*muons);
  //if(jets)      m_decHelper->resetDecorations(*jets);

  // Electron-muon OR
  /*if(electrons && muons) {
    ATH_CHECK( m_eleMuORT->findOverlaps(*electrons, *muons) );
  }
  else if(!electrons && m_requireExpectedPointers) {
    ATH_MSG_ERROR("First container pointer for " << m_eleMuORT.name() << " is NULL!");
    return StatusCode::FAILURE;
  }
  else if(!muons && m_requireExpectedPointers) {
    ATH_MSG_ERROR("Second container pointer for " << m_eleMuORT.name() << " is NULL!");
    return StatusCode::FAILURE;
  }*/
  //ATH_CHECK( removeOverlap(m_eleMuORT, electrons, muons) );
  // Electron-jet OR
  //ATH_CHECK( removeOverlap(m_eleJetORT, electrons, jets) );
  // Muon-jet OR
  //ATH_CHECK( removeOverlap(m_muJetORT, muons, jets) );
  // Apply OverlapRemovalTool, which decorates the respective objects with an "overlaps" tag, which is false if they pass OR and true if they fail
  //ATH_CHECK( m_OverlapRemovalTool->removeOverlaps(electrons, muons, jets, NULL, NULL, NULL, NULL) );

  // Clean up temporary containers
  if (m_inJetCont.value().empty()){
    delete jets;
    jets = nullptr;
  }

  // Create and record output containers (which are view containers)
  xAOD::TruthParticleContainer* outElCont = nullptr;
  if (electrons){
    outElCont = new xAOD::TruthParticleContainer( SG::VIEW_ELEMENTS );
    ATH_CHECK( evtStore()->record ( outElCont, m_outElCont.value() ) );
  }
  xAOD::TruthParticleContainer* outMuCont = nullptr;
  if (muons){
    outMuCont = new xAOD::TruthParticleContainer( SG::VIEW_ELEMENTS );
    ATH_CHECK( evtStore()->record ( outMuCont, m_outMuCont.value() ) );
  }
  xAOD::JetContainer* outJetCont = nullptr;
  if (jets){
    outJetCont = new xAOD::JetContainer( SG::VIEW_ELEMENTS );
    ATH_CHECK( evtStore()->record ( outJetCont, m_outJetCont.value() ) );
  }

  // Create a static accessor for getting the overlap information that the
  // overlap removal tool decorated to the objects
  static SG::AuxElement::Accessor<char> accOverlaps("overlaps");

  //ATH_MSG_DEBUG( "--> Container sizes: jets " << jets->size()<< " electrons: "<< electrons->size() << " muons " << muons->size());

  // Run over input containers and fill output containers with objects which passed the OR. At the moment the variable is a boolean, in a later tag of the OR tool it's changed to char
  if (electrons){
    for(const xAOD::TruthParticle* electron : *electrons){
      bool failedOR = false;
      if (jets) {
        if (jets->size()>0) {
          ATH_MSG_DEBUG( "--> Electron Jet Overlap removal " << jets->size());
          failedOR = checkOverlap(electron, jets, 0.4, 0.2);
        }
      }
      if(muons) {
        if (muons->size()>0) {
          ATH_MSG_DEBUG( "--> Electron Muon Overlap removal "<< muons->size());
          failedOR = checkOverlap(electron, muons, 0.1);
        }
      }
      ATH_MSG_DEBUG( "--> Overlap " << failedOR);
      
      //bool passedOR = ( static_cast<bool>(accOverlaps(*electron)) == false );
      if(!failedOR) 
        outElCont->push_back( const_cast<xAOD::TruthParticle*>(electron) );
    }
  }
  ATH_MSG_DEBUG( "--> Start muons ");
  if (muons){
    for(const xAOD::TruthParticle* muon : *muons){
      bool failedOR = false;
      if (jets) {
        if (jets->size()>0) {
          ATH_MSG_DEBUG( "--> Muon Jet Overlap removal " << jets->size());
          failedOR = checkOverlap(muon, jets, 0.4);
        }
      }
      ATH_MSG_DEBUG( "--> Overlap " << failedOR);
      //bool passedOR = ( static_cast<bool>(accOverlaps(*muon)) == false );
      //if(passedOR) 
      if(!failedOR) 
        outMuCont->push_back( const_cast<xAOD::TruthParticle*>(muon) );
    }
  }
  ATH_MSG_DEBUG( "--> Start jets ");
  if (jets){
    for(const xAOD::Jet* jet : *jets){
      //bool passedOR = ( static_cast<bool>(accOverlaps(*jet)) == false );
      //if(passedOR) 
      bool failedOR = false;
      if (electrons) {
        if (electrons->size()>0) {
          ATH_MSG_DEBUG( "--> Jet Electron Overlap removal " << jets->size());
          failedOR = checkOverlap(jet, electrons, 0.2);
        }
      }
      ATH_MSG_DEBUG( "--> Overlap " << failedOR);
      if(!failedOR) 
        outJetCont->push_back( const_cast<xAOD::Jet*>(jet) );
    }
  }
  ATH_MSG_DEBUG( "--> End jets ");

  return StatusCode::SUCCESS;
}
