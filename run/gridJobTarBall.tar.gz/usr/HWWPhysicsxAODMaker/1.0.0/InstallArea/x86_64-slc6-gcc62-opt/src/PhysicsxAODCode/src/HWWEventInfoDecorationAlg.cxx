///////////////////////// -*- C++ -*- /////////////////////////////
// HWWEventInfoDecorationAlg.cxx
// Implementation file for class HWWEventInfoDecorationAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWEventInfoDecorationAlg.h"

// STL includes

// FrameWork includes

// EDM includes
#include "xAODEventInfo/EventInfo.h"
#include "xAODTracking/VertexContainer.h"
#include "xAODTracking/Vertex.h"



// Constructors
////////////////
HWW::EventInfoDecorationAlg::EventInfoDecorationAlg( const std::string& name,
                                                     ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_inContName(""),
  m_inPrimVtxCont(""),
  m_primVtxIdxName(""),
  m_nPrimVtxName(""),
  m_nPrimVtxTwoTrkName(""),
  m_nPrimVtxThreeTrkName(""),
  m_nPrimVtxFourTrkName("")
{
  //
  // Property declaration
  //
  declareProperty( "EventInfo",                 m_inContName="EventInfo", "Input container name" );
  declareProperty( "PrimaryVertexContainer",    m_inPrimVtxCont="PrimaryVertices", "The input primary vertex container name" );
  declareProperty( "PrimVtxIdxVarName",         m_primVtxIdxName="primVtxIdx", "Variable name for the resuling variable that holds the index of the found primary vertex" );
  declareProperty( "NPrimVtxVarName",           m_nPrimVtxName="nPrimVtx", "Variable name for the resuling variable that holds the number of vertices" );
  declareProperty( "NPrimVtxTwoTrackVarName",   m_nPrimVtxTwoTrkName="nPrimVtxTwoTrk", "Variable name for the resuling variable that holds the number of vertices with two or more tracks" );
  declareProperty( "NPrimVtxThreeTrackVarName", m_nPrimVtxThreeTrkName="nPrimVtxThreeTrk", "Variable name for the resuling variable that holds the number of vertices with three or more tracks" );
  declareProperty( "NPrimVtxFourTrackVarName",  m_nPrimVtxFourTrkName="nPrimVtxFourTrk", "Variable name for the resuling variable that holds the number of vertices with four or more tracks" );
}



// Destructor
///////////////
HWW::EventInfoDecorationAlg::~EventInfoDecorationAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::EventInfoDecorationAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inContName );
  ATH_MSG_DEBUG( "Using: " << m_inPrimVtxCont );
  ATH_MSG_DEBUG( "Using: " << m_primVtxIdxName );

  return StatusCode::SUCCESS;
}



StatusCode HWW::EventInfoDecorationAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");
  return StatusCode::SUCCESS;
}



StatusCode HWW::EventInfoDecorationAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Open EventInfo container
  const xAOD::EventInfo* evtInfo = 0;
  ATH_CHECK( evtStore()->retrieve( evtInfo, m_inContName.value() ));

  // Default value
  int primVtxIdx = 1;
  unsigned int nPrimVtx = 0;
  unsigned int nPrimVtx_ge2Trk = 0;
  unsigned int nPrimVtx_ge3Trk = 0;
  unsigned int nPrimVtx_ge4Trk = 0;

  // Get the primary vertex container
  const xAOD::VertexContainer* primVtxCont(0);
  ATH_CHECK( evtStore()->retrieve( primVtxCont, m_inPrimVtxCont.value() ) );

  // Find "the" primary vertex inside this container
  // and counting the number of vertices in the event
  bool foundPrimary(false);
  for ( std::size_t i=0; i<primVtxCont->size(); ++i ) {
    const xAOD::Vertex* vtx = (*primVtxCont)[i];
    // Get THE primary vertex
    if ( !foundPrimary && vtx->vertexType() == xAOD::VxType::PriVtx ) {
      primVtxIdx = static_cast<int>(i);
      foundPrimary = true;
    }
    // Count the primary vertices
    if ( vtx->vertexType() == xAOD::VxType::PriVtx || vtx->vertexType() == xAOD::VxType::PileUp ){
      nPrimVtx += 1;
      const unsigned int nTP = vtx->nTrackParticles();
      if ( nTP >= 2 ){ nPrimVtx_ge2Trk += 1; }
      if ( nTP >= 3 ){ nPrimVtx_ge3Trk += 1; }
      if ( nTP >= 4 ){ nPrimVtx_ge4Trk += 1; }
    }
  }

  // Define the decorators
  static SG::AuxElement::Decorator<int> decPrimVtxIdx(m_primVtxIdxName.value());
  decPrimVtxIdx(*evtInfo) = primVtxIdx;
  static SG::AuxElement::Decorator<unsigned int> decNPrimVtx(m_nPrimVtxName.value());
  decNPrimVtx(*evtInfo) = nPrimVtx;
  static SG::AuxElement::Decorator<unsigned int> decNPrimVtxTwoTrk(m_nPrimVtxTwoTrkName.value());
  decNPrimVtxTwoTrk(*evtInfo) = nPrimVtx_ge2Trk;
  static SG::AuxElement::Decorator<unsigned int> decNPrimVtxThreeTrk(m_nPrimVtxThreeTrkName.value());
  decNPrimVtxThreeTrk(*evtInfo) = nPrimVtx_ge3Trk;
  static SG::AuxElement::Decorator<unsigned int> decNPrimVtxFourTrk(m_nPrimVtxFourTrkName.value());
  decNPrimVtxFourTrk(*evtInfo) = nPrimVtx_ge4Trk;

  return StatusCode::SUCCESS;
}
