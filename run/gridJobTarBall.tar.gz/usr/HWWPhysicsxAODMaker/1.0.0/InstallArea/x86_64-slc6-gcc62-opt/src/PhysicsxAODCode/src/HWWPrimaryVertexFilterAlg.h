#ifndef HWWCOMMONANALYSISUTILS_HWWPRIMARYVERTEXFILTERALG_H
#define HWWCOMMONANALYSISUTILS_HWWPRIMARYVERTEXFILTERALG_H 1

// STL includes
#include <string>

// FrameWork includes
#include "AthenaBaseComps/AthFilterAlgorithm.h"

// EDM includes

// Forward declarations


// Put everything into a HWW namespace
namespace HWW {

  class PrimaryVertexFilterAlg
    : public ::AthFilterAlgorithm
  {
    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
    public:

      /// Constructor with parameters:
      PrimaryVertexFilterAlg( const std::string& name, ISvcLocator* pSvcLocator );

      /// Destructor:
      virtual ~PrimaryVertexFilterAlg();

      /// Athena algorithm's initalize hook
      virtual StatusCode  initialize();

      /// Athena algorithm's execute hook
      virtual StatusCode  execute();

      /// Athena algorithm's finalize hook
      virtual StatusCode  finalize();


    private:

      /// @name The properties that can be defined via the python job options
      /// @{

      // The name of the primary vertex container
      StringProperty m_inContName;

      /// @}

  };

} // End HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWPRIMARYVERTEXFILTERALG_H
