///////////////////////// -*- C++ -*- /////////////////////////////
// HWWElectronCalibrationSmearingAlg.h
// Header file for class HWW::ElectronCalibrationSmearingAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWELECTRONCALIBRATIONSMEARINGALG_H
#define HWWCOMMONANALYSISUTILS_HWWELECTRONCALIBRATIONSMEARINGALG_H 1

// STL includes
#include <vector>
#include <string>
#include <utility>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"
#include "PATInterfaces/SystematicSet.h"

// forward declarations
namespace CP {
  class IEgammaCalibrationAndSmearingTool;
  class IIsolationCorrectionTool;
}



// Put everything into a HWW namespace
namespace HWW {

  class ElectronCalibrationSmearingAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
   public:

    // Copy constructor:

    /// Constructor with parameters:
    ElectronCalibrationSmearingAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~ElectronCalibrationSmearingAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
   private:

    /// Default constructor:
    // ElectronCalibrationSmearingAlg();

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input container name
    StringProperty m_inCont;

    /// The string separator between the output container name and the sytematic variation (default="___")
    StringProperty m_separator;

    /// The output container name
    StringProperty m_outCont;

    /// The names of all systematic variations to be applied
    StringArrayProperty m_elCalibSmearSysNames;

    /// The ToolHandle for the electron four-momentum correction tool
    ToolHandle<CP::IEgammaCalibrationAndSmearingTool> m_egammaCalibTool;

    /// The EGamma isolation correction tool
    ToolHandle<CP::IIsolationCorrectionTool> m_egammaIsoCorrectionTool;

    /// @}

  private:

    /// @name Truly private internal data members
    /// @{

    /// The vector of all momentum systematics and the corresponding container-name post-fixes
    std::vector< std::pair< CP::SystematicSet, std::string > > m_p4SystVarNameVec;

    /// @}


  };

} // End: HWW namespace



///////////////////////////////////////////////////////////////////
// Inline methods:
///////////////////////////////////////////////////////////////////


#endif //> !HWWCOMMONANALYSISUTILS_HWWELECTRONCALIBRATIONSMEARINGALG_H
