///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetDecorationAlg.cxx
// Implementation file for class HWWJetDecorationAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWJetDecorationAlg.h"

// STL includes
#include <climits>
#include <cmath>

// FrameWork includes
#include "GaudiKernel/SystemOfUnits.h"

// EDM includes
#include "xAODEventInfo/EventInfo.h"
#include "xAODJet/JetContainer.h"
#include "xAODBTagging/BTagging.h"
#include "xAODTruth/TruthEventContainer.h"
#include "xAODTruth/TruthParticleContainer.h"

// Tool includes
#include "JetInterface/IJetSelector.h"
#include "JetInterface/IJetUpdateJvt.h"
#include "JetInterface/IJetModifier.h"
#include "PATCore/IAsgSelectionWithVertexTool.h"

// Helper includes
#include "FourMomUtils/xAODP4Helpers.h"


// Getting the GeV and such units
using namespace Gaudi::Units;


// Constructors
////////////////
HWW::JetDecorationAlg::JetDecorationAlg( const std::string& name,
                                         ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_inContName(""),
  m_inPrimVtxCont("PrimaryVertices"),
  m_truthEventContName(""),
  m_jetSelectionToolList(),
  m_jetDecList(),
  m_selectionWithVertexToolList(),
  m_selectionWithVertexDecoList(),
  m_jvtUpdateTool("JetVertexTaggerTool/JetVertexTaggerTool"),
  m_doJvtUpdate(false),
  m_updatedJVTName("calibJvt"),
  m_fjvtTool("JetForwardJvtTool/JetForwardJvtTool"),
  m_fjvtTightTool("JetForwardJvtTool/JetForwardJvtTightTool"),
  m_doForwardJvt(false),
  m_doJvtPUTruthLabeling(true),
  m_bTagList(),
  m_inTruthContName(""),
  m_truthMatchName("hardScatterTruthMatchDeltaR"),
  m_truthJetPtName("hardScatterTruthJetPt"),
  m_truthJetPtMin(10.0*GeV),
  m_maxDeltaR(0.3)
{
  //
  // Property declaration
  //
  declareProperty( "InputContainer",                  m_inContName, "Input container name" );
  declareProperty( "PrimaryVertexContainer",          m_inPrimVtxCont, "The input primary vertex container name" );
  declareProperty( "TruthEventContainer",             m_truthEventContName, "The input TruthEventContainer name" );

  declareProperty( "JetSelectionToolList",            m_jetSelectionToolList, "List of JetCleaningTool instances" );
  declareProperty( "JetDecorationList",               m_jetDecList, "List of jet decoration names" );
  declareProperty( "SelectionWithVertexToolList",     m_selectionWithVertexToolList, "List of selection-with-vertex tool instances" );
  declareProperty( "SelectionWithVertexToolDecoList", m_selectionWithVertexDecoList, "List of decoration names for each selection-with-vertex tools" );
  declareProperty( "JVTUpdateTool",                   m_jvtUpdateTool,
                   "The CP tool to correct the JVT variable for calibrated jets. No need to set one in the job option as the default instance is OK." );
  declareProperty( "UpdateJVT",                       m_doJvtUpdate, "Declare if JVT should be updated" );
  declareProperty( "UpdateJVTName",                   m_updatedJVTName, "Variable name for the updated JVT" );
  declareProperty( "ForwardJvtTool",                  m_fjvtTool, "The tool handle for the forwardJVT and the truth pileup labeling" );
  declareProperty( "ForwardJvtTightTool",             m_fjvtTightTool, "The tool handle for the tight forwardJVT labeling" );
  declareProperty( "DoForwardJvt",                    m_doForwardJvt, "Declare if forwardJVT should be calculated" );
  declareProperty( "DoJvtPileupTruthLabeling",        m_doJvtPUTruthLabeling, "Do the jet JVT pileup truth labeling (requires also InputTruthContainer to be set to a valid truth jet container)" );
  declareProperty( "BTagNameList",                    m_bTagList, "List of b-tagger names" );
  declareProperty( "InputTruthContainer",             m_inTruthContName, "Input jet truth container name for truth matching" );
  declareProperty( "TruthMatchName",                  m_truthMatchName, "Variable name for the resulting truth match" );
  declareProperty( "TruthJetPtName",                  m_truthJetPtName, "Variable name for the resulting truth-jet pt" );
  declareProperty( "TruthJetMinPt",                   m_truthJetPtMin, "The minimum pt threshold for a truth-jet to be considered for matching" );
  declareProperty( "TruthMatchMaxDeltaR",             m_maxDeltaR, "The maximum deltaR (using rapidity and NOT eta) distance for a successful truth match" );
}



// Destructor
///////////////
HWW::JetDecorationAlg::~JetDecorationAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::JetDecorationAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inContName );
  ATH_MSG_DEBUG( "Using: " << m_inPrimVtxCont );
  ATH_MSG_DEBUG( "Using: " << m_truthEventContName );
  ATH_MSG_DEBUG( "Using: " << m_jetSelectionToolList );
  ATH_MSG_DEBUG( "Using: " << m_jetDecList );
  ATH_MSG_DEBUG( "Using: " << m_selectionWithVertexToolList );
  ATH_MSG_DEBUG( "Using: " << m_selectionWithVertexDecoList );
  ATH_MSG_DEBUG( "Using: " << m_jvtUpdateTool );
  ATH_MSG_DEBUG( "Using: " << m_doJvtUpdate );
  ATH_MSG_DEBUG( "Using: " << m_updatedJVTName );
  ATH_MSG_DEBUG( "Using: " << m_fjvtTool );
  ATH_MSG_DEBUG( "Using: " << m_fjvtTightTool );
  ATH_MSG_DEBUG( "Using: " << m_doForwardJvt );
  ATH_MSG_DEBUG( "Using: " << m_doJvtPUTruthLabeling );
  ATH_MSG_DEBUG( "Using: " << m_bTagList );
  ATH_MSG_DEBUG( "Using: " << m_inTruthContName );
  ATH_MSG_DEBUG( "Using: " << m_truthMatchName );
  ATH_MSG_DEBUG( "Using: " << m_truthJetPtName );
  ATH_MSG_DEBUG( "Using: " << m_truthJetPtMin );
  ATH_MSG_DEBUG( "Using: " << m_maxDeltaR );

  // Some sanity checks to make sure that the lists are of the same size
  if(m_jetSelectionToolList.size() != m_jetDecList.value().size()){
    ATH_MSG_ERROR( "Jet selection tool list is not same size as the decorator name list size" );
    return StatusCode::FAILURE;
  }
  if ( m_selectionWithVertexToolList.size() != m_selectionWithVertexDecoList.value().size() ){
    ATH_MSG_ERROR( "Jet selection-with-vertex tool list is not same size as the SelectionWithVertexToolDecoList size" );
    return StatusCode::FAILURE;
  }

  // Get the needed tools
  ATH_CHECK( m_jetSelectionToolList.retrieve() );
  ATH_CHECK( m_jvtUpdateTool.retrieve() );
  ATH_CHECK( m_selectionWithVertexToolList.retrieve() );
  ATH_CHECK( m_fjvtTool.retrieve() );
  ATH_CHECK( m_fjvtTightTool.retrieve() );

  return StatusCode::SUCCESS;
}



StatusCode HWW::JetDecorationAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release the needed tools
  ATH_CHECK( m_jetSelectionToolList.release() );
  ATH_CHECK( m_jvtUpdateTool.release() );
  ATH_CHECK( m_selectionWithVertexToolList.release() );
  ATH_CHECK( m_fjvtTool.release() );
  ATH_CHECK( m_fjvtTightTool.release() );

  return StatusCode::SUCCESS;
}



StatusCode HWW::JetDecorationAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Check if we run on simulation (or data)
  const xAOD::EventInfo* eventInfo = 0;
  CHECK( evtStore()->retrieve(eventInfo) );
  const bool isSim = eventInfo->eventType(xAOD::EventInfo::EventType::IS_SIMULATION);


  // Open the input containers
  const xAOD::JetContainer *inCont(0);
  ATH_CHECK( evtStore()->retrieve( inCont, m_inContName.value() ) );

  // Decorate the jets
  for ( std::size_t toolIdx=0; toolIdx < m_jetSelectionToolList.size(); ++toolIdx ) {
    // Define the decorators outside of the loop as a static, such that it
    // will be fully cached
    SG::AuxElement::Decorator<char> decSetJetQuality (m_jetDecList.value()[toolIdx]);
    for ( const xAOD::Jet* jet : *inCont ) {
      int jetQuality = m_jetSelectionToolList[toolIdx]->keep( *jet );
      decSetJetQuality(*jet) = static_cast<char>(jetQuality);
    }
  }

  // Get the primary vertex, if needed
  const xAOD::Vertex* primVtx(0);
  if (m_selectionWithVertexToolList.size()) {
    // Get the primary vertex container
    const xAOD::VertexContainer* primVtxCont;
    ATH_CHECK( evtStore()->retrieve( primVtxCont, m_inPrimVtxCont.value() ) );
    // Find "the" primary vertex inside this container
    for ( const auto* vtx : * primVtxCont ) {
      if ( vtx->vertexType() == xAOD::VxType::PriVtx ) {
        primVtx = vtx;
        break;
      }
    }
    if ( !primVtx ) {
      ATH_MSG_WARNING("Couldn't find a primary vertex in this event!");
    }
  }

  // Decorate the jet, if requested
  for ( std::size_t toolIdx=0; toolIdx < m_selectionWithVertexToolList.size(); ++toolIdx ) {
    // Define the decorators outside of the loop, such that it will be fully cached
    SG::AuxElement::Decorator<char> decoSelWVtx (m_selectionWithVertexDecoList.value()[toolIdx]);
    for ( const xAOD::Jet* jet : *inCont){
      const bool passed = m_selectionWithVertexToolList[toolIdx]->accept(jet,primVtx);
      decoSelWVtx(*jet) = static_cast<char>(passed);
    }
  }

  // Copy the b-taggers to the jets
  for ( const auto& tagName : m_bTagList.value() ) {
    SG::AuxElement::Decorator<float> decBTag(tagName);
    for ( const xAOD::Jet* jet : *inCont ) {
      const xAOD::BTagging* btag = jet->btagging();
      if (!btag) {
        ATH_MSG_ERROR("Couldn't find the xAOD::BTagging object for the current jet");
        return StatusCode::FAILURE;
      }
      double bTagWeight = 0.0;
      if ( !(btag->MVx_discriminant(tagName,bTagWeight)) ) {
        ATH_MSG_ERROR("Couldn't find the tagger with name " << tagName);
        return StatusCode::FAILURE;
      }
      decBTag(*jet) = static_cast<float>(bTagWeight);
    }
  }


  // Some lists of selected truth particles
  std::vector<const xAOD::TruthParticle*> selectedTruthWZBosons;
  std::vector<bool> wzBosonIsFromHiggs;
  // Run this part of decorating jets with their truth origin is requested
  if ( isSim && !(m_truthEventContName.value().empty()) ){
    // opening the truthEvent container
    const xAOD::TruthEventContainer* truthEvtContainer = nullptr;
    ATH_CHECK( evtStore()->retrieve( truthEvtContainer, m_truthEventContName.value() ) );

    std::vector<const xAOD::TruthParticle*> selectedTruthHiggsBosons;
    // Get the truth particles from the event and loop ever them
    for ( const xAOD::TruthEvent* truthEvent : *truthEvtContainer ) {
      if ( !truthEvent ) continue;
      for( std::size_t i=0; i < truthEvent->nTruthParticles(); ++i ) {
        const xAOD::TruthParticle* truthPart = truthEvent->truthParticle(i);
        if ( !truthPart ) continue;
        if ( truthPart->barcode()>2e5 ) break;
        const int pdgID  = truthPart->pdgId();
        if ( std::abs(pdgID) <= 22 || std::abs(pdgID) >=26 ) continue;
        const int status = truthPart->status();
        const std::size_t nChildren = truthPart->nChildren();
        if ( nChildren < 2 ) continue;
        const xAOD::TruthParticle* truthChildA = truthPart->child(0);
        if (!truthChildA) continue;
        const int childAbsPdgId = std::abs(truthChildA->pdgId());
        // Select the interesting particles
        ATH_MSG_VERBOSE("Got a truth particle with status " << status << ", PdgID " << pdgID
                        << ", nChildren " << nChildren << ", child0 PdgID " << truthChildA->pdgId()
                        << ", child0 status " << truthChildA->status() );
        if ( (truthPart->isW() || truthPart->isZ()) && nChildren >=2 && childAbsPdgId <= 18 ){
          ATH_MSG_VERBOSE("Found a truth W or Z boson");
          selectedTruthWZBosons.push_back(truthPart);
        }
        else if ( truthPart->isHiggs() && nChildren >=2 && ( childAbsPdgId==23 || childAbsPdgId==24 ) ){
          ATH_MSG_VERBOSE("Found a truth Higgs boson");
          selectedTruthHiggsBosons.push_back(truthPart);
        }
      } // End: loop over all truth particles
    } // End: loop over all truth events
    // Check if the W/Z boson is from a Higgs boson decay
    ATH_MSG_DEBUG("Now going to check if we have a Higgs boson as ancestor");
    for ( const xAOD::TruthParticle* truthPart : selectedTruthWZBosons ){
      if ( selectedTruthHiggsBosons.size() == 0 ){
        wzBosonIsFromHiggs.push_back(false);
        continue;
      }
      bool foundHiggs(false);
      while ( truthPart ){
        if (truthPart->nParents() != 1 ) break;
        truthPart = truthPart->parent();
        if (truthPart->isHiggs()){
          foundHiggs = true;
          break;
        }
      }
      wzBosonIsFromHiggs.push_back(foundHiggs);
    }
  }


  // Run this part if truth-matching or JVT update is requested
  if ( !(m_inTruthContName.value().empty()) || m_doJvtUpdate.value() || m_doForwardJvt.value()
       || (m_doJvtPUTruthLabeling.value() && !(m_inTruthContName.value().empty())) ){
    // Do the truth-matching of the reco jets, if a valid truth-jet container is given
    ATH_MSG_DEBUG("Going to work on truth jet matching and JVT stuff");
    const xAOD::JetContainer *inTruthCont(0);
    if ( evtStore()->contains<xAOD::JetContainer>(m_inTruthContName.value()) ) {
      // We have a truth jet container. Thus, retrieve it and perform the matching
      ATH_CHECK( evtStore()->retrieve( inTruthCont, m_inTruthContName.value() ) );
    }
    // Define the decorators outside of the loop as a static, such that it
    // will be fully cached
    const double maxDR2 = m_maxDeltaR.value()*m_maxDeltaR.value();
    SG::AuxElement::Decorator<float> decJetTruthMatchDR(m_truthMatchName.value());
    SG::AuxElement::Decorator<float> decTruthJetPt(m_truthJetPtName.value());
    SG::AuxElement::Decorator<float> decUpdateJVT(m_updatedJVTName.value());
    const double maxDR2TruthHS = 0.3*0.3;
    const double maxDR2TruthPU = 0.6*0.6;
    SG::AuxElement::Decorator<char> decTruthIsJVTHS("isJvtHS");
    SG::AuxElement::Decorator<char> decTruthIsJVTPU("isJvtPU");
    SG::AuxElement::Decorator<int> decTruthOrigin("truthOrigin");

    SG::AuxElement::Decorator<int> decNTracks("nTracks");

    for ( const xAOD::Jet* jet : *inCont ) {
      if (inTruthCont){
        float tmDeltaR(-1.0);
        double truthJetPt(0.0);
        bool ishs = false;
        bool ispu = true;
        const xAOD::Jet* bestTruthJet = nullptr;
        for ( const xAOD::Jet* truthJet : * inTruthCont ) {
          const double dr2 = xAOD::P4Helpers::deltaR2( *jet, *truthJet, true );
          if ( truthJet->pt() > m_truthJetPtMin.value() ) {
            if ( dr2 >= 0.0 && dr2 < maxDR2 ) {
              tmDeltaR = static_cast<float>(std::sqrt(dr2));
              truthJetPt = truthJet->pt();
              bestTruthJet = truthJet;
            }
            if ( dr2 < maxDR2TruthHS ) ishs = true;
          }
          if ( dr2 < maxDR2TruthPU ) ispu = false;
        } // End: loop over truth jets
        decJetTruthMatchDR(*jet) = tmDeltaR;
        decTruthJetPt(*jet)      = truthJetPt;

        // Now, try to figure out the truth origin
        ATH_MSG_DEBUG("Now going to try to figure out the truth origin");
        int truthOrigin = 0;
        if (bestTruthJet){
          ATH_MSG_VERBOSE("Have a truth jet with pt " << 0.001*(bestTruthJet->pt())
                          << ", eta " << bestTruthJet->eta() << ", phi " << bestTruthJet->phi());
          const double maxDeltaRSquared = 0.6*0.6;
          for ( std::size_t i=0; i < selectedTruthWZBosons.size(); ++i ){
            const xAOD::TruthParticle* truthPart = selectedTruthWZBosons.at(i);
            if (!truthPart){
              ATH_MSG_WARNING("Got a zero pointer to a truth particle... something went wrong");
              continue;
            }
            const bool isFromHiggs = wzBosonIsFromHiggs.at(i);
            // Iterate over the children and find the best deltaR match within DeltaR=0.6
            double minDeltaR2 = maxDeltaRSquared;
            bool foundMatch = false;
            for ( std::size_t iChild=0; iChild < truthPart->nChildren(); ++iChild ){
              const xAOD::TruthParticle* truthChild = truthPart->child(iChild);
              if (!truthChild) continue;
              const int childAbsPdgId = std::abs(truthChild->pdgId());
              if ( childAbsPdgId > 6 && childAbsPdgId !=21 ) continue; // we don't have a hadronic decay
              const double childPt = truthChild->pt();
              if ( childPt < 1000.0 ){
                ATH_MSG_DEBUG("Got a truth child with pt " << 0.001*childPt << " GeV");
                continue;
              }
              ATH_MSG_VERBOSE("Have a truth W or Z child with pt " << 0.001*childPt
                              << " GeV, eta " << truthChild->eta() << ", phi " << truthChild->phi()
                              << ", pdgID " << truthChild->pdgId() << ", status " << truthChild->status());
              const double dr2 = xAOD::P4Helpers::deltaR2( *truthChild, *bestTruthJet, true );
              if ( dr2 < minDeltaR2 ){
                minDeltaR2 = dr2;
                foundMatch = true;
              }
            }
            // If we found a match
            if ( foundMatch ){
              truthOrigin = truthPart->pdgId() * ( isFromHiggs ? 25 : 1 );
            }
          }
        }
        decTruthOrigin(*jet) = truthOrigin;


        // Do also the pileup truth labeling, if requested
        if (m_doJvtPUTruthLabeling.value()){
          decTruthIsJVTHS(*jet) = static_cast<char>(ishs);
          decTruthIsJVTPU(*jet) = static_cast<char>(ispu);
        }
      }// End: if do truth match
      // Do the JVT updating for calibrated jets
      ATH_MSG_DEBUG("updateJVTName starts");
      if ( m_doJvtUpdate.value() ){
        const float newJvt = m_jvtUpdateTool->updateJvt(*jet);
        decUpdateJVT(*jet) = newJvt;
      } // End: if update JVT
      ATH_MSG_DEBUG("updateJVTName ends");
      //Number of ghost-associated tracks (Javier)
      std::vector<const xAOD::TrackParticle*> assocTracks; assocTracks.clear();
      // Here, we explicitly ignore the return value from the function call:
      static_cast<void>( jet->getAssociatedObjects(xAOD::JetAttribute::GhostTrack, assocTracks) );
      decNTracks(*jet) = assocTracks.size();

    }// End: loop over reco jets

    // Do the pass forwardJVT calculation
    if ( m_doForwardJvt.value() ){
      m_fjvtTool->modify( const_cast<xAOD::JetContainer&>(*inCont) );
      m_fjvtTightTool->modify( const_cast<xAOD::JetContainer&>(*inCont) );
    } // End: ForwardJVT

  } // We got a name for the truth jet container or JVT update was requested

  return StatusCode::SUCCESS;
}
