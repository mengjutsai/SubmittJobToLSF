///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetDecorationAlg.h
// Header file for class HWW::JetDecorationAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWJETDECORATIONALG_H
#define HWWCOMMONANALYSISUTILS_HWWJETDECORATIONALG_H 1

// STL includes
#include <string>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "PATCore/IAsgSelectionTool.h"
#include "GaudiKernel/ToolHandle.h"

// Forward declarations
class IJetSelector;
class IJetUpdateJvt;
class IAsgSelectionWithVertexTool;
class IJetModifier;



// Put everything into a HWW namespace
namespace HWW {

  class JetDecorationAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
  public:

    // Copy constructor:

    /// Constructor with parameters:
    JetDecorationAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~JetDecorationAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input jet container name
    StringProperty m_inContName;

    /// The input primary vertex container name
    StringProperty m_inPrimVtxCont;

    /// The input TruthEventContainer name
    StringProperty m_truthEventContName;

    /// The CP selection tools
    ToolHandleArray<IJetSelector> m_jetSelectionToolList;

    /// The jet decoration names
    StringArrayProperty m_jetDecList;

    /// List of selection-with-vertex tool instances
    ToolHandleArray<IAsgSelectionWithVertexTool> m_selectionWithVertexToolList;

    /// List of decoration names for each selection-with-vertex tools
    StringArrayProperty m_selectionWithVertexDecoList;

    /// The CP tool to correct the JVT variable for calibrated jets
    ToolHandle<IJetUpdateJvt> m_jvtUpdateTool;

    /// Declare if JVT should be updated
    BooleanProperty m_doJvtUpdate;

    /// Variable name for the updated JVT
    StringProperty m_updatedJVTName;

    /// The tool handle for the forwardJVT and the truth pileup labeling
    ToolHandle<IJetModifier> m_fjvtTool;

    /// The tool handle for the tight forwardJVT
    ToolHandle<IJetModifier> m_fjvtTightTool;

    /// Declare if forwardJVT should be calculated
    BooleanProperty m_doForwardJvt;

    /// Do the jet JVT pileup truth labeling (requires also InputTruthContainer to be set to a valid truth jet container)
    BooleanProperty m_doJvtPUTruthLabeling;

    /// List of b-tagger names
    StringArrayProperty m_bTagList;

    /// Input jet truth container name for truth matching
    StringProperty m_inTruthContName;

    /// Variable name for the resulting truth match
    StringProperty m_truthMatchName;

    /// Variable name for the truth-jet pt
    StringProperty m_truthJetPtName;

    /// The minimum pt threshold for a truth-jet to be considered for matching
    DoubleProperty m_truthJetPtMin;

    /// The maximum deltaR (using rapidity and NOT eta) distance for a successful truth match
    DoubleProperty m_maxDeltaR;

    /// @}

  private:

  };

} // End: HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWJETDECORATIONALG_H
