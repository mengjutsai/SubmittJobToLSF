//  includes
#include "HWWTriggerTool.h"

// EDM includes
#include "xAODMuon/MuonContainer.h"
#include "xAODEgamma/ElectronContainer.h"
#include "xAODParticleEvent/IParticleLink.h"


HWW::TriggerTool::TriggerTool( std::string name ):
  asg::AsgTool(name),
  m_varPrefix(""),
  m_muonMatchList(),
  m_electronMatchList(),
  m_diMuMatchList(),
  m_diElMatchList(),
  m_elMuMatchList()
{

  declareProperty("VarPrefix", m_varPrefix, "The prefix to be used for the trigger matching flags" );
  declareProperty("MuonMatchList", m_muonMatchList, "The list of trigger chains to do muon matching on" );
  declareProperty("ElectronMatchList", m_electronMatchList, "The list of trigger chains to do electron matching on" );
  declareProperty("DiMuonMatchList", m_diMuMatchList, "The list of trigger chains to do di-muon matching on" );
  declareProperty("DiElectronMatchList", m_diElMatchList, "The list of trigger chains to do di-electron matching on" );
  declareProperty("ElMuMatchList", m_elMuMatchList, "The list of trigger chains to do electron-muon matching on" );

}


HWW::TriggerTool::~TriggerTool() {}


StatusCode HWW::TriggerTool::initialize()
{
  ATH_MSG_INFO ("Initializing " << name() << "...");

  m_tmt.setTypeAndName("Trig::MatchingTool/HWWMatchingTool");
  CHECK(m_tmt.retrieve()); //important to retrieve here, because TrigDecisionTool must be initialized before event loop

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_tmt );
  ATH_MSG_DEBUG( "Using: " << m_varPrefix );
  ATH_MSG_DEBUG( "Using: " << m_muonMatchList );
  ATH_MSG_DEBUG( "Using: " << m_electronMatchList );
  ATH_MSG_DEBUG( "Using: " << m_diMuMatchList );
  ATH_MSG_DEBUG( "Using: " << m_diElMatchList );
  ATH_MSG_DEBUG( "Using: " << m_elMuMatchList );

  return StatusCode::SUCCESS;
}


StatusCode HWW::TriggerTool::finalize()
{
  ATH_MSG_INFO ("Finalizing " << name() << "...");

  return StatusCode::SUCCESS;
}


bool HWW::TriggerTool::match( const xAOD::IParticle *part ) const
{
  if( part->type() == xAOD::Type::Muon ) {
    ATH_MSG_DEBUG( "Particle is a muon, will perform muon trigger matching" );
    const xAOD::Muon* muon = static_cast<const xAOD::Muon*>(part);
    return this->match(muon);
  }
  else if( part->type() == xAOD::Type::Electron ) {
    ATH_MSG_DEBUG( "Particle is an electron, will perform electron trigger matching" );
    const xAOD::Electron* electron = static_cast<const xAOD::Electron*>(part);
    return this->match(electron);
  }
  else ATH_MSG_WARNING( "Particle is neither a muon nor an electron, will fail trigger matching" );

  return false;
}


bool HWW::TriggerTool::match( const xAOD::IParticle *part, const std::string& chain ) const
{
  if( part->type() == xAOD::Type::Muon ) {
    ATH_MSG_DEBUG( "Particle is a muon, will perform muon trigger matching" );
    const xAOD::Muon* muon = static_cast<const xAOD::Muon*>(part);
    return this->match(muon, chain);
  }
  else if( part->type() == xAOD::Type::Electron ) {
    ATH_MSG_DEBUG( "Particle is an electron, will perform electron trigger matching" );
    const xAOD::Electron* electron = static_cast<const xAOD::Electron*>(part);
    return this->match(electron, chain);
  }
  else ATH_MSG_WARNING( "Particle is neither a muon nor an electron, will fail trigger matching" );

  return false;
}


bool HWW::TriggerTool::match( const xAOD::Muon *muon ) const
{
  bool overallMuonMatch = false;
  // Check if a muon trigger chain list was provided and warn the user if not
  if( m_muonMatchList.value().size() == 0 ) {
    ATH_MSG_WARNING( "No muon trigger chain list provided, will return false" );
  }
  // Loop over list of provided muon trigger chains and perform trigger matching
  for( unsigned int i=0; i<m_muonMatchList.value().size(); ++i ) {
    if( this->match(muon, m_muonMatchList.value().at(i)) ) overallMuonMatch = true;
  }
  return overallMuonMatch;
}


bool HWW::TriggerTool::match( const xAOD::Muon *muon, const std::string& chain ) const
{
  // Get the trigger matching result for this muon for the given trigger chain
  bool muonMatch = m_tmt->match(*muon, chain);
  // Tell the user if the muon could be matched to the given trigger chain
  if( muonMatch ) ATH_MSG_DEBUG( "Muon could be matched to trigger chain " << chain );
  // Return the trigger matching result
  return muonMatch;
}


bool HWW::TriggerTool::match( const xAOD::MuonContainer *muonCont ) const
{
  bool overallMuonMatch = false;
  // Check if a muon trigger chain list was provided and warn the user if not
  if( m_muonMatchList.value().size() == 0 ) {
    ATH_MSG_WARNING( "No muon trigger chain list provided, will return false" );
  }
  // Loop over list of provided muon trigger chains and perform trigger matching
  for( unsigned int i=0; i<m_muonMatchList.value().size(); ++i ) {
    if( this->match(muonCont, m_muonMatchList.value().at(i)) ) overallMuonMatch = true;
  }
  return overallMuonMatch;
}


bool HWW::TriggerTool::match( const xAOD::MuonContainer *muonCont, const std::string& chain ) const
{
  // Set up boolean for overall matching success
  bool overallMuonMatch = false;
  // Set up decorator for the trigger matching flag
  xAOD::Muon::Decorator< char > decMuonMatch((m_varPrefix.value()+chain).c_str());
  // Loop over muons
  for( const xAOD::Muon* muon : *muonCont ) {
    // Do the trigger matching
    bool muonMatch = this->match(muon, chain);
    // Set overall matching boolean to true if trigger matching was successful
    if( muonMatch ) overallMuonMatch = true;
    // Decorate muon with trigger matching result
    decMuonMatch(*muon) = muonMatch ? 1 : 0;
  }
  // Return true if any of the muons could be matched to the given trigger chain
  return overallMuonMatch;
}


bool HWW::TriggerTool::match( const xAOD::Electron *electron ) const
{
  bool overallElectronMatch = false;
  // Check if an electron trigger chain list was provided and warn the user if not
  if( m_electronMatchList.value().size() == 0 ) {
    ATH_MSG_WARNING( "No electron trigger chain list provided, will return false" );
  }
  // Loop over list of provided electron trigger chains and perform trigger matching
  for( unsigned int i=0; i<m_electronMatchList.value().size(); ++i ) {
    if( this->match(electron, m_electronMatchList.value().at(i)) ) overallElectronMatch = true;
  }
  return overallElectronMatch;
}


bool HWW::TriggerTool::match( const xAOD::Electron *electron, const std::string& chain ) const
{
  // Get the trigger matching result for this electron for the given trigger chain
  bool electronMatch = m_tmt->match(*electron, chain);
  // Tell the user if the electron could be matched to the given trigger chain
  if( electronMatch ) ATH_MSG_DEBUG( "Electron could be matched to trigger chain " << chain );
  // Return the trigger matching result
  return electronMatch;
}


bool HWW::TriggerTool::match( const xAOD::ElectronContainer *electronCont ) const
{
  bool overallElectronMatch = false;
  // Check if an electron trigger chain list was provided and warn the user if not
  if( m_electronMatchList.value().size() == 0 ) {
    ATH_MSG_WARNING( "No electron trigger chain list provided, will return false" );
  }
  // Loop over list of provided electron trigger chains and perform trigger matching
  for( unsigned int i=0; i<m_electronMatchList.value().size(); ++i ) {
    if( this->match(electronCont, m_electronMatchList.value().at(i)) ) overallElectronMatch = true;
  }
  return overallElectronMatch;
}


bool HWW::TriggerTool::match( const xAOD::ElectronContainer *electronCont, const std::string& chain ) const
{
  // Set up boolean for overall matching success
  bool overallElectronMatch = false;
  // Set up decorator for the trigger matching flag, taking into account naming convention of TrigEgammaMatchingTool
  xAOD::Electron::Decorator< char > decElectronMatch((m_varPrefix.value()+chain).c_str());
  // Loop over electrons
  for( const xAOD::Electron* electron : *electronCont ) {
    // Do the trigger matching
    bool electronMatch = this->match(electron, chain);
    // Set overall matching boolean to true if trigger matching was successful
    if( electronMatch ) overallElectronMatch = true;
    // Decorate electron with trigger matching result
    decElectronMatch(*electron) = electronMatch ? 1 : 0;
  }
  // Return true if any of the electrons could be matched to the given trigger chain
  return overallElectronMatch;
}


//// Keep bitset implementation for now
// bool HWW::TriggerTool::match( const xAOD::IParticleContainer *cont1, const xAOD::IParticleContainer *cont2, const std::string& chain ) const
// {
//   // Vector of IParticle pointer to steer the matching
//   std::vector<const xAOD::IParticle*> myParticles;
//   // Vectors of bitsets to identify matching object pairs
//   std::vector< std::bitset<32> > bitSetVec1;
//   for(uint i=0; i<cont1->size(); i++) {
//     std::bitset<32> bitSet;
//     bitSetVec1.push_back(bitSet);
//   }
//   std::vector< std::bitset<32> > bitSetVec2;
//   for(uint i=0; i<cont2->size(); i++) {
//     std::bitset<32> bitSet;
//     bitSetVec2.push_back(bitSet);
//   }
//   // Trigger matching counter
//   uint matchCounter = 0;

//   // Going through combinations and check if we find a successful match
//   for(uint i=0; i<cont1->size(); i++) {
//     for(uint j=0; j<cont2->size(); j++) {
//       myParticles.clear();
//       myParticles.push_back( cont1->at(i) );
//       myParticles.push_back( cont2->at(j) );
//       bool trigMatch = m_tmt->match(myParticles, chain);
//       if( trigMatch ) {
//         // We found a matching pair, now set the bit entries accordingly
//         bitSetVec1.at(i).set(matchCounter);
//         bitSetVec2.at(j).set(matchCounter);
//         // Increment the matching counter
//         matchCounter++;
//       }
//     }
//   }

//   // Decorate the particles with their respective bitsets
//   SG::AuxElement::Decorator<std::bitset<32>> decTrigMatch( m_varPrefix.value() + chain );
//   ATH_MSG_DEBUG("Bitsets for trigger chain " << chain);
//   for(uint i=0; i<cont1->size(); i++) {
//     decTrigMatch(*(cont1->at(i))) = bitSetVec1.at(i);
//     ATH_MSG_DEBUG("Set for cont1 index " << i << ": " << bitSetVec1.at(i));
//   }
//   for(uint i=0; i<cont2->size(); i++) {
//     decTrigMatch(*(cont2->at(i))) = bitSetVec2.at(i);
//     ATH_MSG_DEBUG("Set for cont2 index " << i << ": " << bitSetVec2.at(i));
//   }

//   return (matchCounter > 0);
// }


bool HWW::TriggerTool::match( const xAOD::IParticleContainer *cont1, const xAOD::IParticleContainer *cont2, const std::string& chain ) const
{
  bool overallMatch = false;
  // Vector of IParticle pointer to steer the matching
  std::vector<const xAOD::IParticle*> myParticles;
  // Vectors of booleans to propagate trigger decisions
  std::vector< bool > boolVec1;
  for(uint i=0; i<cont1->size(); i++) {
    boolVec1.push_back(false);
  }
  std::vector< bool > boolVec2;
  for(uint i=0; i<cont2->size(); i++) {
    boolVec2.push_back(false);
  }

  // Going through combinations and check if we find a successful match
  for(uint i=0; i<cont1->size(); i++) {
    for(uint j=0; j<cont2->size(); j++) {
      myParticles.clear();
      myParticles.push_back( cont1->at(i) );
      myParticles.push_back( cont2->at(j) );
      bool trigMatch = m_tmt->match(myParticles, chain);
      if( trigMatch ) {
        // Set the flags for the respective objects to true
        boolVec1.at(i) = true;
        boolVec2.at(j) = true;
        overallMatch = true;
      }
    }
  }

  // Decorate the particles with their respective bitsets
  SG::AuxElement::Decorator<char> decTrigMatch( m_varPrefix.value() + chain );

  ATH_MSG_DEBUG("Trigger matching results for trigger chain " << chain);
  for(uint i=0; i<cont1->size(); i++) {
    decTrigMatch(*(cont1->at(i))) = boolVec1.at(i) ? 1 : 0;
    ATH_MSG_DEBUG("Cont1 index " << i << ": " << boolVec1.at(i));
  }
  for(uint i=0; i<cont2->size(); i++) {
    decTrigMatch(*(cont2->at(i))) = boolVec2.at(i) ? 1 : 0;
    ATH_MSG_DEBUG("Cont2 index " << i << ": " << boolVec2.at(i));
  }

  return overallMatch;
}

bool HWW::TriggerTool::match( const xAOD::IParticleContainer *cont1, const xAOD::IParticleContainer *cont2 ) const
{
  bool overallMatch = false;
  if( !m_elMuMatchList.value().size() ) {
    ATH_MSG_WARNING( "No di-lepton trigger chain list provided, will do nothing" );
  }
  // Loop over list of provided di-lepton trigger chains and perform trigger matching
  for( uint i=0; i<m_elMuMatchList.value().size(); ++i ) {
    bool trigMatch = this->match(cont1, cont2, m_elMuMatchList.value().at(i));
    overallMatch = (overallMatch || trigMatch);
  }  
  return overallMatch;
}
