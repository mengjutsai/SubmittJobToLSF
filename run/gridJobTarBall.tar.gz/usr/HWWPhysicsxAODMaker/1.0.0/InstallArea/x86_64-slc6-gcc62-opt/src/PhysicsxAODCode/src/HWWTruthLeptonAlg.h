#ifndef HWWCOMMONANALYSISUTILS_HWWTRUTHLEPTONALG_H
#define HWWCOMMONANALYSISUTILS_HWWTRUTHLEPTONALG_H 

// STL includes
#include <string>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
//#include "GaudiKernel/ToolHandle.h"

// EDM includes

// Forward declarations


// Put everything into a HWW namespace
namespace HWW {

  class TruthLeptonAlg
    : public ::AthAlgorithm
  {
    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
    public:

      /// Constructor with parameters:
      TruthLeptonAlg( const std::string& name, ISvcLocator* pSvcLocator );

      /// Destructor:
      virtual ~TruthLeptonAlg();

      /// Athena algorithm's initalize hook
      virtual StatusCode  initialize();

      /// Athena algorithm's execute hook
      virtual StatusCode  execute();

      /// Athena algorithm's finalize hook
      virtual StatusCode  finalize();




    private:

      /// @name The properties that can be defined via the python job options
      /// @{

      //
      // Configurable properties
      //

      /// The input electron container name
      StringProperty m_inElCont;

      /// The input muon container name
      StringProperty m_inMuCont;

      /// The output electron container name
      StringProperty m_outElCont;

      /// The output muon container name
      StringProperty m_outMuCont;

      /// @}

  };

} // End HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWTRUTHLEPTONALG_H
