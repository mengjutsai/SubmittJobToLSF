#!/usr/bin/env python

# ==============================================================================
# File: submitSuperMerge.py
# Author: Karsten Koeneke <karsten.koeneke@cern.ch>
# Description: This file is a python executable that is meant for submitting
# an additional mergin job on existing grid datasets, i.e., produce superMerge
# datasets.
# ==============================================================================


import user  # look for .pythonrc.py for user init
import os,sys



inDSList = ["group.phys-higgs.data15_13TeV.HWW_NoEffiSF.merge.PAOD.V12_rel20p7_Part01",
            "group.phys-higgs.data16_13TeV.HWW_NoEffiSF.merge.PAOD.V12_rel20p7_Part01",
            #"group.phys-higgs.mc15_13TeV.HWW_Common_NoEffiSF.merge.PAOD.V12_rel20p7_Part01",
            #"group.phys-higgs.mc15_13TeV.HWW_HWWHighMass_NoEffiSF.merge.PAOD.V12_rel20p7_Part01",
            #"group.phys-higgs.mc15_13TeV.HWW_Hmumu_NoEffiSF.merge.PAOD.V12_rel20p7_Part01",
            #"group.phys-higgs.mc15_13TeV.HWW_Common_NoEffiSF.merge.PAOD.sysV12_rel20p7_Part01",
            #"group.phys-higgs.mc15_13TeV.HWW_HWWHighMass_NoEffiSF.merge.PAOD.sysV12_rel20p7_Part01",
            #"group.phys-higgs.mc15_13TeV.HWW_Hmumu_NoEffiSF.merge.PAOD.sysV12_rel20p7_Part01"
            ]

inStreamNameList = ["PAOD_ZH", "PAOD_WH",
                    "PAOD_2LDF",
                    #"PAOD_2LJJDF",
                    #"PAOD_2LJJ",
                    #"PAOD_2L"
                    ]

for inDS in inDSList:
    for inStreamName in inStreamNameList:
        job = 'pathena  -c "OUTSTREAMNAME=\''
        job += inStreamName+'\';"'
        job += ' PhysicsxAODConfig/PAODMerge.py  --dbRelease LATEST '
        job += ' --official --voms=atlas:/atlas/phys-higgs/Role=production  --destSE IN2P3-CC_PHYS-HIGGS '
        fullInDSName = inDS+"_"+inStreamName
        job += ' --inDS ' + fullInDSName
        outDSName = fullInDSName.replace(".merge.",".superMerge.")
        job += ' --outDS ' + outDSName
        job += ' --nGBPerJob=5  --skipScout '
        # job += ' --site DESY-HH '
        if inDS.__contains__(".mc1"): job += ' --addNthFieldOfInFileToLFN=3,4 '

        # Now, submit the actual job
        print "Going to run this job:"
        print job
        os.system(job)
        pass
    pass
