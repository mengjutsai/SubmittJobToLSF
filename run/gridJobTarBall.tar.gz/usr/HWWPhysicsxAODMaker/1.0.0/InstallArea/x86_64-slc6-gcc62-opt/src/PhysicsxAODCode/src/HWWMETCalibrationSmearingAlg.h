///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMETCalibrationSmearingAlg.h
// Header file for class HWW::METCalibrationSmearingAlg
// Author: Phuong Dang <nguyen.phuong.dang@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONXAODCODE_HWWMETCALIBRATIONSMEARINGALG_H
#define HWWCOMMONXAODCODE_HWWMETCALIBRATIONSMEARINGALG_H 1

// STL includes
#include <vector>
#include <string>
#include <utility>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"
#include "PATInterfaces/SystematicSet.h"

// forward declarations
class IMETSystematicsTool;

// Put everything into a HWW namespace
namespace HWW {

  class METCalibrationSmearingAlg: public ::AthAlgorithm {

  public:
    /// Default constructor for the framework
    METCalibrationSmearingAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Default destructor
    virtual ~METCalibrationSmearingAlg();

    /// @name  Athena algorithm's Hooks
    /// @{

    /// The framework's initialize method. Called once before the event loop
    virtual StatusCode  initialize();

    /// The framework's exectue method. Called once for every event
    virtual StatusCode  execute();

    /// The framework's initialize method. Called once after the event loop
    virtual StatusCode  finalize();

    /// @}


  private:
    /// The input container name
    StringProperty m_inCont;

    /// The name of the input MET map
    StringProperty m_mapname;

    /// The name of the output final missingET object
    StringProperty m_outFinalName;

    /// The names of all systematic variations to be applied for the MET
    StringArrayProperty m_metSysNames;

    /// The ToolHandle for the MET tool
    ToolHandle<IMETSystematicsTool> m_metSysTool;

    /// The string separator between the output container name and the sytematic variation (default="___")
    StringProperty m_separator;

    /// Define a private enum to be used for the type of systematic variation
    enum MetSystematicType { UNKNOWN, TST, CST, JetTrk };

    /// The vector of all MET systematics and the corresponding container-name post-fixes
    std::vector< std::pair< MetSystematicType, std::pair< CP::SystematicSet, std::string > > > m_metSystVarNameVec;

    /// Flag that says if we have TrackMET or MET
    bool m_isTrackMET;

};

} // End: HWW namespace


#endif //> !HWWCOMMONXAODCODE_HWWMETCALIBRATIONSMEARINGALG_H
