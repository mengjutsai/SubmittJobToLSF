##=============================================================================
## Name:        HWWlnulnuTruthPAODContent.py
##
## Author:      Karsten Koeneke
## Created:     August 2014
##
## Description: Here, we define the content that will be written for the
##              Physics AOD (PAOD) output file.
##=============================================================================

# Import the steering flags for this analysis
from PhysicsxAODConfig.HWWTruthCommonAnalysisFlags import hWWCommon
from HWWlnulnuxAODConfig.HWWlnulnuTruthAnalysisFlags import hWWlnulnu

# Import the common content
from PhysicsxAODConfig import CommonTruthPAODContent


# ====================================================================
# Define the container item list of the output Physics AOD (PAOD)
# ====================================================================
def pAODContent():
    """This function defines then which 'containers' are written to disk."""
    # Take the common parts
    itemList = CommonTruthPAODContent.pAODContent()

    # Now, add specific parts
    itemList.append("xAOD::CompositeParticleContainer#EventTruthEE*")
    itemList.append("xAOD::CompositeParticleContainer#EventTruthEM*")
    itemList.append("xAOD::CompositeParticleContainer#EventTruthME*")
    itemList.append("xAOD::CompositeParticleContainer#EventTruthMM*")
    itemList.append("xAOD::CompositeParticleAuxContainer#EventTruthEE*")
    itemList.append("xAOD::CompositeParticleAuxContainer#EventTruthEM*")
    itemList.append("xAOD::CompositeParticleAuxContainer#EventTruthME*")
    itemList.append("xAOD::CompositeParticleAuxContainer#EventTruthMM*")
    itemList.append("xAOD::AuxContainerBase#EventTruthEE*Aux.-px.-py.-pz.-e.-charge.-pdgId")
    itemList.append("xAOD::AuxContainerBase#EventTruthEM*Aux.-px.-py.-pz.-e.-charge.-pdgId")
    itemList.append("xAOD::AuxContainerBase#EventTruthME*Aux.-px.-py.-pz.-e.-charge.-pdgId")
    itemList.append("xAOD::AuxContainerBase#EventTruthMM*Aux.-px.-py.-pz.-e.-charge.-pdgId")

    return itemList


# ====================================================================
# Define the meta-data item list of the output Physics AOD (PAOD)
# ====================================================================
def pAODMetaDataContent():
    # Take the common parts
    itemList = CommonTruthPAODContent.pAODMetaDataContent()
    return itemList
