///////////////////////// -*- C++ -*- /////////////////////////////
// HWWUnprescaleDataAlg.h
// Header file for class HWW::UnprescaleDataAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWUNPRESCALEDATAALG_H
#define HWWCOMMONANALYSISUTILS_HWWUNPRESCALEDATAALG_H 1

// STL includes
#include <string>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"
#include "AsgAnalysisInterfaces/IPileupReweightingTool.h"


// Forward declarations
// class IPileupReweightingTool;



// Put everything into a HWW namespace
namespace HWW {

  class UnprescaleDataAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
  public:

    // Copy constructor:

    /// Constructor with parameters:
    UnprescaleDataAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~UnprescaleDataAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The pileup reweighting tool
    ToolHandle<CP::IPileupReweightingTool> m_prwTool;

    /// The input EventInfo name
    StringProperty m_inEventInfoName;

    /// The trigger expression to use for the unweighting of the data
    StringProperty m_inTriggerExpression;

    /// The list of lumicalc files to pass to the tool
    StringArrayProperty m_inLumiCalcFiles;

    /// @}

  private:


  };

} // End: HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWUNPRESCALEDATAALG_H
