///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetDecorationAlg.h
// Header file for class HWW::JetDecorationAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWEVENTINFODECORATIONALG_H
#define HWWCOMMONANALYSISUTILS_HWWEVENTINFODECORATIONALG_H 1

// STL includes
#include <string>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"



// Put everything into a HWW namespace
namespace HWW {

  class EventInfoDecorationAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
  public:

    // Copy constructor:

    /// Constructor with parameters:
    EventInfoDecorationAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~EventInfoDecorationAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input jet container name
    StringProperty m_inContName;

    /// The input primary vertex container name
    StringProperty m_inPrimVtxCont;

    /// Variable name for the resuling variable that holds the index of the found primary vertex
    StringProperty m_primVtxIdxName;


    /// Variable name for the resuling variable that holds the number of vertices
    StringProperty m_nPrimVtxName;

    /// Variable name for the resuling variable that holds the number of vertices with two or more tracks
    StringProperty m_nPrimVtxTwoTrkName;

    /// Variable name for the resuling variable that holds the number of vertices with three or more tracks
    StringProperty m_nPrimVtxThreeTrkName;

    /// Variable name for the resuling variable that holds the number of vertices with four or more tracks
    StringProperty m_nPrimVtxFourTrkName;

    /// @}

  private:

  };

} // End: HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWEVENTINFODECORATIONALG_H
