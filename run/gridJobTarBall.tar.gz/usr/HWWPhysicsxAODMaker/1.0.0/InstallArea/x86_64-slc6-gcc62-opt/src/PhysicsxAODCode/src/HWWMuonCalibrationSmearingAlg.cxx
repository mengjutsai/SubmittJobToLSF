///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMuonCalibrationSmearingAlg.cxx
// Implementation file for class HWW::MuonCalibrationSmearingAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWMuonCalibrationSmearingAlg.h"

// STL includes
#include <set>
#include <climits>
#include <cmath>
#include <algorithm>

// EDM includes
#include "xAODCore/ShallowCopy.h"
#include "xAODBase/IParticleHelpers.h"
#include "xAODMuon/Muon.h"
#include "xAODMuon/MuonContainer.h"
#include "xAODMuon/MuonAuxContainer.h"
#include "xAODParticleEvent/IParticleLink.h"

// Tool includes
#include "MuonAnalysisInterfaces/IMuonCalibrationAndSmearingTool.h"
#include "PATInterfaces/SystematicCode.h"
#include "PATInterfaces/SystematicSet.h"
#include "PATInterfaces/SystematicVariation.h"




// Constructors
////////////////
HWW::MuonCalibrationSmearingAlg::MuonCalibrationSmearingAlg( const std::string& name,
                                                             ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_muCalibSmearTool("CP::IMuonCalibrationAndSmearingTool", this)
{
  //
  // Property declaration
  //
  declareProperty("InputContainer",  m_inCont="", "Input container name" );

  declareProperty("Separator", m_separator="___",
                  "The string seperator between the output container name and the sytematic variation (default='___')" );

  declareProperty("OutputContainer", m_outCont="",
                  "The name of the output container with the deep copy of input objects" );

  declareProperty("MuonCalibrationTool",            m_muCalibSmearTool,
                  "The ToolHandle for the muon calibration and smearing tool" );

  declareProperty("MomentumSystematicVariations", m_muCalibSmearSysNames,
                  "The names of all systematic variations to be applied" );
}



// Destructor
///////////////
HWW::MuonCalibrationSmearingAlg::~MuonCalibrationSmearingAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::MuonCalibrationSmearingAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inCont );
  ATH_MSG_DEBUG( "Using: " << m_separator );
  ATH_MSG_DEBUG( "Using: " << m_outCont );
  ATH_MSG_DEBUG( "Using: " << m_muCalibSmearSysNames );
  ATH_MSG_DEBUG( "Using: " << m_muCalibSmearTool );

  // Perform some sanity checks on the given container names
  if ( m_inCont.value().empty() || m_outCont.value().empty() ) {
    ATH_MSG_ERROR("Wrong user setup! You need to give a valid name for both the InputContainer and OutputContainer!");
    return StatusCode::FAILURE;
  }

  // Abort on an unchecked systematics code
  // CP::SystematicCode::enableFailure();

  // Retrieve the tools
  ATH_CHECK(m_muCalibSmearTool.retrieve());

  // Figure out what systematics are available and recommended
  if ( msgLvl(MSG::DEBUG) || msgLvl(MSG::VERBOSE) ) {
    CP::SystematicSet affSys = m_muCalibSmearTool->affectingSystematics();
    std::string affSysNames = affSys.name();
    std::replace( affSysNames.begin(), affSysNames.end(), '-', ',');
    ATH_MSG_DEBUG("Have " << affSys.size() << " affecting systematics with name "
                  << affSysNames << " for tool " << m_muCalibSmearTool->name() );
    CP::SystematicSet recSys = m_muCalibSmearTool->recommendedSystematics();
    std::string recSysNames = recSys.name();
    std::replace( recSysNames.begin(), recSysNames.end(), '-', ',');
    ATH_MSG_DEBUG("Have " << recSys.size() << " recommended systematics with name "
                  << recSysNames << " for tool " << m_muCalibSmearTool->name() );
  }

  // Set up the internal vector of systematics and container name post-fixes,
  // starting with the nominal one. First, clear it. Then, add the nominal, then systematics
  m_p4SystVarNameVec.clear();
  m_p4SystVarNameVec.push_back( std::make_pair( CP::SystematicSet(), "" ) );
  for ( const auto& sysName  :  m_muCalibSmearSysNames.value() ) {
    CP::SystematicVariation sysVar = CP::SystematicVariation(sysName);
    if ( m_muCalibSmearTool->isAffectedBySystematic(sysVar) ) {
      CP::SystematicSet sysSet{sysVar};
      m_p4SystVarNameVec.push_back( std::make_pair( sysSet, m_separator.value()+sysName ) );
      ATH_MSG_DEBUG("Adding systematic variation with name " << sysName );
    }
    else {
      CP::SystematicSet affSys = m_muCalibSmearTool->affectingSystematics();
      std::string affSysNames = affSys.name();
      std::replace( affSysNames.begin(), affSysNames.end(), '-', ',');
      ATH_MSG_WARNING("Couldn't find systematic variation with name " << sysName
                      << " amongst the affected systematics: " << affSysNames );
      return StatusCode::FAILURE;
    }
  } // End: adding all systematic variations to be processed


  return StatusCode::SUCCESS;
}



StatusCode HWW::MuonCalibrationSmearingAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release the tools
  ATH_CHECK(m_muCalibSmearTool.release());

  return StatusCode::SUCCESS;
}



StatusCode HWW::MuonCalibrationSmearingAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Open the input container
  const xAOD::MuonContainer* inCont;
  ATH_CHECK( evtStore()->retrieve( inCont, m_inCont.value() ));


  // Now, we will loop over the 4-momentum systematics to be applied
  for ( const auto& systVarAndContName : m_p4SystVarNameVec ) {
    const CP::SystematicSet& systSet = systVarAndContName.first;
    const std::string& contSuffix    = systVarAndContName.second;

    // Let's create a shallow copy of the const input container
    // auto = std::pair< xAOD::MuonContainer*, xAOD::ShallowAuxContainer* >
    auto inContShallowCopy = xAOD::shallowCopyContainer( *inCont );
    ATH_CHECK( evtStore()->record( inContShallowCopy.first,  m_outCont.value() + contSuffix ) );
    ATH_CHECK( evtStore()->record( inContShallowCopy.second, m_outCont.value() + contSuffix + "Aux." ) );

    // Set the tool state to apply a systematic variation.
    // Event if it is an empty variation, i.e, the nominal case, set the
    // state of the tool to that to avoid that the tool is still in a
    // systematic state from the previous event.
    if( m_muCalibSmearTool->applySystematicVariation( systSet ) != CP::SystematicCode::Ok ) {
      ATH_MSG_ERROR("Cannot configure MuonCalibrationAndSmearingTool for systematic variation " << systSet.name() );
      return StatusCode::FAILURE;
    }
    ATH_MSG_DEBUG("Going to run muon p4 systematic variation (empty=nominal): " << systSet.name() );

    // Loop over all Muons in the shallow-copy container
    for ( xAOD::Muon* muon : *(inContShallowCopy.first) ) {
      ATH_MSG_VERBOSE("Now iterating over the muon shallow copy container... at index=" << muon->index() );
      const double originalPt = muon->pt();
      if ( m_muCalibSmearTool->applyCorrection(*muon) == CP::CorrectionCode::Error ) {
        ATH_MSG_ERROR("MuonCalibrationAndSmearingTool reported a CP::CorrectionCode::Error");
        return StatusCode::FAILURE;
      }
      ATH_MSG_VERBOSE("Original pt: " << originalPt << " MeV, new pt: " << muon->pt()
                      << " MeV, original-new pt: " << originalPt - muon->pt() << " MeV" );
    } // End: loop over Muons

    // Create the ElementLinks to the original muons.
    // Unfortunately, needed my missingET tools
    if ( !(xAOD::setOriginalObjectLink( *inCont, *(inContShallowCopy.first) )) ) {
      ATH_MSG_FATAL("Couldn't set the ElementLink to the original container!");
      return StatusCode::FAILURE;
    }

  } // End: loop over systematic variations


  // TODO: Do the bookkeeping stuff

  return StatusCode::SUCCESS;
}
