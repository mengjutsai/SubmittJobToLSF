///////////////////////// -*- C++ -*- /////////////////////////////
// HWWTruthJetSelectionTool.cxx
// Implementation file for class HWW::TruthJetSelectionTool
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWTruthJetSelectionTool.h"

// STL includes
#include <climits>
#include <cmath>
#include <string>

// FrameWork includes
#include "GaudiKernel/IToolSvc.h"

// EDM includes
#include "xAODBase/ObjectType.h"
#include "xAODBase/IParticle.h"
#include "xAODJet/Jet.h"
#include "xAODBTagging/BTagging.h"
#include "xAODTracking/Vertex.h"



// Constructors
////////////////
HWW::TruthJetSelectionTool::TruthJetSelectionTool( std::string name ) :
  asg::AsgTool(name),
  m_doBTagCut(false),
  m_cutPosition_pteta(-9),
  m_cutPosition_btag(-9)
{
  //
  // Property declaration
  //
  declareProperty( "CutPtMinList",     m_ptMinList,
                   "The jet.pt() minimum cut values. Must be same lenght as the eta list" );

  declareProperty( "CutAbsEtaMaxList", m_absEtaMaxList,
                   "The |jet.cluster().eta()| maximum cut value. Must be same lenght as the pt list" );


}




// Destructor
///////////////
HWW::TruthJetSelectionTool::~TruthJetSelectionTool()
{}




// Athena algtool's Hooks
////////////////////////////
StatusCode HWW::TruthJetSelectionTool::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_ptMinList );
  ATH_MSG_DEBUG( "Using: " << m_absEtaMaxList );

  // Perform some sanity checks on the given lists
  if ( !(m_ptMinList.value().empty()) || !(m_absEtaMaxList.value().empty()) ) {
    if ( m_ptMinList.value().size() != m_absEtaMaxList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_ptMinList.name() << " is " << m_ptMinList.value().size()
                    << " and size of " << m_absEtaMaxList.name() << " is " << m_absEtaMaxList.value().size() );
      return StatusCode::FAILURE;
    }
  }

  // --------------------------------------------------------------------------
  // Register the cuts and check that the registration worked:
  // NOTE: THE ORDER IS IMPORTANT!!! Cut0 corresponds to bit 0, Cut1 to bit 1,...
  // if ( m_cutPosition_nSCTMin < 0 ) sc = 0; // Exceeded the number of allowed cuts

  // NOTE that we only register here the cuts. And what we register is only the
  // name of a cut and its description. The description SHOULD of course
  // describe what the cut will actually do in the end. But it may not (if the
  // developer has forgotten about it).

  // Register the jet pt-eta (2-dim) selection, if requested
  if ( !(m_absEtaMaxList.value().empty()) ) {
    ATH_MSG_DEBUG("Registering pt-eta cut");
    std::string cutDescription("");
    for ( std::size_t i=0; i<m_absEtaMaxList.value().size(); ++i ) {
      cutDescription += " (";
      cutDescription += Form( "%g", m_ptMinList.value().at(i) * 0.001 );
      cutDescription += " GeV < jet.pt && |jet.eta| < ";
      cutDescription += Form( "%g", m_absEtaMaxList.value().at(i) );
      cutDescription += " )";
    }
    m_cutPosition_pteta = m_accept.addCut( "PtEtaCut", cutDescription );
    if ( m_cutPosition_pteta < 0 ) {
      ATH_MSG_ERROR("Couldn't book jet pt-eta cut");
      return StatusCode::FAILURE;
    }
  }

  // Register the b-tagging cut cut
  /*if ( m_doBTagCut ) {
    ATH_MSG_DEBUG("Registering b-tagging cut");
    m_cutPosition_btag = m_accept.addCut( "BTagCut", Form("%g < bTagWeight < %g",
                                                          m_bTagWeightMin.value(),
                                                          m_bTagWeightMax.value()) );
    if ( m_cutPosition_btag < 0 ) {
      ATH_MSG_ERROR("Couldn't book b-tagging cut");
      return StatusCode::FAILURE;
    }
  }*/

  return StatusCode::SUCCESS;
}




StatusCode HWW::TruthJetSelectionTool::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  return StatusCode::SUCCESS;
}




// Method to get the plain TAccept.
const Root::TAccept& HWW::TruthJetSelectionTool::getTAccept( ) const
{
  return m_accept;
}




// The main accept method: the actual cuts are applied here
const Root::TAccept& HWW::TruthJetSelectionTool::accept( const xAOD::IParticle* part) const
{
  // Reset the cut result bits to zero (= fail cut)
  m_accept.clear();

  // cast to an Jet
  if ( part->type() != xAOD::Type::Jet ) {
    ATH_MSG_ERROR("Didn't get an IParticle of type Jet... exiting");
    return m_accept;
  }
  const xAOD::Jet* jet = static_cast<const xAOD::Jet*>(part);
  if ( !jet ) {
    ATH_MSG_ERROR("Couldn't cast to an Jet");
    return m_accept;
  }


  // ---------------------------------------------------------------------------
  // Do the actual selection:
  // If a cut is not passed, we return and the subsequent cuts are not tried out

  // Do the jet pt-eta (2-dim) selection, if requested
  if ( !(m_absEtaMaxList.value().empty()) ) {
    bool passCut = false;
    const double pt = jet->pt();
    const double absEta = std::abs(jet->eta());
    double previousAbsEtaMax = -10000.0;
    for ( std::size_t i=0; i<m_absEtaMaxList.value().size(); ++i ) {
      if ( previousAbsEtaMax < absEta && absEta < m_absEtaMaxList.value().at(i) ) {
        ATH_MSG_VERBOSE("Check if jet with eta ( " << previousAbsEtaMax << " < " << absEta << " < " << m_absEtaMaxList.value().at(i) << " ) has pT ( " << pt << " > " << m_ptMinList.value().at(i) << " )");
        if( pt > m_ptMinList.value().at(i) ) {
          // Return if the jet passes the selection
          passCut = true;
        }
        break; // We are in the right eta-bin, nothing more to do here
      }
      previousAbsEtaMax = m_absEtaMaxList.value().at(i);
    }
    m_accept.setCutResult( m_cutPosition_pteta, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing pt-eta cut");
      return m_accept;
    }
    ATH_MSG_VERBOSE("Passing pt-eta cut");
  } // End: do pt-eta cut

  // Do the b-tagging selection, if requested
  /*if ( m_doBTagCut && !(m_bTagWeightName.value().empty()) ) {
    ATH_MSG_VERBOSE("Going to do b-tagging selection");
    // Get the b-tagging weight directly from the BTagging object
    static SG::AuxElement::ConstAccessor<double> accBTagWeight (m_bTagWeightName.value());
    const xAOD::BTagging* btag = jet->btagging();
    if ( !btag || !(accBTagWeight.isAvailable(*btag)) ) {
      ATH_MSG_WARNING("You requested a b-tagging weight with name '"
                      << m_bTagWeightName.value() << "', but it is not available.");
      return m_accept;
    }
    const double bTagWeight = accBTagWeight(*btag);
    const bool passCut = m_bTagWeightMin.value() < bTagWeight && bTagWeight < m_bTagWeightMax.value();
    m_accept.setCutResult( m_cutPosition_btag, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing b-tagging cut");
      return m_accept;
    }
    ATH_MSG_VERBOSE("Passing b-tagging cut");
  } // End: do b-tagging cut
  */

  return m_accept;
}
