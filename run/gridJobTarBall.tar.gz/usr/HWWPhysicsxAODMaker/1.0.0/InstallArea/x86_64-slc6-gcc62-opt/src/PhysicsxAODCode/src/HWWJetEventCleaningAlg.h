///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetEventCleaningAlg.h
// Header file for class HWW::JetEventCleaningAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////
#ifndef HWWCOMMONANALYSISUTILS_HWWJETEVENTCLEANINGALG_H
#define HWWCOMMONANALYSISUTILS_HWWJETEVENTCLEANINGALG_H 1

// STL includes
#include <string>
#include <stdint.h>

// FrameWork includes
#include "AthenaBaseComps/AthAlgorithm.h"


// Put everything into a HWW namespace
namespace HWW {

  class JetEventCleaningAlg
    : public ::AthAlgorithm
  {

    ///////////////////////////////////////////////////////////////////
    // Public methods:
    ///////////////////////////////////////////////////////////////////
  public:

    // Copy constructor:

    /// Constructor with parameters:
    JetEventCleaningAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Destructor:
    virtual ~JetEventCleaningAlg();

    /// Athena algtool's initialize hook: Called by Athena once before the event loop starts
    virtual StatusCode  initialize();

    /// Athena algtool's execute hook: Called by Athena once for every event
    virtual StatusCode  execute();

    /// Athena algtool's finalize hook: Called by Athena once after the event loop finishes
    virtual StatusCode  finalize();



    ///////////////////////////////////////////////////////////////////
    // Private data:
    ///////////////////////////////////////////////////////////////////
  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The input jet container name
    StringProperty m_inContName;

    /// The string separator between the variable/container name and its sytematic variation (default="___")
    StringProperty m_separator;

    /// Remove jets that fail the cleaning from the CompositeParticle
    BooleanProperty m_removeBadJets;

    /// The name of the variable for passing the jet event cleaning
    StringProperty m_passEventCleaningVarName;

    /// The name of the variable for passing the JVT selection
    StringProperty m_passJVTVarName;

    /// The name of the variable for passing the jet cleaning selection
    StringProperty m_passJetCleaningVarName;

    /// Minimum jet pt cut for the cleaning
    DoubleProperty m_cutMinPt;

    /// Maximum jet pt cut for the cleaning
    DoubleProperty m_cutMaxPt;

    /// The |eta| cut for the boundary between central and forward
    DoubleProperty m_cutAbsEta;

    /// Decorate all copies of the input container
    bool m_decoAllCopies;

    /// @}

  private:

    /// @name Truly private internal data members
    /// @{

    /// The vector of jet container names
    std::vector<std::string> m_containerNameList;

    /// @}

  };

} // End: HWW namespace


#endif //> !HWWCOMMONANALYSISUTILS_HWWJETEVENTCLEANINGALG_H
