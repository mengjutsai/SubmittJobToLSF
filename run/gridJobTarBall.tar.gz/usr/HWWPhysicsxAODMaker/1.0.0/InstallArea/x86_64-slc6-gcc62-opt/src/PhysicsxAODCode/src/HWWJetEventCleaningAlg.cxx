///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetEventCleaningAlg.cxx
// Implementation file for class HWW::JetEventCleaningAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWJetEventCleaningAlg.h"

// STL includes
#include <climits>
#include <cmath>
#include <algorithm>
#include <vector>

// EDM includes
#include "xAODJet/Jet.h"
#include "xAODParticleEvent/CompositeParticle.h"
#include "xAODParticleEvent/CompositeParticleContainer.h"



// Constructors
////////////////
HWW::JetEventCleaningAlg::JetEventCleaningAlg( const std::string& name,
                                               ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_inContName(""),
  m_separator("___"),
  m_removeBadJets(true),
  m_passEventCleaningVarName("PassJetEventCleaning"),
  m_passJVTVarName("PassJVT"),
  m_passJetCleaningVarName(""),
  m_cutMinPt(20000.0),
  m_cutMaxPt(60000.0),
  m_cutAbsEta(2.4),
  m_decoAllCopies(true),
  m_containerNameList()
{
  //
  // Property declaration
  //
  declareProperty("InputContainer", m_inContName, "Input container name" );
  declareProperty("Separator", m_separator,
                  "The string seperator between the variable/container name and its sytematic variation (default='___')" );

  declareProperty("RemoveBadJets",            m_removeBadJets,            "Remove jets that fail the cleaning from the CompositeParticle");
  declareProperty("PassEventCleaningVarName", m_passEventCleaningVarName, "The name of the variable for passing the jet event cleaning");
  declareProperty("PassJVTVarName",           m_passJVTVarName,           "The name of the variable for passing the JVT selection");
  declareProperty("PassJetCleaningVarName",   m_passJetCleaningVarName,   "The name of the variable for passing the jet cleaning selection");
  declareProperty("CutPtMin",                 m_cutMinPt,                 "Minimum jet pt cut for the cleaning");
  declareProperty("CutPtMax",                 m_cutMaxPt,                 "Maximum jet pt cut for the cleaning");
  declareProperty("CutAbsEtaMax",             m_cutAbsEta,                "The |eta| cut for the boundary between central and forward");

  declareProperty("DecorateAllCopies", m_decoAllCopies, "If true, will decorate all copies of the input container" );
}



// Destructor
///////////////
HWW::JetEventCleaningAlg::~JetEventCleaningAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::JetEventCleaningAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inContName );
  ATH_MSG_DEBUG( "Using: " << m_separator );
  ATH_MSG_DEBUG( "Using: " << m_removeBadJets );
  ATH_MSG_DEBUG( "Using: " << m_passEventCleaningVarName );
  ATH_MSG_DEBUG( "Using: " << m_passJVTVarName );
  ATH_MSG_DEBUG( "Using: " << m_passJetCleaningVarName );
  ATH_MSG_DEBUG( "Using: " << m_cutMinPt );
  ATH_MSG_DEBUG( "Using: " << m_cutMaxPt );
  ATH_MSG_DEBUG( "Using: " << m_cutAbsEta );
  ATH_MSG_DEBUG( "Using DecorateAllCopies: " << m_decoAllCopies );

  return StatusCode::SUCCESS;
}



StatusCode HWW::JetEventCleaningAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");
  return StatusCode::SUCCESS;
}



StatusCode HWW::JetEventCleaningAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Now, let's try to get all requested CompositeParticle containers and iterate over them.
  // If not specifically requested to get all copies, only the exactly given
  // name will be retrieved. Otherwise, all containers with the same base-name,
  // i.e, the part before the "___", if present, will be used.
  // Do this expensive string manupulation and StoreGate search only the first time.
  if (m_containerNameList.empty()){
    if (m_decoAllCopies){
      const std::string& inContName = m_inContName.value();
      // Now, get all the StoreGate names of existing CompositeParticleContainers
      std::vector<std::string> sgKeys;
      evtStore()->keys<xAOD::CompositeParticleContainer>(sgKeys);
      ATH_MSG_DEBUG("Found " << sgKeys.size() << " xAOD::CompositeParticleContainers in the event store.");
      m_containerNameList.reserve(sgKeys.size());
      // Now, let's find all container names that start with our inContName
      for ( const std::string& item : sgKeys ){
        if ( inContName.empty() || item.compare(0, inContName.length(), inContName) == 0 ){
          // We found a match, i.e, the current StoreGate key begins with our searchString
          ATH_MSG_DEBUG("Found matching xAOD::CompositeParticleContainer name: " << item);
          m_containerNameList.push_back(item);
        }
      }
    }
    else{
      m_containerNameList.push_back(m_inContName.value());
    }
  }

  // Define the accessors outside of the loop as a static, such that it
  // will be fully cached
  SG::AuxElement::Decorator<char> decoPassJetEventCleaning(m_passEventCleaningVarName.value());
  SG::AuxElement::Accessor<char>  accPassJVT(m_passJVTVarName.value());
  SG::AuxElement::Accessor<char>  accPassClean(m_passJetCleaningVarName.value());

  // Get the cut values
  const bool removeBadJets = m_removeBadJets.value();
  const double cutPtMin    = m_cutMinPt.value();
  const double cutPtMax    = m_cutMaxPt.value();
  const double cutAbsEta   = m_cutAbsEta.value();

  // Now, iterate over all input container names that were found and use these jet containers.
  for ( std::size_t contIdx=0; contIdx<m_containerNameList.size(); ++contIdx ) {
    xAOD::CompositeParticleContainer* inCont = nullptr;
    ATH_CHECK( evtStore()->retrieve( inCont, m_containerNameList.at(contIdx) ));
    if ( inCont->size() == 0 ) {
      ATH_MSG_DEBUG("Have an empty input container... going to the next");
      continue;
    }
    ATH_MSG_VERBOSE("Now reading input container with name: " << m_containerNameList.at(contIdx)
                    << " and size: " <<" "<<inCont->size());

    // Loop over all Jets in the current input container to calculate the event cleaning pass/fail
    for ( xAOD::CompositeParticle* compPart : *inCont ) {
      ATH_MSG_VERBOSE("Looking at CompositeParticle number " << compPart->index() << " with pt=" << 0.001*(compPart->pt())
                      << " GeV, eta=" << compPart->eta() << ", phi=" << compPart->phi() );

      // Default event rejection
      bool rejectEvent(false);

      // Iterate over all particles of the current CompositeParticle
      for ( std::size_t partIdx=0; partIdx<compPart->nParts(); ++partIdx ){
        const xAOD::Jet* jet = compPart->jet(partIdx);
        if (!jet) continue;
        bool passJVT   = true;
        if (accPassJVT.isAvailable(*jet)) passJVT = static_cast<bool>(accPassJVT(*jet));
        bool passClean = true;
        if (accPassClean.isAvailable(*jet)) passClean = static_cast<bool>(accPassClean(*jet));
        const double jetPt     = jet->pt();
        const double jetAbsEta = std::abs(jet->eta());
        // Remove jets that don't pass the JVT and/or cleaning requirements
        if (removeBadJets){
          if ( jetPt > cutPtMin  && jetPt < cutPtMax && jetAbsEta < cutAbsEta ){
            if (!passJVT) compPart->removePart(jet,false);
          }
          if (!passClean) compPart->removePart(jet,false);
        }
        // Perform the event-based cleaning and label the CompositeParticle with the result
        if (!rejectEvent){
          if ( jetPt > cutPtMin && jetPt < cutPtMax && jetAbsEta < cutAbsEta ){
            if ( passJVT && !passClean ){
              rejectEvent = true;
              continue;
            }
          }
          else if ( jetPt > cutPtMax || ( jetPt > cutPtMin && jetPt < cutPtMax && jetAbsEta > cutAbsEta ) ){
            if ( !passClean ){
              rejectEvent = true;
              continue;
            }
          }
        }
      }
      // Iterate over all "other" particles of the current CompositeParticle
      for ( std::size_t partIdx=0; partIdx<compPart->nOtherParts(); ++partIdx ){
        const xAOD::Jet* jet = compPart->otherJet(partIdx);
        if (!jet) continue;
        bool passJVT   = true;
        if (accPassJVT.isAvailable(*jet)) passJVT = static_cast<bool>(accPassJVT(*jet));
        bool passClean = true;
        if (accPassClean.isAvailable(*jet)) passClean = static_cast<bool>(accPassClean(*jet));
        const double jetPt     = jet->pt();
        const double jetAbsEta = std::abs(jet->eta());
        // Remove jets that don't pass the JVT and/or cleaning requirements
        if (removeBadJets){
          if ( jetPt > cutPtMin  && jetPt < cutPtMax && jetAbsEta < cutAbsEta ){
            if (!passJVT) compPart->removeOtherPart(jet);
          }
          if (!passClean) compPart->removeOtherPart(jet);
        }
        // Perform the event-based cleaning and label the CompositeParticle with the result
        if (!rejectEvent){
          if ( jetPt > cutPtMin && jetPt < cutPtMax && jetAbsEta < cutAbsEta ){
            if ( passJVT && !passClean ){
              rejectEvent = true;
              continue;
            }
          }
          else if ( jetPt > cutPtMax || ( jetPt > cutPtMin && jetPt < cutPtMax && jetAbsEta > cutAbsEta ) ){
            if ( !passClean ){
              rejectEvent = true;
              continue;
            }
          }
        }
      }

      // Set the information if the current event passes the jet cleaning selection and store it
      decoPassJetEventCleaning(*compPart) = static_cast<char>( !rejectEvent );
    }


  } // End: Loop over all input JetContainer names

  return StatusCode::SUCCESS;
}
