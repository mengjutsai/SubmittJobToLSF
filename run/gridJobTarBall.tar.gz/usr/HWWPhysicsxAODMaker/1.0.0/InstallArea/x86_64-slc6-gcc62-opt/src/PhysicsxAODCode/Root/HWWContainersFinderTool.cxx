///////////////////////// -*- C++ -*- /////////////////////////////
// HWWContainersFinderTool.cxx
// Implementation file for class HWW::ContainersFinderTool
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWContainersFinderTool.h"

// STL includes
#include <string>
#include <algorithm>

// FrameWork includes
#include "GaudiKernel/IToolSvc.h"



// Constructors
////////////////
HWW::ContainersFinderTool::ContainersFinderTool( std::string name ) :
  asg::AsgTool(name),
  m_nominalSuffix(""),
  m_separator("___")
{
  //
  // Property declaration
  //
  declareProperty("NominalSuffix", m_nominalSuffix, "The suffix for the nominal name (default='')" );
  declareProperty("Separator",     m_separator,     "The string seperator between the variable/container name and its sytematic variation (default='___')" );
}


// Destructor
///////////////
HWW::ContainersFinderTool::~ContainersFinderTool()
{}


// Athena algtool's Hooks
////////////////////////////
StatusCode HWW::ContainersFinderTool::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_nominalSuffix );
  ATH_MSG_DEBUG( "Using: " << m_separator );

  return StatusCode::SUCCESS;
}


StatusCode HWW::ContainersFinderTool::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  return StatusCode::SUCCESS;
}


/// Get all container names with their systematic types, given one container name
template<class TCONT>
StatusCode HWW::ContainersFinderTool::containerTemplateNamesAndSysTypes( ContNameAndSysTypeVec_t& result, const std::string& searchPattern ) const
{
  // Now, let's try to find all containers that match the given pattern.
  // All containers with the same base-name, i.e, the part before the
  // separator (default: "___"), if present, will be used.

  // First, remove the suffix that is separated by the separator (default: "___"), if present
  std::string searchString = searchPattern;
  std::string::size_type pos = searchPattern.find( m_separator.value() );
  if(searchPattern.npos != pos){ searchString = searchPattern.substr(0, pos); }

  // Now, get all the StoreGate names of existing containers xAOD::IParticleContainers
  ATH_MSG_DEBUG("Looking for a serach pattern with name: '" << searchPattern << "'");
  ATH_MSG_DEBUG("Looking for a serach string with name:  '" << searchString << "'");
  ATH_MSG_VERBOSE("Current event store content: " << evtStore()->dump() );
  std::vector<std::string> sgKeys;
  evtStore()->keys<TCONT>(sgKeys);
  ATH_MSG_DEBUG("Found " << sgKeys.size() << " containers in the event store.");
  result.reserve(sgKeys.size());

  // Create a temporary name list and a name for the nominal one. This is
  // needed since we want to require that the name of the nominal container
  // is the zeroth entry in the final list of container names.
  std::vector<const std::string*> tmpSysContainerNameList;
  tmpSysContainerNameList.reserve(sgKeys.size());
  std::string originalContName = "";
  std::string nominalContName  = "";
  const std::string nominalContNameWithSuffix = searchString + m_separator.value() + m_nominalSuffix.value();

  // Now, let's find all container names that start with our searchString
  for ( const std::string& item : sgKeys ){
    if ( item.compare(0, searchString.length(), searchString) == 0 ){
      // We found a match, i.e, the current StoreGate key begins with our searchString
      ATH_MSG_DEBUG("Found matching container name: " << item);

      // If the nominal container name is assumed to have no suffix
      if ( m_nominalSuffix.value().empty() ){
        if ( item.length() == searchString.length() ){
          ATH_MSG_DEBUG("Found nominal container with name: " << item);
          // If the nominal suffix is an empty string, the nominal container name is assumed to have no suffix
          nominalContName = searchString;
        }
        else{
          tmpSysContainerNameList.push_back(&item);
        }
      }
      // If we have a nominal suffix, we can have both nominal and original (uncalibrated) container names
      else {
        if ( item == nominalContNameWithSuffix ){
          ATH_MSG_DEBUG("Found exactly the nominal container name: " << item);
          nominalContName = item;
        }
        else if ( item == searchString ){
          ATH_MSG_DEBUG("Found original container with name: " << item);
          originalContName = item;
        }
        else{
          tmpSysContainerNameList.push_back(&item);
        }
      }
    }
  }

  // If we haven't found the nominal container, we have a problem...
  if (nominalContName.empty()){
    ATH_MSG_FATAL("Couldn't find the nominal container name... aborting!");
    return StatusCode::FAILURE;
  }

  // Sort the systematics container names alphabetically
  std::sort( tmpSysContainerNameList.begin(), tmpSysContainerNameList.end(),
             [](const std::string* lhs, const std::string* rhs) { return (*lhs) < (*rhs); }
           );

  // Now, actaully build the final container name list with the orignal one
  // being the zeroth (if present), the nominal one next, and all systematic ones afterwards.
  if ( !(originalContName.empty()) ){
    result.push_back( std::make_pair(originalContName, HWW::SystematicType::ORIGNIAL) );
  }
  result.push_back( std::make_pair(nominalContName, HWW::SystematicType::NOMINAL) );
  for ( const std::string* item : tmpSysContainerNameList ){
    result.push_back( std::make_pair(*item, HWW::SystematicType::FOURMOM) );
  }

  return StatusCode::SUCCESS;
}
