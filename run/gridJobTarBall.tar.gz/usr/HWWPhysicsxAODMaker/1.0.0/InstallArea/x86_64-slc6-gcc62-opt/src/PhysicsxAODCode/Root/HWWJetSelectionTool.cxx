///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetSelectionTool.cxx
// Implementation file for class HWW::JetSelectionTool
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWJetSelectionTool.h"

// STL includes
#include <climits>
#include <cmath>
#include <string>

// FrameWork includes
#include "GaudiKernel/IToolSvc.h"

// EDM includes
#include "xAODBase/ObjectType.h"
#include "xAODBase/IParticle.h"
#include "xAODJet/Jet.h"
#include "xAODBTagging/BTagging.h"
#include "xAODTracking/Vertex.h"



// Constructors
////////////////
HWW::JetSelectionTool::JetSelectionTool( std::string name ) :
  asg::AsgTool(name),
  m_updatedJVTName("calibJvt"),
  m_passForwardJVTName(""),
  m_passJVTName(""),
  m_doJVTCut(false),
  m_requireTruthMatch(false),
  m_bTagWeightName(""),
  m_bTagWeightMin(-1.0*DBL_MAX),
  m_bTagWeightMax(DBL_MAX),
  m_doBTagCut(false),
  m_cutPosition_pteta(-9),
  m_cutPosition_clean(-9),
  m_cutPosition_jvt(-9),
  m_cutPosition_forwardjvt(-9),
  m_cutPosition_tm(-9),
  m_cutPosition_btag(-9)
{
  //
  // Property declaration
  //
  declareProperty( "CutPtMinList",     m_ptMinList,
                   "The jet.pt() minimum cut values. Must be same lenght as the eta list" );

  declareProperty( "CutAbsEtaMaxList", m_absEtaMaxList,
                   "The |jet.cluster().eta()| maximum cut value. Must be same lenght as the pt list" );

  declareProperty( "CutCleanList", m_cleanList, "The JetCleaning selection list" );

  declareProperty( "CutCleanPtMinList", m_cleanPtMinList,
                   "The jet.pt minimum cuts for the JetCleaning selection; must be ordered from lowest to highest" );

  declareProperty( "UpdateJVTName", m_updatedJVTName, "Variable name for the updated JVT" );

  declareProperty( "PassForwardJVTName", m_passForwardJVTName, "Name of the variable that stores if a forward jet passes the FJVT selection" );

  declareProperty( "PassJVTName", m_passJVTName, "Name of the variable that stores if a jet passes the JVT selection" );
  m_passJVTName.declareUpdateHandler( &HWW::JetSelectionTool::setupJVTCut, this );

  declareProperty( "RequireTruthMatch", m_requireTruthMatch,
                   "Require the jet to be truth-matched" );

  declareProperty( "BTagWeightName", m_bTagWeightName,
                   "The b-tagging variable name" );

  declareProperty( "CutBTagWeightMin", m_bTagWeightMin,
                   "The b-tagging minimum cut value." );
  m_bTagWeightMin.declareUpdateHandler( &HWW::JetSelectionTool::setupBTagCut, this );

  declareProperty( "CutBTagWeightMax", m_bTagWeightMax,
                   "The b-tagging maximum cut value." );
  m_bTagWeightMax.declareUpdateHandler( &HWW::JetSelectionTool::setupBTagCut, this );
}




// Destructor
///////////////
HWW::JetSelectionTool::~JetSelectionTool()
{}




// Athena algtool's Hooks
////////////////////////////
StatusCode HWW::JetSelectionTool::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_ptMinList );
  ATH_MSG_DEBUG( "Using: " << m_absEtaMaxList );
  ATH_MSG_DEBUG( "Using: " << m_updatedJVTName );
  ATH_MSG_DEBUG( "Using: " << m_passForwardJVTName );
  ATH_MSG_DEBUG( "Using: " << m_passJVTName );
  ATH_MSG_DEBUG( "Using: " << m_requireTruthMatch );
  ATH_MSG_DEBUG( "Using: " << m_bTagWeightName );
  ATH_MSG_DEBUG( "Using: " << m_bTagWeightMin );
  ATH_MSG_DEBUG( "Using: " << m_bTagWeightMax );

  // Perform some sanity checks on the given lists
  if ( !(m_ptMinList.value().empty()) || !(m_absEtaMaxList.value().empty()) ) {
    if ( m_ptMinList.value().size() != m_absEtaMaxList.value().size() ) {
      ATH_MSG_ERROR("Inconsistent configuration!"
                    << " Size of " << m_ptMinList.name() << " is " << m_ptMinList.value().size()
                    << " and size of " << m_absEtaMaxList.name() << " is " << m_absEtaMaxList.value().size() );
      return StatusCode::FAILURE;
    }
  }

  // --------------------------------------------------------------------------
  // Register the cuts and check that the registration worked:
  // NOTE: THE ORDER IS IMPORTANT!!! Cut0 corresponds to bit 0, Cut1 to bit 1,...
  // if ( m_cutPosition_nSCTMin < 0 ) sc = 0; // Exceeded the number of allowed cuts

  // NOTE that we only register here the cuts. And what we register is only the
  // name of a cut and its description. The description SHOULD of course
  // describe what the cut will actually do in the end. But it may not (if the
  // developer has forgotten about it).

  // Register the jet pt-eta (2-dim) selection, if requested
  if ( !(m_absEtaMaxList.value().empty()) ) {
    ATH_MSG_DEBUG("Registering pt-eta cut");
    std::string cutDescription("");
    for ( std::size_t i=0; i<m_absEtaMaxList.value().size(); ++i ) {
      cutDescription += " (";
      cutDescription += Form( "%g", m_ptMinList.value().at(i) * 0.001 );
      cutDescription += " GeV < jet.pt && |jet.eta| < ";
      cutDescription += Form( "%g", m_absEtaMaxList.value().at(i) );
      cutDescription += " )";
    }
    m_cutPosition_pteta = m_accept.addCut( "PtEtaCut", cutDescription );
    if ( m_cutPosition_pteta < 0 ) {
      ATH_MSG_ERROR("Couldn't book jet pt-eta cut");
      return StatusCode::FAILURE;
    }
  }

  // Register the JetCleaning cut
  if ( !(m_cleanList.value().empty()) ) {
    ATH_MSG_DEBUG("Registering JetCleaning cut");
    // Build the cut description name
    std::string cutDescription("");
    if ( m_cleanPtMinList.value().empty() && m_cleanList.value().size() == 1 ) {
      cutDescription = m_cleanList.value().at(0);
    }
    else if ( m_cleanPtMinList.value().size() == m_cleanList.value().size() ) {
      // We have pt-dependent JetCleaning cuts
      const std::size_t maxIdx = m_cleanPtMinList.value().size();
      for ( std::size_t i=0; i<maxIdx; ++i ) {
        cutDescription += " (";
        cutDescription += Form( "%f", m_cleanPtMinList.value().at(i) * 0.001 );
        cutDescription += " GeV < ptJet && JetCleaning=" + m_cleanList.value().at(i) + ") ";
      }
    }
    // Actually register the cut
    m_cutPosition_clean = m_accept.addCut( "JetCleaningCut", cutDescription );
    if ( m_cutPosition_clean < 0 ) {
      ATH_MSG_ERROR("Couldn't book JetCleaning cut");
      return StatusCode::FAILURE;
    }
  }

  // Register the forwardJVT cut
  if ( !(m_passForwardJVTName.value().empty()) ) {
    ATH_MSG_DEBUG("Registering ForwardJVT cut");
    m_cutPosition_forwardjvt = m_accept.addCut( "ForwardJVTCut", m_passForwardJVTName.value() );
    if ( m_cutPosition_forwardjvt < 0 ) {
      ATH_MSG_ERROR("Couldn't book ForwardJVT cut");
      return StatusCode::FAILURE;
    }
  }

  // Register the JVT cut
  if ( m_doJVTCut ) {
    ATH_MSG_DEBUG("Registering JVT cut");
    m_cutPosition_jvt = m_accept.addCut( "JVTCut", m_passJVTName.value() );
    if ( m_cutPosition_jvt < 0 ) {
      ATH_MSG_ERROR("Couldn't book JVT cut");
      return StatusCode::FAILURE;
    }
  }

  // If we require the jet to be truth-matched
  if (m_requireTruthMatch) {
    ATH_MSG_DEBUG("Registering truth-match cut");
    m_cutPosition_tm = m_accept.addCut( "TruthMatch", "Require truth-match" );
    if ( m_cutPosition_tm < 0 ) {
      ATH_MSG_ERROR("Couldn't book truth-match cut");
      return StatusCode::FAILURE;
    }
  }

  // Register the b-tagging cut cut
  if ( m_doBTagCut && !(m_bTagWeightName.value().empty()) ) {
    ATH_MSG_DEBUG("Registering b-tagging cut");
    m_cutPosition_btag = m_accept.addCut( "BTagCut", Form("%g < bTagWeight < %g",
                                                          m_bTagWeightMin.value(),
                                                          m_bTagWeightMax.value()) );
    if ( m_cutPosition_btag < 0 ) {
      ATH_MSG_ERROR("Couldn't book b-tagging cut");
      return StatusCode::FAILURE;
    }
  }

  return StatusCode::SUCCESS;
}




StatusCode HWW::JetSelectionTool::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  return StatusCode::SUCCESS;
}




// Method to get the plain TAccept.
const Root::TAccept& HWW::JetSelectionTool::getTAccept( ) const
{
  return m_accept;
}




// The main accept method: the actual cuts are applied here
const Root::TAccept& HWW::JetSelectionTool::accept( const xAOD::IParticle* part,
                                                    const xAOD::Vertex* /*primVtx*/ ) const
{
  // Reset the cut result bits to zero (= fail cut)
  m_accept.clear();

  // cast to an Jet
  if ( part->type() != xAOD::Type::Jet ) {
    ATH_MSG_ERROR("Didn't get an IParticle of type Jet... exiting");
    return m_accept;
  }
  const xAOD::Jet* jet = static_cast<const xAOD::Jet*>(part);
  if ( !jet ) {
    ATH_MSG_ERROR("Couldn't cast to an Jet");
    return m_accept;
  }


  // ---------------------------------------------------------------------------
  // Do the actual selection:
  // If a cut is not passed, we return and the subsequent cuts are not tried out

  // Do the jet pt-eta (2-dim) selection, if requested
  if ( !(m_absEtaMaxList.value().empty()) ) {
    bool passCut = false;
    const double pt = jet->pt();
    const double absEta = std::abs(jet->eta());
    double previousAbsEtaMax = -10000.0;
    for ( std::size_t i=0; i<m_absEtaMaxList.value().size(); ++i ) {
      if ( previousAbsEtaMax < absEta && absEta < m_absEtaMaxList.value().at(i) ) {
        ATH_MSG_VERBOSE("Check if jet with eta ( " << previousAbsEtaMax << " < " << absEta << " < " << m_absEtaMaxList.value().at(i) << " ) has pT ( " << pt << " > " << m_ptMinList.value().at(i) << " )");
        if( pt > m_ptMinList.value().at(i) ) {
          // Return if the jet passes the selection
          passCut = true;
        }
        break; // We are in the right eta-bin, nothing more to do here
      }
      previousAbsEtaMax = m_absEtaMaxList.value().at(i);
    }
    m_accept.setCutResult( m_cutPosition_pteta, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing pt-eta cut");
      return m_accept;
    }
    ATH_MSG_VERBOSE("Passing pt-eta cut");
  } // End: do pt-eta cut

  // Do the JetCleaning selection, if requested, TODO: need to check if ORing the JetCleaning working points is necessary
  if ( !(m_cleanList.value().empty()) ) {
    ATH_MSG_VERBOSE("Going to do JetCleaning selection");
    bool passCut(false);
    const std::size_t maxIdx = m_cleanList.value().size();
    const double jetPt = jet->pt();
    for ( std::size_t i=0; i<maxIdx; ++i ) {
      // Check in which pt-bin we are
      if ( i+1 < maxIdx ) {
        if( m_cleanPtMinList.value().at(i) < jetPt && jetPt < m_cleanPtMinList.value().at(i+1) ) {
          ATH_MSG_VERBOSE("Check if jet is " << m_cleanList.value().at(i) << " for pT bin ( " << m_cleanPtMinList.value().at(i) << " < " << jetPt << " < " << m_cleanPtMinList.value().at(i+1) << " )");
          // Get the JetCleaning decision from previously decorated tag
          passCut = ( jet->auxdata<char>(m_cleanList.value().at(i)) != 0 );
          break; // We are in the right pt-bin, nothing more to do here
        }
      }
      else if ( m_cleanPtMinList.value().at(i) < jetPt ) {
        ATH_MSG_VERBOSE("Check if jet is " << m_cleanList.value().at(i) << " for pT bin ( " << m_cleanPtMinList.value().at(i) << " < " << jetPt << " )");
        // Get the JetCleaning decision from previously decorated tag
        passCut = ( jet->auxdata<char>(m_cleanList.value().at(i)) != 0 );
      }
    } // End: loop over all pt bins
    // Return if the jet passes the selection
    m_accept.setCutResult( m_cutPosition_clean, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing JetCleaning cut");
      return m_accept;
    }
  } // End: do JetCleaning selection



  // Apply the forwardJVT cut, if requested
  if ( !(m_passForwardJVTName.value().empty()) ) {
    ATH_MSG_DEBUG("Going to do ForwardJVT selection");
    static SG::AuxElement::Accessor<char> accPassForwardJVT(m_passForwardJVTName.value());
    if ( !(accPassForwardJVT.isAvailable(*jet)) ){
      ATH_MSG_ERROR("Pass ForwardJVT variable with name '" << m_passForwardJVTName.value() << "' is not available. Failing this cut.");
      m_accept.setCutResult( m_cutPosition_forwardjvt, false );
      return m_accept;
    }
    const bool passForwardJVT = static_cast<bool>(accPassForwardJVT(*jet));
    ATH_MSG_VERBOSE("Check if jet passes: (passForwardJVT=" << passForwardJVT << ")");
    m_accept.setCutResult( m_cutPosition_forwardjvt, passForwardJVT );
    if ( !passForwardJVT ) {
      ATH_MSG_VERBOSE("Failing ForwardJVT cut");
      return m_accept;
    }
    ATH_MSG_VERBOSE("Passing ForwardJVT cut");
  } // End: do ForwardJVF cut



  // Do the JVT selection, if requested
  if ( m_doJVTCut ) {
    ATH_MSG_VERBOSE("Going to do JVT selection");
    static SG::AuxElement::Accessor<char> accPassJVT(m_passJVTName.value());
    if ( !(accPassJVT.isAvailable(*jet)) ){
      ATH_MSG_ERROR("Pass JVT variable with name '" << m_passJVTName.value() << "' is not available. Failing this cut.");
      m_accept.setCutResult( m_cutPosition_jvt, false );
      return m_accept;
    }
    const bool passJVT = static_cast<bool>(accPassJVT(*jet));
    m_accept.setCutResult( m_cutPosition_jvt, passJVT );
    if ( !passJVT ) {
      ATH_MSG_VERBOSE("Failing JVT cut");
      return m_accept;
    }
    ATH_MSG_VERBOSE("Passing JVT cut");
  } // End: do JVF cut


  // If we require the jet to be truth-matched
  if (m_requireTruthMatch) {
    ATH_MSG_VERBOSE("Going to do the truth-match");
    static SG::AuxElement::Accessor<float> accJetTruthMatchDR("hardScatterTruthMatchDeltaR");
    if ( !(accJetTruthMatchDR.isAvailable(*jet)) ) {
      ATH_MSG_DEBUG("No Variable of name hardScatterTruthMatchDeltaR available... will not try to truth-match");
    }
    else {
      const float dr = accJetTruthMatchDR(*jet);
      const bool passCut = dr > -0.1;
      m_accept.setCutResult( m_cutPosition_tm, passCut );
      if ( !passCut ) {
        ATH_MSG_VERBOSE("Failing truth-match");
        return m_accept;
      }
      ATH_MSG_VERBOSE("Passing truth-match");
    }
  } // End: require truth-match


  // Do the b-tagging selection, if requested
  if ( m_doBTagCut && !(m_bTagWeightName.value().empty()) ) {
    ATH_MSG_VERBOSE("Going to do b-tagging selection");
    // Get the b-tagging weight directly from the BTagging object
    static SG::AuxElement::ConstAccessor<double> accBTagWeight (m_bTagWeightName.value());
    const xAOD::BTagging* btag = jet->btagging();
    if ( !btag || !(accBTagWeight.isAvailable(*btag)) ) {
      ATH_MSG_WARNING("You requested a b-tagging weight with name '"
                      << m_bTagWeightName.value() << "', but it is not available.");
      return m_accept;
    }
    const double bTagWeight = accBTagWeight(*btag);
    const bool passCut = m_bTagWeightMin.value() < bTagWeight && bTagWeight < m_bTagWeightMax.value();
    m_accept.setCutResult( m_cutPosition_btag, passCut );
    if ( !passCut ) {
      ATH_MSG_VERBOSE("Failing b-tagging cut");
      return m_accept;
    }
    ATH_MSG_VERBOSE("Passing b-tagging cut");
  } // End: do b-tagging cut


  return m_accept;
}
