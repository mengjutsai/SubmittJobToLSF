# ====================================================================
# Here, we convert TruthParticle leptons from TRUTH1 to TruthParticle we want.
# 
# ====================================================================

# ====================================================================
# block that this file is included twice
# ====================================================================
include.block("PhysicsxAODConfig/HWWTruthLeptonMod.py")


# ====================================================================
# Lets do it
# ====================================================================

hWWCommonCalibSeq += CfgMgr.HWW__TruthLeptonAlg( "HWWTruthLeptonAlg",
                                                                 #OutputLevel                   = VERBOSE,
                                                                 InputElectrons                = hWWCommon.Electrons.inCont,
                                                                 InputMuons                    = hWWCommon.Muons.inCont,
                                                                 OutputElectrons               = hWWCommon.Electrons.calibCont,
                                                                 OutputMuons                   = hWWCommon.Muons.calibCont,
                                                                 )

hWWCommonCalibSeq += CfgMgr.HWW__TruthJetMETAlg( "HWWTruthJetMETAlg",
                                                                 #OutputLevel                   = VERBOSE,
                                                                 InputJets                     = hWWCommon.Jets.inCont,
                                                                 InputMet                      = hWWCommon.MET.inCont,
                                                                 OutputJets                    = hWWCommon.Jets.calibCont,
                                                                 OutputMet                     = hWWCommon.MET.calibCont,
                                                                 )










