///////////////////////// -*- C++ -*- /////////////////////////////
// HWWJetCalibrationSmearingAlg.cxx
// Implementation file for class HWW::JetCalibrationSmearingAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWJetCalibrationSmearingAlg.h"

// STL includes
#include <set>
#include <climits>
#include <cmath>
#include <algorithm>

// boost includes
#include <boost/algorithm/string/replace.hpp>

// Framework inlcudes
#include "GaudiKernel/SystemOfUnits.h"

// EDM includes
#include "xAODCore/ShallowCopy.h"
#include "xAODBase/IParticleHelpers.h"
#include "xAODJet/Jet.h"
#include "xAODJet/JetContainer.h"
#include "xAODJet/JetAuxContainer.h"
#include "xAODParticleEvent/IParticleLink.h"

// Tool includes
#include "PATInterfaces/SystematicCode.h"
#include "PATInterfaces/SystematicSet.h"
#include "PATInterfaces/SystematicVariation.h"
#include "JetCalibTools/IJetCalibrationTool.h"
#include "JetCPInterfaces/ICPJetUncertaintiesTool.h"
#include "JetResolution/IJERSmearingTool.h"


using Gaudi::Units::GeV;

// Constructors
////////////////
HWW::JetCalibrationSmearingAlg::JetCalibrationSmearingAlg( const std::string& name,
                                                           ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_inCont(""),
  m_outCont(""),
  m_doBJES(true),
  m_jesNameSuffix(""),
  m_jesSmearSysNames(),
  m_mcType("MC16"),
  m_jerSmearSysNames(),
  m_jetCalibTool("", this),
  m_jesUncertaintyTool(""),
  m_jesSysUncertaintyTool(""),
  m_jerSmearTool(""),
  m_separator("___"),
  m_doFatJetHack(false)
{
  //
  // Property declaration
  //
  declareProperty("InputContainer",  m_inCont, "Input container name" );
  declareProperty("OutputContainer", m_outCont,
                  "The name of the output container with the deep copy of input objects" );

  declareProperty("JetCalibrationTool", m_jetCalibTool,
                  "The ToolHandle for the jet calibration tool" );

  declareProperty("DoBJESLabeling", m_doBJES,
                  "Enable using the truth b-jet labeling to get flavor-dependent JES uncertainties (default: true)");

  declareProperty("JESUncertaintyTool", m_jesUncertaintyTool,
                  "The ToolHandle for the jet energy scale uncertainties tool" );

  declareProperty("JESSystematicsUncertaintyTool", m_jesSysUncertaintyTool,
                  "The ToolHandle for the jet energy scale uncertainties tool for systematics" );

  declareProperty("JESSystematicVariations", m_jesSmearSysNames,
                  "The names of all systematic variations to be applied to the Jet Energy Scale" );

  declareProperty("MCType", m_mcType, "The name of the MC, either 'MC16' (default) or 'AFII'");

  declareProperty("JESSystematicsNameSuffix",  m_jesNameSuffix,
                  "The suffix for the JES systematic variation name as used in the output container name; to be added before the '__1up/down' part" );


  declareProperty("JERSmearingTool", m_jerSmearTool,
                  "The ToolHandle for the jet energy resolution smearing tool" );

  declareProperty("JERSystematicVariations", m_jerSmearSysNames,
                  "The names of all systematic variations to be applied to the Jet Energy Resolution" );


  declareProperty("Separator", m_separator,
                  "The string seperator between the output container name and the sytematic variation (default='___')" );

  declareProperty("DoFatJetHack", m_doFatJetHack, "Enable a hack for using the fat-jet" );
}



// Destructor
///////////////
HWW::JetCalibrationSmearingAlg::~JetCalibrationSmearingAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::JetCalibrationSmearingAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inCont );
  ATH_MSG_DEBUG( "Using: " << m_outCont );
  ATH_MSG_DEBUG( "Using: " << m_doBJES );
  ATH_MSG_DEBUG( "Using: " << m_jetCalibTool );
  ATH_MSG_DEBUG( "Using: " << m_jesUncertaintyTool );
  ATH_MSG_DEBUG( "Using: " << m_jesSysUncertaintyTool );
  ATH_MSG_DEBUG( "Using: " << m_jesNameSuffix );
  ATH_MSG_DEBUG( "Using: " << m_mcType );
  ATH_MSG_DEBUG( "Using: " << m_jesSmearSysNames );
  ATH_MSG_DEBUG( "Using: " << m_jerSmearTool );
  ATH_MSG_DEBUG( "Using: " << m_jerSmearSysNames );
  ATH_MSG_DEBUG( "Using: " << m_separator );
  ATH_MSG_DEBUG( "Using: " << m_doFatJetHack );

  // Perform some sanity checks on the given container names
  if ( m_inCont.value().empty() || m_outCont.value().empty() ) {
    ATH_MSG_ERROR("Wrong user setup! You need to give a valid name for both the InputContainer and OutputContainer!");
    return StatusCode::FAILURE;
  }

  // Abort on an unchecked systematics code
  // CP::SystematicCode::enableFailure();

  // Retrieve the tools (if they are scheduled)
  if (!m_jetCalibTool.empty()) ATH_CHECK(m_jetCalibTool.retrieve());
  if (!m_jesUncertaintyTool.empty()) ATH_CHECK(m_jesUncertaintyTool.retrieve());
  if (!m_jesSysUncertaintyTool.empty()) ATH_CHECK(m_jesSysUncertaintyTool.retrieve());
  if (!m_jerSmearTool.empty()) ATH_CHECK(m_jerSmearTool.retrieve());



  // Configure the systematic variations due to the jet energy scale, if requested
  //---------------------------------------------------------------------------
  if (!m_jesSysUncertaintyTool.empty()){
    // Figure out what systematics are available and recommended for the jet energy scale
    if ( msgLvl(MSG::DEBUG) || msgLvl(MSG::VERBOSE) ) {
      CP::SystematicSet affSys = m_jesSysUncertaintyTool->affectingSystematics();
      std::string affSysNames = affSys.name();
      boost::replace_all( affSysNames, "-", "\", \"");
      affSysNames = "[\""+affSysNames+"\"]";
      ATH_MSG_DEBUG("Have " << affSys.size() << " affecting JES systematics with name "
                    << affSysNames << " for tool " << m_jesSysUncertaintyTool->name() );
      CP::SystematicSet recSys = m_jesSysUncertaintyTool->recommendedSystematics();
      std::string recSysNames = recSys.name();
      boost::replace_all( recSysNames, "-", "\", \"");
      recSysNames = "[\""+recSysNames+"\"]";
      ATH_MSG_DEBUG("Have " << recSys.size() << " recommended JES systematics with name "
                    << recSysNames << " for tool " << m_jesSysUncertaintyTool->name() );
    }

    // Set up the internal vector of systematics and container name post-fixes,
    // starting with the nominal one. First, clear it. Then, add the nominal, then systematics
    m_jesSystVarNameVec.clear();
    for ( const auto& sysName  :  m_jesSmearSysNames.value() ) {
      // here, we need to hack a bit. The tool only knows "__continuous" names and
      // NOT "__1up" or "__1down" names. So we need to massage the systematic name
      // accordingly...
      std::string newSysName = sysName;
      const std::string up{"__1up"};
      const std::string down{"__1down"};
      const std::string continiuous{"__continuous"};
      int sigmas = 0;
      std::size_t pos = 0;
      while ( (pos = newSysName.find(up, pos)) != std::string::npos ) {
        newSysName.replace(pos, up.length(), "");
        pos += 1;
        sigmas = 1;
      }
      pos = 0;
      if ( sigmas == 0 ) {
        while ( (pos = newSysName.find(down, pos)) != std::string::npos ) {
          newSysName.replace(pos, down.length(), "");
          pos += 1;
          sigmas = -1;
        }
      }
      // Now, massage the systematic name in the following matter:
      //   1.: If we run on full-sim, but the systeamtic has "AFII" in its name,
      //       we create the corresponding output container, but with the nominal calibration.
      //   2.: If we run on AtlFast2, but the systeamtic has "MC16" in its name,
      //       we create the corresponding output container, but with the nominal calibration.
      const std::string af2Name{"AFII"};
      const std::string mc16Name{"MC16"};
      bool useEmptySystematic = false;
      // If we have MC15 FullSim, look for 'AFII' in the systematic name and replace it with 'MC16'
      if ( m_mcType.value() == mc16Name ){
        if ( newSysName.find(af2Name) != std::string::npos ){
          boost::replace_all(newSysName, af2Name, mc16Name);
          useEmptySystematic = true;
        }
      }
      // If we have AtlFast2, look for 'MC16' in the systematic name and replace it with 'AFII'
      else if ( m_mcType.value() == af2Name ){
        if ( newSysName.find(mc16Name) != std::string::npos ){
          boost::replace_all(newSysName, mc16Name, af2Name);
          useEmptySystematic = true;
        }
      }

      // Now, create the SystematicVariation with the new name
      CP::SystematicVariation sysVar = CP::SystematicVariation(newSysName+continiuous);
      if ( m_jesSysUncertaintyTool->isAffectedBySystematic(sysVar) ) {
        CP::SystematicVariation sysVarForTool = CP::SystematicVariation( newSysName, static_cast<float>(sigmas) );
        CP::SystematicSet sysSet{sysVarForTool};

        // Create the output container name
        std::string fixedSysName = sysName;
        if ( !(m_jesNameSuffix.value().empty()) ){
          boost::replace_all( fixedSysName, "__", m_jesNameSuffix.value() + "__");
          ATH_MSG_VERBOSE("Changed the systematic suffix for the output container from " << sysName << " to " << fixedSysName);
        }
        const std::string outContName = m_outCont.value() + m_separator.value() + fixedSysName;
        if (useEmptySystematic){ m_jesSystVarNameVec.push_back( std::make_pair( CP::SystematicSet(), outContName ) ); }
        else {                   m_jesSystVarNameVec.push_back( std::make_pair( sysSet, outContName ) ); }
        ATH_MSG_VERBOSE("Adding systematic variation with name " << fixedSysName
                      << " and name as known to the tool: " << sysVarForTool.name() << " and usingEmptySystematics=" << useEmptySystematic );
      }
      else {
        CP::SystematicSet affSys = m_jesSysUncertaintyTool->affectingSystematics();
        std::string affSysNames = affSys.name();
        boost::replace_all( affSysNames, "-", "\", \"");
        affSysNames = "[\""+affSysNames+"\"]";
        ATH_MSG_WARNING("Couldn't find JES systematic variation with name " << sysVar.name()
                        << " amongst the affected systematics: " << affSysNames );
        return StatusCode::FAILURE;
      }
    } // End: adding all systematic variations to be processed
  } // End: setup JES systematics


  // Configure the systematic variations due to the jet energy resolution, if requested
  //---------------------------------------------------------------------------
  if (!m_jerSmearTool.empty()){
    // Figure out what systematics are available and recommended for the jet energy resolution
    if ( msgLvl(MSG::DEBUG) || msgLvl(MSG::VERBOSE) ) {
      CP::SystematicSet affSys = m_jerSmearTool->affectingSystematics();
      std::string affSysNames = affSys.name();
      std::replace( affSysNames.begin(), affSysNames.end(), '-', ',');
      ATH_MSG_DEBUG("Have " << affSys.size() << " affecting JER systematics with name "
                    << affSysNames << " for tool " << m_jerSmearTool->name() );
      CP::SystematicSet recSys = m_jerSmearTool->recommendedSystematics();
      std::string recSysNames = recSys.name();
      std::replace( recSysNames.begin(), recSysNames.end(), '-', ',');
      ATH_MSG_DEBUG("Have " << recSys.size() << " recommended JER systematics with name "
                    << recSysNames << " for tool " << m_jerSmearTool->name() );
    }

    // Set up the internal vector of systematics and container name post-fixes,
    // starting with the nominal one. First, clear it. Then, add the nominal, then systematics
    m_jerSystVarNameVec.clear();
    // m_jerSystVarNameVec.push_back( std::make_pair( CP::SystematicSet(), "" ) );
    for ( const auto& sysName  :  m_jerSmearSysNames.value() ) {
      CP::SystematicVariation sysVar = CP::SystematicVariation(sysName);
      if ( m_jerSmearTool->isAffectedBySystematic(sysVar) ) {
        CP::SystematicSet sysSet{sysVar};
        m_jerSystVarNameVec.push_back( std::make_pair( sysSet, m_separator.value()+sysName ) );
        ATH_MSG_DEBUG("Adding systematic variation with name " << sysName );
      }
      else {
        CP::SystematicSet affSys = m_jerSmearTool->affectingSystematics();
        std::string affSysNames = affSys.name();
        std::replace( affSysNames.begin(), affSysNames.end(), '-', ',');
        ATH_MSG_WARNING("Couldn't find JER systematic variation with name " << sysName
                        << " amongst the affected systematics: " << affSysNames );
        return StatusCode::FAILURE;
      }
    } // End: adding all systematic variations to be processed
  } // End: setup JER systematics

  return StatusCode::SUCCESS;
}



StatusCode HWW::JetCalibrationSmearingAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release the tools
  if (!m_jetCalibTool.empty()) ATH_CHECK(m_jetCalibTool.release());
  if (!m_jesUncertaintyTool.empty()) ATH_CHECK(m_jesUncertaintyTool.release());
  if (!m_jesSysUncertaintyTool.empty()) ATH_CHECK(m_jesSysUncertaintyTool.release());
  if (!m_jerSmearTool.empty()) ATH_CHECK(m_jerSmearTool.release());

  return StatusCode::SUCCESS;
}



StatusCode HWW::JetCalibrationSmearingAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Open the input container
  const xAOD::JetContainer* inCont;
  ATH_CHECK( evtStore()->retrieve( inCont, m_inCont.value() ));


  // First, apply the nominal jet calibration on this, if requested
  //---------------------------------------------------------------------------
  const xAOD::JetContainer* useAsInCont = nullptr;
  if (!m_jetCalibTool.empty()){
    // Let's create a shallow copy of the const input container
    auto inCalibContShallowCopy = xAOD::shallowCopyContainer( *inCont );
    ATH_CHECK( evtStore()->record( inCalibContShallowCopy.first,  m_outCont.value() ) );
    ATH_CHECK( evtStore()->record( inCalibContShallowCopy.second, m_outCont.value() + "Aux." ) );

    // Loop over all jets in the shallow-copy container
    for ( xAOD::Jet* jet : *(inCalibContShallowCopy.first) ) {
      ATH_MSG_VERBOSE("Now iterating over the calib jet shallow copy container... at index=" << jet->index() );
      const double originalPt = jet->pt();
      if ( m_jetCalibTool->applyCorrection(*jet) == CP::CorrectionCode::Error ) {
        ATH_MSG_ERROR("JetCalibrationTool reported a CP::CorrectionCode::Error");
        return StatusCode::FAILURE;
      }
      ATH_MSG_VERBOSE("Original pt: " << originalPt << " MeV, new pt: " << jet->pt()
                      << " MeV, original-new pt: " << originalPt - jet->pt() << " MeV" );
    } // End: loop over jets

    // Create the ElementLinks to the original jets.
    // Unfortunately, needed my missingET tools
    if ( !(xAOD::setOriginalObjectLink( *inCont, *(inCalibContShallowCopy.first) )) ) {
      ATH_MSG_FATAL("Couldn't set the ElementLink to the original container!");
      return StatusCode::FAILURE;
    }
    ATH_MSG_VERBOSE("Using calibrated shallowCopyContainer from now on");
    useAsInCont = inCalibContShallowCopy.first;
  } // End: jet calibration
  else {
    ATH_MSG_VERBOSE("Using original input container from now on");
    useAsInCont = inCont;
  }


  // Then, apply the systematic variations on additional shallow copy containers
  //---------------------------------------------------------------------------
  if (!m_jesUncertaintyTool.empty()){
    // If requested, also set for each jet a boolean flag, if this is a b-jet or
    // not using truth information). This is needed for some flavor-composition
    // dependent JES systeamtics. We need to do this only for the nominally
    // calibrated jets.
    if ( m_doBJES.value() ){
      SG::AuxElement::Decorator<char> decoIsBjet("IsBjet");
      for ( const xAOD::Jet* jet : *useAsInCont ) {
        ATH_MSG_VERBOSE("Now iterating over the jet container to apply truth b-tag info... at index=" << jet->index() );
        int label = -1;
        jet->getAttribute("HadronConeExclTruthLabelID",label);
        bool isBJet = false;
        if ( jet->pt() > 20.0*GeV && std::abs(jet->eta()) < 2.5 && label == 5 ){
          ATH_MSG_VERBOSE("Have a truth-tagged b-jet at index=" << jet->index());
          isBJet = true;
        }
        decoIsBjet(*jet) = static_cast<char>(isBJet);
      }
    }// Done with applying the truth b-tag info

    // Now, we will loop over the jet energy scale systematics to be applied
    for ( const auto& systVarAndContName : m_jesSystVarNameVec ) {
      const CP::SystematicSet& systSet = systVarAndContName.first;
      const std::string& contName      = systVarAndContName.second;

      // Let's create a shallow copy of the const input container
      auto inContShallowCopy = xAOD::shallowCopyContainer( *useAsInCont );
      ATH_CHECK( evtStore()->record( inContShallowCopy.first,  contName ) );
      ATH_CHECK( evtStore()->record( inContShallowCopy.second, contName + "Aux." ) );

      // Set the tool state to apply a systematic variation
      if( m_jesSysUncertaintyTool->applySystematicVariation( systSet ) != CP::SystematicCode::Ok ) {
        ATH_MSG_ERROR("Cannot configure JESUncertaintyTool for systematic variation " << systSet.name() );
        return StatusCode::FAILURE;
      }
      ATH_MSG_DEBUG("Going to run jet energy scale p4 systematic variation " << systSet.name()
                    << " over " << (inContShallowCopy.first)->size() << " jets "
                    << "and storing result in output container with name " << contName );

      // Loop over all jets in the shallow-copy container
      for ( xAOD::Jet* jet : *(inContShallowCopy.first) ) {
        const double originalPt = jet->pt();
        ATH_MSG_VERBOSE("Now iterating over the jet shallow copy container... at index=" << jet->index()
                        << ", pT=" << 0.001*originalPt << " GeV, eta=" << jet->eta()
                        << ", mass=" << jet->m()*0.001 << " GeV" );
        // Hardcoded hack to make the fat-jet tool not throw an ERROR
        if ( m_doFatJetHack.value() ){
          const bool passPt  = originalPt >= 150.0*GeV && originalPt < 3000.0*GeV;
          const bool passEta = std::abs(jet->eta()) < 2.0;
          const bool passAll = passPt && passEta && ( (jet->m())/originalPt < 1.0 ) && ( (jet->m())/originalPt > 0.0 );
          if ( !passAll ){
            ATH_MSG_VERBOSE("Current jet with index=" << jet->index() << " failed");
            continue;
          }
        } // End: do fat-jet hack
        if ( m_jesUncertaintyTool->applyCorrection(*jet) == CP::CorrectionCode::Error ) {
          ATH_MSG_ERROR("JESUncertaintyTool reported a CP::CorrectionCode::Error");
          return StatusCode::FAILURE;
        }
        ATH_MSG_VERBOSE("Original pt: " << originalPt << " MeV, new pt: " << jet->pt()
                        << " MeV, original-new pt: " << originalPt - jet->pt() << " MeV" );
      } // End: loop over jets

      // Create the ElementLinks to the original muons.
      // Unfortunately, needed my missingET tools
      if ( !(xAOD::setOriginalObjectLink( *inCont, *(inContShallowCopy.first) )) ) {
        ATH_MSG_FATAL("Couldn't set the ElementLink to the original container!");
        return StatusCode::FAILURE;
      }
    } // End: loop over JES systematic variations
  } // End: Apply JES systematic variations



  // Then, apply the jet energy resolution
  //---------------------------------------------------------------------------
  if (!m_jerSmearTool.empty()){
    // Now, we will loop over the jet energy resolution systematics to be applied
    for ( const auto& systVarAndContName : m_jerSystVarNameVec ) {
      const CP::SystematicSet& systSet = systVarAndContName.first;
      const std::string& contSuffix    = systVarAndContName.second;

      // Let's create a shallow copy of the const input container
      auto inContShallowCopy = xAOD::shallowCopyContainer( *useAsInCont );
      ATH_CHECK( evtStore()->record( inContShallowCopy.first,  m_outCont.value() + contSuffix ) );
      ATH_CHECK( evtStore()->record( inContShallowCopy.second, m_outCont.value() + contSuffix + "Aux." ) );

      // Set the tool state to apply a systematic variation
      if( m_jerSmearTool->applySystematicVariation( systSet ) != CP::SystematicCode::Ok ) {
        ATH_MSG_ERROR("Cannot configure JERSmearingTool for systematic variation " << systSet.name() );
        return StatusCode::FAILURE;
      }
      ATH_MSG_DEBUG("Going to run jet energy resolution p4 systematic variation " << systSet.name() );

      // Loop over all jets in the shallow-copy container
      for ( xAOD::Jet* jet : *(inContShallowCopy.first) ) {
        ATH_MSG_VERBOSE("Now iterating over the jet shallow copy container... at index=" << jet->index() );
        const double originalPt = jet->pt();
        if ( m_jerSmearTool->applyCorrection(*jet) == CP::CorrectionCode::Error ) {
          ATH_MSG_ERROR("JERSmearingTool reported a CP::CorrectionCode::Error");
          return StatusCode::FAILURE;
        }
        ATH_MSG_VERBOSE("Original pt: " << originalPt << " MeV, new pt: " << jet->pt()
                        << " MeV, original-new pt: " << originalPt - jet->pt() << " MeV" );
      } // End: loop over jets

      // Create the ElementLinks to the original muons.
      // Unfortunately, needed my missingET tools
      if ( !(xAOD::setOriginalObjectLink( *inCont, *(inContShallowCopy.first) )) ) {
        ATH_MSG_FATAL("Couldn't set the ElementLink to the original container!");
        return StatusCode::FAILURE;
      }

    } // End: loop over JER systematic variations
  } // End: JER application


  // TODO: Do the bookkeeping stuff

  return StatusCode::SUCCESS;
}
