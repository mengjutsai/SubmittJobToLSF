// METMakerAlg.cxx

#include "HWWMETMakerAlg.h"
#include "METInterface/IMETMaker.h"

#include "xAODMissingET/MissingETContainer.h"
#include "xAODMissingET/MissingETAuxContainer.h"
#include "xAODMissingET/MissingETComposition.h"
#include "xAODMissingET/MissingETAssociationMap.h"

#include "xAODJet/JetContainer.h"
#include "xAODEgamma/ElectronContainer.h"
#include "xAODEgamma/PhotonContainer.h"
#include "xAODMuon/MuonContainer.h"
#include "xAODTau/TauJetContainer.h"

#include "METUtilities/METHelpers.h"

namespace HWW {

  //**********************************************************************

  METMakerAlg::METMakerAlg(const std::string& name, ISvcLocator* pSvcLocator ) :
    ::AthAlgorithm( name, pSvcLocator ),
    m_mapname(""),
    m_corename(""),
    m_outname(""),
    m_outtrackname(""),
    m_jetColl(""),
    m_eleColl(""),
    m_gammaColl(""),
    m_tauColl(""),
    m_muonColl(""),
    m_doJVT(true),
    m_doMuonToJetAsso(false),
    m_metmaker("met::METMaker/met::METMaker")
  {
    declareProperty( "InputMETMap",    m_mapname,      "The name of the input MET map" );
    declareProperty( "InputMETCore",   m_corename,     "The name of the input MET core" );
    declareProperty( "OutputMET",      m_outname,      "The name of the newly created output MET container" );
    declareProperty( "OutputTrackMET", m_outtrackname, "The name of the newly created output TrackMET container" );

    declareProperty( "InputJets",      m_jetColl,      "The name of the input jet container" );
    declareProperty( "InputElectrons", m_eleColl,      "The name of the input electron container" );
    declareProperty( "InputPhotons",   m_gammaColl,    "The name of the input photon container" );
    declareProperty( "InputTaus",      m_tauColl,      "The name of the input tau container" );
    declareProperty( "InputMuons",     m_muonColl,     "The name of the input muon container" );

    declareProperty( "UseJVT",         m_doJVT,        "Decide if the JVT cut should be used or not (default: true)" );

    declareProperty( "DoMuonJetAssociation",
                     m_doMuonToJetAsso, "Decide if we want to do the muon-to-jet ghost association (default: false)" );

    declareProperty( "METMakerTool",   m_metmaker,     "Athena configured tool: the handle for the METMaker tool" );
  }


  //**********************************************************************


  METMakerAlg::~METMakerAlg() { }


  //**********************************************************************


  StatusCode METMakerAlg::initialize()
  {
    ATH_MSG_DEBUG("Initializing " << name() << "...");
    ATH_MSG_DEBUG( "Using: " << m_mapname );
    ATH_MSG_DEBUG( "Using: " << m_corename );
    ATH_MSG_DEBUG( "Using: " << m_outname );
    ATH_MSG_DEBUG( "Using: " << m_outtrackname );
    ATH_MSG_DEBUG( "Using: " << m_jetColl );
    ATH_MSG_DEBUG( "Using: " << m_eleColl );
    ATH_MSG_DEBUG( "Using: " << m_gammaColl );
    ATH_MSG_DEBUG( "Using: " << m_tauColl );
    ATH_MSG_DEBUG( "Using: " << m_muonColl );
    ATH_MSG_DEBUG( "Using: " << m_doJVT );
    ATH_MSG_DEBUG( "Using: " << m_doMuonToJetAsso );
    ATH_MSG_DEBUG( "Using: " << m_metmaker );

    // Some sanity checks of the user configuration
    if ( m_mapname.value().empty() ){
      ATH_MSG_FATAL("You need to specify: " << m_mapname );
      return StatusCode::FAILURE;
    }
    if ( m_corename.value().empty() ){
      ATH_MSG_FATAL("You need to specify: " << m_corename );
      return StatusCode::FAILURE;
    }
    if ( m_jetColl.value().empty() ){
      ATH_MSG_FATAL("You need to specify: " << m_jetColl );
      return StatusCode::FAILURE;
    }
    if ( m_outname.value().empty() && m_outtrackname.value().empty() ){
      ATH_MSG_FATAL("You need to specify either " << m_outname
                    << ", or " << m_outtrackname << ", or both!");
      return StatusCode::FAILURE;
    }

    // retrieve tools
    ATH_CHECK( m_metmaker.retrieve() );

    return StatusCode::SUCCESS;
  }


  //**********************************************************************


  StatusCode METMakerAlg::finalize()
  {
    ATH_MSG_DEBUG ("Finalizing " << name() << "...");

    // release tools
    ATH_CHECK( m_metmaker.release() );

    return StatusCode::SUCCESS;
  }


  //**********************************************************************


  StatusCode METMakerAlg::execute()
  {
    ATH_MSG_DEBUG("Executing " << name() << "...");

    const xAOD::MissingETAssociationMap* metMap = nullptr;
    ATH_CHECK( evtStore()->retrieve(metMap, m_mapname.value()) );
    metMap->resetObjSelectionFlags();

    // Retrieve containers ***********************************************

    /// MET
    const xAOD::MissingETContainer* coreMet = nullptr;
    ATH_CHECK( evtStore()->retrieve(coreMet, m_corename.value()) );

    /// Jets
    const xAOD::JetContainer* jetCont = nullptr;
    ATH_CHECK( evtStore()->retrieve(jetCont, m_jetColl.value()) );
    ATH_MSG_DEBUG("Successfully retrieved jet collection with name: " << m_jetColl.value() );

    /// Electrons
    const xAOD::ElectronContainer* elCont = nullptr;
    if ( !m_eleColl.value().empty() ){
      ATH_CHECK( evtStore()->retrieve(elCont, m_eleColl.value()) );
      ATH_MSG_DEBUG("Successfully retrieved electron collection with name: " << m_eleColl.value() );
    }

    /// Photons
    const xAOD::PhotonContainer* phCont = nullptr;
    if ( !m_gammaColl.value().empty() ){
      ATH_CHECK( evtStore()->retrieve(phCont, m_gammaColl.value()) );
      ATH_MSG_DEBUG("Successfully retrieved photon collection with name: " << m_gammaColl.value() );
    }

    /// Taus
    const xAOD::TauJetContainer* tauCont = nullptr;
    if ( !m_tauColl.value().empty() ){
      ATH_CHECK( evtStore()->retrieve(tauCont, m_tauColl.value()) );
      ATH_MSG_DEBUG("Successfully retrieved tau collection with name: " << m_tauColl.value() );
    }

    /// Muons
    const xAOD::MuonContainer* muonCont = nullptr;
    if ( !m_muonColl.value().empty() ){
      ATH_CHECK( evtStore()->retrieve(muonCont, m_muonColl.value()) );
      ATH_MSG_DEBUG("Successfully retrieved muon collection with name: " << m_muonColl.value() );
    }


    // First, ghost associate muons to jets, if requested
    if ( muonCont && jetCont && m_doMuonToJetAsso.value() ){
      ATH_MSG_DEBUG("Performing the muon-to-jet ghost association");
      met::addGhostMuonsToJets(*muonCont, const_cast<xAOD::JetContainer&>(*jetCont));
    }

    // Create a MissingETContainer with its aux store
    xAOD::MissingETContainer* newMet = new xAOD::MissingETContainer();
    xAOD::MissingETAuxContainer* metAuxCont = new xAOD::MissingETAuxContainer();
    newMet->setStore(metAuxCont);


    // Rebuild the individual MET terms from the provided objects **************

    // Electrons
    if (elCont){
      ATH_MSG_DEBUG("Rebuilding electron term");
      ATH_CHECK( m_metmaker->rebuildMET("RefEle",
                                        xAOD::Type::Electron,
                                        newMet,
                                        elCont,
                                        metMap) );
    }

    // Photons
    if (phCont){
      ATH_MSG_DEBUG("Rebuilding photon term");
      ATH_CHECK( m_metmaker->rebuildMET("RefGamma",
                                        xAOD::Type::Photon,
                                        newMet,
                                        phCont,
                                        metMap) );
    }

    // Taus
    if (tauCont){
      ATH_MSG_DEBUG("Rebuilding tau term");
      ATH_CHECK( m_metmaker->rebuildMET("RefTau",
                                        xAOD::Type::Tau,
                                        newMet,
                                        tauCont,
                                        metMap) );
    }

    // Muons
    if (muonCont){
      ATH_MSG_DEBUG("Rebuilding muon term");
      ATH_CHECK( m_metmaker->rebuildMET("Muons",
                                        xAOD::Type::Muon,
                                        newMet,
                                        muonCont,
                                        metMap) );
    }

    // Track-based MET, if requested
    if ( !(m_outtrackname.value().empty()) ){
      ATH_MSG_DEBUG("Rebuilding TackMET");
      // Create a MissingETContainer with its aux store for the track-based MET
      // and copy over the already created MET terms from the normal newMet container
      xAOD::MissingETContainer* newTrackMet = new xAOD::MissingETContainer();
      ATH_CHECK( evtStore()->record(newTrackMet, m_outtrackname.value()) );
      xAOD::MissingETAuxContainer* metTrackAuxCont = new xAOD::MissingETAuxContainer();
      ATH_CHECK( evtStore()->record(metTrackAuxCont, m_outtrackname.value()+"Aux.") );
      newTrackMet->setStore(metTrackAuxCont);

      // Copy over all already recalculated terms
      for ( const xAOD::MissingET* recalcMet : *newMet ){
        xAOD::MissingET* newTerm = new xAOD::MissingET();
        newTrackMet->push_back(newTerm);
        *newTerm = *recalcMet;
      }

      // The track-based jet term
      ATH_CHECK( m_metmaker->rebuildTrackMET("RefJetTrk",
                                             "PVSoftTrk",
                                             newTrackMet,
                                             jetCont,
                                             coreMet,
                                             metMap,
                                             m_doJVT.value()) );

      // Final track met
      ATH_CHECK( m_metmaker->buildMETSum("FinalTrk",  newTrackMet, MissingETBase::Source::Track) );
      ATH_CHECK( m_metmaker->buildMETSum("FinalClus", newTrackMet, MissingETBase::Source::LCTopo) );

    } // End: track-based missingET calculation


    // Now, back to the normal met calculation, if requested
    if ( !(m_outname.value().empty()) ){
      ATH_MSG_DEBUG("Rebuilding MET");

      // Actually record the new MET containers to StoreGate
      ATH_CHECK( evtStore()->record(newMet, m_outname.value()) );
      ATH_CHECK( evtStore()->record(metAuxCont, m_outname.value()+"Aux.") );

      // Jets
      ATH_CHECK( m_metmaker->rebuildJetMET("RefJet",
                                           "SoftClus",
                                           "PVSoftTrk",
                                           newMet,
                                           jetCont,
                                           coreMet,
                                           metMap,
                                           m_doJVT.value()) );

      // Final
      ATH_CHECK( m_metmaker->buildMETSum("FinalTrk",  newMet, MissingETBase::Source::Track) );
      ATH_CHECK( m_metmaker->buildMETSum("FinalClus", newMet, MissingETBase::Source::LCTopo) );
    }
    else {
      // Clean up in case the new MET containers were not recorded to StoreGate
      delete newMet;
      delete metAuxCont;
    }

    return StatusCode::SUCCESS;
  }
}
