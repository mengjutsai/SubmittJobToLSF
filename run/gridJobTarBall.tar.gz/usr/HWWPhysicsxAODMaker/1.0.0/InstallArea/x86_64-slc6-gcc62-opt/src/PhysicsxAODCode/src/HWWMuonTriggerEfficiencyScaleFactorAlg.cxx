///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMuonTriggerEfficiencyScaleFactorAlg.cxx
// Implementation file for class HWW::MuonTriggerEfficiencyScaleFactorAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWMuonTriggerEfficiencyScaleFactorAlg.h"

// STL includes
#include <set>
#include <climits>
#include <cmath>

// boost includes
#include <boost/algorithm/string/predicate.hpp>
#include <boost/algorithm/string/replace.hpp>


// FrameWork includes
#include "GaudiKernel/SystemOfUnits.h"

// EDM includes
#include "AthContainers/ConstDataVector.h"
#include "xAODEventInfo/EventInfo.h"
#include "xAODCore/ShallowCopy.h"
#include "xAODMuon/Muon.h"
#include "xAODMuon/MuonContainer.h"
#include "xAODMuon/MuonAuxContainer.h"
#include "xAODParticleEvent/IParticleLink.h"

// Tool includes
#include "MuonAnalysisInterfaces/IMuonTriggerScaleFactors.h"
#include "PATInterfaces/ISystematicsTool.h"
#include "PATInterfaces/SystematicCode.h"
#include "PATInterfaces/SystematicSet.h"
#include "PATInterfaces/SystematicVariation.h"




// Getting the GeV and such units
using namespace Gaudi::Units;


// Constructors
////////////////
HWW::MuonTriggerEfficiencyScaleFactorAlg::MuonTriggerEfficiencyScaleFactorAlg( const std::string& name,
                                                                               ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_inCont(""),
  m_contFindTool("HWW::ContainersFinderTool/ContainersFinderTool"),
  m_decoAllCopies(true),
  m_separator("___"),
  m_muEffiSFTool2015List(),
  m_muEffiSFTool2016List(),
  m_muEffSFVarNameList(),
  m_muEffSFSysNames(),
  m_muTrigName2015List(),
  m_muTrigName2016List(),
  m_useDataEffi(false),
  m_effiSystVarNameVec()
{
  //
  // Property declaration
  //
  declareProperty("InputContainer",       m_inCont,        "Input container name" );
  declareProperty("ContainersFinderTool", m_contFindTool,  "The tool that tries to find all input containers, including their systematic variations" );
  declareProperty("DecorateAllCopies",    m_decoAllCopies, "If true, will decorate all copies of the input container" );

  declareProperty("Separator", m_separator,
                  "The string seperator between the output container name and the sytematic variation (default='___')" );

  declareProperty("MuonEfficiencyScaleFactorTools2015", m_muEffiSFTool2015List,
                  "The ToolHandle for the muon efficiency scale factor tool for 2015" );
  declareProperty("MuonEfficiencyScaleFactorTools2016", m_muEffiSFTool2016List,
                  "The ToolHandle for the muon efficiency scale factor tool for 2016" );

  declareProperty("EfficiencyScaleFactorVarNames", m_muEffSFVarNameList,
                  "The name of the efficiency scale-factor variable that will be added to the muon" );

  declareProperty("EfficiencySystematicVariations", m_muEffSFSysNames,
                  "The names of all systematic variations to be applied" );

  declareProperty("EfficiencyVarNames", m_muEffVarNameList,
                  "The name of the efficiency variables that will be added to the muon" );

  declareProperty("TriggerNames2015", m_muTrigName2015List, "The names of the 2015 triggers to be used" );
  declareProperty("TriggerNames2016", m_muTrigName2016List, "The names of the 2016 triggers to be used" );

  declareProperty("GetDataEfficiency", m_useDataEffi,
                  "Set to true, if we want the data efficiency (default: false)" );
}



// Destructor
///////////////
HWW::MuonTriggerEfficiencyScaleFactorAlg::~MuonTriggerEfficiencyScaleFactorAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::MuonTriggerEfficiencyScaleFactorAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inCont );
  ATH_MSG_DEBUG( "Using: " << m_contFindTool );
  ATH_MSG_DEBUG( "Using DecorateAllCopies: " << m_decoAllCopies );
  ATH_MSG_DEBUG( "Using: " << m_separator );
  ATH_MSG_DEBUG( "Using: " << m_muEffiSFTool2015List );
  ATH_MSG_DEBUG( "Using: " << m_muEffiSFTool2016List );
  ATH_MSG_DEBUG( "Using: " << m_muEffSFVarNameList );
  ATH_MSG_DEBUG( "Using: " << m_muEffSFSysNames );
  ATH_MSG_DEBUG( "Using: " << m_muEffVarNameList );
  ATH_MSG_DEBUG( "Using: " << m_muTrigName2015List );
  ATH_MSG_DEBUG( "Using: " << m_muTrigName2016List );
  ATH_MSG_DEBUG( "Using GetDataEfficiency: " << m_useDataEffi );

  // Perform some sanity checks on the given container names
  if ( m_inCont.value().empty() ) {
    ATH_MSG_FATAL("Wrong user setup! You need to give a valid name for both the InputContainer!");
    return StatusCode::FAILURE;
  }

  // Abort on an unchecked systematics code
  // CP::SystematicCode::enableFailure();

  // Retrieve the tools
  ATH_CHECK(m_contFindTool.retrieve());
  ATH_CHECK(m_muEffiSFTool2015List.retrieve());
  ATH_CHECK(m_muEffiSFTool2016List.retrieve());
  // Check that we have at least one tool in the list
  if ( m_muEffiSFTool2015List.empty() ){
    ATH_MSG_FATAL("No muon efficiency scale factor tool given... stopping!");
    return StatusCode::FAILURE;
  }

  // Check that we get the same number of 2015 tools as 2016 tools
  if ( m_muEffiSFTool2015List.size() != m_muEffiSFTool2016List.size() ){
    ATH_MSG_FATAL("Got " << m_muEffiSFTool2015List.size() << " muon 2015 trigger efficiency tools, but "
                  << m_muEffiSFTool2016List.size() << " muon 2016 trigger efficiency tools... stopping!");
    return StatusCode::FAILURE;
  }

  // Check that we get the same number of 2015 trigger names as 2016 trigger names
  if ( m_muTrigName2015List.value().size() != m_muTrigName2016List.value().size() ){
    ATH_MSG_FATAL("Got " << m_muTrigName2015List.value().size() << " muon 2015 trigger names, but "
                  << m_muTrigName2016List.value().size() << " muon 2016 trigger names... stopping!");
    return StatusCode::FAILURE;
  }

  // Check that we get the same number of 2015 trigger names as 2015 trigger tools
  if ( m_muTrigName2015List.value().size() != m_muEffiSFTool2015List.size() ){
    ATH_MSG_FATAL("Got " << m_muTrigName2015List.value().size() << " muon 2015 trigger names, but "
                  << m_muEffiSFTool2015List.size() << " muon 2015 trigger efficiency tools... stopping!");
    return StatusCode::FAILURE;
  }

  // Check that we have the same number of efficiency variable names as tools.
  // Since we can have either EfficiencyVarNames and/or EfficiencyScaleFactorVarNames,
  // we need to test both
  if (    ( m_muEffVarNameList.value().size()   && m_muEffiSFTool2015List.size() != m_muEffVarNameList.value().size()   )
       || ( m_muEffSFVarNameList.value().size() && m_muEffiSFTool2015List.size() != m_muEffSFVarNameList.value().size() ) ){
    ATH_MSG_FATAL("Got " << m_muEffiSFTool2015List.size() << " muon trigger efficiency tools, but "
                  << m_muEffVarNameList.value().size() << " efficiency variable names and "
                  << m_muEffSFVarNameList.value().size() << " efficiency scale-factor variable names... stopping!");
    return StatusCode::FAILURE;
  }

  // Figure out what systematics are available and recommended
  if ( msgLvl(MSG::DEBUG) || msgLvl(MSG::VERBOSE) ) {
    CP::SystematicSet affSys = m_muEffiSFTool2015List[0]->affectingSystematics();
    std::string affSysNames = affSys.name();
    boost::replace_all( affSysNames, "-", "\", \"");
    affSysNames = "[\""+affSysNames+"\"]";
    ATH_MSG_DEBUG("Have " << affSys.size() << " affecting systematics with name "
                  << affSysNames << " for tool " << m_muEffiSFTool2015List[0]->name() );
    CP::SystematicSet recSys = m_muEffiSFTool2015List[0]->recommendedSystematics();
    std::string recSysNames = recSys.name();
    boost::replace_all( recSysNames, "-", "\", \"");
    recSysNames = "[\""+recSysNames+"\"]";
    ATH_MSG_DEBUG("Have " << recSys.size() << " recommended systematics with name "
                  << recSysNames << " for tool " << m_muEffiSFTool2015List[0]->name() );
  }

  // Set up the internal vector of systematics and container name post-fixes,
  // starting with the nominal one. First, clear it. Then, add the nominal, then systematics
  m_effiSystVarNameVec.clear();
  std::size_t maxIdx  = m_muEffSFVarNameList.value().size();
  if (!maxIdx) maxIdx = m_muEffVarNameList.value().size();
  for ( std::size_t i=0; i<maxIdx; ++i ){
    std::string effSFName = "";
    std::string effName   = "";
    if (m_muEffSFVarNameList.value().size()) effSFName = m_muEffSFVarNameList.value()[i];
    if (m_muEffVarNameList.value().size())   effName   = m_muEffVarNameList.value()[i];
    // Make a vector that will hold for this trigger the nominal variable names and all systematic ones
    std::vector< std::pair< CP::SystematicSet, std::pair<std::string, std::string> > > tmpVec;
    // Add the nominal one
    tmpVec.push_back( std::make_pair( CP::SystematicSet(), std::make_pair(effSFName,effName) ) );
    // Now, loop over all systeamtics
    for ( const std::string& sysName  :  m_muEffSFSysNames.value() ) {
      CP::SystematicVariation sysVar = CP::SystematicVariation(sysName);
      if ( m_muEffiSFTool2015List[0]->isAffectedBySystematic(sysVar) ) {
        CP::SystematicSet sysSet{sysVar};
        const std::string tmpEffSFName = effSFName.empty() ?  ""  :  effSFName + m_separator.value() + sysName;
        tmpVec.push_back( std::make_pair( sysSet, std::make_pair(tmpEffSFName,"") ) );
        ATH_MSG_DEBUG("Adding systematic variation with name " << sysName );
      }
      else {
        CP::SystematicSet affSys = m_muEffiSFTool2015List[0]->affectingSystematics();
        std::string affSysNames = affSys.name();
        boost::replace_all( affSysNames, "-", "\", \"");
        affSysNames = "[\""+affSysNames+"\"]";
        ATH_MSG_WARNING("Couldn't find systematic variation with name " << sysName
                        << " amongst the affected systematics: " << affSysNames );
        return StatusCode::FAILURE;
      }
    } // Done looping over all systematic names
    m_effiSystVarNameVec.push_back(tmpVec);
  } // Done looping over all trigger names

  // Check that we get the same number of 2015 trigger names as the build vector of systemaics and variables
  if ( m_muTrigName2015List.value().size() != m_effiSystVarNameVec.size() ){
    ATH_MSG_FATAL("Got " << m_muTrigName2015List.value().size() << " muon 2015 trigger names, but "
                  << m_effiSystVarNameVec.size() << " assambled vector of sytematics and variable names... stopping!");
    return StatusCode::FAILURE;
  }

  return StatusCode::SUCCESS;
}



StatusCode HWW::MuonTriggerEfficiencyScaleFactorAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release the tools
  ATH_CHECK(m_muEffiSFTool2015List.release());
  ATH_CHECK(m_muEffiSFTool2016List.release());
  ATH_CHECK(m_contFindTool.release());

  return StatusCode::SUCCESS;
}



StatusCode HWW::MuonTriggerEfficiencyScaleFactorAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Open EventInfo container
  const xAOD::EventInfo* evtInfo;
  ATH_CHECK( evtStore()->retrieve(evtInfo) );
  // Don't process this event, if it is data
  const bool isSim = evtInfo->eventType(xAOD::EventInfo::EventType::IS_SIMULATION);
  if ( !isSim ) {
    ATH_MSG_DEBUG ("It is a data event... nothing to be done...");
    return StatusCode::SUCCESS;
  }

  // Get the current random run number
  unsigned int randomRunNumber = 282625; // Default to period 2015J, i.e, largest period in 2015
  if ( evtInfo->isAvailable<unsigned int>("RandomRunNumber") ){
    ATH_MSG_VERBOSE("The RandomRunNumber is available");
    unsigned int runNum = evtInfo->auxdata<unsigned int>("RandomRunNumber");
    ATH_MSG_DEBUG("Got RandomRunNumber " << runNum << " from EventInfo");
    if (runNum) randomRunNumber = runNum;
  }
  else{
    ATH_MSG_WARNING("We are running on MC, but no RandomRunNumber is available... you need to schedule the PileupReweightingTool");
  }

  // Get the number of tools that we will iterate over
  const std::size_t nTools = m_muEffiSFTool2015List.size();


  // Now, let's try to get all requested containers and iterate over them.
  // If not specifically requested to get all copies, only the exactly given
  // name will be retrieved. Otherwise, all containers with the same base-name,
  // i.e, the part before the "___", if present, will be used.
  // Do this expensive string manupulation and StoreGate search only the first time.
  if (m_inContNameAndSysTypeList.empty()){
    if (m_decoAllCopies){
      ATH_CHECK( m_contFindTool->muonNamesAndSysTypes( m_inContNameAndSysTypeList, m_inCont.value() ) );
      ATH_MSG_DEBUG("Found " << m_inContNameAndSysTypeList.size() << " input containers to run over");
    }
    else {
      m_inContNameAndSysTypeList.push_back( std::make_pair( m_inCont.value(), HWW::SystematicType::NOMINAL ) );
      ATH_MSG_DEBUG("Only using the one given input container name to run over");
    }
  }


  // Hard-code the single-muon trigger name starting with 2016 period D4
  const std::string singleMuonTrigName2016A  = "HLT_mu24_ivarmedium_OR_HLT_mu50";
  const std::string singleMuonTrigName2016D4 = "HLT_mu26_ivarmedium_OR_HLT_mu50";


  // Open the input container
  for ( std::size_t contIdx=0; contIdx<m_inContNameAndSysTypeList.size(); ++contIdx ) {
    const xAOD::MuonContainer* inCont;
    ATH_CHECK( evtStore()->retrieve( inCont, m_inContNameAndSysTypeList.at(contIdx).first ));
    if ( inCont->size() == 0 ) {
      ATH_MSG_DEBUG("Have an empty input container... going to the next");
      continue;
    }
    ATH_MSG_VERBOSE("Now reading input container with name: " << m_inContNameAndSysTypeList.at(contIdx).first
                    << " and size: " << " " << inCont->size());

    // Check the systematics type of the input container
    HWW::SystematicType inContSysType = m_inContNameAndSysTypeList.at(contIdx).second;

    // Loop over the different tools that are provided
    for ( std::size_t toolIdx=0; toolIdx<nTools; ++toolIdx){
      // Get the tool for 2015 or 2016, depending on the run number,
      // as well as the trigger name
      CP::IMuonTriggerScaleFactors* muEffiSFTool = nullptr;
      const std::string* trigName = nullptr;
      if (randomRunNumber < 290000){
        ATH_MSG_VERBOSE("Got random run number " << randomRunNumber << " from 2015 with corresponding trigger name " << m_muTrigName2015List.value()[toolIdx] );
        muEffiSFTool = dynamic_cast<CP::IMuonTriggerScaleFactors*>(m_muEffiSFTool2015List[toolIdx].get());
        trigName = &(m_muTrigName2015List.value()[toolIdx]);
      }
      else{
        ATH_MSG_VERBOSE("Got random run number " << randomRunNumber << " from 2016 with corresponding trigger name " << m_muTrigName2016List.value()[toolIdx]);
        muEffiSFTool = dynamic_cast<CP::IMuonTriggerScaleFactors*>(m_muEffiSFTool2016List[toolIdx].get());
        trigName = &(m_muTrigName2016List.value()[toolIdx]);
        // Now, do a special case for for run numbers starting with 2016 D4 and the single-muon trigger name
        if (randomRunNumber >= 302919 && (*trigName) == singleMuonTrigName2016A ){
          ATH_MSG_VERBOSE("Got random run number " << randomRunNumber << " from 2016 starting at D4 with corresponding trigger name " << singleMuonTrigName2016D4);
          trigName = &singleMuonTrigName2016D4;
        }
      }
      // Set the current run number for the tool
/*      if( muEffiSFTool->setRunNumber( static_cast<int>(randomRunNumber) ) != CP::CorrectionCode::Ok ) {
        ATH_MSG_ERROR("Cannot configure MuonTriggerScaleFactors with random run number " << randomRunNumber );
        return StatusCode::FAILURE;
      }*/ //mgeisen change

      // Get also the current vector of systematics and variable names corresponding to the current trigger name
      const std::vector< std::pair< CP::SystematicSet, std::pair<std::string, std::string> > >& tmpSysVarVec = m_effiSystVarNameVec[toolIdx];
      // Now, lets loop over all systematic uncertainties and the corresponding variable names for this current trigger
      for ( const auto& systVariationAndVarName : tmpSysVarVec ){
        const CP::SystematicSet& systSet                       = systVariationAndVarName.first;
        const std::pair<std::string, std::string>& varNamePair = systVariationAndVarName.second;
        const std::string& varName    = varNamePair.first;
        const std::string& effVarName = varNamePair.second;

        // Set the tool state to apply a systematic variation.
        // Event if it is an empty variation, i.e, the nominal case, set the
        // state of the tool to that to avoid that the tool is still in a
        // systematic state from the previous event.
        ATH_MSG_VERBOSE("Name of the next variation: " << systSet.name() );
        if( muEffiSFTool->applySystematicVariation( systSet ) != CP::SystematicCode::Ok ) {
          ATH_MSG_ERROR("Cannot configure MuonEfficiencyScaleFactors for systematic variation " << systSet.name() );
          return StatusCode::FAILURE;
        }
        if ( !((systSet.name()).empty()) ) {
          // If we are NOT on the nominally calibrated 4-vector container, but
          // rather on a container with systematically varied 4-vectors, we
          // actually don't also apply the systematically varied scale factors,
          // i.e., we don't have both systematics (4-vector AND efficiency) at the
          // same time.
          if ( inContSysType == HWW::SystematicType::FOURMOM ) {
            ATH_MSG_DEBUG("We encountered an efficiency systematic set. "
                          << "but we are currenlty looking at a container with "
                          << "a systematically varied 4-vector... thus skipping.");
            // We can actually break out of the loop over efficiency systematics
            // here, because the nominal efficiency is always the first one in our
            // set of efficiency "systematics"
            break;
          }
        }
        ATH_MSG_DEBUG("Going to run muon efficiency scale-factor systematic variation (empty=nominal): " << systSet.name() );

        // Run the scale factors only if we have a variable name
        if ( !(varName.empty()) ) {
          // Create the accassor for the new variable that will hold the efficiency scale factor
          SG::AuxElement::Decorator<float> decoSetEffiSF(varName);

          // Loop over all Muons in the current input container
          for ( const xAOD::Muon* muon : *inCont ) {
            ATH_MSG_VERBOSE("Now iterating over the muon container for scale-factors... at index=" << muon->index() );
            // Need to create a muon container as the trigger scale-factor method wants a container
            ConstDataVector<xAOD::MuonContainer> muons = ConstDataVector<xAOD::MuonContainer>(SG::VIEW_ELEMENTS);
            muons.push_back( muon );
            double effiSFValue(1.0);
            const xAOD::MuonContainer* muonCont = static_cast<const xAOD::MuonContainer*>(muons.asDataVector());
            if ( muEffiSFTool->getTriggerScaleFactor(*muonCont,effiSFValue,*trigName) == CP::CorrectionCode::Error ) {
              ATH_MSG_ERROR("MuonTriggerScaleFactors reported a CP::CorrectionCode::Error");
              return StatusCode::FAILURE;
            }
            // Decorate the current muon with the resulting efficiency scale-factor
            ATH_MSG_VERBOSE("Decorating the muon with a trigger efficiency scale-factor variable with name "
                            << varName << " and value " << effiSFValue << " for trigger " << *trigName );
            decoSetEffiSF(*muon) = static_cast<float>(effiSFValue);
          } // End: loop over Muons
        } // End: have variable name

        // Do also the trigger efficiencies. This is only available for the nominal ones
        if ( !(effVarName.empty()) ){
          // Create the accassor for the new variable that will hold the efficiency scale factor
          SG::AuxElement::Decorator<float> accSetEffi(effVarName);

          // Loop over all Muons in the current input container
          for ( const xAOD::Muon* muon : *inCont ) {
            ATH_MSG_VERBOSE("Now iterating over the muon container for efficiencies... at index=" << muon->index() );
            double effiValue(0.0);
            if ( muEffiSFTool->getTriggerEfficiency(*muon,effiValue,*trigName,m_useDataEffi) == CP::CorrectionCode::Error ) {
              ATH_MSG_ERROR("MuonEfficiencyScaleFactors reported a CP::CorrectionCode::Error");
              return StatusCode::FAILURE;
            }
            // Decorate the current muon with the resulting efficiency scale-factor
            ATH_MSG_VERBOSE("Decorating the muon with an efficiency scale-factor variable with name "
                            << effVarName << " and value " << effiValue );
            accSetEffi(*muon) = effiValue;
          } // End: loop over Muons
        } // End: do also the trigger efficiencies

      } // End: loop over systematic variations

    } // End: loop over the scale-factor tools

  } // End: loop over input containers


  // TODO: Do the bookkeeping stuff

  return StatusCode::SUCCESS;
}
