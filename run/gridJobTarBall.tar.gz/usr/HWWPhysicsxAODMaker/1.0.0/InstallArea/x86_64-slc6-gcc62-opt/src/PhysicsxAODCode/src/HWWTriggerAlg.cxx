//  includes
#include "HWWTriggerAlg.h"

// EDM includes
#include "xAODMuon/MuonContainer.h"
#include "xAODEgamma/ElectronContainer.h"

// Tool includes
#include "PhysicsxAODCode/IHWWTriggerTool.h"

#include <bitset>

HWW::TriggerAlg::TriggerAlg( const std::string& name, ISvcLocator* pSvcLocator ):
  AthAlgorithm( name, pSvcLocator ),
  m_doMuonMatch(false),
  m_doElectronMatch(false),
  m_doDiMuMatch(false),
  m_doDiElMatch(false),
  m_doElMuMatch(false),
  m_varPrefix("trigMatch_")
{

  declareProperty("TrigTool", m_TrigTool, "The HWWTriggerTool" );
  declareProperty("Muons", m_inMuons, "The name of the input muon collection" );
  declareProperty("Electrons", m_inElectrons, "The name of the input electron collection" );
  declareProperty("PerformMuonMatch", m_doMuonMatch, "The switch for the muon trigger matching" );
  declareProperty("PerformElectronMatch", m_doElectronMatch, "The switch for the electron trigger matching" );
  declareProperty("PerformDiMuMatch", m_doDiMuMatch, "The switch for the di-muon trigger matching" );
  declareProperty("PerformDiElMatch", m_doDiElMatch, "The switch for the di-electron trigger matching" );
  declareProperty("PerformElMuMatch", m_doElMuMatch, "The switch for the electron-muon trigger matching" );
  declareProperty("VarPrefix", m_varPrefix, "Prefix used for the decoration variables" );
}


HWW::TriggerAlg::~TriggerAlg() {}


StatusCode HWW::TriggerAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_TrigTool );
  ATH_MSG_DEBUG( "Using: " << m_inMuons );
  ATH_MSG_DEBUG( "Using: " << m_inElectrons );
  ATH_MSG_DEBUG( "Perform muon trigger matching: " << m_doMuonMatch );
  ATH_MSG_DEBUG( "Perform electron trigger matching: " << m_doElectronMatch );
  ATH_MSG_DEBUG( "Perform di-muon trigger matching: " << m_doDiMuMatch );
  ATH_MSG_DEBUG( "Perform di-electron trigger matching: " << m_doDiElMatch );
  ATH_MSG_DEBUG( "Perform electron-muon trigger matching: " << m_doElMuMatch );

  ATH_CHECK(m_TrigTool.retrieve());

  return StatusCode::SUCCESS;
}


StatusCode HWW::TriggerAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release all tools
  ATH_CHECK( m_TrigTool.release() );

  return StatusCode::SUCCESS;
}


StatusCode HWW::TriggerAlg::execute()
{
  ATH_MSG_DEBUG("Executing " << name() << "...");

  // Get input containers
  const xAOD::MuonContainer* muons(0);
  if( !m_inMuons.value().empty() ) {
    ATH_CHECK( evtStore()->retrieve(muons, m_inMuons.value()) );
    ATH_MSG_DEBUG( "Muon container with name " << m_inMuons.value() <<" and size: " << muons->size() );
  }
  const xAOD::ElectronContainer* electrons(0);
  if( !m_inElectrons.value().empty() ) {
    ATH_CHECK( evtStore()->retrieve(electrons, m_inElectrons.value()) );
    ATH_MSG_DEBUG( "Electron container with name " << m_inElectrons.value() <<" and size: " << electrons->size() );
  }

  // Do the muon trigger matching, if requested
  if( m_doMuonMatch ) {
    if( !muons ) {
      ATH_MSG_ERROR( "Trying to perform muon trigger matching without input muons, abort..." );
      return StatusCode::FAILURE;
    }
    // Perform muon trigger matching on input muons and decorate them with the results
    m_TrigTool->match(muons);
  }

  // Do the electron trigger matching, if requested
  if( m_doElectronMatch ) {
    if( !electrons ) {
      ATH_MSG_ERROR( "Trying to perform electron trigger matching without input electrons, abort..." );
      return StatusCode::FAILURE;
    }
    // Perform electron trigger matching on input electrons and decorate them with the results
    m_TrigTool->match(electrons);
  }

  // Do the electron-muon trigger matching, if requested
  if( m_doElMuMatch ) {
    if( !muons || !electrons ) {
      ATH_MSG_ERROR( "Trying to perform electron-muon trigger matching without input muons or electrons, abort..." );
      return StatusCode::FAILURE;
    }

    if( !muons->size() || !electrons->size() ) {
      ATH_MSG_DEBUG( "Not an electron+muon event, skip electron-muon trigger matching..." );
    }
    else {
      m_TrigTool->match(muons, electrons);
    }
  }

  return StatusCode::SUCCESS;
}
