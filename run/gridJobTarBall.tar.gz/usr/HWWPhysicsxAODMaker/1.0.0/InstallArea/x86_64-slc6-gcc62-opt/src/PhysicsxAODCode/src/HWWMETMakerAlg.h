///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMETMakerAlg.h

#ifndef HWWCOMMONXAODCODE_HWWMETMAKERALG_H
#define HWWCOMMONXAODCODE_HWWMETMAKERALG_H

#include "AthenaBaseComps/AthAlgorithm.h"
#include "GaudiKernel/ToolHandle.h"

// Forward declarations
class IMETMaker;



namespace HWW {
  class METMakerAlg : public AthAlgorithm {

  public:

    /// Constructor with parameters:
    METMakerAlg(const std::string& name, ISvcLocator* pSvcLocator);

    /// Destructor:
    ~METMakerAlg();

    /// @name  Athena algorithm's Hooks
    /// @{

    /// The framework's initialize method. Called once before the event loop
    virtual StatusCode  initialize();

    /// The framework's exectue method. Called once for every event
    virtual StatusCode  execute();

    /// The framework's initialize method. Called once after the event loop
    virtual StatusCode  finalize();

    /// @}

  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// The name of the input MET map
    StringProperty m_mapname;

    /// The name of the input MET core
    StringProperty m_corename;

    /// The name of the newly created output MET container
    StringProperty m_outname;

    /// The name of the newly created output TrackMET container
    StringProperty m_outtrackname;


    /// The name of the input jet container
    StringProperty m_jetColl;

    /// The name of the input electron container
    StringProperty m_eleColl;

    /// The name of the input photon container
    StringProperty m_gammaColl;

    /// The name of the input tau container
    StringProperty m_tauColl;

    /// The name of the input muon container
    StringProperty m_muonColl;


    /// Decide if the JVT cut should be used or not (default: true)
    BooleanProperty m_doJVT;


    /// Decide if we want to do the muon-to-jet ghost association
    BooleanProperty m_doMuonToJetAsso;


    /// Athena configured tool: the handle for the METMaker tool
    ToolHandle<IMETMaker> m_metmaker;

    /// @}

  };

}

#endif
