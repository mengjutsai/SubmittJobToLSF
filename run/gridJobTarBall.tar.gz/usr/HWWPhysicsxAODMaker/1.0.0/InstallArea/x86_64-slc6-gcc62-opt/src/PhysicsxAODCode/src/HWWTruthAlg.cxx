// PhysicsxAODCode includes
#include "HWWTruthAlg.h"

// EDM includes
#include "xAODCore/AuxContainerBase.h"
#include "xAODTruth/TruthEventContainer.h"
#include "xAODTruth/TruthParticleContainer.h"
#include "xAODTruth/TruthParticleAuxContainer.h"
#include "xAODJet/Jet.h"
#include "xAODEventInfo/EventInfo.h"
#include "xAODJet/JetContainer.h"
#include "xAODJet/JetAuxContainer.h"
#include "xAODMissingET/MissingETContainer.h"
#include "xAODMissingET/MissingETAuxContainer.h"

// Helper includes
#include "AthAnalysisBaseComps/AthAnalysisHelper.h"
#include "FourMomUtils/xAODP4Helpers.h"
#include "CxxUtils/fpcompare.h"


enum WWType{
  NOWW=0,
  TAUTAU,
  TAUE,
  TAUM,
  EE,
  EM,
  MM
};



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool xaodPtSorting(const xAOD::IParticle *part1,
                   const xAOD::IParticle *part2) {
  return CxxUtils::fpcompare::greater( part1->pt(), part2->pt() );
}





///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
HWW::TruthAlg::TruthAlg( const std::string& name, ISvcLocator* pSvcLocator ) :
  // AthAlgorithm( name, pSvcLocator ),
  AthAnalysisAlgorithm( name, pSvcLocator ),
  m_truthInputCont(""),
  m_truthOutputCont(""),
  m_trutJetInputCont(""),
  m_truthWZJetInputCont(""),
  m_truthMetInputCont(""),
  m_truthElectronInputCont(""),
  m_truthMuonInputCont(""),
  m_EventInfoCont(""),
  m_writeSplitAux(false),
  m_isSherpa(false),
  m_isNNLOPS(false),
  m_generator(Generator::UNKNOWN)
{
  declareProperty( "TruthInputContainer" ,     m_truthInputCont,   "Name of the input truth container" );
  declareProperty( "TruthOutputContainer",     m_truthOutputCont,  "Name of the output truth container" );
  declareProperty( "TruthJetInputContainer",   m_trutJetInputCont, "Name of the input truth jet container" );
  declareProperty( "TruthWZJetInputContainer", m_truthWZJetInputCont, "Name of the input truth WZ jet container" );
  declareProperty( "TruthMetInputContainer",   m_truthMetInputCont, "Name of the input truth MET container" );
  declareProperty( "TruthElectronInputContainer",   m_truthElectronInputCont, "Name of the input truth electron container" );
  declareProperty( "TruthMuonInputContainer",   m_truthMuonInputCont, "Name of the input truth muon container" );
  declareProperty( "EventInfoContainer",       m_EventInfoCont,    "Name of the EventInfo container" );

  declareProperty( "IsSherpa",                 m_isSherpa,         "Sherpa or Powheg" );
  declareProperty( "IsNNLOPS",                 m_isNNLOPS,         "Powheg NNLOPS ggF" );

  declareProperty( "WriteSplitOutputContainer", m_writeSplitAux=true,
                   "Decide if we want to write a fully-split AuxContainer such that we can remove any variables" );
}



HWW::TruthAlg::~TruthAlg() {}



StatusCode HWW::TruthAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");
  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_truthInputCont );
  ATH_MSG_DEBUG( "Using: " << m_truthOutputCont );
  ATH_MSG_DEBUG( "Using: " << m_trutJetInputCont );
  ATH_MSG_DEBUG( "Using: " << m_truthWZJetInputCont );
  ATH_MSG_DEBUG( "Using: " << m_truthMetInputCont );
  ATH_MSG_DEBUG( "Using: " << m_truthElectronInputCont );
  ATH_MSG_DEBUG( "Using: " << m_truthMuonInputCont );
  ATH_MSG_DEBUG( "Using: " << m_EventInfoCont );
  ATH_MSG_DEBUG( "Using: " << m_writeSplitAux );
  ATH_MSG_DEBUG( "Using: " << m_isSherpa );
  ATH_MSG_DEBUG( "Using: " << m_isNNLOPS );

  // TODO: Reimplement use of rel21 equivalent of HiggsWeightTool
  // // check for the generator type
  // ///m_isSherpa=false;
  // if (m_isNNLOPS) {
  //   higgsMCtool = new xAOD::HiggsWeightTool( "HiggsWeightTool" );
  //   higgsMCtool->setProperty( "OutputLevel", MSG::DEBUG ).ignore();
  //   higgsMCtool->setProperty( "RequireFinite", true ).ignore();
  //   higgsMCtool->setProperty( "WeightCutOff", 100.0 ).ignore();
  //   higgsMCtool->setProperty("ForceNNLOPS",true).ignore();
  //   //if (forceVBF) higgsMCtool->setProperty("ForceVBF",true).ignore();
  //   //if (forceVH) higgsMCtool->setProperty("ForceVH",true).ignore();
  //   higgsMCtool->initialize().ignore();
  // }

  return StatusCode::SUCCESS;
}



StatusCode HWW::TruthAlg::beginInputFile()
{
  ATH_MSG_DEBUG ("Beginning a new input file " << name() << "...");

  // Try to determine the generator that was used for the current input file
  std::string generatorName;
  StatusCode sc = this->retrieveMetadata("/TagInfo","generators",generatorName);
  if ( !(sc.isSuccess()) ){
    ATH_MSG_WARNING("Couldn't find the generator name in the '/TagInfo' folder of the meta-data in the input file... ignoring it");
  }
  if ( generatorName.find("Powheg+Pythia8+EvtGen") != std::string::npos ){ m_generator = Generator::POWHEGPYTHIA8EVTGEN ; }
  ATH_MSG_INFO("Found the generator name " << generatorName << ", thus generator enum = "<< m_generator );

  return StatusCode::SUCCESS;
}



StatusCode HWW::TruthAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");
  return StatusCode::SUCCESS;
}



StatusCode HWW::TruthAlg::execute()
{
  //ATH_MSG_DEBUG ("Executing " << name() << "...");

  const xAOD::EventInfo* eventInfo = nullptr;
  CHECK( evtStore()->retrieve(eventInfo) );

  // Only run HWWTruthAlg.cxx on the MC
  const bool isSim = eventInfo->eventType(xAOD::EventInfo::EventType::IS_SIMULATION);
  if ( !isSim ) {
    ATH_MSG_DEBUG ("It is a data event... nothing to be done...");
    return StatusCode::SUCCESS;
  }



  // opening the truthEvent container
  const xAOD::TruthEventContainer* xTruthEventContainer = nullptr;
  ATH_CHECK( evtStore()->retrieve( xTruthEventContainer, m_truthInputCont) );

  std::vector<const xAOD::TruthParticle* > m_interestingLeptons;
  std::vector<const xAOD::TruthParticle* > ORLeptons;
  std::vector<const xAOD::TruthParticle* > m_interestingParticles;
  std::vector<const xAOD::TruthParticle* > m_neutrinosFromW;
  std::vector<const xAOD::TruthParticle* > m_leptonsFromW;
  int Nz=0;
  int Nem =0;
  int Ntau=0;
  int NeDirect=0;
  int NmDirect=0;
  int Nnu =0;
  int Nem_acc=0;

  // if this is this is a sample where the neutrinos and the leptons have the same same flavour (so this will be undistinguishable WW/ZZ events),
  //when this is !=0, this can only be a ZZ event
  int CountSherpaLepton=0;

  ///////////////////////////////////////////////////////////////////////////
  // this part is from Pere on H removal in WWW events
  int abs_pdgId;
  int abs_parent_pdgId;
  int nWlep=0;
  int nWnu=0;
  int nWparents=0;
  std::map<float,TLorentzVector> Wbosons;

  //// this is for the OR removal between W+jets and W+gamma samples
  bool hasPhoton=false;
  std::vector<const xAOD::TruthParticle* > photons;
  std::vector<const xAOD::TruthParticle* > leptonsFromWZwithTau;

  // For the truth Higgs bosons
  std::vector<const xAOD::TruthParticle* > higgsBosons;

  // Define some containers of selected objects that are needed for the VBF mjj flag
  std::vector<const xAOD::TruthParticle* > MCTruthPhotonList;
  std::vector<const xAOD::TruthParticle* > MCTruthElectronList;
  std::vector<TLorentzVector > MCTruthTauList;

  // Get the truth particles from the event and loop ever them
  std::vector<float> ptLoss;
  for ( const auto* truthPartCont : *xTruthEventContainer ) {
    for(unsigned int i = 0; i < truthPartCont->nTruthParticles(); i++){
      const xAOD::TruthParticle* particle = truthPartCont->truthParticle(i);
      if ( !particle ) continue;
      if ( particle->barcode()>2e5 ) break;
      const int pdg       = particle->pdgId();
      const int absPdg    = std::abs(pdg);
      const int status    = particle->status();
      const double pt     = particle->pt();
      double eta = 999999.0;
      if ( pt > 0.1 ) eta = particle->eta();
      const double absEta = std::abs(eta);
      const xAOD::TruthVertex* decvtx = particle->decayVtx();


      // Select everything that is needed to get the VBF mjj variable correctly

      // Photons
      if ( absPdg == 22 && status == 1 && pt >= 15000.0 && absEta <= 5.0  ) {
        MCTruthPhotonList.push_back( particle ) ;
      }

      // Electrons
      if ( absPdg == 11 && status == 1 && pt >= 15000.0 && absEta <= 5.0 ) {
        MCTruthElectronList.push_back( particle ) ;
      }

      // Taus
      if ( absPdg == 15 && status != 3 ) {
        const xAOD::TruthParticle* tau = particle;
        const xAOD::TruthVertex* taudecvtx = tau->decayVtx();
        int leptonic = 0;

        if (taudecvtx && taudecvtx->nOutgoingParticles()>0 ) {
          for ( std::size_t chil=0; chil<taudecvtx->nOutgoingParticles(); chil++) {
            const xAOD::TruthParticle* testTau = taudecvtx->outgoingParticle(chil);
            if (testTau==0) {
              ATH_MSG_DEBUG(" Found child of tau lepton with NULL pointer!!!!");
              leptonic = -999;
              continue;
            }
            const int childAbsPdg = std::abs(testTau->pdgId());
            if ( childAbsPdg == 12  ) {
              leptonic = 1;
            }
            if ( childAbsPdg == 14  ) {
              leptonic = 2;
            }
            if ( childAbsPdg == 15  ) {
              leptonic = 11;
            }
          }
        }

        if (leptonic == 0) {
          TLorentzVector nutau  = this->sumDaughterNeutrinos( tau );
          TLorentzVector tauvis( tau->px() - nutau.Px(),
                                 tau->py() - nutau.Py(),
                                 tau->pz() - nutau.Pz(),
                                 tau->e()  - nutau.E()  );

          if ( tauvis.Pt() >= 15000.0 && std::abs(tauvis.PseudoRapidity()) <= 5.0 ) {
            MCTruthTauList.push_back( tauvis ) ;
          }
        }
      } // Done with the stuff for the VBF mjj


      // Back to the main part
      if ( pdg==22 ) {
        if ( status==1 ) {
          if ( pt>10e3 && absEta<2.5 ) {
            photons.push_back(particle);
          }
        }
      }

      // this is the block from Pere (I don't have time to check the overlap with what was already there:
      abs_pdgId = std::abs(pdg);
      if( (abs_pdgId==11) || (abs_pdgId==12) || (abs_pdgId==13) || (abs_pdgId==14) || (abs_pdgId==15) || (abs_pdgId==16) ){
        nWparents = 0;
        TLorentzVector Wboson;

        //loop over parent truth particles
        for(unsigned int j=0;j< particle->nParents();j++) {
          const xAOD::TruthParticle* parent = particle->parent(j);
          if (!parent) continue;
          abs_parent_pdgId = std::abs(parent->pdgId());

          //consider lepton or neutrino truth particles with W-boson parent
          if( abs_parent_pdgId==24 ){
            nWparents += 1;

            //fill the parent map only for the lepton truth particles (avoid double counting)
            if( (abs_pdgId==11) || (abs_pdgId==13) || (abs_pdgId==15) ){
              Wboson.SetPtEtaPhiM(parent->pt(), parent->eta(), parent->phi(), parent->m());
              Wbosons.insert( std::map<float,TLorentzVector>::value_type(particle->charge()*(parent->m()), Wboson) );
            }
          }
        }//end loop over parent truth particles
      }

      //count number of leptons in event with exactly one W-boson parent
      if ( ((abs_pdgId==11) || (abs_pdgId==13) || (abs_pdgId==15)) && (nWparents == 1) )  nWlep += 1;

      //count number of neutrinos in event with exactly one W-boson parent
      if( ((abs_pdgId==12) || (abs_pdgId==14) || (abs_pdgId==16)) && (nWparents == 1) )   nWnu += 1;

      //////////////// END of Pere's block


      if ( m_isSherpa && status==11 && ( absPdg>10 && absPdg<17 ) ) {
        /*
        ATH_MSG_DEBUG( "  found a s11 with: " << particle->pt()
                 << " , " << particle->eta()
                 << " , " << particle->phi()
                 << " , Status: " << particle->status()
                 << " , barcode: " << particle->barcode()
                 << "  ID: " <<  particle->pdgId() );// << std::endl;
        */

        if ( absPdg==12 || absPdg==14 || absPdg==16 ) {
          m_neutrinosFromW.push_back( particle );
          Nnu++;
          if ( absPdg==12 ) CountSherpaLepton += -11;
          if ( absPdg==14 ) CountSherpaLepton += -13;
          if ( absPdg==16 ) CountSherpaLepton += -15;
        }

        if ( absPdg==11 || absPdg==13 || absPdg==15 ) {
          // this is crazy but Sherpa is really impossible to understand!!!!!
          if ( absPdg==15 &&  decvtx!=0) {
            if (  decayIntoItself(particle, 11) ) continue;
          }
          CountSherpaLepton += absPdg;

          if ( absPdg==11 )  {
            Nem++;
            NeDirect++;
          }
          if ( absPdg==13 )  {
            NmDirect++;
            Nem++;
          }
          if ( absPdg==15 ) {
            leptonsFromWZwithTau.push_back(particle);
            Ntau++;
            //printRecursively(particle);
            const xAOD::TruthParticle* lepton= lastOfKind(particle); // overwrite to avoid GenRecord crazyness
            const xAOD::TruthVertex* decLepton = lepton->decayVtx();
            if ( decLepton==0 ) {
              ATH_MSG_DEBUG(" Found tau lepton with EMPTY decay vertex .... BAD!!!!");
              continue;
            }
            for (unsigned int partT=0; partT<decLepton->nOutgoingParticles(); partT++) {
              const xAOD::TruthParticle* lep2 = decLepton->outgoingParticle(partT);
              if ( lep2==0 ) {
                ATH_MSG_DEBUG(" Found child of tau lepton with NULL pointer!!!!");
                continue;
              }
              const int PDGtau=lep2->pdgId();
              ATH_MSG_DEBUG("Found a tau decay with: " << lep2->pt() << " , " << lep2->eta()
                            << " , " << lep2->phi() << " , Status: " << lep2->status() << "  ID: " <<  lep2->pdgId() << "  barcode: " << lep2->barcode() );
              if ( std::abs(PDGtau)==12 || std::abs(PDGtau)==14 || std::abs(PDGtau)==16 ) {
                m_neutrinosFromW.push_back( lep2 );
                Nnu++;
              } else if ( std::abs(PDGtau)==11 || std::abs(PDGtau)==13 ) {
                m_leptonsFromW.push_back(lep2);
              }
            }
          } // end of tau block
          if ( absPdg==11 || absPdg==13 ) {
            m_leptonsFromW.push_back(particle);
            leptonsFromWZwithTau.push_back(particle);
          }
        }
      } ///end of Sherpa block

      /////////////////////////////////////////////////////////////////////////////
      /////////////////////////////////////////////////////////////////////////////
      /////////////////////////////////////////////////////////////////////////////
      if ( ( absPdg==24 || absPdg==23 ) && !m_isSherpa && decvtx!=0 ) {

        if ( decvtx->nOutgoingParticles()<2 ) {
          ATH_MSG_VERBOSE("Found a W/Z not decaying in at least 2 particles ... " << particle->status() << " and barcode: " << particle->barcode() );
          continue;
        }

        if ( absPdg==23 ) Nz++;

        ATH_MSG_DEBUG( "  found a boson with: " << particle->pt() << " , " << eta
                       << " , " << particle->phi() << " , Status: " << particle->status() << "  ID: " <<  particle->pdgId() );// << std::endl;

        m_interestingParticles.push_back( particle );
        for (unsigned int part=0; part<decvtx->nOutgoingParticles(); part++) {
          const xAOD::TruthParticle* lepton = decvtx->outgoingParticle(part);
          if (!lepton) {
            ATH_MSG_DEBUG(" SOMETHING MUST BE REALLY REALLY WRONG HERE ... W/Z direct decay is NULL pointer ");
            continue;
          }
          const int PDGlep = lepton->pdgId();
          const xAOD::TruthVertex* decLepton = lepton->decayVtx();

          if ( std::abs(PDGlep)==15 ||  std::abs(PDGlep)==13 ||  std::abs(PDGlep)==11 ){
            leptonsFromWZwithTau.push_back(lepton);
          }

          /// case of taus
          if ( std::abs(PDGlep)==15 ) {
            Ntau++;
            ATH_MSG_DEBUG( "  found a tau with: " << lepton->pt() << " , " << lepton->eta()
                           << " , " << lepton->phi() << " , Status: " << lepton->status() << "  ID: " <<  lepton->pdgId() );
            lepton = lastOfKind(lepton); // overwrite to avoid GenRecord crazyness
            ATH_MSG_DEBUG( "  found a Final tau with: " << lepton->pt() << " , " << lepton->eta()
                           << " , " << lepton->phi() << " , Status: " << lepton->status() << "  ID: " <<  lepton->pdgId() );
            decLepton= lepton->decayVtx();
            if ( !decLepton ) {
              ATH_MSG_DEBUG(" Found tau lepton with EMPTY decay vertex .... BAD!!!!");
              continue;
            }
            for (unsigned int partT=0; partT<decLepton->nOutgoingParticles(); partT++) {
              const xAOD::TruthParticle* lep2 = decLepton->outgoingParticle(partT);
              if ( !lep2 ) {
                ATH_MSG_DEBUG(" Found child of tau lepton with NULL pointer!!!!");
                continue;
              }
              const int PDGtau = lep2->pdgId();
              ATH_MSG_DEBUG( "     found a tau decay with: " << lep2->pt() << " , " << lep2->eta()
                             << " , " << lep2->phi() << " , Status: " << lep2->status() << "  ID: " <<  lep2->pdgId() << "  barcode: " << lep2->barcode() );
              if ( std::abs(PDGtau)==12 || std::abs(PDGtau)==14 || std::abs(PDGtau)==16 ) {
                m_neutrinosFromW.push_back( lep2 );
                Nnu++;
              } else if ( std::abs(PDGtau)==11 || std::abs(PDGtau)==13 ) {
                m_leptonsFromW.push_back(lep2);
              }
            }
          } // end of tau block
          if ( std::abs(PDGlep)==11 || std::abs(PDGlep)==13 ) {
            ATH_MSG_DEBUG( "     found a boson direct decay with: " << lepton->pt() << " , " << lepton->eta() << " , " << lepton->phi()
                           << " , Status: " << lepton->status() << "  ID: " <<  lepton->pdgId() << "  barcode: " << lepton->barcode() );
            //printRecursively( decvtx->outgoingParticle(part), "  ");
            Nem++;
            m_leptonsFromW.push_back( lepton );
            //if ( std::abs(PDGlep)==13 ) {
            //  const xAOD::TruthParticle* tmpPart2=lastOfKind(decvtx->outgoingParticle(part));
            //  float tmpPtLoss= (tmpPart2->pt()-decvtx->outgoingParticle(part)->pt())/decvtx->outgoingParticle(part)->pt();
            //  ptLoss.push_back(tmpPtLoss);
            //}
            if ( std::abs(PDGlep)==11 )  NeDirect++;
            if ( std::abs(PDGlep)==13 )  NmDirect++;
          }
          if ( std::abs(PDGlep)==12 || std::abs(PDGlep)==14 || std::abs(PDGlep)==16 ) {
            m_neutrinosFromW.push_back( lepton );
            Nnu++;
          }
        }
      } // end of W/Z block

      /////////////////////////////////////////////////////////////////////////////
      /////////////////////////////////////////////////////////////////////////////
      /////////////////////////////////////////////////////////////////////////////
      if ( absPdg==25 && decvtx!=0 ) {
        if ( decvtx->nOutgoingParticles()<2 ) ATH_MSG_DEBUG("Found a Higgs boson with not decaying into at least 2 particles");
        else {
          ATH_MSG_DEBUG( "  found a Higgs boson with: " << particle->pt() << " , " << eta
                         << " , " << particle->phi() << " , Status: " << particle->status() << "  ID: " <<  particle->pdgId() );// << std::endl;
          m_interestingParticles.push_back( particle );
        }
      }
      if ( absPdg==25 && particle->status() == 62 ) {
        higgsBosons.push_back(particle);
      }

      /////////////////////////////////////////////////////////////////////////////
      /////////////////////////////////////////////////////////////////////////////
      /////////////////////////////////////////////////////////////////////////////

      // Leptons for Sherpa 2.2 Z+jets re-weighting
      if( pt>20e3 && absEta<4.5 && status==1 && (absPdg==13 || absPdg==11) && !decayIntoItself(particle) ) {
        ORLeptons.push_back(particle);
      }

      if ( pt<5e3 )                  continue;
      if ( absEta>2.5 )                continue;
      if ( status!=1 )                 continue;
      if ( absPdg!=13 && absPdg!=11 )  continue;
      if ( decayIntoItself(particle) ) continue;

      if ( absPdg==13 ) {
        ATH_MSG_DEBUG( "  found a muon with: " << particle->pt() << " , " << particle->eta()
                       << " , " << particle->phi() << " , Status: " << particle->status() << "  ID: " <<  particle->pdgId() );
        m_interestingLeptons.push_back(particle);
        if ( pt>20e3 ) Nem_acc++;
      }

      if ( absPdg==11 ) {
        ATH_MSG_DEBUG("  found an electron with: " << particle->pt() << " , " << particle->eta() << " , " << particle->phi() << " , " << particle->barcode()
                      << " , Status: " << particle->status() << "  ID: " <<  particle->pdgId() );
        m_interestingLeptons.push_back(particle);
        if ( pt>20e3 ) Nem_acc++;
      }

    }
    continue;
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  std::sort( m_interestingLeptons.begin(), m_interestingLeptons.end(), xaodPtSorting);

  xAOD::TruthParticleContainer*    goodParts    = new xAOD::TruthParticleContainer;
  xAOD::TruthParticleAuxContainer* goodPartsAux = new xAOD::TruthParticleAuxContainer;
  goodParts->setStore( goodPartsAux ); //gives it a new associated aux container
  CHECK( evtStore()->record(goodParts   ,"SelTruthParticles") );
  CHECK( evtStore()->record(goodPartsAux,"SelTruthParticlesAux.") );
  for ( unsigned int iL=0; iL<m_interestingLeptons.size(); iL++) {
    if (  !isFromW( m_interestingLeptons.at(iL), m_leptonsFromW ) ) {
      //std::cout << " ... particle not coming from W " << std::endl;
      if ( (m_interestingLeptons.at(iL))->pt()>20e3 ) Nem_acc--;
      continue;
    }
    xAOD::TruthParticle* newPart = new xAOD::TruthParticle;
    goodParts->push_back(newPart);
    *newPart = *( m_interestingLeptons.at(iL) );
  }
  /*
  for ( unsigned int iL=0; iL<m_interestingParticles.size(); iL++) {
    xAOD::TruthParticle* newPart = new xAOD::TruthParticle;
    goodParts->push_back(newPart);
    *newPart = *( m_interestingParticles.at(iL) );
  }
  */

  //// photon business
  bool hasFSRPhotonLargeDeltaR = false;
  float minDR = 999.9;
  if ( photons.size()>0 ) {
    for (unsigned int iP=0; iP<photons.size(); iP++) {
      const xAOD::TruthParticle* particle = photons.at(iP);
      ATH_MSG_DEBUG( "--> photon with: " << particle->pt()
          << " , " << particle->eta()
          << " , " << particle->phi()
          << " , Status: " << particle->status()
          << " , barcode: " << particle->barcode()
          << "  ID: " <<  particle->pdgId() << "    .... " <<  m_isSherpa );// << std::endl;

      //const xAOD::TruthParticle* tmpPart=firstOfKind(particle);

      bool found=false;
      const xAOD::TruthVertex* prodvtx = particle->prodVtx();
      ATH_MSG_DEBUG( "--> incoming particle size: " << prodvtx->nIncomingParticles());
      for (unsigned int moth=0; moth<prodvtx->nIncomingParticles(); moth++) {
        const xAOD::TruthParticle* mother= prodvtx->incomingParticle(moth);
        ATH_MSG_DEBUG( "--> lepton from W/Z decay size: " << leptonsFromWZwithTau.size());
        ATH_MSG_DEBUG( "--> mother of photon id: " << mother->pdgId()  << ", status: " << mother->status() << ", barcode: " << mother->barcode());
        if (  m_isSherpa ) {
          if (fabs(mother->pdgId()) == 11 || fabs(mother->pdgId()) == 13 || fabs(mother->pdgId()) == 15) {
            found = true;
            ATH_MSG_DEBUG( "--> found photon from lepton ");
            for ( unsigned int iL=0; iL<m_interestingLeptons.size(); iL++) {
              const xAOD::TruthParticle* lepAfterRad = m_interestingLeptons.at(iL);
              //if (fabs(mother->pdgId()) == lepAfterRad->pdgId()) {
              ATH_MSG_DEBUG( "--> Delta R lepton after rad- photon: "<< (particle->p4()).DeltaR(lepAfterRad->p4()));
              if (minDR > (particle->p4()).DeltaR(lepAfterRad->p4())){
                minDR = (particle->p4()).DeltaR(lepAfterRad->p4()); 
              }

              //}

            }

          }
          /*for (unsigned int ref=0; ref<leptonsFromWZwithTau.size(); ref++) {
            const xAOD::TruthParticle* lepFromWZ = leptonsFromWZwithTau.at(ref);
            ATH_MSG_DEBUG( "--> Delta R lepton- photon: "<< (particle->p4()).DeltaR(lepFromWZ->p4()));
            if ( lepFromWZ == mother ) {
            found = true;
            ATH_MSG_DEBUG( "--> found photon from lepton ");
            ATH_MSG_DEBUG( "--> Delta R lepton- photon: "<< (particle->p4()).DeltaR(lepFromWZ->p4()));
            if ( !(xAOD::P4Helpers::isInDeltaR(*particle, *lepFromWZ, 0.1)) ){
            hasFSRPhotonLargeDeltaR = true;
            ATH_MSG_DEBUG( "--> found photon from lepton with DR > 0.1");
          //break;
          }
          }
          }*/
        }else if (mother->pdgId()==24 ||  mother->pdgId()==23){ // for Powheg and Alpgen
          found = true;
          for (unsigned int ref=0; ref<leptonsFromWZwithTau.size(); ref++) {
            const xAOD::TruthParticle* lepFromWZ = leptonsFromWZwithTau.at(ref);
            //const xAOD::TruthVertex* lepprodvtx = lepFromWZ->prodVtx();
            ATH_MSG_DEBUG( "--> lepton with: " << lepFromWZ->pt()
                << " , " << lepFromWZ->eta()
                << " , " << lepFromWZ->phi()
                << " , Status: " << lepFromWZ->status()
                << " , barcode: " << lepFromWZ->barcode()
                << "  ID: " <<  lepFromWZ->pdgId()  );// << std::endl;
            /*for (unsigned int lep_moth=0; lep_moth<lepprodvtx->nIncomingParticles(); lep_moth++) {
              const xAOD::TruthParticle* lep_mother= lepprodvtx->incomingParticle(lep_moth);
              ATH_MSG_DEBUG( "--> mother of lepton id: " << lep_mother->pdgId()  << ", status: " << lep_mother->status() << ", barcode: " << lep_mother->barcode());
            }*/
            if (lepFromWZ->status() == 1) {
              TLorentzVector status3lep(0,0,0,0);
              status3lep+=particle->p4();
              status3lep+=lepFromWZ->p4();
              if (minDR > (particle->p4()).DeltaR(lepFromWZ->p4())){
                minDR = (particle->p4()).DeltaR(lepFromWZ->p4());
              } 
              ATH_MSG_DEBUG( "--> lepton+photon with: " << status3lep.Pt() << ", " << status3lep.Eta() << ", " << status3lep.Phi() << ", Delta R "<< (particle->p4()).DeltaR(lepFromWZ->p4()));
            }


          }

        }

      }
      if ( found ) {
        hasPhoton=true;
        if(minDR > 0.1) {
          hasFSRPhotonLargeDeltaR = true;
          ATH_MSG_DEBUG( "--> found photon from lepton with DR > 0.1");
          break;
        } 
      }
    }
  }

  // const xAOD::EventInfo* eventInfo = 0; // MOVE
  // CHECK( evtStore()->retrieve(eventInfo) ); // MOVE

  bool isZ=false;
  WWType WWtype=NOWW;

  if ( Nz!=0 || CountSherpaLepton!=0 ) {
    isZ=true;
  } else if ( NeDirect+NmDirect+Ntau!=2 ) {
    //ATH_MSG_INFO( "  option: Ntau: " << Ntau << "   ,  Nlep: " << Nem << " (" << NeDirect << "," << NmDirect << ") , neutrinos: " << Nnu );
    isZ=true;
  } else {
    if ( Ntau==2 )  WWtype=TAUTAU;
    else if ( Ntau==1 )  {
      if ( NeDirect==1 && NmDirect==0 )      WWtype=TAUE;
      else if ( NeDirect==0 && NmDirect==1 ) WWtype=TAUM;
      else ATH_MSG_ERROR( "  unrecognised configuration: Ntau: " << Ntau << "   ,  Nlep: " << Nem << " (" << NeDirect << "," << NmDirect << ") , neutrinos: " << Nnu );
    } else if ( Ntau==0 &&  Nem==2 ) {
      if ( NeDirect==2 && NmDirect==0 )      WWtype=EE;
      else if ( NeDirect==0 && NmDirect==2 ) WWtype=MM;
      else if ( NeDirect==1 && NmDirect==1 ) WWtype=EM;
      else ATH_MSG_ERROR( "  unrecognised configuration: Ntau: " << Ntau << "   ,  Nlep: " << Nem << " (" << NeDirect << "," << NmDirect << ") , neutrinos: " << Nnu );
    }
  }

  //ATH_MSG_INFO( "  option: Ntau: " << Ntau << "   ,  Nlep: " << Nem << " (" << NeDirect << "," << NmDirect << ") , neutrinos: " << Nnu << " , " <<  CountSherpaLepton << "  TYPE: " <<   WWtype << "  ... truth: " << Nem_acc << "  ... leptons from W: " << m_leptonsFromW.size() );

  eventInfo->auxdecor<char>("truth_isZZ")             = static_cast<char>(isZ);
  eventInfo->auxdecor<int>("truth_WWtype")            = WWtype;
  eventInfo->auxdecor<int>("truth_nTruthLep")         = Nem_acc;
  eventInfo->auxdecor<char>("truth_hasFSRPhoton")     = static_cast<char>(hasPhoton);
  eventInfo->auxdecor<char>("truth_hasFSRPhotonDR01") = static_cast<char>(hasFSRPhotonLargeDeltaR);

  float Mvv=0.0;
  if ( m_neutrinosFromW.size()>1 ) {
    TLorentzVector myMvv(0,0,0,0);
    myMvv+=(m_neutrinosFromW.at(0))->p4();
    myMvv+=(m_neutrinosFromW.at(1))->p4();
    Mvv=myMvv.M();
  }
  eventInfo->auxdecor<float>("truth_mvv") = Mvv;

  // Add the higgs pt
  float higgsPt  = -1000.0;
  float higgsY   = 0.0;
  float higgsPhi = 0.0;
  float higgsM   = 0.0;
  std::size_t nHiggs = higgsBosons.size();
  ATH_MSG_DEBUG("Found " << nHiggs << " Higgs bosons");
  if (nHiggs>=2){
    ATH_MSG_WARNING("Found apparently " << nHiggs << " Higgs bosons");
  }
  if (nHiggs){
    higgsPt  = higgsBosons[0]->pt();
    higgsY   = higgsBosons[0]->rapidity();
    higgsPhi = higgsBosons[0]->phi();
    higgsM   = higgsBosons[0]->m();
  }
  eventInfo->auxdecor<float>("truthHiggsPt")  = higgsPt;
  eventInfo->auxdecor<float>("truthHiggsY")   = higgsY;
  eventInfo->auxdecor<float>("truthHiggsPhi") = higgsPhi;
  eventInfo->auxdecor<float>("truthHiggsM")   = higgsM;



  /*
  if ( ptLoss.size()>0 ) {
    eventInfo->auxdecor<float>("truth_ptLoss_0")=ptLoss[0];
    if ( ptLoss.size()>1 ) {
      eventInfo->auxdecor<float>("truth_ptLoss_1")=ptLoss[1];
    } else {
      eventInfo->auxdecor<float>("truth_ptLoss_1")=1.;
    }
  } else {
    eventInfo->auxdecor<float>("truth_ptLoss_0")=1.;
    eventInfo->auxdecor<float>("truth_ptLoss_1")=1.;
  }
  */


  // -----------------------------------------------------
  // Calculate the di-boson invariant mass
  // -----------------------------------------------------
  float massVV = 0.0;
  std::vector<const xAOD::TruthParticle*> vBosonList;
  for ( const xAOD::TruthParticle* part : m_interestingParticles ){
    const int absPDG = part->absPdgId();
    if ( absPDG == 23 || absPDG==24 ){
      vBosonList.push_back(part);
    }
  }
  if ( vBosonList.size() == 2 ){
    const xAOD::TruthParticle* partA = vBosonList[0];
    const xAOD::TruthParticle* partB = vBosonList[1];
    const double diBosonMass = ( partA->p4() + partB->p4() ).M();
    massVV = static_cast<float>(diBosonMass);
  }
  eventInfo->auxdecor<float>("truth_VVMass") = massVV;


  //default
  float M01 = -999.;

  // Pere's information
  //consider events with exactly 3 leptons and 3 neutrions, each with exactly one W-boson parent (this selects 100% of events in Sherpa and VBFNLO)
  if ( (nWlep==3) && (nWnu==3) ){
    //get the information of the 3 W-bosons in the event (needed for the sorting)
    TLorentzVector tmp_Wboson0;
    TLorentzVector tmp_Wboson1;
    TLorentzVector tmp_Wboson2;
    float tmp_chargeMass0 = 0.0;
    float tmp_chargeMass1 = 0.0;
    float tmp_chargeMass2 = 0.0;

    std::map<float,TLorentzVector>::iterator it = Wbosons.begin();
    int Wb_count = 0;

    while(it != Wbosons.end()){
      if (Wb_count==0){
        tmp_Wboson0 = (*it).second;
        tmp_chargeMass0 = (*it).first;
      }
      else if (Wb_count==1){
        tmp_Wboson1 = (*it).second;
        tmp_chargeMass1 = (*it).first;
      }
      else if (Wb_count==2){
        tmp_Wboson2 = (*it).second;
        tmp_chargeMass2 = (*it).first;
      }

      Wb_count += 1;
      ++it;

    }

    float tmp_chargeMass01 = tmp_chargeMass0*tmp_chargeMass1;
    float tmp_chargeMass02 = tmp_chargeMass0*tmp_chargeMass2;
    float tmp_chargeMass12 = tmp_chargeMass1*tmp_chargeMass2;

    TLorentzVector tmp_Wboson01 = tmp_Wboson0 + tmp_Wboson1;
    TLorentzVector tmp_Wboson02 = tmp_Wboson0 + tmp_Wboson2;
    TLorentzVector tmp_Wboson12 = tmp_Wboson1 + tmp_Wboson2;
    // TODO: The higgs mass is wrong here, no? It was generated with 125.0
    float tmp_Higgs_mDiff01 = std::abs( (0.001*(tmp_Wboson01.M())) - 125.09 );
    float tmp_Higgs_mDiff02 = std::abs( (0.001*(tmp_Wboson02.M())) - 125.09 );
    float tmp_Higgs_mDiff12 = std::abs( (0.001*(tmp_Wboson12.M())) - 125.09 );

    // now sort the W-bosons: tmp_Wboson0, tmp_Wboson1, tmp_Wboson2 --> Wboson0, Wboson1, Wboson2
    TLorentzVector Wboson0;
    TLorentzVector Wboson1;
    TLorentzVector Wboson2;

    if (tmp_chargeMass01 > 0){
      Wboson0 = tmp_Wboson2;
      if(tmp_Higgs_mDiff02 < tmp_Higgs_mDiff12){
        Wboson1 = tmp_Wboson0;
        Wboson2 = tmp_Wboson1;
      }
      else{
        Wboson1 = tmp_Wboson1;
        Wboson2 = tmp_Wboson0;
      }
    }
    if (tmp_chargeMass02 > 0){
      Wboson0 = tmp_Wboson1;
      if(tmp_Higgs_mDiff01 < tmp_Higgs_mDiff12){
        Wboson1 = tmp_Wboson0;
        Wboson2 = tmp_Wboson2;
      }
      else{
        Wboson1 = tmp_Wboson2;
        Wboson2 = tmp_Wboson0;
      }

    }

    if (tmp_chargeMass12 > 0){
      Wboson0 = tmp_Wboson0;
      if(tmp_Higgs_mDiff01 < tmp_Higgs_mDiff02){
        Wboson1 = tmp_Wboson1;
        Wboson2 = tmp_Wboson2;
      }
      else{
        Wboson1 = tmp_Wboson2;
        Wboson2 = tmp_Wboson1;
      }
    }

    //now that we have sorted the 3 W-bosons, we can compute necessary things
    TLorentzVector Wboson01 = Wboson0 + Wboson1;
    TLorentzVector Wboson02 = Wboson0 + Wboson2;
    TLorentzVector Wboson12 = Wboson1 + Wboson2;

    M01 = 0.001*(Wboson01.M());

  }// if a 3Wlep + 3Wnu event
  eventInfo->auxdecor<float>("truth_mW0W1") =  M01;


  // Filter based on rapidity acceptance and sort
  std::vector<const xAOD::Jet* > filteredJets;

  /// now the jets
  const xAOD::JetContainer* truthjets = 0;
  CHECK( evtStore()->retrieve( truthjets, m_trutJetInputCont) );
  std::vector<const xAOD::Jet*> selJets;
  unsigned int numberOfTruthJets = 0;
  for ( const auto* jet : *truthjets ) {
    const double jetPt =  jet->pt();
    // jet selection for the VBF mjj calculation
    if ( jetPt < 15e3 ) continue;
    const double absY  = std::abs(jet->rapidity());
    if ( absY < 5.0 ) {
      bool JetOverlapsWithPhoton   = false;
      bool JetOverlapsWithElectron = false;
      bool JetOverlapsWithTau      = false;

      JetOverlapsWithPhoton   = this->checkOverlap(jet, MCTruthPhotonList  );
      JetOverlapsWithElectron = this->checkOverlap(jet, MCTruthElectronList);
      JetOverlapsWithTau      = this->checkOverlap(jet, MCTruthTauList     );

      if (!JetOverlapsWithPhoton && !JetOverlapsWithElectron && !JetOverlapsWithTau ) {
         filteredJets.push_back( jet );
      }
    } // End of the jet selection for the VBF mjj calculation

    // Jet counting for Sherpa 2.2 Z+jets re-weighting
    if( jet->pt()>20e3 && std::abs(jet->eta())<4.5 ){
      float mindR=100;
      for (unsigned int iL=0; iL<ORLeptons.size(); iL++) {
        const xAOD::TruthParticle* lepton = ORLeptons.at(iL);
        float tmpDR=(jet->p4()).DeltaR(lepton->p4());
        if ( tmpDR<mindR ) mindR=tmpDR;
      }
      if ( mindR<0.2 ) continue;
      numberOfTruthJets++;
    }
    //

    if ( jet->pt()<25e3       )     continue;
    if ( std::abs(jet->eta())>4.5 ) continue;
    // now OR
    float mindR=100;
    for (unsigned int iL=0; iL<m_interestingLeptons.size(); iL++) {
      const xAOD::TruthParticle* lepton = m_interestingLeptons.at(iL);
      if (lepton->pt()<20e3) continue;
      float tmpDR=(jet->p4()).DeltaR(lepton->p4());
      //if ( tmpDR<0.2 ) std::cout << " the jet overlap with the lepton " << lepton->pdgId() << "  ... with dR= " << tmpDR << std::endl;
      if ( tmpDR<mindR ) mindR=tmpDR;
    }
    if ( mindR<0.2 ) continue;
    selJets.push_back( jet );
  }
  // Truth jet multiplicity for Sherpa 2.2 Z+jets re-weighting
  eventInfo->auxdecor<unsigned int>("truth_nJet") = numberOfTruthJets;

  // WZ truth jet multiplicity for Sherpa 2.2 Z+jets re-weighting, if requested
  if( !m_truthWZJetInputCont.value().empty() ) {
    const xAOD::JetContainer* truthWZJets = 0;
    CHECK( evtStore()->retrieve( truthWZJets, m_truthWZJetInputCont ) );
    unsigned int numberOfTruthWZJets = 0;
    for ( const auto* jet : *truthWZJets ) {
      if( jet->pt()>20e3 && std::abs(jet->eta())<4.5 ){
        float mindR=100;
        for (unsigned int iL=0; iL<ORLeptons.size(); iL++) {
          const xAOD::TruthParticle* lepton = ORLeptons.at(iL);
          float tmpDR=(jet->p4()).DeltaR(lepton->p4());
          if ( tmpDR<mindR ) mindR=tmpDR;
        }
        if ( mindR<0.2 ) continue;
        numberOfTruthWZJets++;
      }
    }
    eventInfo->auxdecor<unsigned int>("truth_nWZJet") = numberOfTruthWZJets;
  }

  xAOD::JetContainer* goodJets       = new xAOD::JetContainer;
  xAOD::JetAuxContainer* goodJetsAux = new xAOD::JetAuxContainer;
  goodJets->setStore( goodJetsAux ); //gives it a new associated aux container
  CHECK( evtStore()->record(goodJets   ,"TruthSelJets") );
  CHECK( evtStore()->record(goodJetsAux,"TruthSelJetsAux.") );

  for ( unsigned int iJ=0; iJ<selJets.size(); iJ++) {
    xAOD::Jet* newJet = new xAOD::Jet;
    goodJets->push_back(newJet);
    *newJet = *( selJets.at(iJ) );
  }


  /// Neutrino from W - only MET
  xAOD::MissingETContainer*    nuMET    = new xAOD::MissingETContainer();
  xAOD::MissingETAuxContainer* nuMETAux = new xAOD::MissingETAuxContainer();
  nuMET->setStore(nuMETAux);
  ATH_CHECK( evtStore()->record(nuMET,    "MET_fromW" ) );
  ATH_CHECK( evtStore()->record(nuMETAux, "MET_fromWAux." ) );

  xAOD::MissingET* newTerm = new xAOD::MissingET();
  nuMET->push_back(newTerm);
  TLorentzVector myNewMET(0,0,0,0);
  float theSumEt=0;
  for (unsigned int iM=0; iM<m_neutrinosFromW.size(); iM++) {
    theSumEt+=(m_neutrinosFromW.at(iM)->pt());
    myNewMET+= (m_neutrinosFromW.at(iM))->p4();
    newTerm->add( m_neutrinosFromW.at(iM) );
  }


  // Finally, calculate the VBF mjj
  float truth_VBFMjj = -999.0;
  if ( filteredJets.size()>=2) {
    std::sort( filteredJets.begin(), filteredJets.end(), xaodPtSorting );

    TLorentzVector DiJetSystem(filteredJets[0]->px() + filteredJets[1]->px(),
                               filteredJets[0]->py() + filteredJets[1]->py(),
                               filteredJets[0]->pz() + filteredJets[1]->pz(),
                               filteredJets[0]->e()  + filteredJets[1]->e() );
    truth_VBFMjj = DiJetSystem.M();

    //ATH_MSG_INFO ("Weight[0][1]: "  << (pow((500000.0/truth_VBFMjj), 3.28954929195  ) / 0.00502 )/eventInfo->mcEventWeights()[0] ); //DEBUG
  }

  eventInfo->auxdecor<float>("truth_VBFMjj")    = truth_VBFMjj;

  // Truth ttbar pt and top pt
  double ttbarpt = 0;
  double toppt = 0;
  int nOutgoingPartons = 0;
  std::vector<const xAOD::TruthParticle*> vTopList;
  for ( const auto* truthParticle : *xTruthEventContainer ) {
    for(unsigned int i = 0; i < truthParticle->nTruthParticles(); i++){
      const xAOD::TruthParticle* particle = truthParticle->truthParticle(i);
      if ( !particle ) continue;
      const int pdg       = particle->pdgId();
      const int absPdg    = std::abs(pdg);
      const int status    = particle->status();
      if(status==23 && !(absPdg>=11 && absPdg<=16) ){
            nOutgoingPartons++;
      }
      if ( absPdg != 6 ) continue;
      if ( m_generator == Generator::POWHEGPYTHIA8EVTGEN && status == 62 ) vTopList.push_back(particle);
      else if ( status == 3 ) vTopList.push_back(particle);
    }
  }
  if ( vTopList.size() == 2 ){
    const xAOD::TruthParticle* top1 = vTopList[0];
    const xAOD::TruthParticle* top2 = vTopList[1];
    ttbarpt = ( top1->p4() + top2->p4() ).Pt();
    if(top1->pdgId() == 6 && top2->pdgId() == -6) toppt = ( top1->p4() ).Pt();
    else if(top1->pdgId() == -6 && top2->pdgId() == 6) toppt = ( top2->p4() ).Pt();
  }
  eventInfo->auxdecor<float>("truth_ttbarpt")          = ttbarpt;
  eventInfo->auxdecor<float>("truth_toppt")            = toppt;
  eventInfo->auxdecor<int>("truth_nOutgoingPartons")   = nOutgoingPartons;

  /// few add ons by Kathrin for truth MT and NNLOPS
  // Block from Kathrin on Truth MT
  // first, start with using dressed four vector
  const xAOD::TruthParticleContainer* truthele = 0;
  CHECK( evtStore()->retrieve( truthele, m_truthElectronInputCont) );
  std::vector<const xAOD::TruthParticle*> selEles;
  unsigned int numberOfTruthEle = 0;
  for(const xAOD::TruthParticle* electron : *truthele){
      ATH_MSG_DEBUG( "--> electron with: " << electron->pt()
         << " , " << electron->eta()
         << " , " << electron->phi()
         << " , Status: " << electron->status()
         << " , barcode: " << electron->barcode()
         << " , mother id: " <<electron->auxdata<int>("motherID")
         << " , particle origin: " <<electron->auxdata<unsigned int>("classifierParticleOrigin")
         << "  ID: " <<  electron->pdgId() );// << std::endl;
      if (fabs(electron->auxdata<int>("motherID")) <= 24 && electron->pt() > 5000.0) {
        selEles.push_back( electron );
        numberOfTruthEle++;
      }
  }
  ATH_MSG_DEBUG( "Electrons: " << numberOfTruthEle );
  const xAOD::TruthParticleContainer* truthmuon = 0;
  CHECK( evtStore()->retrieve( truthmuon, m_truthMuonInputCont) );
  unsigned int numberOfTruthMu = 0;
  std::vector<const xAOD::TruthParticle*> selMus;
  for(const xAOD::TruthParticle* muon : *truthmuon){
      ATH_MSG_DEBUG( "--> muon with: " << muon->pt()
         << " , " << muon->eta()
         << " , " << muon->phi()
         << " , Status: " << muon->status()
         << " , barcode: " << muon->barcode()
         << " , mother id: " <<muon->auxdata<int>("motherID")
         << " , particle origin: " <<muon->auxdata<unsigned int>("classifierParticleOrigin")
         << "  ID: " <<  muon->pdgId() );// << std::endl;
      if (fabs(muon->auxdata<int>("motherID")) <= 24 && muon->pt() > 5000.0){ 
        selMus.push_back( muon );
        numberOfTruthMu++;
      }
  }
  ATH_MSG_DEBUG( "Muons: " << numberOfTruthMu );
   
  const xAOD::MissingETContainer* truthmets = 0;
  CHECK( evtStore()->retrieve( truthmets, m_truthMetInputCont) );
  const xAOD::MissingET* met = (*truthmets)["NonInt"];
  ATH_MSG_DEBUG( "--> met with: " << met->met()
         << " , " << met->name());// << std::endl;
  //setup to calculate MT here
  double truthMT=-999.9;
  if (numberOfTruthMu==1 && numberOfTruthEle==1)
    truthMT=calculateMT(selEles.at(0),selMus.at(0), met); 
  else if (numberOfTruthMu==2 && numberOfTruthEle==0)
    truthMT=calculateMT(selMus.at(0),selMus.at(1), met); 
  else if (numberOfTruthMu==0 && numberOfTruthEle==2)
    truthMT=calculateMT(selEles.at(0),selEles.at(1), met); 
  else
    ATH_MSG_DEBUG( "Either too few or too many leptons found!! Muons: " << numberOfTruthMu << " Electrons: "<< numberOfTruthEle );
  ATH_MSG_DEBUG( "Truth MT: " << truthMT );
  eventInfo->auxdecor<float>("truth_MT")    = truthMT;


  // TODO: Reimplement use of rel21 equivalent of HiggsWeightTool

  // //NNLOPS for now only wg1 qcd uncertainties
  // double weight_qcd_wg1_mu = 1.0;
  // double weight_qcd_wg1_res = 1.0;
  // double weight_qcd_wg1_mig01 = 1.0;
  // double weight_qcd_wg1_mig12 = 1.0;
  // double weight_qcd_wg1_vbf2j = 1.0;
  // double weight_qcd_wg1_vbf3j = 1.0;
  // double weight_qcd_wg1_pTH = 1.0;
  // double weight_qcd_wg1_qm_t = 1.0;
  // double weight_qcd_jve_mu = 1.0;
  // double weight_qcd_jve_mig01 = 1.0;
  // double weight_qcd_jve_mig12 = 1.0;

  // if(m_isNNLOPS) {
  //   // All input files used for test have the HTXS content
  //   if (eventInfo->isAvailable<int>("HTXS_Njets_pTjet30")) {
  //     double HTXS_Njets30 = eventInfo->auxdata<int>("HTXS_Njets_pTjet30");
  //     double HTXS_Stage1 = eventInfo->auxdata<int>("HTXS_Stage1_Category_pTjet30");
  //     //double HTXS_index  = eventInfo->auxdata<int>("HTXS_Stage1_FineIndex_pTjet30");
  //     double HTXS_pTH  = eventInfo->auxdata<float>("HTXS_Higgs_pt");
  //     //double HTXS_etaH = eventInfo->auxdata<float>("HTXS_Higgs_eta");
  //     //double HTXS_phiH = eventInfo->auxdata<float>("HTXS_Higgs_phi");
  //     //double HTXS_mH   = eventInfo->auxdata<float>("HTXS_Higgs_m");
  //     xAOD::HiggsWeights hw = higgsMCtool->getHiggsWeights(HTXS_Njets30,HTXS_pTH,HTXS_Stage1); // get higgs weights for jetbinning of 30 GeV
  //     weight_qcd_wg1_mu = hw.qcd_wg1_mu;
  //     weight_qcd_wg1_res = hw.qcd_wg1_res;
  //     weight_qcd_wg1_mig01 = hw.qcd_wg1_mig01;
  //     weight_qcd_wg1_mig12 = hw.qcd_wg1_mig12;
  //     weight_qcd_wg1_vbf2j = hw.qcd_wg1_vbf2j;
  //     weight_qcd_wg1_vbf3j = hw.qcd_wg1_vbf3j;
  //     weight_qcd_wg1_pTH = hw.qcd_wg1_pTH;
  //     weight_qcd_wg1_qm_t = hw.qcd_wg1_qm_t;
  //     weight_qcd_jve_mu = hw.ggF_qcd_jve[0];
  //     weight_qcd_jve_mig01 = hw.ggF_qcd_jve[1];
  //     weight_qcd_jve_mig12 = hw.ggF_qcd_jve[2];
  //   } else {
  //     ATH_MSG_WARNING( "HTXS Njets distribution missing for sample. Correct NNLOPS not possible " );
  //   }
  // }
  // eventInfo->auxdecor<float>("weight_qcd_wg1_mu")     = weight_qcd_wg1_mu;
  // eventInfo->auxdecor<float>("weight_qcd_wg1_res")    = weight_qcd_wg1_res;
  // eventInfo->auxdecor<float>("weight_qcd_wg1_mig01")  = weight_qcd_wg1_mig01;
  // eventInfo->auxdecor<float>("weight_qcd_wg1_mig12")  = weight_qcd_wg1_mig12;
  // eventInfo->auxdecor<float>("weight_qcd_wg1_vbf2j")  = weight_qcd_wg1_vbf2j;
  // eventInfo->auxdecor<float>("weight_qcd_wg1_vbf3j")  = weight_qcd_wg1_vbf3j;
  // eventInfo->auxdecor<float>("weight_qcd_wg1_pTH")    = weight_qcd_wg1_pTH;
  // eventInfo->auxdecor<float>("weight_qcd_wg1_qm_t")   = weight_qcd_wg1_qm_t;
  // eventInfo->auxdecor<float>("weight_qcd_jve_mu")     = weight_qcd_jve_mu;
  // eventInfo->auxdecor<float>("weight_qcd_jve_mig01")  = weight_qcd_jve_mig01;
  // eventInfo->auxdecor<float>("weight_qcd_jve_mig12")  = weight_qcd_jve_mig12;

  return StatusCode::SUCCESS;
}




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////// some helper function
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool HWW::TruthAlg::decayIntoItself(const xAOD::TruthParticle* part, int status) {
  if (!part) return false;
  const int partPDG = part->pdgId();
  const xAOD::TruthVertex* decvtx = part->decayVtx();
  if ( !decvtx )                         return false;
  if ( decvtx->nOutgoingParticles()==0 ) return false;

  for (unsigned int chil=0; chil<decvtx->nOutgoingParticles(); ++chil) {
    const xAOD::TruthParticle* child = decvtx->outgoingParticle(chil);
    if (!child) continue;
    const int barcode = child->barcode();
    if ( barcode>=2e5 ) continue;
    const int PDG = child->pdgId();
    if ( status==-1 ) {
      if ( PDG==partPDG ) return true;
    } else {
      if ( PDG==partPDG && child->status()==status) return true;
    }
  }
  return false;
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const xAOD::TruthParticle* HWW::TruthAlg::lastOfKind(const xAOD::TruthParticle* part) {
  if (!part) return nullptr;
  const int partPDG = part->pdgId();
  const xAOD::TruthVertex* decvtx = part->decayVtx();
  if ( !decvtx ) return part;
  if ( decvtx->nOutgoingParticles()==0 ) return part;

  for (unsigned int chil=0; chil<decvtx->nOutgoingParticles(); chil++) {
    const xAOD::TruthParticle* childPart = decvtx->outgoingParticle(chil);
    if (!childPart) continue;
    const int barcode = childPart->barcode();
    if ( barcode >= 2e5 ) continue;
    const int PDG = childPart->pdgId();
    if ( PDG == partPDG ) return lastOfKind(childPart);
  }
  return part;
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const xAOD::TruthParticle* HWW::TruthAlg::firstOfKind(const xAOD::TruthParticle* part) {
  if (!part) return nullptr;
  int partPDG = part->pdgId();
  const xAOD::TruthVertex* prodvtx = part->prodVtx();
  if ( !prodvtx ) return part;
  const std::size_t nInParts = prodvtx->nIncomingParticles();
  if ( nInParts == 0 ) return part;

  if ( nInParts==1 ) {
    const xAOD::TruthParticle* inPart = prodvtx->incomingParticle(0);
    if (!inPart) return part;
    const int motherPDG = inPart->pdgId();
    if ( partPDG!=motherPDG ) return part;
    return firstOfKind(inPart);
  } else { //needed for Sherpa
    for (unsigned int moth=0; moth<nInParts; moth++) {
      const xAOD::TruthParticle* inMother = prodvtx->incomingParticle(moth);
      if (!inMother) continue;
      const int motherPDG = inMother->pdgId();
      if ( partPDG != motherPDG ) continue;
      if ( inMother->status()==11 ) return inMother;
    }
  }
  return part;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void HWW::TruthAlg::printRecursively(const xAOD::TruthParticle* part, std::string preVal) {
  if (!part) return;
  const xAOD::TruthVertex* decvtx = part->decayVtx();
  if ( !decvtx ) return ;
  const std::size_t nOutParts = decvtx->nOutgoingParticles();
  if ( nOutParts==0 ) return ;

  for (unsigned int chil=0; chil<nOutParts; chil++) {
    const xAOD::TruthParticle* childPart = decvtx->outgoingParticle(chil);
    if (!childPart) continue;
    const int barcode = childPart->barcode();
    if ( barcode>=2e5 ) continue;
    printRecursively(childPart, preVal+" ");
  }
  return ;
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool HWW::TruthAlg::isFromW( const xAOD::TruthParticle* part, const std::vector<  const xAOD::TruthParticle*>& Wlist) {
  if (!part) return false;
  const xAOD::TruthParticle* tmpPart = firstOfKind(part);
  for ( unsigned int iP=0; iP<Wlist.size(); ++iP) {
    if ( tmpPart==Wlist.at(iP) ) return true;
  }
  return false;
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
TLorentzVector HWW::TruthAlg::sumDaughterNeutrinos(const xAOD::TruthParticle *part) {
  TLorentzVector nu(0,0,0,0);
  if ( ( abs( part->pdgId() ) == 12 ) || ( abs( part->pdgId() ) == 14 ) || ( abs( part->pdgId() ) == 16 ) ) {
    nu.SetPx(part->px());
    nu.SetPy(part->py());
    nu.SetPz(part->pz());
    nu.SetE(part->e());
    return nu;
  }

  if ( part->hasDecayVtx() == 0 ) return nu;
  const xAOD::TruthVertex* decvtx = part->decayVtx();
  const std::size_t nOutParts = decvtx->nOutgoingParticles();
  for ( unsigned int chil=0; chil<nOutParts; ++chil) {
    // Protect against null pointer. This should not happen though.
    // Maybe, if that is the case for a tau decay, sum the visible parts and
    // subtract those from the full tau instead?
    const xAOD::TruthParticle* childPart = decvtx->outgoingParticle(chil);
    if (!childPart){ continue; }
    nu += sumDaughterNeutrinos( childPart );
  }
  return nu;
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool HWW::TruthAlg::checkOverlap(const xAOD::IParticle* part, std::vector<const xAOD::TruthParticle* > list) {
  if (!part) return false;
  for (std::size_t i = 0; i < list.size(); ++i) {
    const xAOD::TruthParticle* truthPart = list[i];
    const double pt = truthPart->pt();
    if (pt > 15000.0) {
      if ( xAOD::P4Helpers::isInDeltaR(*part, *truthPart, 0.3) ) return true;
    }
  }
  return false;
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool HWW::TruthAlg::checkOverlap(const xAOD::IParticle* part, std::vector<TLorentzVector > list) {
  if (!part) return false;
  const double maxDeltaR2 = 0.3*0.3;
  for (size_t i = 0; i < list.size(); ++i) {
    const TLorentzVector& partB = list[i];
    const double pt = partB.Pt();
    if (pt > 15000.0) {
      const double phi      = partB.Phi();
      const double rapidity = partB.PseudoRapidity();
      if ( xAOD::P4Helpers::deltaR2(*part,rapidity,phi) < maxDeltaR2 ) return true;
    }
  }
  return false;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
double HWW::TruthAlg::calculateMT( const xAOD::TruthParticle *lep1, const xAOD::TruthParticle *lep2, const xAOD::MissingET* missET )
{
    
  const double mpx( missET->mpx() );
  const double mpy( missET->mpy() );
  const double met( missET->met() );
  TLorentzVector l1 = lep1->p4();
  TLorentzVector l2 = lep2->p4();
  TLorentzVector leptons = l1+l2;

  // Now, actually calculate the result (in two parts)
  const double px( leptons.Px() );
  const double py( leptons.Py() );
  const double part2 = (px+mpx)*(px+mpx) + (py+mpy)*(py+mpy);
  double mll2( leptons.M2() );
  // This is needed for rare cases when the TLorentzVector.M2 returns negative values
  mll2 = mll2 < 0.0 ? -mll2 : mll2;
  const double etll( std::sqrt( (px*px + py*py) + mll2 ) );
  const double part1( (etll+met)*(etll+met) );

  // One last sanity check
  if ( part1 < part2 ) {
    // This should not be... throw an error.
    throw std::runtime_error("Got an invalid mt calculation");
  }
  return std::sqrt( part1 - part2 );

}


