///////////////////////// -*- C++ -*- /////////////////////////////
// HWWMETCalibrationSmearingAlg.cxx
// Implementation file for class HWW::METCalibrationSmearingAlg
// Author: Phuong Dang <nguyen.phuong.dang@cern.ch>
///////////////////////////////////////////////////////////////////

// PhysicsxAODCode includes
#include "HWWMETCalibrationSmearingAlg.h"

// STL includes
#include <set>
#include <climits>
#include <cmath>

// EDM includes
#include "xAODCore/ShallowCopy.h"
#include "xAODMissingET/MissingETContainer.h"
#include "xAODMissingET/MissingETComposition.h"
#include "xAODMissingET/MissingETAuxContainer.h"
#include "xAODMissingET/MissingETComponentMap.h"
#include "xAODBase/IParticleContainer.h"

// Tool includes
#include "METInterface/IMETSystematicsTool.h"
#include "AsgTools/ToolHandle.h"
#include "AsgTools/AsgTool.h"
#include "PATInterfaces/SystematicCode.h"
#include "PATInterfaces/SystematicSet.h"
#include "PATInterfaces/SystematicVariation.h"


HWW::METCalibrationSmearingAlg::METCalibrationSmearingAlg( const std::string& name, ISvcLocator* pSvcLocator )
  : AthAlgorithm( name, pSvcLocator ),
  m_inCont(""),
  m_mapname(""),
  m_outFinalName(""),
  m_metSysNames(),
  m_metSysTool("met::METSystematicsTool/met::METSystematicsTool"),
  m_separator(""),
  m_metSystVarNameVec(),
  m_isTrackMET(false)
{

  declareProperty("InputContainer", m_inCont,  "Input container name" );
  declareProperty("InputMETMap",    m_mapname, "The name of the input MET map" );

  declareProperty("OutputMETFinalName", m_outFinalName="Final",
                  "The name of the output final missingET object" );

  declareProperty("METSystematicVariations", m_metSysNames,
                  "The names of all systematic variations to be applied to the MET" );

  declareProperty("METSystematicsTool", m_metSysTool,
                  "The ToolHandle for the MET systematics tool" );

  declareProperty("Separator", m_separator="___",
                  "The string seperator between the output container name and the sytematic variation (default='___')" );

}


HWW::METCalibrationSmearingAlg::~METCalibrationSmearingAlg() {}


StatusCode HWW::METCalibrationSmearingAlg::initialize() {
  ATH_MSG_DEBUG("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inCont );
  ATH_MSG_DEBUG( "Using: " << m_mapname );
  ATH_MSG_DEBUG( "Using: " << m_outFinalName );
  ATH_MSG_DEBUG( "Using: " << m_metSysNames );
  ATH_MSG_DEBUG( "Using: " << m_metSysTool );
  ATH_MSG_DEBUG( "Using: " << m_separator );

  // Perform some sanity checks on the given container names
  if ( m_inCont.value().empty() ) {
    ATH_MSG_ERROR("Wrong user setup! You need to give a valid name for the InputContainer!");
    return StatusCode::FAILURE;
  }

  // Abort on an unchecked systematics code
  // CP::SystematicCode::enableFailure();

  // Retrieve the tools
  ATH_CHECK(m_metSysTool.retrieve());

  // Figure out what systematics are available and recommended for the MET
  if ( msgLvl(MSG::DEBUG) || msgLvl(MSG::VERBOSE) ) {
    CP::SystematicSet affSys = m_metSysTool->affectingSystematics();
    std::string affSysNames = affSys.name();
    std::replace( affSysNames.begin(), affSysNames.end(), '-', ',');
    ATH_MSG_DEBUG("Have " << affSys.size() << " affecting MET systematics with name "
                  << affSysNames << " for tool " << m_metSysTool->name() );
    CP::SystematicSet recSys = m_metSysTool->recommendedSystematics();
    std::string recSysNames = recSys.name();
    std::replace( recSysNames.begin(), recSysNames.end(), '-', ',');
    ATH_MSG_DEBUG("Have " << recSys.size() << " recommended MET systematics with name "
                  << recSysNames << " for tool " << m_metSysTool->name() );
  }


  // Set up the internal vector of systematics and container name post-fixes,
  // starting with the nominal one. First, clear it. Then, add the nominal, then systematics
  m_metSystVarNameVec.clear();

  for ( const auto& sysName  :  m_metSysNames.value() ) {
    CP::SystematicVariation sysVar = CP::SystematicVariation(sysName);
    if ( m_metSysTool->isAffectedBySystematic(sysVar) ) {
      HWW::METCalibrationSmearingAlg::MetSystematicType metSysType = HWW::METCalibrationSmearingAlg::MetSystematicType::UNKNOWN;
      if ( sysName.find("MET_SoftCalo") != std::string::npos ){ metSysType = HWW::METCalibrationSmearingAlg::MetSystematicType::CST; }
      if ( sysName.find("MET_SoftTrk")  != std::string::npos ){ metSysType = HWW::METCalibrationSmearingAlg::MetSystematicType::TST; }
      if ( sysName.find("MET_JetTrk")   != std::string::npos ){ metSysType = HWW::METCalibrationSmearingAlg::MetSystematicType::JetTrk; }
      CP::SystematicSet sysSet{sysVar};
      m_metSystVarNameVec.push_back( std::make_pair( metSysType, std::make_pair( sysSet, m_inCont.value()+m_separator.value()+sysName ) ) );
      ATH_MSG_DEBUG("Adding systematic variation with name " << sysName );
    }
    else {
      CP::SystematicSet affSys = m_metSysTool->affectingSystematics();
      std::string affSysNames = affSys.name();
      std::replace( affSysNames.begin(), affSysNames.end(), '-', ',');
      ATH_MSG_WARNING("Couldn't find MET systematic variation with name " << sysName
                      << " amongst the affected systematics: " << affSysNames );
      return StatusCode::FAILURE;
    }
  } // End: adding all systematic variations to be processed

  // Try to infer if we have TrackMET based on the name of the input container
  if ( m_inCont.value().find("TrackMET") != std::string::npos ){ m_isTrackMET = true; }

  return StatusCode::SUCCESS;
}



StatusCode HWW::METCalibrationSmearingAlg::finalize() {
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release the tools
  ATH_CHECK(m_metSysTool.release());

  return StatusCode::SUCCESS;
}



StatusCode HWW::METCalibrationSmearingAlg::execute() {
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Open the input container
  const xAOD::MissingETContainer * inCont;
  ATH_CHECK( evtStore()->retrieve( inCont, m_inCont.value() ) );
  ATH_MSG_DEBUG("Got MissingETContainer with name: " << m_inCont.value() );

  // Also load the missingET map
  const xAOD::MissingETAssociationMap* metMap = nullptr;
  ATH_CHECK( evtStore()->retrieve( metMap, m_mapname.value() ) );
  ATH_MSG_DEBUG("Got MissingETAssociationMap with name: " << m_mapname.value() );

  // Now, we will loop over the jet energy resolution systematics to be applied
  for ( const auto& systVarAndContName : m_metSystVarNameVec ) {
    // const bool isTrackMETSystematics = systVarAndContName.first;
    const HWW::METCalibrationSmearingAlg::MetSystematicType metSysType = systVarAndContName.first;
    // if ( isTrackMETSystematics && !m_isTrackMET ){ continue; }
    const CP::SystematicSet& systSet = systVarAndContName.second.first;
    const std::string& contName      = systVarAndContName.second.second;
    ATH_MSG_DEBUG("Working now on container " << contName << " with systematic variation: " << systSet.name() );

    xAOD::MissingETContainer * outCont = new xAOD::MissingETContainer();
    ATH_CHECK( evtStore()->record( outCont, contName ));
    xAOD::MissingETAuxContainer* outContAux = new xAOD::MissingETAuxContainer();
    ATH_CHECK( evtStore()->record( outContAux, contName + "Aux." ) );
    outCont->setStore( outContAux );

    // Set the tool state to a given systematic variation
    if ( m_metSysTool->applySystematicVariation( systSet ) != CP::SystematicCode::Ok ) {
      ATH_MSG_ERROR("Cannot configure HWWMETCalibrationSmearingAlg for systematic variation " << systSet.name() );
      return StatusCode::FAILURE;
    }

    // Define the right bitmasks for the soft terms
    const MissingETBase::Types::bitmask_t metTST = MissingETBase::Source::softEvent() |  MissingETBase::Source::track();
    const MissingETBase::Types::bitmask_t metCST = MissingETBase::Source::softEvent() |  MissingETBase::Source::clusterLC();


    // Create a new, empty missingET final object
    xAOD::MissingET* correctedMETFinal = new xAOD::MissingET(0.,0.,0.,m_outFinalName.value(),MissingETBase::Source::total());
    // Add the corrected copy to the output container right away so the container takes ownership
    outCont->push_back(correctedMETFinal);

    // Do the work in case we are dealing with the soft terms
    if ( metSysType != HWW::METCalibrationSmearingAlg::MetSystematicType::JetTrk ){
      ATH_MSG_DEBUG("Working on soft-term systematics");
      // Check which soft term systematics to use
      // MissingETBase::Types::bitmask_t metSoftTermMask;
      const xAOD::MissingET* metSoftEvent;
      if ( metSysType == HWW::METCalibrationSmearingAlg::MetSystematicType::CST ){
        metSoftEvent = (*inCont)["SoftClus"];
        ATH_MSG_VERBOSE("Working with CaloSoftTerm");
      }
      else if  ( metSysType == HWW::METCalibrationSmearingAlg::MetSystematicType::TST ){
        metSoftEvent = (*inCont)["PVSoftTrk"];
        ATH_MSG_VERBOSE("Working with TrackSoftTerm");
      }
      else{
        ATH_MSG_FATAL("Have no clue what type of missingET systematics I should use");
        return StatusCode::FAILURE;
      }
      // Get the missingET from the input
      if ( !metSoftEvent ) {
        ATH_MSG_FATAL("Got a null-pointer for the MET softEvent!");
        return StatusCode::FAILURE;
      }

      xAOD::MissingET * correctedSoftTermCopy = nullptr;
      if ( m_metSysTool->correctedCopy(*metSoftEvent, correctedSoftTermCopy) != CP::CorrectionCode::Ok
           || !correctedSoftTermCopy ) {
        ATH_MSG_ERROR("HWWMETCalibrationSmearingAlg reported a CP::CorrectionCode::Error");
        if (correctedSoftTermCopy) delete correctedSoftTermCopy;
        return StatusCode::FAILURE;
      }

      // Loop over all missingET terms in the input container
      // and add up all their contributions to the new final missingET,
      // except for the old METFinal and the old soft term
      ATH_MSG_DEBUG("Have MissingETContainer with " << inCont->size() << " elements");
      for ( const auto* met : *inCont ) {
        ATH_MSG_VERBOSE("Looking at missingET with source=" << met->source() << " and name=" << met->name());
        if ( met->source() == MissingETBase::Source::total() ) continue;
        if ( met->source() == metTST ) continue;
        if ( met->source() == metCST ) continue;
        ATH_MSG_VERBOSE("Adding missingET with source=" << met->source() << " and name=" << met->name());
        *correctedMETFinal += *met;
      }
      // also add the new soft term
      ATH_MSG_VERBOSE("Adding soft-term missingET with source=" << correctedSoftTermCopy->source() << " and name=" << correctedSoftTermCopy->name());
      *correctedMETFinal += *correctedSoftTermCopy;

      // Clean up
      delete correctedSoftTermCopy;

    } // End: treating of the soft term
    else {
      ATH_MSG_DEBUG("Working on RefJetTrk systematics");
      // Get the missingET from the input
      const xAOD::MissingET* metRefJetTrk = (*inCont)["RefJetTrk"];
      if ( !metRefJetTrk ) {
        // ATH_MSG_FATAL("Got a null-pointer for the MET RefJetTrk!");
        // return StatusCode::FAILURE;

        // HACK: For now, just write the unchanged MET out again.
        ATH_MSG_VERBOSE("Got no RefJetTrk in the input, just copying over the existing total MET");
        const xAOD::MissingET* metFinal = (*inCont)[MissingETBase::Source::total()];
        *correctedMETFinal += *metFinal;
        continue;
      }

      // Reset the metMap
      metMap->resetObjSelectionFlags();

      // Get the corrected RefJetTrk
      xAOD::MissingET * correctedmetRefJetTrkCopy = nullptr;
      ATH_MSG_VERBOSE("Going to ask for a corrected copy for RefJetTrk with systematic " << systSet.name() );
      if ( m_metSysTool->correctedCopy(*metRefJetTrk, correctedmetRefJetTrkCopy, metMap) != CP::CorrectionCode::Ok
           || !correctedmetRefJetTrkCopy ) {
        ATH_MSG_ERROR("HWWMETCalibrationSmearingAlg reported a CP::CorrectionCode::Error");
        if (correctedmetRefJetTrkCopy) delete correctedmetRefJetTrkCopy;
        return StatusCode::FAILURE;
      }
      ATH_MSG_VERBOSE("Got a corrected copy for RefJetTrk");

      // Loop over all missingET terms in the input container
      // and add up all their contributions to the new final missingET,
      // except for the old METFinal and the old RefJetTrk term
      ATH_MSG_DEBUG("Have MissingETContainer with " << inCont->size() << " elements");
      for ( const auto* met : *inCont ) {
        ATH_MSG_VERBOSE("Looking at missingET with source=" << met->source() << " and name=" << met->name());
        if ( met->source() == MissingETBase::Source::total() ) continue;
        if ( met->name() == "RefJetTrk" ) continue;
        if ( met->source() == metCST ) continue;
        ATH_MSG_VERBOSE("Adding missingET with source=" << met->source() << " and name=" << met->name());
        *correctedMETFinal += *met;
      }
      // also add the new soft term
      ATH_MSG_VERBOSE("Adding soft-term missingET with source=" << correctedmetRefJetTrkCopy->source() << " and name=" << correctedmetRefJetTrkCopy->name());
      *correctedMETFinal += *correctedmetRefJetTrkCopy;

      // Clean up
      delete correctedmetRefJetTrkCopy;

    } // End: treat the RefJetTrk term

  } // End: loop over MET systematic variations

  return StatusCode::SUCCESS;
}
