#ifndef HWWCOMMONXAODCODE_HWWTRUTHALG_H
#define HWWCOMMONXAODCODE_HWWTRUTHALG_H 1

// #include "AthenaBaseComps/AthAlgorithm.h"
#include "AthAnalysisBaseComps/AthAnalysisAlgorithm.h"

// EDM includes
#include "xAODTruth/TruthParticleFwd.h"
#include "xAODBase/IParticle.h"
#include "xAODMissingET/MissingETContainer.h"
#include "xAODMissingET/MissingETAuxContainer.h"

// ROOT includes
#include "TLorentzVector.h"
// #include <TLorentzVector>

// TODO: Reimplement use of rel21 equivalent of HiggsWeightTool
//#include "TruthWeightTools/TruthWeightTool.h"
//#include "TruthWeightTools/HiggsWeightTool.h"


// Put everything into a HWW namespace
namespace HWW {

  class TruthAlg: public ::AthAnalysisAlgorithm // ::AthAlgorithm
  {
  public:
    /// Default constructor
    TruthAlg( const std::string& name, ISvcLocator* pSvcLocator );

    /// Default destructor
    virtual ~TruthAlg();

    /// Default athena initialize hook
    virtual StatusCode  initialize();

    /// Funtion to be called when a new input file is opened
    virtual StatusCode  beginInputFile();

    /// Default athena execute hook
    virtual StatusCode  execute();

    /// Default athena finalize hook
    virtual StatusCode  finalize();


  private:

    /// @name Private helper functions

    /// Check if a truth partice decays to itself
    bool decayIntoItself(const xAOD::TruthParticle* part, int status=-1);

    /// See if the truth particle is the last of its kind
    const xAOD::TruthParticle* lastOfKind(const xAOD::TruthParticle* part);

    /// See if the truth particle is the first of its kind
    const xAOD::TruthParticle* firstOfKind(const xAOD::TruthParticle* part);

    /// Helper to recursively print info of a decay chain
    void printRecursively(const xAOD::TruthParticle* part, std::string preVal="");

    /// Check for particles from W bosons
    bool isFromW( const xAOD::TruthParticle* part, const std::vector<const xAOD::TruthParticle*>& Wlist);

    /// Sum the four-momenta of all daughter neutrinos of the given particle
    TLorentzVector sumDaughterNeutrinos(const xAOD::TruthParticle *part);

    /// Check if the given particle overlaps in DeltaR with any of the list
    bool checkOverlap(const xAOD::IParticle* part, std::vector<const xAOD::TruthParticle* > list);

    /// Check if the given particle overlaps in DeltaR with any of the list
    bool checkOverlap(const xAOD::IParticle* part, std::vector<TLorentzVector > list);

    ///Calculate TruthMT 
    double calculateMT(const xAOD::TruthParticle *lep1, const xAOD::TruthParticle *lep2, const xAOD::MissingET* met);
    /// @}


  private:

    /// @name The properties that can be defined via the python job options
    /// @{

    /// Name of the input truth container
    StringProperty m_truthInputCont;

    /// Name of the output truth container
    StringProperty m_truthOutputCont;

    /// Name of the truth jet input container
    StringProperty m_trutJetInputCont;

    /// Name of the truth WZ jet input container
    StringProperty m_truthWZJetInputCont;

    /// Name of the truth met input container
    StringProperty m_truthMetInputCont;

    /// Name of the truth electron input container
    StringProperty m_truthElectronInputCont;

    /// Name of the truth muon input container
    StringProperty m_truthMuonInputCont;

    /// Name of the event info container
    StringProperty m_EventInfoCont;

    /// Decide if we want to write a fully-split AuxContainer such that we can remove any variables
    BooleanProperty m_writeSplitAux;

    BooleanProperty m_isSherpa;

    BooleanProperty m_isNNLOPS;

    /// @}

    /// @name Private data members
    /// @{

    /// enum for encoding which generator we have at hand
    enum Generator{
      UNKNOWN=0,
      POWHEGPYTHIA8EVTGEN
    };

    /// Store the result of searching for the generator in the input file
    Generator m_generator;

    // TODO: Reimplement use of rel21 equivalent of HiggsWeightTool
    /// TruthWeight tool for NNLOPS only (for now)
    //xAOD::HiggsWeightTool *higgsMCtool;
    /// @}

  };

}

#endif //> !HWWCOMMONXAODCODE_HWWDILBUILDERALG_H
