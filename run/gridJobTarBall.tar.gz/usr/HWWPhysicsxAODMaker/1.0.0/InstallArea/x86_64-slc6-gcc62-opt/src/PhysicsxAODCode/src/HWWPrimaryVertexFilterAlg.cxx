//  includes
#include "HWWPrimaryVertexFilterAlg.h"

// Tool includes
#include "xAODTracking/VertexContainer.h"
#include "xAODTracking/Vertex.h"


HWW::PrimaryVertexFilterAlg::PrimaryVertexFilterAlg( const std::string& name, ISvcLocator* pSvcLocator ):
  AthFilterAlgorithm( name, pSvcLocator ),
  m_inContName("")
{
  declareProperty("PrimaryVertexContainer", m_inContName="PrimaryVertices", "The name of the input primary vertex container" );
}


HWW::PrimaryVertexFilterAlg::~PrimaryVertexFilterAlg() {}


StatusCode HWW::PrimaryVertexFilterAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inContName );

  return StatusCode::SUCCESS;
}



StatusCode HWW::PrimaryVertexFilterAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");
  return StatusCode::SUCCESS;
}



StatusCode HWW::PrimaryVertexFilterAlg::execute()
{
  // Default
  bool eventPasses = false;

  // Get the primary vertex container
  const xAOD::VertexContainer* primVtxCont;
  ATH_CHECK( evtStore()->retrieve( primVtxCont, m_inContName.value() ) );

  // Find "the" primary vertex inside this container
  for ( const auto* vtx : * primVtxCont ) {
    if ( vtx->vertexType() == xAOD::VxType::PriVtx ) {
      eventPasses = true;
      break;
    }
  }

  this->setFilterPassed( eventPasses );
  ATH_MSG_DEBUG("Event passes primary vertex selection: " << eventPasses );

  return StatusCode::SUCCESS;
}
