///////////////////////// -*- C++ -*- /////////////////////////////
// HWWEventSelectionAlg.cxx
// Implementation file for class HWW::EventSelectionAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWEventSelectionAlg.h"

// STL includes
#include <climits>
#include <cmath>

// boost includes

// FrameWork includes

// EDM includes
#include "xAODBase/IParticle.h"
#include "xAODParticleEvent/CompositeParticle.h"
#include "xAODParticleEvent/CompositeParticleContainer.h"
#include "xAODMuon/Muon.h"
#include "xAODJet/Jet.h"
#include "xAODBTagging/BTagging.h"


// Constructors
////////////////
HWW::EventSelectionAlg::EventSelectionAlg( const std::string& name,
                                           ISvcLocator* pSvcLocator ) :
  ::AthFilterAlgorithm( name, pSvcLocator ),
  m_inContList(),
  m_nMinOtherLeptons(0),
  m_nMinJets(0),
  m_nMinBJets(0),
  m_taggerName("MV2c10"),
  m_taggerCut(0.1758),
  m_hasIDFakeMuon(false),
  m_hasIDOtherMuon(false)
{
  //
  // Property declaration
  //
  declareProperty("InputContainerList",     m_inContList,       "Input container name list" );
  declareProperty("MinNOtherLeptons",       m_nMinOtherLeptons, "The minimum number of other leptons required" );
  declareProperty("MinNJets",               m_nMinJets,         "The minimum number of jets required" );
  declareProperty("MinNBJets",              m_nMinBJets,        "The minimum number of b-tagged jets required" );
  declareProperty("TaggerName",             m_taggerName,       "The name of the tagger that we want to use (default='MV2c20')" );
  declareProperty("BTagOperatingPoint" ,    m_taggerCut,        "The cut value on the b-tagging discriminant" );
  declareProperty("HasIdentifiedFakeMuon",  m_hasIDFakeMuon,    "Ask for an identified fake muon" );
  declareProperty("HasIdentifiedOtherMuon", m_hasIDOtherMuon,   "Ask for an identified other muon" );
}


// Destructor
///////////////
HWW::EventSelectionAlg::~EventSelectionAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::EventSelectionAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inContList );
  ATH_MSG_DEBUG( "Using: " << m_nMinOtherLeptons );
  ATH_MSG_DEBUG( "Using: " << m_nMinJets );
  ATH_MSG_DEBUG( "Using: " << m_nMinBJets );
  ATH_MSG_DEBUG( "Using: " << m_taggerName );
  ATH_MSG_DEBUG( "Using: " << m_taggerCut );
  ATH_MSG_DEBUG( "Using: " << m_hasIDFakeMuon );
  ATH_MSG_DEBUG( "Using: " << m_hasIDOtherMuon );

  // Perform some sanity checks on the given container names
  if ( m_inContList.value().empty() ) {
    ATH_MSG_ERROR("Wrong user setup! You need to give at least one name for the InputContainerList!");
    return StatusCode::FAILURE;
  }

  return StatusCode::SUCCESS;
}



StatusCode HWW::EventSelectionAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");
  return StatusCode::SUCCESS;
}



StatusCode HWW::EventSelectionAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Now, let's try to get all requested CompositeParticleContainers and iterate over them.
  // If not specifically requested to get all copies, only the exactly given
  // name will be retrieved. Otherwise, all containers with the same base-name,
  // i.e, the part before the "___", if present, will be used.
  // Do this expensice string manupulation and StoreGate search only the first time.
  if (m_containerNameList.empty()){
    for ( const std::string& inContName  :  m_inContList.value() ){
      // First, remove the suffix that is separated by "___", if present
      std::string searchString = inContName;
      std::string::size_type pos = inContName.find("___");
      if(inContName.npos != pos){ searchString = inContName.substr(0, pos); }
      // Now, get all the StoreGate names of existing CompositeParticleContainer
      std::vector<std::string> sgKeys;
      evtStore()->keys<xAOD::CompositeParticleContainer>(sgKeys);
      ATH_MSG_DEBUG("Found " << sgKeys.size() << " xAOD::CompositeParticleContainer in the event store.");
      m_containerNameList.reserve(sgKeys.size());
      // Now, let's find all container names that start with our searchString
      for ( const std::string& item : sgKeys ){
        if ( item.compare(0, searchString.length(), searchString) == 0 ){
          // We found a match, i.e, the current StoreGate key begins with our searchString
          ATH_MSG_DEBUG("Found matching xAOD::CompositeParticleContainer name: " << item);
          m_containerNameList.push_back(item);
        }
      }
    }
  }

  // default event pass/fail value
  bool passEvent = false;

  // Now, iterate over all input container names that were found and use these electron containers.
  for ( const std::string& inName : m_containerNameList ){
    // Open the input containers
    const xAOD::CompositeParticleContainer *inCont = nullptr;
    ATH_CHECK( evtStore()->retrieve( inCont, inName ) );

    // Loop over all CompositeParticles in the input container
    for ( const xAOD::CompositeParticle* compPart : *inCont ){
      // Get the number of additional leptons
      bool passNOtherLepton = false;
      std::size_t nOtherLeptons = 0;
      // Only actually calculate the number of other leptons, if we are looking for at least one
      if (m_nMinOtherLeptons.value()){ nOtherLeptons = compPart->nOtherMuons() + compPart->nOtherElectrons(); }
      if ( static_cast<int>(nOtherLeptons) >= m_nMinOtherLeptons.value() ){
        passNOtherLepton = true;
        ATH_MSG_VERBOSE("Have " << nOtherLeptons << " other leptons");
      }

      // Check for the minimum number of jets
      bool passNJets = false;
      std::size_t nJets = 0;
      // Only actually calculate the number of jets, if we are looking for at least one
      if (m_nMinJets.value()){ nJets = compPart->nJets(); }// + compPart->nOtherJets(); }
      if ( static_cast<int>(nJets) >= m_nMinJets.value() ){
        passNJets = true;
        ATH_MSG_VERBOSE("Have " << nJets << " jets");
      }

      // Check for the minimum number of jets
      bool passNBJets = false;
      // Look for a good b-jet amongst the standard jets, if we looking for at least one
      if ( m_nMinBJets.value() <= 0 ){ passNBJets = true; }
      else{
        int nBTags = 0;
        const std::size_t nParts = compPart->nParts();
        for ( std::size_t i=0; i<nParts; ++i ){
          const xAOD::Jet* jet = compPart->jet(i);
          if (!jet) continue; // this was not a jet
          bool passBTagging = false;
          ATH_CHECK( this->isBTagged(jet, passBTagging) );
          if (passBTagging){
            nBTags += 1;
            ATH_MSG_VERBOSE("Have a b-jet amongst the standard jets");
          }
        } // End: Loop over the jets
        if ( nBTags >= m_nMinBJets.value() ){
          passNBJets = true;
          ATH_MSG_VERBOSE("Have " << nBTags << " b-jet amongst the standard jets");
        }
        else{
          // Look for a good b-jet amongst the other jets, if we don't yet have enough b-jets
          const std::size_t nOtherParts = compPart->nOtherParts();
          for ( std::size_t i=0; i<nOtherParts; ++i ){
            const xAOD::Jet* jet = compPart->jet(i);
            if (!jet) continue; // this was not a jet
            bool passBTagging = false;
            ATH_CHECK( this->isBTagged(jet, passBTagging) );
            if (passBTagging){
              nBTags += 1;
              ATH_MSG_VERBOSE("Have a b-jet amongst the other jets");
            }
          } // End: Loop over the jets
          if ( nBTags >= m_nMinBJets.value() ){
            passNBJets = true;
            ATH_MSG_VERBOSE("Have " << nBTags << " b-jet amongst the other jets");
          }
        }
      } // Done with the b-jets

      // Check if we have an identified fake muon
      bool passIDFakeMuon = false;
      if ( !(m_hasIDFakeMuon.value()) ){ passIDFakeMuon = true; }
      else if (compPart->nMuons() == 0) { }
      else {
        // Iterate over all particles of the current CompositeParticle
        for ( std::size_t partIdx=0; partIdx<compPart->nParts(); ++partIdx ){
          const xAOD::Muon* muon = compPart->muon(partIdx);
          if ( !muon ) continue;
          passIDFakeMuon = this->muonIsID(muon);
        }
      }

      // Check if we have an identified other muon
      bool passIDOtherMuon = false;
      if ( !(m_hasIDOtherMuon.value()) ){ passIDOtherMuon = true; }
      else if (compPart->nOtherMuons() == 0) { }
      else {
        // Iterate over all other particles of the current CompositeParticle
        for ( std::size_t partIdx=0; partIdx<compPart->nOtherParts(); ++partIdx ){
          const xAOD::Muon* muon = compPart->otherMuon(partIdx);
          if ( !muon ) continue;
          passIDOtherMuon = this->muonIsID(muon);
        }
      }

      // Make the pass/fail decission for this event object
      if ( passNOtherLepton && passNJets && passNBJets && passIDFakeMuon && passIDOtherMuon ){
        passEvent = true;
        ATH_MSG_VERBOSE("Found all requirements fullfilled");
        break;
      }
    } // End: loop over CompositeParticles

    // If we have at least one event object that passes, we accept the event
    if (passEvent) break;

  } // End: Loop over all input containers

  // Set the event pass/fail decission
  this->setFilterPassed( passEvent );
  ATH_MSG_DEBUG("Accepting this event (yes/no): " << passEvent);

  return StatusCode::SUCCESS;
}


/// Check if a jet is b-tagged
StatusCode HWW::EventSelectionAlg::isBTagged(const xAOD::Jet* jet, bool& passBTagging ) const
{
  const xAOD::BTagging* btag = jet->btagging();
  if (!btag) {
    ATH_MSG_ERROR("Couldn't find the xAOD::BTagging object for the current jet");
    return StatusCode::FAILURE;
  }
  double bTagWeight = 0.0;
  if ( !(btag->MVx_discriminant(m_taggerName.value(),bTagWeight)) ) {
    ATH_MSG_ERROR("Couldn't find the tagger with name " << m_taggerName.value());
    return StatusCode::FAILURE;
  }
  if ( bTagWeight > m_taggerCut.value() ){ passBTagging = true; }

  return StatusCode::SUCCESS;
}


/// Check if the muon is fully identified
bool HWW::EventSelectionAlg::muonIsID(const xAOD::Muon* muon) const
{
  if ( std::abs(muon->eta()) > 2.5 ) return false;
  double muonPt = muon->pt();
  if ( muonPt < 15000.0 ) return false;
  if ( muon->auxdata<int>("Quality") >= 1 ) return false;
  if ( std::abs(muon->auxdata<float>("d0sig")) > 3.0 ) return false;
  if ( std::abs(muon->auxdata<float>("z0") * muon->auxdata<float>("sinTheta")) > 0.5 ) return false;
  if ( (muon->auxdata<float>("ptvarcone30"))/muonPt > 0.06 ) return false;
  if ( (muon->auxdata<float>("topoetcone20"))/muonPt > 0.09 ) return false;
  return true;
}
