///////////////////////// -*- C++ -*- /////////////////////////////
// HWWDecorationAlg.cxx
// Implementation file for class HWWDecorationAlg
// Author: Karsten Koeneke <karsten.koeneke@cern.ch>
///////////////////////////////////////////////////////////////////

// Includes from this package
#include "HWWElectronDecorationAlg.h"

// STL includes
#include <climits>
#include <cmath>

// FrameWork includes

// EDM includes
#include "xAODEgamma/ElectronContainer.h"
#include "xAODTracking/TrackParticleContainer.h"
#include "xAODTracking/VertexContainer.h"
#include "xAODTracking/Vertex.h"
#include "xAODTracking/TrackParticlexAODHelpers.h"
#include "xAODEventInfo/EventInfo.h"
#include "xAODTruth/TruthParticle.h"
#include "xAODTruth/TruthParticleContainer.h"


// Tool includes
#include "PATCore/TAccept.h"
#include "PATCore/IAsgSelectionTool.h"
#include "PATCore/IAsgSelectionWithVertexTool.h"
#include "IsolationSelection/IIsolationSelectionTool.h"
#include "ElectronPhotonSelectorTools/IEGammaAmbiguityTool.h"
#include "ElectronPhotonSelectorTools/ElectronSelectorHelpers.h"
#include "ElectronPhotonSelectorTools/AsgElectronChargeIDSelectorTool.h"


// Constructors
////////////////
HWW::ElectronDecorationAlg::ElectronDecorationAlg( const std::string& name,
                                                   ISvcLocator* pSvcLocator ) :
  ::AthAlgorithm( name, pSvcLocator ),
  m_inContName(""),
  m_electronSelectionToolList(),
  m_electronDecList(),
  m_selectionWithVertexToolList(),
  m_selectionWithVertexDecoList(),
  m_isoToolList(),
  m_electronIsoWPList(),
  m_transferSources(),
  m_transferTargets(),
  m_doImpactParameter(false),
  m_inPrimVtxCont("PrimaryVertices"),
  m_doAmbiguity(false),
  m_egammaAmbiguityTool("EGammaAmbiguityTool/EGammaAmbiguityTool",this),
  m_egammaAmbiguityTool_Tight("EGammaAmbiguityTool/EGammaAmbiguityTool",this),
  m_doECIDS(false),
  m_electronECIDSTool("AsgElectronChargeIDSelectorTool/AsgElectronChargeIDSelectorTool",this),
  m_doTruth(false),
  m_decoAllCopies(false),
  m_containerNameList()
{
  //
  // Property declaration
  //
  declareProperty( "InputContainer",                  m_inContName, "Input container name" );
  declareProperty( "SelectionToolList",               m_electronSelectionToolList, "List of Electron ID selection tool instances" );
  declareProperty( "SelectionToolDecoList",           m_electronDecList, "List of electron decoration names" );
  declareProperty( "SelectionWithVertexToolList",     m_selectionWithVertexToolList, "List of selection-with-vertex tool instances" );
  declareProperty( "SelectionWithVertexToolDecoList", m_selectionWithVertexDecoList, "List of decoration names for each selection-with-vertex tools" );
  declareProperty( "IsolationToolList",               m_isoToolList, "List of CP tool to calculate the lepton isolation" );
  declareProperty( "IsolationToolDecoList",           m_electronIsoWPList, "List of electron isolation result names" );
  declareProperty( "TransferValueSources",            m_transferSources, "Transfer variables from the input (given here) to the output" );
  declareProperty( "TransferValueTargets",            m_transferTargets, "Transfer variables from the input to the output (given here)" );
  declareProperty( "DoImpactParameter",               m_doImpactParameter, "If true, will calculate and store the z0sinTheta, d0, and d0Err" );
  declareProperty( "PrimaryVertexContainer",          m_inPrimVtxCont, "The input primary vertex container name" );
  declareProperty( "DoAmbiguity",                     m_doAmbiguity, "If true, will calculate and store the result of the egamma ambiguity tool" );
  declareProperty( "EGammeAmbiguityTool",             m_egammaAmbiguityTool, "The egamma ambiguity tool" );
  declareProperty( "EGammeAmbiguityToolTight",        m_egammaAmbiguityTool_Tight, "The egamma ambiguity tool (tight)" );//mgeisen
  declareProperty( "DoChargeIDTagging",               m_doECIDS, "If true, will calculate and store the result of the electron Charge ID selector" );
  declareProperty( "ElectronChargeIDSelectorTool",    m_electronECIDSTool, "The electron charge ID selector tool" );
  declareProperty( "DoTruthInformation",              m_doTruth, "If true, will decorate charge and pt to ele" );
  declareProperty( "DecorateAllCopies",               m_decoAllCopies, "If true, will decorate all copies of the input container" );
}



// Destructor
///////////////
HWW::ElectronDecorationAlg::~ElectronDecorationAlg()
{}



// Athena Algorithm's Hooks
////////////////////////////
StatusCode HWW::ElectronDecorationAlg::initialize()
{
  ATH_MSG_DEBUG ("Initializing " << name() << "...");

  // Print the configuration to the log file
  ATH_MSG_DEBUG( "Using: " << m_inContName );
  ATH_MSG_DEBUG( "Using: " << m_electronSelectionToolList );
  ATH_MSG_DEBUG( "Using: " << m_electronDecList );
  ATH_MSG_DEBUG( "Using: " << m_selectionWithVertexToolList );
  ATH_MSG_DEBUG( "Using: " << m_selectionWithVertexDecoList );
  ATH_MSG_DEBUG( "Using: " << m_isoToolList );
  ATH_MSG_DEBUG( "Using: " << m_electronIsoWPList );
  ATH_MSG_DEBUG( "Using: " << m_transferSources );
  ATH_MSG_DEBUG( "Using: " << m_transferTargets );
  ATH_MSG_DEBUG( "Using: " << m_inPrimVtxCont );
  ATH_MSG_DEBUG( "Using DoImpactParameter: " << m_doImpactParameter );
  ATH_MSG_DEBUG( "Using DoAmbiguity: " << m_doAmbiguity );
  ATH_MSG_DEBUG( "Using: " << m_egammaAmbiguityTool );
  ATH_MSG_DEBUG( "Using: " << m_egammaAmbiguityTool_Tight );
  ATH_MSG_DEBUG( "Using DoChargeIDTagging: " << m_doECIDS );
  ATH_MSG_DEBUG( "Using: " << m_electronECIDSTool );
  ATH_MSG_DEBUG( "Using DoTruthInformation: " << m_doTruth );
  ATH_MSG_DEBUG( "Using DecorateAllCopies: " << m_decoAllCopies );

  // Some sanity checks to make sure that the lists are of the same size
  if ( m_electronSelectionToolList.size() != m_electronDecList.value().size() ){
    ATH_MSG_ERROR( "Electron selection tool list is not same size as the decorator name list size" );
    return StatusCode::FAILURE;
  }
  if ( m_selectionWithVertexToolList.size() != m_selectionWithVertexDecoList.value().size() ){
    ATH_MSG_ERROR( "Electron selection-with-vertex tool list is not same size as the SelectionWithVertexToolDecoList size" );
    return StatusCode::FAILURE;
  }
  if ( m_transferSources.value().size() != m_transferTargets.value().size() ){
    ATH_MSG_ERROR( "Transfer value source and target lists are not same size" );
    return StatusCode::FAILURE;
  }

  // Get the needed tools
  ATH_CHECK( m_electronSelectionToolList.retrieve() );
  ATH_CHECK( m_selectionWithVertexToolList.retrieve() );
  ATH_CHECK( m_isoToolList.retrieve() );
  ATH_CHECK( m_egammaAmbiguityTool.retrieve() );
  ATH_CHECK( m_egammaAmbiguityTool_Tight.retrieve() );
  if (m_doECIDS) ATH_CHECK( m_electronECIDSTool.retrieve() );

  return StatusCode::SUCCESS;
}



StatusCode HWW::ElectronDecorationAlg::finalize()
{
  ATH_MSG_DEBUG ("Finalizing " << name() << "...");

  // Release the needed tools
  ATH_CHECK( m_electronSelectionToolList.release() );
  ATH_CHECK( m_selectionWithVertexToolList.release() );
  ATH_CHECK( m_isoToolList.release() );
  ATH_CHECK( m_egammaAmbiguityTool.release() );
  ATH_CHECK( m_egammaAmbiguityTool_Tight.release() );
  if (m_doECIDS)ATH_CHECK( m_electronECIDSTool.release() );

  return StatusCode::SUCCESS;
}



StatusCode HWW::ElectronDecorationAlg::execute()
{
  ATH_MSG_DEBUG ("Executing " << name() << "...");

  // Open the input EventInfo object
  const xAOD::EventInfo* evtInfo;
  ATH_CHECK( evtStore()->retrieve( evtInfo, "EventInfo" ));
  const bool isSim = evtInfo->eventType(xAOD::EventInfo::EventType::IS_SIMULATION);

  // Define the decorators outside of the loop as a static, such that it
  // will be fully cached
  static xAOD::Electron::Decorator<float> z0Deco("z0");
  // static xAOD::Electron::Decorator<float> z0SigDeco("z0sig");
  static xAOD::Electron::Decorator<float> z0ErrDeco("z0err");
  static xAOD::Electron::Decorator<float> sinThetaDeco("sinTheta");
  static xAOD::Electron::Decorator<float> d0Deco("d0");
  static xAOD::Electron::Decorator<float> d0SigDeco("d0sig");
  static SG::AuxElement::Accessor< std::vector<float> > accDefParamCovMatrix( "definingParametersCovMatrix" );
  static xAOD::Electron::Decorator<int> AmbiguityLooseDeco("AmbiguityLoose");
  static xAOD::Electron::Decorator<int> AmbiguityTightDeco("AmbiguityTight");
  static xAOD::Electron::Decorator<char> PassBLayerDeco("passBLayerRequirement");

  static xAOD::Electron::Decorator<float> ECIDSDeco("chargeIDTag");

  static SG::AuxElement::Decorator<float>decTruthPt        ("truthPt");
  static SG::AuxElement::Decorator<float>decTruthEta       ("truthEta");
  static SG::AuxElement::Decorator<float>decTruthPhi       ("truthPhi");
  static SG::AuxElement::Decorator<float>decTruthCharge    ("truthCharge");

  static SG::AuxElement::Decorator<int>  decFlavourTag ("flavourTag");

  std::vector< xAOD::Electron::Decorator<char> > isoDecList;
  isoDecList.reserve( m_electronIsoWPList.value().size() );
  for ( std::size_t idxIso=0; idxIso<m_electronIsoWPList.value().size(); ++idxIso ){
    isoDecList.push_back( xAOD::Electron::Decorator<char>( m_electronIsoWPList.value().at(idxIso) ) );
  }

  // Get the primary vertex, if needed
  const xAOD::Vertex* primVtx(0);
  if (m_doImpactParameter) {
    // Get the primary vertex container
    const xAOD::VertexContainer* primVtxCont;
    ATH_CHECK( evtStore()->retrieve( primVtxCont, m_inPrimVtxCont.value() ) );
    // Find "the" primary vertex inside this container
    for ( const auto* vtx : * primVtxCont ) {
      if ( vtx->vertexType() == xAOD::VxType::PriVtx ) {
        primVtx = vtx;
        break;
      }
    }
    if ( !primVtx ) {
      ATH_MSG_WARNING("Couldn't find a primary vertex in this event!");
    }
  }


  // Karsten: Test if the input TruthMuons container actually exists.
  const xAOD::TruthParticleContainer* teles = nullptr;
  if (m_doTruth && isSim){
    if ( evtStore()->contains<xAOD::TruthParticleContainer>("TruthElectrons") ){
      ATH_CHECK( evtStore()->retrieve( teles, "TruthElectrons" ) );
    }
    else {
      ATH_MSG_WARNING("Couldn't find the xAOD::TruthParticleContainer 'TruthElectrons'. Won't decorate truth four-momentum or charge.");
    }
  }



  // Now, let's try to get all requested electron containers and iterate over them.
  // If not specifically requested to get all copies, only the exactly given
  // name will be retrieved. Otherwise, all containers with the same base-name,
  // i.e, the part before the "___", if present, will be used.
  // Do this expensice string manupulation and StoreGate search only the first time.
  if (m_containerNameList.empty()){
    if (m_decoAllCopies){
      const std::string& inContName = m_inContName.value();
      // First, remove the suffix that is separated by "___", if present
      std::string searchString = inContName;
      std::string::size_type pos = inContName.find("___");
      if(inContName.npos != pos){ searchString = inContName.substr(0, pos); }
      // Now, get all the StoreGate names of existing MuonContainers
      std::vector<std::string> sgKeys;
      evtStore()->keys<xAOD::ElectronContainer>(sgKeys);
      ATH_MSG_DEBUG("Found " << sgKeys.size() << " xAOD::ElectronContainers in the event store.");
      m_containerNameList.reserve(sgKeys.size());
      // Now, let's find all container names that start with our searchString
      for ( const std::string& item : sgKeys ){
        if ( item.compare(0, searchString.length(), searchString) == 0 ){
          // We found a match, i.e, the current StoreGate key begins with our searchString
          ATH_MSG_DEBUG("Found matching xAOD::ElectronContainer name: " << item);
          m_containerNameList.push_back(item);
        }
      }
    }
    else{
      m_containerNameList.push_back(m_inContName.value());
    }
  }

  // Now, iterate over all input container names that were found and use these electron containers.
  for ( const std::string& inName : m_containerNameList ){
    // Open the input containers
    const xAOD::ElectronContainer *inCont(0);
    ATH_CHECK( evtStore()->retrieve( inCont, inName ) );

    // Decorate the electrons, if requested
    for ( std::size_t toolIdx=0; toolIdx < m_electronSelectionToolList.size(); ++toolIdx ) {
      // Define the decorators outside of the loop as a static, such that it
      // will be fully cached
      SG::AuxElement::Decorator<char> decSetElLH (m_electronDecList.value()[toolIdx]);
      for ( const xAOD::Electron* electron : *inCont){
        bool electronLH = false;
        if ( m_electronSelectionToolList[toolIdx]->accept( electron ) ){ electronLH = true; }
        decSetElLH(*electron) = electronLH ? 1 : 0;
      }
    }

    // Decorate the electrons, if requested
    for ( std::size_t toolIdx=0; toolIdx < m_selectionWithVertexToolList.size(); ++toolIdx ) {
      // Define the decorators outside of the loop, such that it will be fully cached
      SG::AuxElement::Decorator<char> decoSelWVtx (m_selectionWithVertexDecoList.value()[toolIdx]);
      for ( const xAOD::Electron* electron : *inCont){
        const bool passed = m_selectionWithVertexToolList[toolIdx]->accept(electron,primVtx);
        decoSelWVtx(*electron) = static_cast<char>(passed);
      }
    }

    // transfer the LH values from input to output, if requested
    for ( std::size_t i=0; i<m_transferSources.value().size(); ++i ){
      // Get the variable name that we want to get from the input/output
      const std::string& inVarName  = m_transferSources.value().at(i);
      const std::string& outVarName = m_transferTargets.value().at(i);

      // Test if both the input is actually available and that we can write the output
      bool inOK = false;
      bool inOLDOK = false;
      try{ inOK = inCont->isAvailable<char>(inVarName); }
      catch ( const std::exception& e){ inOK = false; }
      try{ inOLDOK = inCont->isAvailable<int>(inVarName); }
      catch ( const std::exception& e){ inOLDOK = false; }
      const bool outOK = !(inCont->isAvailable<char>(outVarName));
      ATH_MSG_DEBUG("Variable " << inVarName << " is available<char>=" << inOK << " is available<int>=" << inOLDOK
                    << ", and variable " << outVarName << " is available for writing: " << outOK );
      if ( (inOK || inOLDOK) && outOK ) {
        ATH_MSG_DEBUG("Going to transfer " << inVarName
                      << " from input to output with name " << outVarName );
        // Create the accessors for the current transver of vars
        SG::AuxElement::Decorator<char> setVarDeco(outVarName);

        if (inOK){
          SG::AuxElement::Accessor<char> getVarAcc(inVarName);
          for ( const xAOD::Electron* electron : *inCont){
            const char varVal = getVarAcc(*electron);
            setVarDeco(*electron) = varVal;
          }
        }
        else {
          SG::AuxElement::Accessor<int> getOLDVarAcc(inVarName);
          for ( const xAOD::Electron* electron : *inCont){
            const char varVal = static_cast<char>(getOLDVarAcc(*electron));
            setVarDeco(*electron) = varVal;
          }
        }
      }
    } // End: Loop over transfer values


    for ( const xAOD::Electron* electron : *inCont){
      // Get the TrackParticle
      const xAOD::TrackParticle* trackPart(0);
      trackPart = electron->trackParticle();
      if ( !trackPart ) {
        ATH_MSG_ERROR("Couldn't get the TrackParticle for this Electron");
        return StatusCode::FAILURE;
      }

      // Check if the electron TrackParticle passes the b-layer requirements
      const bool passBLay = ElectronSelectorHelpers::passBLayerRequirement(trackPart);
      PassBLayerDeco(*electron) = passBLay;

      // Do the impact parameter calculations
      if ( m_doImpactParameter && primVtx ) {

        ATH_MSG_VERBOSE("Going to do z0 determination");
        // The TrackParticle is expressed w.r.t. the beam spot. Thus, we need to
        // do some gymnastics in order to get it w.r.t. the primary vertex.
        // const float z0sig = static_cast<float>(xAOD::TrackingHelpers::z0significance(trackPart, primVtx));
        // z0SigDeco(*electron)    = z0sig;
        const float z0 = trackPart->z0() + trackPart->vz() - primVtx->z();
        const float sinTheta = std::sin(trackPart->theta());
        z0Deco(*electron)       = z0;
        sinThetaDeco(*electron) = sinTheta;

        ATH_MSG_VERBOSE("Going to do d0 selection");
        const float d0 = trackPart->d0();
        float d0sig    = 0.0;
        float z0err    = 0.0;
        if( !accDefParamCovMatrix.isAvailable( *trackPart ) ) {
          ATH_MSG_DEBUG("No definingParametersCovMatrix for current muon TrackParticle");
        }
        else {
          d0sig = static_cast<float>(xAOD::TrackingHelpers::d0significance( trackPart, evtInfo->beamPosSigmaX(), evtInfo->beamPosSigmaY(), evtInfo->beamPosSigmaXY() ));
          z0err = std::sqrt(trackPart->definingParametersCovMatrixVec().at(2));
        }
        d0Deco(*electron)    = d0;
        d0SigDeco(*electron) = d0sig;
        z0ErrDeco(*electron) = z0err;

      } // End: Do the impact parameter calculations

      // Calculate the pass/fails for the isolation
      for ( std::size_t idxIso=0; idxIso<m_isoToolList.size(); ++idxIso ){
        const bool passed = (m_isoToolList[idxIso])->accept(*electron);
        (isoDecList.at(idxIso))(*electron) = static_cast<char>(passed);
      } // End: do the iso WP calculation

      // Calculate the result for the egamma ambiguity tool
      if (m_doAmbiguity){
        const bool AmbiguityLoose=m_egammaAmbiguityTool->accept(*electron);
        const bool AmbiguityTight=m_egammaAmbiguityTool_Tight->accept(*electron);
        // AmbiguityTight returns AuthorElectron (true or false) defined by EGammaAmbiguityTool
        // AmbiguityLoose returns AuthorElectron||AuthorAmbiguous (true or false) defined by EGammaAmbiguityTool
        AmbiguityLooseDeco(*electron) = AmbiguityLoose;
        AmbiguityTightDeco(*electron) = AmbiguityTight;
      }

      // Do the charge-identification tagging, if requested
      if (m_doECIDS){ ECIDSDeco(*electron) = m_electronECIDSTool->calculate(electron); }

      // Get the MCTruthClassifer results and attach them to the muon directly
      if (m_doTruth && isSim){
        ATH_MSG_VERBOSE("Doing ele truth");

        // Default values
        int charge = 0;
        float pt   = 0;
        float eta  = 0;
        float phi  = 0;

        // philip: want also the truth pt
        if ( electron->isAvailable<ElementLink<xAOD::TruthParticleContainer> >("firstEgMotherTruthParticleLink") ) {
          ATH_MSG_VERBOSE("Got a electron truthParticleLink");
          const ElementLink<xAOD::TruthParticleContainer>& link = electron->auxdata<ElementLink<xAOD::TruthParticleContainer> >("firstEgMotherTruthParticleLink");
          if ( link.isValid() ){
            ATH_MSG_VERBOSE("Did get a valid muon truthParticleLink");
            const xAOD::TruthParticle* truth = *link;

            // philip:
            // ok, here's the new way: I'm trying to get the dressed pt
            // if I just loop the truth particles, look for a particle with matching barcode and retrieve the pt_dressed it should be fine, no?
            if ( teles ){
              for(const xAOD::TruthParticle* tele : *teles){
                if ( truth && truth->barcode() == tele->barcode() && (truth->absPdgId()==11) ) {
                  pt     = tele->auxdata<float>("pt_dressed")    ;
                  eta    = tele->auxdata<float>("eta_dressed")   ;
                  phi    = tele->auxdata<float>("phi_dressed")   ;
                  charge = tele->charge();
                }
              }
            }
          }
        }

        // Decorate the muon with the final result
        if ( teles ){
          decTruthPt       (*electron) = pt    ;
          decTruthEta      (*electron) = eta   ;
          decTruthPhi      (*electron) = phi   ;
          decTruthCharge   (*electron) = charge;
        }
      } // End: doTruth


      //------------------------------------------------//
      //  Truth flavour decorator as in Run-I (Javier)  //
      //------------------------------------------------//

      if (isSim){

        int flavTag = -1;

        //Store b, c, s and light truth objects (quarks and hadrons)
        const xAOD::TruthParticleContainer* truthParticles = 0;
        ATH_CHECK(evtStore()->retrieve( truthParticles, "TruthParticles" ));
        xAOD::TruthParticleContainer::const_iterator truthItr = truthParticles->begin();
        xAOD::TruthParticleContainer::const_iterator truthItrE = truthParticles->end();

        std::vector<const xAOD::TruthParticle*> bTruth; bTruth.clear();
        std::vector<const xAOD::TruthParticle*> cTruth; cTruth.clear();
        std::vector<const xAOD::TruthParticle*> sTruth; sTruth.clear();
        std::vector<const xAOD::TruthParticle*> lTruth; lTruth.clear();
        std::vector<const xAOD::TruthParticle*> eTruth; eTruth.clear();

        for (truthItr = truthParticles->begin(); truthItr != truthItrE; ++truthItr){
          const xAOD::TruthParticle * part = (*truthItr); long int pdg = part->pdgId();
          if (part->pt() <= 5000) continue;

          //Classify the truth particle
          bool hasBottom = 0; bool hasCharm = 0; bool hasStrange = 0; bool hasLight = 0;
          int q1 = (abs(pdg)/1000)%10; int q2 = (abs(pdg)/100)%10; int q3 = (abs(pdg)/10)%10;

          if (q1 == 0 && q2 == 5 && q3 == 5) hasBottom = 1; //BBbar meson
          else if (q1 == 0 && q3 < 5 && q3 > 0 && q2 == 5 ) hasBottom = 1; //Bottom meson
          else if (q1 == 5) hasBottom = 1; //Bottom baryon
          else if (abs(pdg) == 5) hasBottom = 1; //Bottom quark

          else if (q1 == 0 && q3 == 4 && q2 == 4) hasCharm = 1; //CCbar meson
          else if (q1 == 0 && q3 < 4 && q3 > 0 && q2 == 4) hasCharm = 1; //Charmed meson
          else if (q1 == 4) hasCharm = 1; //Charmed baryon
          else if (abs(pdg) == 4) hasCharm = 1; //Charm quark

          else if (q1 == 3) hasStrange = 1; //Strange baryon
          else if ((q1 == 0 && q2 == 3 && q3 < 3 && q3 > 0)|| abs(pdg) == 130) hasStrange = 1; //Strange meson
          else if (abs(pdg) == 3) hasStrange = 1; //Strange quark

          else if (q1 == 2 || q1 == 1) hasLight = 1; //Light baryon
          else if ((q1==0 && (q3 == 1 || q3 == 2) && (q2 == 1|| q2 == 2)) || (q1 == 0&& q3 == 3 && q2 == 3)) hasLight = 1; //Light meson
          else if (abs(pdg) == 2 || abs(pdg) == 1) hasLight = 1; //u,d quarks

          if (hasBottom) bTruth.push_back(part);
          if (hasCharm) cTruth.push_back(part);
          if (hasStrange) sTruth.push_back(part);
          if (hasLight) lTruth.push_back(part);
          if (fabs(pdg) == 11) eTruth.push_back(part);
        }

        //Now classify the electron
        TLorentzVector elVect; elVect.SetPtEtaPhiE(electron->pt(), electron->eta(), electron->phi(), electron->e());

        bool electronBottom = 0; bool electronCharm = 0; bool electronStrange = 0;
        bool electronLight = 0;

        bool bottomLeptonic = 0; bool bottomHadronic = 0;
        bool charmLeptonic = 0; bool charmHadronic = 0;
        bool strangeLeptonic = 0; bool strangeHadronic = 0;
        bool lightLeptonic = 0; bool lightHadronic = 0;
        bool gluonLeptonic = 0; bool gluonHadronic = 0;

        //See if it is matched to a truth electron
        bool isLeptonic = 0;
        for (size_t m = 0; m < eTruth.size(); ++m){
          TLorentzVector truthVect; truthVect.SetPtEtaPhiE(eTruth[m]->pt(), eTruth[m]->eta(), eTruth[m]->phi(), eTruth[m]->e());
          double dR = elVect.DeltaR(truthVect);
          if (dR < 0.03) isLeptonic = 1;
        }

        //Try to find a bottom-match
        for (size_t b = 0; b < bTruth.size(); ++b){
          TLorentzVector bVect; bVect.SetPtEtaPhiE(bTruth[b]->pt(), bTruth[b]->eta(), bTruth[b]->phi(), bTruth[b]->e());
          double dR = elVect.DeltaR(bVect);
          if (dR < 0.4) electronBottom = 1;
        }

        if (electronBottom){
          if (isLeptonic) bottomLeptonic = 1;
          else bottomHadronic = 1;
        }

        if (!electronBottom){

          //Try to find a charm-match
          for (size_t c = 0; c < cTruth.size(); ++c){
            TLorentzVector cVect; cVect.SetPtEtaPhiE(cTruth[c]->pt(), cTruth[c]->eta(), cTruth[c]->phi(), cTruth[c]->e());
            double dR = elVect.DeltaR(cVect);
            if (dR < 0.4) electronCharm = 1;
          }

          if (electronCharm){
            if (isLeptonic) charmLeptonic = 1;
            else charmHadronic = 1;
          }

          if (!electronCharm){

            //Try to find a strange-match
            for (size_t s = 0; s < sTruth.size(); ++s){
              TLorentzVector sVect; sVect.SetPtEtaPhiE(sTruth[s]->pt(), sTruth[s]->eta(), sTruth[s]->phi(), sTruth[s]->e());
              double dR = elVect.DeltaR(sVect);
              if (dR < 0.4) electronStrange = 1;
            }

            if (electronStrange){
              if (isLeptonic) strangeLeptonic = 1;
              else strangeHadronic = 1;
            }

            if (!electronStrange){

              //Try to find a light-match
              for (size_t l = 0; l < lTruth.size(); ++l){
                TLorentzVector lVect; lVect.SetPtEtaPhiE(lTruth[l]->pt(), lTruth[l]->eta(), lTruth[l]->phi(), lTruth[l]->e());
                double dR = elVect.DeltaR(lVect);
                if (dR < 0.4) electronLight = 1;
              }

              if (electronLight){
                if (isLeptonic) lightLeptonic = 1;
                else lightHadronic = 1;
              }

              if (!electronLight){
                if (isLeptonic) gluonLeptonic = 1;
                else gluonHadronic = 1;

              }
            }
          }
        }

        if (bottomLeptonic) flavTag = 1;
        if (bottomHadronic) flavTag = 2;

        if (charmLeptonic) flavTag = 3;
        if (charmHadronic) flavTag = 4;

        if (strangeLeptonic) flavTag = 5;
        if (strangeHadronic) flavTag = 6;

        if (lightLeptonic) flavTag = 7;
        if (lightHadronic) flavTag = 8;

        if (gluonLeptonic) flavTag = 9;
        if (gluonHadronic) flavTag = 10;

        //Decorate the electron with the flavour tag
        decFlavourTag(*electron) = flavTag;

      } //End: isSim

    } // End: loop over electrons

  } // End: Loop over all input ElectronContainer names

  return StatusCode::SUCCESS;
}
